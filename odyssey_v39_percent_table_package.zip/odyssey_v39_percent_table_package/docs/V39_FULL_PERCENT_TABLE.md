# Odyssey V39 Full Benchmark % Table vs Transformer

| Context | Transformer Speed % | V39 Speed % | V39 Speed Gain | Transformer Cache % | V39 Cache % | Cache Reduction |
|---:|---:|---:|---:|---:|---:|---:|
| 64 | 100.0% | 108.7% | +8.7% | 100.0% | 1.758% | 98.24% |
| 128 | 100.0% | 113.9% | +13.9% | 100.0% | 0.879% | 99.12% |
| 256 | 100.0% | 112.8% | +12.8% | 100.0% | 0.439% | 99.56% |
| 512 | 100.0% | 113.5% | +13.5% | 100.0% | 0.220% | 99.78% |
| 1024 | 100.0% | 128.1% | +28.1% | 100.0% | 0.110% | 99.89% |
| 1536 | 100.0% | 130.9% | +30.9% | 100.0% | 0.073% | 99.93% |
| 2048 | 100.0% | 127.5% | +27.5% | 100.0% | 0.055% | 99.95% |

## Training / Quality Gate

- Final train loss: ~4.8% better than tiny matched Transformer
- Train slope: ~85.6% of Transformer
- Validation slope: ~70% of Transformer
- Params: ~3% smaller

## Core interpretation

- Short context: modest V39 lead
- Mid context: clear V39 lead
- Long context: strong V39 lead
- Memory: overwhelming structural advantage
- CUDA remains required for final production proof
