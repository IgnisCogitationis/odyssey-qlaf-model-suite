#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python smoke_test_v15.py --device cuda --dtype bf16 --size small
python benchmark_v15_gpu.py \
  --device cuda \
  --dtype bf16 \
  --size small \
  --seqs 128 256 512 1024 2048 4096 \
  --batches 1 2 4 \
  --modes prefill decode_one decode_chunk train \
  --pressures balanced lean survival \
  --warmup 10 \
  --trials 20 \
  --out results/v15_a100_raw.csv
