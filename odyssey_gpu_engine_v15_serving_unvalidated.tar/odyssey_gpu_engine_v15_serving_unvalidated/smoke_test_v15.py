import argparse, torch
from odyssey_gpu_v15 import OdysseyGPUV15LM, MatchedTransformerV15LM, OdysseyV15Engine, preset_v15, count_params

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--dtype", default="bf16", choices=["fp32","fp16","bf16"])
    ap.add_argument("--size", default="tiny")
    args = ap.parse_args()

    device = torch.device(args.device)
    dtype = {"fp32":torch.float32,"fp16":torch.float16,"bf16":torch.bfloat16}[args.dtype]
    amp = device.type == "cuda" and dtype != torch.float32
    cfg = preset_v15(args.size, vocab_size=2048, max_seq_len=256)

    for name, cls in [("odyssey_v15", OdysseyGPUV15LM), ("transformer", MatchedTransformerV15LM)]:
        model = cls(cfg).to(device)
        x = torch.randint(0, cfg.vocab_size, (2,64), device=device)
        y = torch.randint(0, cfg.vocab_size, (2,64), device=device)
        opt = torch.optim.AdamW(model.parameters(), lr=1e-4)

        model.train()
        opt.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=dtype, enabled=amp):
            logits, loss = model(x, y, phase="train", pressure="balanced")
        assert logits.shape == (2,64,cfg.vocab_size)
        assert torch.isfinite(loss)
        loss.backward()
        opt.step()

        if name == "odyssey_v15":
            engine = OdysseyV15Engine(model)
            cache = engine.make_cache(batch_size=2, device=device)
            with torch.no_grad(), torch.autocast(device_type=device.type, dtype=dtype, enabled=amp):
                pf = engine.prefill(x, cache=cache)
                one = engine.decode_one(x[:, :16], cache=cache)
                chk = engine.decode_chunk(x[:, :32], cache=cache)
            assert one.shape == (2, cfg.vocab_size)
            print("cache:", cache)

        print(f"{name}: PASS params={count_params(model):,} loss={float(loss.detach().cpu()):.4f}")

    if device.type == "cuda":
        print("GPU:", torch.cuda.get_device_name())
        print("peak_mem_mb:", torch.cuda.max_memory_allocated()/1024/1024)

if __name__ == "__main__":
    main()
