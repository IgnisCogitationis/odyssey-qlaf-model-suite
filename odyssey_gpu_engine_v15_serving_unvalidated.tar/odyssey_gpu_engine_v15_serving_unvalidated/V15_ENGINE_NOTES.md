# v15 Engine Notes

## What v15 changes

### 1. Serving wrapper is now first-class

The model and serving engine are separated:

- `OdysseyGPUV15LM`: neural model
- `OdysseyV15Cache`: cache/state metadata
- `OdysseyV15Engine`: serving/training wrapper

This makes it easier to hand the engine to a GPU contractor.

### 2. Cache interface exists

The cache stores:

- last sequence length
- pressure mode
- phase
- selected routing mode
- route confidence summary
- optional compact QLAF state summary
- token counter
- refresh cadence

This is not yet a high-performance CUDA cache, but it is the correct interface.

### 3. Decode modes split

- `prefill`: full prompt processing
- `decode_one`: one token
- `decode_chunk`: small chunk
- `train`: forward/backward

### 4. Policy auto-selection

The engine chooses:

- `survival` for very short or pressured decode
- `lean` for normal decode
- `balanced` for prefill/training
- `full` only when explicitly requested

### 5. What still needs GPU validation

- whether packed QLAF beats FlashAttention at 512+
- whether local grouped mixer is faster than depthwise conv
- whether TSC budget actually helps quality enough
- whether compile succeeds with each static wrapper
- whether future Triton kernel improves state combine

## Strongest likely production form

```text
train:      balanced, soft route, budgeted TSC
prefill:    balanced or lean, top-2 route, budgeted TSC
decode_one: lean/survival, top-1 route, TSC off
decode_chk: lean, top-1/top-2 route, tiny TSC budget
```

## Do not do

- Do not keep TSC always on in decode.
- Do not use full AION as a branch.
- Do not benchmark only CPU and claim GPU win.
- Do not compare against weak transformer baseline; compare against FlashAttention where possible.
