# Odyssey GPU Engine v15 — Serving-Oriented Unvalidated Engine

Status: **written and packaged, not CUDA/Triton validated in this environment**.

v15 continues from v14 and focuses on what was still weak:

1. v14 still recomputed too much during decode.
2. v14 had policy modes, but not enough serving-oriented cache structure.
3. v14 had a benchmark harness, but not enough separation between prefill, single-token decode, chunk decode, and training.
4. v14 did not expose enough static phase wrappers for `torch.compile`.
5. v14 had no clean runtime auto-policy selector.

v15 adds:

- `OdysseyV15Cache`
- serving-oriented `OdysseyV15Engine`
- explicit `prefill()`, `decode_one()`, `decode_chunk()`, `train_step()` wrappers
- static mode wrappers for compile experiments
- automatic pressure/policy selection from sequence length and memory pressure
- QLAF compact summary cache placeholders
- route/confidence cache placeholders
- pressure-aware local/TSC disabling
- benchmark runner with separate prefill/decode-one/decode-chunk/train rows
- GPU failure checklist and tuning guide

Important: the cache is a **safe reference cache**, not a final fused CUDA cache. It records policy/state metadata and provides the interface needed for a future optimized kernel.
