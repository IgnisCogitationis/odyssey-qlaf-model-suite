from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Optional, Dict, Tuple
import math
import time
import torch
import torch.nn as nn
import torch.nn.functional as F

Phase = Literal["train", "prefill", "decode_one", "decode_chunk"]
Pressure = Literal["full", "balanced", "lean", "survival"]

@dataclass
class V15Config:
    vocab_size: int = 8192
    d_model: int = 512
    n_layers: int = 8
    n_heads: int = 8
    d_ff: int = 2048
    max_seq_len: int = 4096
    dropout: float = 0.0

    n_states: int = 4
    tsc_rank: int = 4

    qlaf_weight: float = 0.84
    local_weight: float = 0.12
    tsc_weight: float = 0.04
    controller_mix: float = 0.06

    short_seq_cutoff: int = 128
    decode_tsc_budget: float = 0.0
    chunk_tsc_budget: float = 0.03125
    prefill_tsc_budget: float = 0.125
    train_tsc_budget: float = 0.125
    train_tsc_grad_scale: float = 0.30

    local_kernel: int = 5
    grouped_local: bool = True

    refresh_every_tokens: int = 64
    confidence_refresh_threshold: float = 0.55

def preset_v15(size: str = "small", **overrides) -> V15Config:
    presets = {
        "tiny": dict(d_model=128, n_layers=2, n_heads=4, d_ff=512, max_seq_len=2048, n_states=4, tsc_rank=4),
        "small": dict(d_model=256, n_layers=4, n_heads=4, d_ff=1024, max_seq_len=4096, n_states=4, tsc_rank=4),
        "base": dict(d_model=512, n_layers=8, n_heads=8, d_ff=2048, max_seq_len=4096, n_states=4, tsc_rank=4),
        "large": dict(d_model=768, n_layers=12, n_heads=12, d_ff=3072, max_seq_len=8192, n_states=6, tsc_rank=6),
    }
    kw = presets.get(size, presets["small"]).copy()
    kw.update(overrides)
    return V15Config(**kw)

@dataclass
class OdysseyV15Cache:
    """
    Reference serving cache.

    This cache is intentionally conservative. It records route/controller metadata and
    provides the shape of the future high-performance cache without pretending to be a
    final CUDA cache.
    """
    batch_size: int
    max_seq_len: int
    device: torch.device
    token_count: int = 0
    last_seq_len: int = 0
    phase: str = "prefill"
    pressure: str = "balanced"
    route_mode: str = "top1"
    confidence_mean: float = 1.0
    refresh_due: bool = False
    qlaf_summary: Optional[torch.Tensor] = None
    route_summary: Optional[torch.Tensor] = None

    def update(self, seq_len: int, phase: str, pressure: str, route_mode: str, confidence: Optional[torch.Tensor] = None):
        self.last_seq_len = seq_len
        self.phase = phase
        self.pressure = pressure
        self.route_mode = route_mode
        self.token_count += seq_len if phase == "prefill" else 1
        if confidence is not None:
            self.confidence_mean = float(confidence.detach().float().mean().cpu())
        self.refresh_due = (self.token_count % max(1, 64) == 0) or (self.confidence_mean < 0.55)

    def reset(self):
        self.token_count = 0
        self.last_seq_len = 0
        self.phase = "prefill"
        self.pressure = "balanced"
        self.route_mode = "top1"
        self.confidence_mean = 1.0
        self.refresh_due = False
        self.qlaf_summary = None
        self.route_summary = None

class RMSNorm(nn.Module):
    def __init__(self, d: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(d))
        self.eps = eps
    def forward(self, x):
        return x * torch.rsqrt(x.square().mean(dim=-1, keepdim=True) + self.eps) * self.weight

class SwiGLU(nn.Module):
    def __init__(self, d, ff):
        super().__init__()
        self.w1 = nn.Linear(d, ff, bias=False)
        self.w2 = nn.Linear(d, ff, bias=False)
        self.w3 = nn.Linear(ff, d, bias=False)
    def forward(self, x):
        return self.w3(F.silu(self.w1(x)) * self.w2(x))

def route_mode_for_phase(phase: Phase) -> str:
    if phase == "train":
        return "soft"
    if phase == "prefill":
        return "top2"
    return "top1"

def route_weights(logits: torch.Tensor, mode: str) -> torch.Tensor:
    if mode == "top1":
        idx = logits.argmax(dim=-1, keepdim=True)
        return torch.zeros_like(logits).scatter_(-1, idx, 1.0)
    if mode == "top2" and logits.size(-1) > 2:
        vals, idx = torch.topk(logits, k=2, dim=-1)
        sparse = torch.full_like(logits, float("-inf"))
        sparse.scatter_(-1, idx, vals)
        return torch.softmax(sparse, dim=-1)
    return torch.softmax(logits, dim=-1)

class PackedQLAFV15(nn.Module):
    def __init__(self, cfg: V15Config):
        super().__init__()
        self.cfg = cfg
        d, s = cfg.d_model, cfg.n_states
        self.packed = nn.Linear(d, s*d + s + d, bias=False)
        self.out = nn.Linear(d, d, bias=False)
        self.scale = nn.Parameter(torch.ones(s, d) / math.sqrt(d))

    def forward(self, x, phase: Phase):
        B, T, D = x.shape
        S = self.cfg.n_states
        z = self.packed(x)
        raw = z[..., :S*D].view(B, T, S, D)
        logits = z[..., S*D:S*D+S]
        control = z[..., S*D+S:]
        mode = route_mode_for_phase(phase)
        weights = route_weights(logits, mode)
        states = torch.tanh(raw) * self.scale.view(1,1,S,D)
        combined = torch.einsum("bts,btsd->btd", weights, states)
        summary = combined[:, -1, :].detach()
        return self.out(combined), logits, control, summary, mode

class AIONPolicyV15(nn.Module):
    def __init__(self, d):
        super().__init__()
        self.branch = nn.Linear(d, 3, bias=True)
        self.conf = nn.Linear(d, 1, bias=True)
    def forward(self, control):
        h = torch.tanh(control)
        branch = torch.softmax(self.branch(h), dim=-1)
        confidence = torch.sigmoid(self.conf(h)).squeeze(-1)
        return branch, confidence

class LocalMixerV15(nn.Module):
    def __init__(self, cfg: V15Config):
        super().__init__()
        d = cfg.d_model
        self.cfg = cfg
        self.grouped = nn.Sequential(nn.Linear(d,d,bias=False), nn.GELU(), nn.Linear(d,d,bias=False))
        self.dw = nn.Conv1d(d,d,kernel_size=cfg.local_kernel,padding=cfg.local_kernel-1,groups=d,bias=False)
        self.pw = nn.Linear(d,d,bias=False)
        self.gate = nn.Linear(d,d,bias=False)
    def forward(self, x):
        if self.cfg.grouped_local:
            y = self.grouped(x)
        else:
            y = self.dw(x.transpose(1,2))[:, :, :x.size(1)].transpose(1,2)
            y = self.pw(y)
        return y * torch.sigmoid(self.gate(x))

class BudgetTSCV15(nn.Module):
    def __init__(self, cfg: V15Config):
        super().__init__()
        d, r = cfg.d_model, cfg.tsc_rank
        self.d, self.r = d, r
        self.l = nn.Linear(d, r*d, bias=False)
        self.rg = nn.Linear(d, r, bias=False)
        self.o = nn.Linear(d, d, bias=False)
    def all(self, x):
        B,T,D = x.shape
        l = self.l(x).view(B,T,self.r,D)
        r = torch.softmax(self.rg(x), dim=-1).view(B,T,self.r,1)
        return self.o(torch.tanh((l*r).sum(dim=2)))
    def budget(self, x, confidence, ratio: float):
        if ratio <= 0:
            return torch.zeros_like(x)
        B,T,D = x.shape
        k = max(1, int(T * ratio))
        _, idx = torch.topk(-confidence, k=k, dim=1)
        mask = torch.zeros(B,T,device=x.device,dtype=x.dtype)
        mask.scatter_(1, idx, 1.0)
        return self.all(x) * mask.unsqueeze(-1)

def branch_policy(cfg: V15Config, phase: Phase, pressure: Pressure, seq_len: int):
    if phase != "train" and seq_len <= cfg.short_seq_cutoff:
        return dict(local=0.0, tsc=0.0, budget=0.0, ff=1.0)
    if pressure == "survival":
        return dict(local=0.0, tsc=0.0, budget=0.0, ff=0.75)
    if pressure == "lean":
        if phase == "decode_one":
            return dict(local=0.0, tsc=0.0, budget=0.0, ff=0.85)
        if phase == "decode_chunk":
            return dict(local=0.20, tsc=0.10, budget=cfg.chunk_tsc_budget, ff=0.90)
        return dict(local=0.35, tsc=0.15, budget=cfg.prefill_tsc_budget, ff=1.0)
    if pressure == "balanced":
        if phase == "decode_one":
            return dict(local=0.15, tsc=0.0, budget=0.0, ff=0.90)
        if phase == "decode_chunk":
            return dict(local=0.40, tsc=0.20, budget=cfg.chunk_tsc_budget, ff=1.0)
        if phase == "train":
            return dict(local=1.0, tsc=0.50, budget=cfg.train_tsc_budget, ff=1.0)
        return dict(local=0.85, tsc=0.40, budget=cfg.prefill_tsc_budget, ff=1.0)
    return dict(local=1.0, tsc=1.0, budget=1.0, ff=1.0)

class OdysseyBlockV15(nn.Module):
    def __init__(self, cfg: V15Config):
        super().__init__()
        self.cfg = cfg
        d = cfg.d_model
        self.n1 = RMSNorm(d)
        self.qlaf = PackedQLAFV15(cfg)
        self.aion = AIONPolicyV15(d)
        self.local = LocalMixerV15(cfg)
        self.tsc = BudgetTSCV15(cfg)
        self.n2 = RMSNorm(d)
        self.ff = SwiGLU(d, cfg.d_ff)
        self.drop = nn.Dropout(cfg.dropout)

    def forward(self, x, phase: Phase, pressure: Pressure):
        cfg = self.cfg
        h = self.n1(x)
        q, route_logits, control, summary, route_mode = self.qlaf(h, phase)
        gate, confidence = self.aion(control)
        pol = branch_policy(cfg, phase, pressure, x.size(1))

        l = self.local(h) * pol["local"] if pol["local"] > 0 else torch.zeros_like(q)

        if pol["tsc"] <= 0:
            t = torch.zeros_like(q)
        elif pol["budget"] >= 1.0:
            t = self.tsc.all(h) * pol["tsc"]
        else:
            t = self.tsc.budget(h, confidence, pol["budget"]) * pol["tsc"]
            if phase == "train":
                t = t * cfg.train_tsc_grad_scale + t.detach() * (1.0 - cfg.train_tsc_grad_scale)

        fixed = cfg.qlaf_weight*q + cfg.local_weight*l + cfg.tsc_weight*t
        adaptive = gate[...,0:1]*q + gate[...,1:2]*l + gate[...,2:3]*t
        y = (1-cfg.controller_mix)*fixed + cfg.controller_mix*adaptive

        x = x + self.drop(y)
        if pol["ff"] > 0:
            x = x + self.drop(self.ff(self.n2(x)) * pol["ff"])
        return x, confidence, summary, route_mode

class OdysseyGPUV15LM(nn.Module):
    def __init__(self, cfg: V15Config):
        super().__init__()
        self.cfg = cfg
        self.tok = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.pos = nn.Embedding(cfg.max_seq_len, cfg.d_model)
        self.blocks = nn.ModuleList([OdysseyBlockV15(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.head.weight = self.tok.weight

    def forward(self, idx, targets=None, phase: Phase="train", pressure: Pressure="balanced", cache: Optional[OdysseyV15Cache]=None):
        B,T = idx.shape
        if T > self.cfg.max_seq_len:
            raise ValueError(f"seq {T} > max_seq_len {self.cfg.max_seq_len}")
        pos = torch.arange(T, device=idx.device).unsqueeze(0)
        x = self.tok(idx) + self.pos(pos)

        last_conf, last_summary, last_route = None, None, route_mode_for_phase(phase)
        for block in self.blocks:
            x, last_conf, last_summary, last_route = block(x, phase, pressure)

        if cache is not None:
            cache.update(T, phase, pressure, last_route, last_conf)
            cache.qlaf_summary = last_summary
            if last_conf is not None:
                cache.route_summary = last_conf[:, -1].detach()

        x = self.norm(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss

class TransformerAttentionV15(nn.Module):
    def __init__(self, cfg: V15Config):
        super().__init__()
        assert cfg.d_model % cfg.n_heads == 0
        self.cfg = cfg
        self.qkv = nn.Linear(cfg.d_model, 3*cfg.d_model, bias=False)
        self.o = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
    def forward(self, x):
        B,T,D = x.shape
        H = self.cfg.n_heads
        hd = D // H
        qkv = self.qkv(x).view(B,T,3,H,hd).transpose(1,3)
        q,k,v = qkv[:,:,0], qkv[:,:,1], qkv[:,:,2]
        y = F.scaled_dot_product_attention(q,k,v,is_causal=True)
        return self.o(y.transpose(1,2).contiguous().view(B,T,D))

class TransformerBlockV15(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.n1 = RMSNorm(cfg.d_model)
        self.attn = TransformerAttentionV15(cfg)
        self.n2 = RMSNorm(cfg.d_model)
        self.ff = SwiGLU(cfg.d_model, cfg.d_ff)
    def forward(self, x):
        x = x + self.attn(self.n1(x))
        x = x + self.ff(self.n2(x))
        return x

class MatchedTransformerV15LM(nn.Module):
    def __init__(self, cfg: V15Config):
        super().__init__()
        self.cfg = cfg
        self.tok = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.pos = nn.Embedding(cfg.max_seq_len, cfg.d_model)
        self.blocks = nn.ModuleList([TransformerBlockV15(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.head.weight = self.tok.weight
    def forward(self, idx, targets=None, phase: Phase="train", pressure: Pressure="balanced", cache=None):
        B,T = idx.shape
        pos = torch.arange(T, device=idx.device).unsqueeze(0)
        x = self.tok(idx) + self.pos(pos)
        for b in self.blocks:
            x = b(x)
        x = self.norm(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss

class OdysseyV15Engine:
    """
    Runtime wrapper. This is the production-facing API.
    """
    def __init__(self, model: OdysseyGPUV15LM):
        self.model = model
        self.cfg = model.cfg

    def make_cache(self, batch_size: int, device: torch.device):
        return OdysseyV15Cache(batch_size=batch_size, max_seq_len=self.cfg.max_seq_len, device=device)

    def choose_pressure(self, phase: Phase, seq_len: int, memory_pressure: float = 0.0) -> Pressure:
        if memory_pressure > 0.85:
            return "survival"
        if phase == "decode_one":
            return "survival" if seq_len <= self.cfg.short_seq_cutoff else "lean"
        if phase == "decode_chunk":
            return "lean"
        if memory_pressure > 0.60:
            return "lean"
        return "balanced"

    @torch.no_grad()
    def prefill(self, idx, cache: Optional[OdysseyV15Cache]=None, pressure: Optional[Pressure]=None):
        p = pressure or self.choose_pressure("prefill", idx.size(1))
        self.model.eval()
        return self.model(idx, phase="prefill", pressure=p, cache=cache)[0]

    @torch.no_grad()
    def decode_one(self, idx, cache: Optional[OdysseyV15Cache]=None, pressure: Optional[Pressure]=None):
        p = pressure or self.choose_pressure("decode_one", idx.size(1))
        self.model.eval()
        logits, _ = self.model(idx, phase="decode_one", pressure=p, cache=cache)
        return logits[:, -1, :]

    @torch.no_grad()
    def decode_chunk(self, idx, cache: Optional[OdysseyV15Cache]=None, pressure: Optional[Pressure]=None):
        p = pressure or self.choose_pressure("decode_chunk", idx.size(1))
        self.model.eval()
        return self.model(idx, phase="decode_chunk", pressure=p, cache=cache)[0]

    def train_step(self, idx, targets, optimizer, pressure: Pressure="balanced"):
        self.model.train()
        optimizer.zero_grad(set_to_none=True)
        _, loss = self.model(idx, targets, phase="train", pressure=pressure)
        loss.backward()
        optimizer.step()
        return loss

def count_params(model):
    return sum(p.numel() for p in model.parameters())

def maybe_compile(model, enabled: bool):
    if not enabled:
        return model
    try:
        return torch.compile(model)
    except Exception as e:
        print("torch.compile failed; using eager:", repr(e))
        return model
