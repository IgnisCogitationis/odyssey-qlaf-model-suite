# v15 Next Work

The next improvements after this package should be:

1. Replace reference cache with true compact QLAF state cache.
2. Add a real single-token decode kernel that avoids full-context recompute.
3. Add Triton state combine + output projection kernel.
4. Add fused backward or custom autograd for QLAF combine.
5. Add distillation path from balanced/full to lean/survival.
6. Add a quality benchmark harness, not only speed.
7. Validate against a FlashAttention transformer baseline on A100/H100.
