#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python smoke_test_v15.py --device cuda --dtype bf16 --size base
python benchmark_v15_gpu.py \
  --device cuda \
  --dtype bf16 \
  --size base \
  --seqs 256 512 1024 2048 4096 8192 \
  --batches 1 2 4 8 \
  --modes prefill decode_one decode_chunk train \
  --pressures balanced lean survival \
  --warmup 10 \
  --trials 20 \
  --compile \
  --out results/v15_h100_raw.csv
