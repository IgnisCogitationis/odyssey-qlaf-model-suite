
# Canonical Odyssey Model Registry + Full Benchmark System

This package builds a canonical registry of every discoverable Odyssey model/repo artifact in the uploaded workspace, **excluding**:
- odyssey_final_fast
- odyssey_final_balanced
- odyssey_final_quality

## What is included
- `metadata/canonical_model_registry.json` and `.csv`
- `canonical_odyssey/registry.py` to query the registry
- `canonical_odyssey/bench_system.py` with benchmark adapters for:
  - extracted repo bundles (`bench_production.py` wrapper)
  - standalone CPU/common-harness models
- scripts for smoke-running the registry system

## Registry counts
Total models/artifacts: 48

## Families covered
family
direct_upload           3
repo_bundle             7
standalone_bundle       5
standalone_uploaded     4
workspace_repo         29

## Notes
- Repo bundles from `full_odyssey_code_package.zip` are treated as canonical benchmarkable bundle families.
- Workspace repo snapshots from `odyssey_workspace_full_code_bundle.zip` are registered as source artifacts even when they do not expose a unified benchmark entrypoint.
- Standalone bundle models from `odyssey_full_code_bundle.zip` are registered individually.
- Direct uploaded standalone files are also registered.

## Example usage
```bash
PYTHONPATH=. python scripts/build_registry.py
PYTHONPATH=. python scripts/run_registry_smoke.py
```

## Benchmark adapters
### Repo bundle
```python
from canonical_odyssey.bench_system import benchmark_repo_bundle
res = benchmark_repo_bundle('advanced_qlaf_engine', mode='production', scale='s128')
```

### Standalone common harness
```python
from canonical_odyssey.bench_system import benchmark_standalone_common
rows = benchmark_standalone_common('odyssey_research_grade_patch', seq_lens=[32,64])
```
