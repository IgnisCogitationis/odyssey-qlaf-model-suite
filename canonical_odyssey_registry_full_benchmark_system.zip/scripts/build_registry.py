
from canonical_odyssey.registry import load_registry
import pandas as pd
from pathlib import Path
reg = load_registry()
print(f"models: {reg['model_count']}")
print(pd.DataFrame(reg['models']).groupby('family').size())
