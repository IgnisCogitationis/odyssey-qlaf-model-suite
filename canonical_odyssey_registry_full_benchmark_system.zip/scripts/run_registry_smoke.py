
from canonical_odyssey.registry import list_models
from canonical_odyssey.bench_system import benchmark_standalone_common
import json
from pathlib import Path

out = Path('outputs')
out.mkdir(exist_ok=True)
models = [m['id'] for m in list_models(family='standalone_bundle') if m['id'] in {'odyssey_research_grade_patch','odyssey_stronger_mixer_patch'}]
rows = []
for m in models:
    try:
        rows.extend(benchmark_standalone_common(m))
    except Exception as e:
        rows.append({'model_id': m, 'error': f'{type(e).__name__}: {e}'})
(out/'registry_smoke_results.json').write_text(json.dumps(rows, indent=2))
print(json.dumps(rows, indent=2))
