
from __future__ import annotations
import json
from pathlib import Path
from typing import Dict, List

ROOT = Path(__file__).resolve().parents[1]
REGISTRY_PATH = ROOT / 'metadata' / 'canonical_model_registry.json'

def load_registry() -> Dict:
    return json.loads(REGISTRY_PATH.read_text(encoding='utf-8'))

def list_models(status: str | None = None, family: str | None = None) -> List[dict]:
    models = load_registry()['models']
    if status is not None:
        models = [m for m in models if m.get('status') == status]
    if family is not None:
        models = [m for m in models if m.get('family') == family]
    return models
