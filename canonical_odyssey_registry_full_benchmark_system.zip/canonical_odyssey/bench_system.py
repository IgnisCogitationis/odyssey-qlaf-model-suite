
from __future__ import annotations
import importlib.util
import json
import os
import random
import statistics
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path
from typing import Dict, List, Any

import torch
import torch.nn as nn

from .registry import load_registry

ROOT = Path(__file__).resolve().parents[1]

class TinyTransformer(nn.Module):
    def __init__(self, vocab_size: int = 256, seq_len: int = 64, dim: int = 96, heads: int = 4, layers: int = 2):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, dim)
        self.pos = nn.Parameter(torch.zeros(1, seq_len, dim))
        enc = nn.TransformerEncoderLayer(d_model=dim, nhead=heads, dim_feedforward=4*dim, dropout=0.0, activation='gelu', batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(enc, num_layers=layers)
        self.norm = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, vocab_size, bias=False)
    def forward(self, ids: torch.Tensor):
        x = self.emb(ids) + self.pos[:, :ids.size(1), :]
        T = ids.size(1)
        mask = torch.full((T, T), float('-inf'))
        mask = torch.triu(mask, diagonal=1)
        x = self.encoder(x, mask=mask)
        return self.head(self.norm(x))


def _load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def _bench_model(model: nn.Module, seq_len: int, batch_size: int = 1, warmup: int = 1, steps: int = 2) -> Dict[str, float]:
    model.eval()
    x = torch.randint(0, 256, (batch_size, seq_len), dtype=torch.long)
    with torch.no_grad():
        for _ in range(warmup):
            _ = model(x)
        times = []
        for _ in range(steps):
            t0 = time.perf_counter()
            _ = model(x)
            times.append(time.perf_counter() - t0)
    avg = statistics.mean(times)
    return {'avg_forward_ms': avg * 1000.0, 'tokens_per_sec': batch_size * seq_len / avg, 'params': sum(p.numel() for p in model.parameters())}


def benchmark_standalone_common(model_id: str, seq_lens: List[int] = [32, 64]) -> List[Dict[str, Any]]:
    reg = load_registry()['models']
    entry = next(m for m in reg if m['id'] == model_id)
    src = entry['source_subpath']
    if entry['source_archive']:
        zpath = Path(entry['source_archive'])
        with zipfile.ZipFile(zpath) as z, tempfile.TemporaryDirectory() as td:
            z.extract(entry['source_subpath'], td)
            path = Path(td) / entry['source_subpath']
            return _benchmark_standalone_path(path, model_id, seq_lens)
    return _benchmark_standalone_path(Path(src), model_id, seq_lens)


def _benchmark_standalone_path(path: Path, model_id: str, seq_lens: List[int]) -> List[Dict[str, Any]]:
    out = []
    mod = _load_module(path, f'mod_{model_id}')
    tfm_cache = {}
    for seq_len in seq_lens:
        tfm = TinyTransformer(seq_len=seq_len)
        tf_stats = _bench_model(tfm, seq_len)
        if hasattr(mod, 'CPUUltimateEngine') and hasattr(mod, 'CPUUltimateConfig'):
            cfg = mod.CPUUltimateConfig(model_size='60m')
            cfg.vocab_size = 256
            cfg.max_seq_len = seq_len
            cfg.num_threads = 2
            if hasattr(cfg, 'dim') and not hasattr(cfg, 'layers'):
                pass
            model = mod.CPUUltimateEngine(cfg)
            stats = _bench_model(model, seq_len)
            out.append({'model_id': model_id, 'seq_len': seq_len, 'tokens_per_sec': stats['tokens_per_sec'], 'transformer_tokens_per_sec': tf_stats['tokens_per_sec'], 'speedup_vs_transformer_pct': (stats['tokens_per_sec']/tf_stats['tokens_per_sec'] - 1.0)*100.0})
        elif hasattr(mod, 'ResearchOdyssey'):
            model = mod.ResearchOdyssey(vocab_size=256, seq_len=seq_len, dim=80, layers=3, kernel=3, ff_mult=2, dropout=0.0)
            stats = _bench_model(model, seq_len)
            out.append({'model_id': model_id, 'seq_len': seq_len, 'tokens_per_sec': stats['tokens_per_sec'], 'transformer_tokens_per_sec': tf_stats['tokens_per_sec'], 'speedup_vs_transformer_pct': (stats['tokens_per_sec']/tf_stats['tokens_per_sec'] - 1.0)*100.0})
        elif hasattr(mod, 'OdysseyMixerLM'):
            for mixer in ['dwconv','fullconv','gatedconv','hybrid']:
                model = mod.OdysseyMixerLM(vocab_size=256, seq_len=seq_len, dim=72, layers=2, mixer_type=mixer, kernel=3, ff_mult=2, dropout=0.0)
                stats = _bench_model(model, seq_len)
                out.append({'model_id': f'{model_id}:{mixer}', 'seq_len': seq_len, 'tokens_per_sec': stats['tokens_per_sec'], 'transformer_tokens_per_sec': tf_stats['tokens_per_sec'], 'speedup_vs_transformer_pct': (stats['tokens_per_sec']/tf_stats['tokens_per_sec'] - 1.0)*100.0})
        else:
            raise RuntimeError(f'No supported common benchmark adapter for {model_id} from {path}')
    return out


def benchmark_repo_bundle(model_id: str, mode: str = 'production', scale: str = 's128') -> Dict[str, Any]:
    reg = load_registry()['models']
    entry = next(m for m in reg if m['id'] == model_id)
    zpath = Path(entry['source_archive'])
    subroot = entry['source_subpath']
    with tempfile.TemporaryDirectory() as td, zipfile.ZipFile(zpath) as z:
        root_extract = Path(td)
        z.extractall(root_extract)
        repo = root_extract / subroot
        script = repo / 'bench_production.py'
        env = os.environ.copy()
        env.update({'ODYSSEY_BENCH_MODE': mode, 'ODYSSEY_BENCH_SCALE': scale, 'ODYSSEY_BENCH_DEVICE': 'cpu', 'ODYSSEY_BENCH_WARMUP': '0', 'ODYSSEY_BENCH_TRIALS': '1'})
        proc = subprocess.run([sys.executable, str(script)], cwd=str(repo), env=env, capture_output=True, text=True, timeout=180)
        return {'model_id': model_id, 'mode': mode, 'scale': scale, 'returncode': proc.returncode, 'stdout_tail': proc.stdout[-2000:], 'stderr_tail': proc.stderr[-2000:]}
