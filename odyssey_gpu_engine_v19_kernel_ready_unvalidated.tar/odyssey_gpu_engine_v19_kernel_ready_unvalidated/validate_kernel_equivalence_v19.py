import argparse, torch
from kernel_boundaries_v19 import qlaf_prefill_kernel_reference, qlaf_decode_kernel_reference

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--device",default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--dtype",default="bf16",choices=["fp32","fp16","bf16"])
    args=ap.parse_args()
    device=torch.device(args.device)
    dtype={"fp32":torch.float32,"fp16":torch.float16,"bf16":torch.bfloat16}[args.dtype]
    B,T,D,S=2,16,64,4
    x=torch.randn(B,T,D,device=device,dtype=dtype)
    pw=torch.randn(S*D+S+D,D,device=device,dtype=dtype)*0.02
    ow=torch.randn(D,D,device=device,dtype=dtype)*0.02
    sw=torch.randn(D,D,device=device,dtype=dtype)*0.02
    scale=torch.ones(S,D,device=device,dtype=dtype)
    out,summary,rid,conf=qlaf_prefill_kernel_reference(x,pw,ow,scale,S,"top2")
    dec,summary2,rid2,conf2=qlaf_decode_kernel_reference(x[:,:1],summary,pw,ow,sw,scale,S,0.875)
    assert out.shape==(B,T,D)
    assert dec.shape==(B,1,D)
    assert summary.shape==(B,D)
    print("kernel reference equivalence smoke: PASS")
if __name__=="__main__": main()
