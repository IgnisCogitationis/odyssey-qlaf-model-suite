#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python validate_kernel_equivalence_v19.py --device cuda --dtype bf16
python smoke_test_v19.py --device cuda --dtype bf16 --size small
python quality_speed_dashboard_v19.py --device cuda --dtype bf16 --size small --seqs 128 256 512 1024 2048 4096 --batch 4 --trials 20 --out results/v19_a100_dashboard.csv
