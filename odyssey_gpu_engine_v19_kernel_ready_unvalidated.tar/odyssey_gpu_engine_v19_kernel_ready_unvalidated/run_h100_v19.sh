#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python validate_kernel_equivalence_v19.py --device cuda --dtype bf16
python smoke_test_v19.py --device cuda --dtype bf16 --size base
python quality_speed_dashboard_v19.py --device cuda --dtype bf16 --size base --seqs 256 512 1024 2048 4096 8192 --batch 8 --trials 20 --out results/v19_h100_dashboard.csv
