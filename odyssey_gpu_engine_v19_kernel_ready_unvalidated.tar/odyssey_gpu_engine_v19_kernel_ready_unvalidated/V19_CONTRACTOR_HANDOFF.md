# v19 Contractor Handoff

## Objective

Implement and validate high-performance GPU kernels while preserving the v19 public API.

## Replace these reference functions first

Located in `kernel_boundaries_v19.py`:

1. `qlaf_prefill_kernel_reference`
2. `qlaf_decode_kernel_reference`
3. `budgeted_tsc_reference`
4. `fused_residual_reference`

## Required tests

1. Run `smoke_test_v19.py`.
2. Run `validate_kernel_equivalence_v19.py`.
3. Run `benchmark_v19_gpu.py` on A100/H100.
4. Run `evaluate_drift_v19.py`.
5. Run `train_distill_v19.py`.

## Numeric tolerances

- FP32: `rtol=1e-4`, `atol=1e-4`
- FP16: `rtol=1e-2`, `atol=1e-2`
- BF16: `rtol=2e-2`, `atol=2e-2`

## Must not change

- public class names
- method signatures
- CSV schemas
- cache semantics
- baseline transformer comparison

## Highest priority

True fused decode-one QLAF kernel.

If that works, the engine has the strongest chance to beat transformer in production serving.
