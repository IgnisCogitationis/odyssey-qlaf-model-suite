"""
Cache quantization scaffolding.

Reference version stores FP tensors by default. Quantization hooks are provided for
future production serving.
"""

from __future__ import annotations
from dataclasses import dataclass
import torch


@dataclass
class QuantizedSummary:
    q: torch.Tensor
    scale: torch.Tensor
    zero: torch.Tensor
    dtype: str = "int8"


def quantize_summary_int8(x: torch.Tensor) -> QuantizedSummary:
    max_abs = x.detach().abs().amax(dim=-1, keepdim=True).clamp_min(1e-6)
    scale = max_abs / 127.0
    q = torch.clamp(torch.round(x / scale), -127, 127).to(torch.int8)
    zero = torch.zeros_like(scale)
    return QuantizedSummary(q=q, scale=scale, zero=zero, dtype="int8")


def dequantize_summary(qs: QuantizedSummary) -> torch.Tensor:
    return qs.q.float() * qs.scale.float()


def maybe_quantize_summary(x: torch.Tensor, enabled: bool):
    return quantize_summary_int8(x) if enabled else x


def maybe_dequantize_summary(x):
    if isinstance(x, QuantizedSummary):
        return dequantize_summary(x)
    return x
