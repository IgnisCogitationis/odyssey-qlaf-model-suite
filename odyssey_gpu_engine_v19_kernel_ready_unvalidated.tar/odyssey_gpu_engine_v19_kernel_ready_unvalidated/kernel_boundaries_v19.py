"""
Kernel boundary reference implementations.

GPU contractor should replace these with Triton/CUDA kernels while preserving outputs.
"""

from __future__ import annotations
from typing import Tuple, Optional
import torch
import torch.nn.functional as F


def route_weights_reference(logits: torch.Tensor, mode: str) -> Tuple[torch.Tensor, torch.Tensor]:
    if mode == "top1":
        idx = logits.argmax(dim=-1, keepdim=True)
        return torch.zeros_like(logits).scatter_(-1, idx, 1.0), idx.squeeze(-1)
    if mode == "top2" and logits.size(-1) > 2:
        vals, idx = torch.topk(logits, k=2, dim=-1)
        sparse = torch.full_like(logits, float("-inf"))
        sparse.scatter_(-1, idx, vals)
        return torch.softmax(sparse, dim=-1), idx[..., 0]
    return torch.softmax(logits, dim=-1), logits.argmax(dim=-1)


def qlaf_prefill_kernel_reference(
    x: torch.Tensor,
    packed_weight: torch.Tensor,
    out_weight: torch.Tensor,
    state_scale: torch.Tensor,
    n_states: int,
    route_mode: str,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    Reference QLAF prefill path.

    Returns:
    - output [B,T,D]
    - summary [B,D]
    - route_id [B,T]
    - confidence [B,T]
    """
    B, T, D = x.shape
    z = F.linear(x, packed_weight)
    raw = z[..., :n_states * D].view(B, T, n_states, D)
    logits = z[..., n_states * D:n_states * D + n_states]
    weights, route_id = route_weights_reference(logits, route_mode)
    states = torch.tanh(raw) * state_scale.view(1, 1, n_states, D)
    combined = torch.einsum("bts,btsd->btd", weights, states)
    out = F.linear(combined, out_weight)
    confidence = weights.max(dim=-1).values
    summary = combined[:, -1, :]
    return out, summary, route_id, confidence


def qlaf_decode_kernel_reference(
    x_token: torch.Tensor,
    prev_summary: Optional[torch.Tensor],
    packed_weight: torch.Tensor,
    out_weight: torch.Tensor,
    summary_weight: torch.Tensor,
    state_scale: torch.Tensor,
    n_states: int,
    summary_mix: float,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    Reference recurrent decode kernel.

    x_token: [B,1,D]
    prev_summary: [B,D] or None
    """
    B, T, D = x_token.shape
    assert T == 1, "decode kernel expects one token"
    z = F.linear(x_token, packed_weight)
    raw = z[..., :n_states * D].view(B, T, n_states, D)
    logits = z[..., n_states * D:n_states * D + n_states]
    weights, route_id = route_weights_reference(logits, "top1")
    states = torch.tanh(raw) * state_scale.view(1, 1, n_states, D)
    combined = torch.einsum("bts,btsd->btd", weights, states)
    if prev_summary is not None:
        recurrent = F.linear(prev_summary, summary_weight).unsqueeze(1)
        combined = summary_mix * recurrent + (1.0 - summary_mix) * combined
    out = F.linear(combined, out_weight)
    confidence = weights.max(dim=-1).values
    summary = combined[:, -1, :]
    return out, summary, route_id.squeeze(1), confidence.squeeze(1)


def budgeted_tsc_reference(
    x: torch.Tensor,
    confidence: torch.Tensor,
    left_weight: torch.Tensor,
    right_weight: torch.Tensor,
    out_weight: torch.Tensor,
    rank: int,
    budget: float,
) -> torch.Tensor:
    if budget <= 0:
        return torch.zeros_like(x)
    B, T, D = x.shape
    k = max(1, int(T * budget))
    _, idx = torch.topk(-confidence, k=k, dim=1)
    mask = torch.zeros(B, T, device=x.device, dtype=x.dtype)
    mask.scatter_(1, idx, 1.0)

    left = F.linear(x, left_weight).view(B, T, rank, D)
    right = torch.softmax(F.linear(x, right_weight), dim=-1).view(B, T, rank, 1)
    y = F.linear(torch.tanh((left * right).sum(dim=2)), out_weight)
    return y * mask.unsqueeze(-1)


def fused_residual_reference(
    x: torch.Tensor,
    q: torch.Tensor,
    local: torch.Tensor,
    tsc: torch.Tensor,
    gate: torch.Tensor,
    qlaf_weight: float,
    local_weight: float,
    tsc_weight: float,
    controller_mix: float,
) -> torch.Tensor:
    fixed = qlaf_weight * q + local_weight * local + tsc_weight * tsc
    adaptive = gate[..., 0:1] * q + gate[..., 1:2] * local + gate[..., 2:3] * tsc
    return x + (1.0 - controller_mix) * fixed + controller_mix * adaptive
