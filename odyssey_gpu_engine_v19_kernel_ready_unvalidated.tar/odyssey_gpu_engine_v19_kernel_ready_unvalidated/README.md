# Odyssey GPU Engine v19 — Kernel-Ready Production Boundary Pass

Status: **written and packaged, not CUDA/Triton validated in this environment**.

v19 continues from v18. It focuses on the remaining gap before real A100/H100 validation:

> The architecture and recurrent/decode/distillation logic exist, but the engine needs clean kernel boundaries, CUDA graph hooks, cache quantization options, and a single validation harness that exposes exactly what a GPU engineer must replace or test.

## What v19 adds

- `OdysseyGPUV19LM`
- `OdysseyV19Engine`
- `OdysseyV19Cache`
- kernel boundary interface:
  - `qlaf_prefill_kernel_reference`
  - `qlaf_decode_kernel_reference`
  - `budgeted_tsc_reference`
  - `fused_residual_reference`
- optional cache quantization scaffold
- CUDA graph capture placeholders
- decode drift + speed benchmark
- distillation harness
- quality-speed dashboard CSV generator
- contractor validation checklist
- A100/H100 scripts
- matched transformer baseline

## What is still not validated

- real Triton/CUDA kernels
- FlashAttention-2 exact baseline
- full quality parity
- production memory advantage
- TensorRT/ONNX deployment

## Recommended handoff

Give this package to a GPU engineer and ask them to implement the functions in `kernel_boundaries_v19.py` using Triton/CUDA while preserving the Python reference outputs.
