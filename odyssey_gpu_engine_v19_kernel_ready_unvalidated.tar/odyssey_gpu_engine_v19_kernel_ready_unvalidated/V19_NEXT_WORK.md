# v19 Next Work

1. Implement Triton replacement for `qlaf_decode_kernel_reference`.
2. Implement Triton replacement for `qlaf_prefill_kernel_reference`.
3. Add CUDA graphs for fixed-shape decode.
4. Add FlashAttention-2 transformer baseline verification.
5. Add real corpus training and quality evaluation.
6. Add quantized cache A/B test.
7. Add TensorRT/ONNX feasibility pass.
