#!/usr/bin/env bash
set -euo pipefail
export TORCHINDUCTOR_MAX_AUTOTUNE=1
PYTHONPATH=. python -m odyssey_route_b.tests.test_ffn_strategies
PYTHONPATH=. python -m odyssey_route_b.tests.test_reference_single_kernel
PYTHONPATH=. python -m odyssey_route_b.tests.test_gpu_compile_and_parity
PYTHONPATH=. python -m odyssey_route_b.tests.test_long_decode_drift
PYTHONPATH=. python -m odyssey_route_b.benchmarks.benchmark_single_vs_tiled --dtype bfloat16 --B 16 --H 512 --S 8 --R 64
PYTHONPATH=. python -m odyssey_route_b.benchmarks.benchmark_single_vs_tiled --dtype float16 --B 16 --H 512 --S 8 --R 64
