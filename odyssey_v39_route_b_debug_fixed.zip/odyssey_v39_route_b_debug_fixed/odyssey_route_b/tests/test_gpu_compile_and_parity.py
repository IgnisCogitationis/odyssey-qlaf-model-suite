import json
import torch
from odyssey_route_b.kernels import triton_available, single_kernel_route_b, torch_reference_single_kernel

def make_case(dtype=torch.float32, B=2, H=128, S=4, R=16, seed=0):
    torch.manual_seed(seed)
    dev = "cuda"
    return {
        "x": torch.randn(B,H,device=dev,dtype=dtype),
        "route_norm_w": torch.randn(H,device=dev,dtype=dtype),
        "to_state_w": torch.randn(S+R,H,device=dev,dtype=dtype) / (H ** 0.5),
        "summary": torch.randn(B,S,R,device=dev,dtype=dtype) * 0.1,
        "weight": torch.rand(B,S,device=dev,dtype=dtype),
        "readout_w": torch.randn(H,S*R,device=dev,dtype=dtype) / ((S*R) ** 0.5),
        "tsc_norm_w": torch.randn(H,device=dev,dtype=dtype),
        "tsc_gate_w": torch.randn(1,H,device=dev,dtype=dtype) / (H ** 0.5),
        "tsc_proj_w": torch.randn(H,H,device=dev,dtype=dtype) / (H ** 0.5),
    }

if not triton_available():
    print(json.dumps({"status":"skip","reason":"cuda_or_triton_unavailable"}))
else:
    rows = []
    for dtype, tol in [(torch.float32, 2e-3), (torch.bfloat16, 2e-2), (torch.float16, 3e-2)]:
        case = make_case(dtype=dtype)
        ref = torch_reference_single_kernel(**case)
        ker = single_kernel_route_b(**case)
        torch.cuda.synchronize()
        diffs = {
            "core": float((ref[0].float() - ker[0].float()).abs().max().item()),
            "summary": float((ref[1].float() - ker[1].float()).abs().max().item()),
            "weight": float((ref[2].float() - ker[2].float()).abs().max().item()),
        }
        ok = diffs["core"] < tol and diffs["summary"] < tol and diffs["weight"] < tol
        rows.append({"dtype":str(dtype), "tol":tol, "diffs":diffs, "ok":ok})
    print(json.dumps(rows, indent=2))
    assert all(r["ok"] for r in rows), rows
