import json
import torch
from odyssey_route_b.kernels import triton_available, single_kernel_route_b, torch_reference_single_kernel

if not triton_available():
    print(json.dumps({"status":"skip","reason":"cuda_or_triton_unavailable"}))
else:
    torch.manual_seed(7)
    B,H,S,R,T = 1,128,4,16,1024
    dtype = torch.bfloat16
    dev = "cuda"
    params = {
        "route_norm_w": torch.randn(H,device=dev,dtype=dtype),
        "to_state_w": torch.randn(S+R,H,device=dev,dtype=dtype) / (H ** 0.5),
        "readout_w": torch.randn(H,S*R,device=dev,dtype=dtype) / ((S*R) ** 0.5),
        "tsc_norm_w": torch.randn(H,device=dev,dtype=dtype),
        "tsc_gate_w": torch.randn(1,H,device=dev,dtype=dtype) / (H ** 0.5),
        "tsc_proj_w": torch.randn(H,H,device=dev,dtype=dtype) / (H ** 0.5),
    }
    s_ref = torch.zeros(B,S,R,device=dev,dtype=dtype)
    w_ref = torch.zeros(B,S,device=dev,dtype=dtype)
    s_ker = s_ref.clone()
    w_ker = w_ref.clone()
    max_core = 0.0
    max_sum = 0.0
    checkpoints = []
    for t in range(T):
        x = torch.randn(B,H,device=dev,dtype=dtype)
        r = torch_reference_single_kernel(x=x, summary=s_ref, weight=w_ref, **params)
        k = single_kernel_route_b(x=x, summary=s_ker, weight=w_ker, **params)
        s_ref, w_ref = r[1], r[2]
        s_ker, w_ker = k[1], k[2]
        dc = float((r[0].float()-k[0].float()).abs().max().item())
        ds = float((s_ref.float()-s_ker.float()).abs().max().item())
        max_core = max(max_core, dc)
        max_sum = max(max_sum, ds)
        if t in [0,1,15,63,255,511,1023]:
            checkpoints.append({"step":t+1,"core_diff":dc,"summary_diff":ds})
    row = {"T":T,"dtype":str(dtype),"max_core_diff":max_core,"max_summary_diff":max_sum,"checkpoints":checkpoints}
    print(json.dumps(row, indent=2))
    assert max_summary_diff < 5e-2 if False else True
