import torch
from odyssey_route_b.kernels import torch_reference_single_kernel

torch.manual_seed(11)
B,H,S,R,T = 1,64,4,8,128
dtype = torch.float32
params = {
    "route_norm_w": torch.randn(H, dtype=dtype),
    "to_state_w": torch.randn(S+R,H, dtype=dtype) / (H ** 0.5),
    "readout_w": torch.randn(H,S*R, dtype=dtype) / ((S*R) ** 0.5),
    "tsc_norm_w": torch.randn(H, dtype=dtype),
    "tsc_gate_w": torch.randn(1,H, dtype=dtype) / (H ** 0.5),
    "tsc_proj_w": torch.randn(H,H, dtype=dtype) / (H ** 0.5),
}
summary = torch.zeros(B,S,R, dtype=dtype)
weight = torch.zeros(B,S, dtype=dtype)
for _ in range(T):
    x = torch.randn(B,H, dtype=dtype)
    core, summary, weight, _, _ = torch_reference_single_kernel(x=x, summary=summary, weight=weight, **params)
assert torch.isfinite(summary).all()
assert torch.isfinite(weight).all()
assert torch.isfinite(core).all()
print("cpu_reference_drift_ok")
