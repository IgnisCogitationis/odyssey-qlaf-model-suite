# Final Debug Passes

This build patches and instruments the final five targets.

## 1. Triton compile errors

Patch:
- Removed cross-program race from the previous one-kernel block-split design.
- Update/cache write is now in `_update_kernel`.
- Readout/TSC is now in `_readout_tsc_kernel`.
- Production still requires Triton/CUDA; no PyTorch fallback is used in forward.

Validation:
```bash
PYTHONPATH=. python -m odyssey_route_b.tests.test_gpu_compile_and_parity
```

## 2. Kernel vs reference parity

Reference:
```text
torch_reference_single_kernel
```

GPU test:
```text
test_gpu_compile_and_parity
```

## 3. bf16/fp16 tolerance

Initial tolerances:
```text
fp32: 2e-3
bf16: 2e-2
fp16: 3e-2
```

## 4. Long decode cache drift

Validation:
```bash
PYTHONPATH=. python -m odyssey_route_b.tests.test_long_decode_drift
```

## 5. Single-kernel vs tiled-kernel speed

This fixed build provides a race-free two-stage debug core. Compare it against:
- previous single-kernel package
- tiled-projection package
- mma-tiled package

Benchmark:
```bash
PYTHONPATH=. python -m odyssey_route_b.benchmarks.benchmark_single_vs_tiled --dtype bfloat16
```
