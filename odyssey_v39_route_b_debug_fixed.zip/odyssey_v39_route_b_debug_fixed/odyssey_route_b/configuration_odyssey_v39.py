try:
    from transformers import PretrainedConfig
except Exception:
    class PretrainedConfig:
        model_type = None
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

class OdysseyV39Config(PretrainedConfig):
    model_type = "odyssey_v39"

    def __init__(self, vocab_size=32000, hidden_size=512, num_layers=8,
                 num_states=8, state_rank=64, intermediate_size=2048,
                 decode_ffn_size=512, max_positions=8192, rms_eps=1e-6,
                 tsc_scale=0.05, aion_threshold=0.55,
                 ffn_strategy="decode_light", kernel_mode="single_kernel",
                 require_triton_kernel=True, use_cache=True,
                 tie_word_embeddings=True, bos_token_id=0, eos_token_id=0,
                 pad_token_id=0, **kwargs):
        super().__init__(bos_token_id=bos_token_id, eos_token_id=eos_token_id,
                         pad_token_id=pad_token_id,
                         tie_word_embeddings=tie_word_embeddings, **kwargs)
        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.num_states = num_states
        self.state_rank = state_rank
        self.intermediate_size = intermediate_size
        self.decode_ffn_size = decode_ffn_size
        self.max_positions = max_positions
        self.rms_eps = rms_eps
        self.tsc_scale = tsc_scale
        self.aion_threshold = aion_threshold
        self.ffn_strategy = ffn_strategy
        self.kernel_mode = kernel_mode
        self.require_triton_kernel = require_triton_kernel
        self.use_cache = use_cache
