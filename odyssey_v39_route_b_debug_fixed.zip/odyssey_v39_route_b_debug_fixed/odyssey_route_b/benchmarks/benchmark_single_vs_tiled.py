import argparse, json, time, torch
from odyssey_route_b.kernels import triton_available, single_kernel_route_b

def sync():
    torch.cuda.synchronize()

def make_case(dtype, B, H, S, R):
    dev="cuda"; torch.manual_seed(123)
    return {
        "x": torch.randn(B,H,device=dev,dtype=dtype),
        "route_norm_w": torch.randn(H,device=dev,dtype=dtype),
        "to_state_w": torch.randn(S+R,H,device=dev,dtype=dtype)/(H**0.5),
        "summary": torch.randn(B,S,R,device=dev,dtype=dtype)*0.1,
        "weight": torch.rand(B,S,device=dev,dtype=dtype),
        "readout_w": torch.randn(H,S*R,device=dev,dtype=dtype)/((S*R)**0.5),
        "tsc_norm_w": torch.randn(H,device=dev,dtype=dtype),
        "tsc_gate_w": torch.randn(1,H,device=dev,dtype=dtype)/(H**0.5),
        "tsc_proj_w": torch.randn(H,H,device=dev,dtype=dtype)/(H**0.5),
    }

def bench(fn, warmup, iters):
    for _ in range(warmup):
        fn()
    sync()
    times=[]
    for _ in range(iters):
        t=time.perf_counter()
        fn()
        sync()
        times.append(time.perf_counter()-t)
    return min(times), sum(times)/len(times)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--dtype", default="bfloat16", choices=["float32","float16","bfloat16"])
    ap.add_argument("--B", type=int, default=16)
    ap.add_argument("--H", type=int, default=512)
    ap.add_argument("--S", type=int, default=8)
    ap.add_argument("--R", type=int, default=64)
    ap.add_argument("--iters", type=int, default=50)
    args=ap.parse_args()
    if not triton_available():
        print(json.dumps({"status":"skip","reason":"cuda_or_triton_unavailable"})); return
    dtype={"float32":torch.float32,"float16":torch.float16,"bfloat16":torch.bfloat16}[args.dtype]
    case=make_case(dtype,args.B,args.H,args.S,args.R)
    best,mean=bench(lambda: single_kernel_route_b(**case), 10, args.iters)
    row={"kernel":"debug_two_stage_core","dtype":args.dtype,"B":args.B,"H":args.H,"S":args.S,"R":args.R,
         "best_us":best*1e6,"mean_us":mean*1e6}
    print(json.dumps(row, indent=2))
if __name__=="__main__":
    main()
