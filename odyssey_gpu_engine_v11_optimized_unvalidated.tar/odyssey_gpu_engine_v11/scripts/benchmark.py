import argparse, csv, json, platform, time, pathlib, sys
import torch
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from odyssey_engine.config import preset
from odyssey_engine.model import OdysseyGPUV11LM, MatchedTransformerLM, count_parameters


def sync(device):
    if device.type == 'cuda': torch.cuda.synchronize()

def bench(fn, device, warmup, trials):
    for _ in range(warmup): fn()
    sync(device); times=[]
    for _ in range(trials):
        t=time.perf_counter(); fn(); sync(device); times.append(time.perf_counter()-t)
    return sum(times)/len(times)

ap=argparse.ArgumentParser()
ap.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
ap.add_argument('--size', default='small')
ap.add_argument('--seqs', nargs='+', type=int, default=[128,256,512,1024])
ap.add_argument('--batch-sizes', nargs='+', type=int, default=[1,2])
ap.add_argument('--trials', type=int, default=10); ap.add_argument('--warmup', type=int, default=5)
ap.add_argument('--out', default='results/v11_benchmark_raw.csv')
ap.add_argument('--compile', action='store_true')
args=ap.parse_args(); device=torch.device(args.device); pathlib.Path(args.out).parent.mkdir(parents=True, exist_ok=True)
cfg=preset(args.size, max_seq_len=max(args.seqs))
rows=[]
for b in args.batch_sizes:
  for s in args.seqs:
    for mode in ['forward','decode','train']:
      for name, cls in [('transformer', MatchedTransformerLM), ('odyssey_v11', OdysseyGPUV11LM)]:
        m=cls(cfg).to(device)
        if args.compile:
          try: m=torch.compile(m)
          except Exception as e: print('compile skipped', e)
        x=torch.randint(0,cfg.vocab_size,(b,s),device=device); y=torch.randint(0,cfg.vocab_size,(b,s),device=device)
        opt=torch.optim.AdamW(m.parameters(), lr=1e-4)
        amp=(device.type=='cuda')
        if device.type=='cuda': torch.cuda.reset_peak_memory_stats()
        if mode=='forward':
          m.eval()
          def fn():
            with torch.no_grad(), torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp): m(x, decode=False)
        elif mode=='decode':
          m.eval()
          def fn():
            with torch.no_grad(), torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp): m(x, decode=True)
        else:
          m.train()
          def fn():
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp): _, loss=m(x,y,decode=False)
            loss.backward(); opt.step()
        try:
          avg=bench(fn, device, args.warmup, args.trials)
          peak=torch.cuda.max_memory_allocated()/1024/1024 if device.type=='cuda' else 0.0
          row=dict(model=name,mode=mode,batch=b,seq=s,avg_s=avg,tokens_per_s=b*s/avg,peak_mem_mb=peak,params=count_parameters(m))
          print(row); rows.append(row)
        except RuntimeError as e:
          print('SKIP', name, mode, b, s, e)
        del m
        if device.type=='cuda': torch.cuda.empty_cache()

with open(args.out,'w',newline='') as f:
    w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
# percent table
by={}
for r in rows: by.setdefault((r['mode'],r['batch'],r['seq']),{})[r['model']]=r
pct=[]
for key,d in sorted(by.items()):
    if 'transformer' not in d: continue
    base=d['transformer']['avg_s']
    for model,r in d.items():
        ratio=base/r['avg_s']; pct.append({**r, 'speed_ratio_vs_transformer': ratio, 'percent_speedup_vs_transformer': (ratio-1)*100})
pct_path=str(pathlib.Path(args.out).with_name('v11_percent_vs_transformer.csv'))
with open(pct_path,'w',newline='') as f:
    w=csv.DictWriter(f, fieldnames=list(pct[0].keys())); w.writeheader(); w.writerows(pct)
(pathlib.Path(args.out).with_name('environment.json')).write_text(json.dumps({'python':platform.python_version(),'torch':torch.__version__,'cuda':torch.cuda.is_available(),'device':str(device),'gpu':torch.cuda.get_device_name() if torch.cuda.is_available() and device.type=='cuda' else None,'config':cfg.__dict__}, indent=2))
print('WROTE', args.out, pct_path)
