#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python scripts/smoke_test.py --device cuda --size small
python scripts/benchmark.py --device cuda --size small --seqs 128 256 512 1024 2048 4096 --batch-sizes 1 2 4 --trials 20 --warmup 10 --out results/a100_v11_raw.csv
python scripts/benchmark.py --device cuda --size base --seqs 512 1024 2048 4096 --batch-sizes 1 2 --trials 20 --warmup 10 --out results/a100_v11_base_raw.csv
