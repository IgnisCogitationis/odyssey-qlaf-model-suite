import argparse, torch, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from odyssey_engine.config import preset
from odyssey_engine.model import OdysseyGPUV11LM, MatchedTransformerLM, count_parameters
from odyssey_engine.runtime import OdysseyRuntime

ap = argparse.ArgumentParser(); ap.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu'); ap.add_argument('--size', default='tiny')
args = ap.parse_args(); device=torch.device(args.device)
cfg = preset(args.size, max_seq_len=256)
for name, cls in [('odyssey_v11', OdysseyGPUV11LM), ('transformer', MatchedTransformerLM)]:
    m = cls(cfg).to(device)
    x = torch.randint(0, cfg.vocab_size, (2,64), device=device); y=torch.randint(0,cfg.vocab_size,(2,64),device=device)
    opt=torch.optim.AdamW(m.parameters(), lr=1e-4)
    logits, loss = m(x,y); assert logits.shape == (2,64,cfg.vocab_size); assert torch.isfinite(loss)
    loss.backward(); opt.step()
    rt = OdysseyRuntime(m, device=device) if name == 'odyssey_v11' else None
    if rt: cache=rt.prefill(x[:,:16]); step, cache=rt.decode_step(x[:,:17], cache); assert step.shape == (2,cfg.vocab_size)
    print(f'{name}: PASS params={count_parameters(m):,} loss={float(loss.detach().cpu()):.4f}')
