from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Dict, Any
import torch

@dataclass
class DecodeCache:
    tokens_seen: int = 0
    meta: Dict[str, Any] = field(default_factory=dict)
    # Placeholder for future per-layer QLAF/router caches.
    qlaf_state: Optional[list] = None

class OdysseyRuntime:
    def __init__(self, model, device=None, dtype=torch.bfloat16, amp=True):
        self.model = model
        self.device = device or next(model.parameters()).device
        self.dtype = dtype
        self.amp = amp and self.device.type == "cuda"

    @torch.no_grad()
    def prefill(self, idx: torch.Tensor) -> DecodeCache:
        self.model.eval()
        with torch.autocast(device_type=self.device.type, dtype=self.dtype, enabled=self.amp):
            _ = self.model(idx.to(self.device), decode=False)
        return DecodeCache(tokens_seen=idx.size(1), meta={"prefill_shape": tuple(idx.shape)})

    @torch.no_grad()
    def decode_step(self, idx: torch.Tensor, cache: Optional[DecodeCache] = None):
        self.model.eval()
        with torch.autocast(device_type=self.device.type, dtype=self.dtype, enabled=self.amp):
            logits, _ = self.model(idx.to(self.device), decode=True)
        if cache is not None:
            cache.tokens_seen += 1
        return logits[:, -1, :], cache

    def train_step(self, idx: torch.Tensor, targets: torch.Tensor, optimizer):
        self.model.train(); optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=self.device.type, dtype=self.dtype, enabled=self.amp):
            logits, loss = self.model(idx.to(self.device), targets.to(self.device), decode=False)
        loss.backward(); optimizer.step()
        return float(loss.detach().cpu())
