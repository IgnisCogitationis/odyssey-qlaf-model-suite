"""Optional Triton kernels for Odyssey GPU v11.

These kernels are intentionally guarded: if Triton is unavailable, the model falls back to PyTorch.
The fused kernel here targets the QLAF combine step after states and router weights are computed.
A production kernel would fuse in-projection, state nonlinearity, router, weighted combine, and output projection.
"""
from __future__ import annotations
import torch

try:
    import triton
    import triton.language as tl
    HAS_TRITON = True
except Exception:
    triton = None
    tl = None
    HAS_TRITON = False


def triton_available() -> bool:
    return HAS_TRITON and torch.cuda.is_available()


if HAS_TRITON:
    @triton.jit
    def _qlaf_weighted_sum_kernel(states, weights, out, N: tl.constexpr, S: tl.constexpr, D: tl.constexpr, BLOCK_D: tl.constexpr):
        pid_n = tl.program_id(0)
        pid_d = tl.program_id(1)
        offs_d = pid_d * BLOCK_D + tl.arange(0, BLOCK_D)
        mask = offs_d < D
        acc = tl.zeros((BLOCK_D,), tl.float32)
        for s in range(0, S):
            w = tl.load(weights + pid_n * S + s)
            vals = tl.load(states + (pid_n * S + s) * D + offs_d, mask=mask, other=0.0)
            acc += w * vals
        tl.store(out + pid_n * D + offs_d, acc, mask=mask)


def qlaf_weighted_sum_triton(states: torch.Tensor, weights: torch.Tensor) -> torch.Tensor:
    """states: [B,T,S,D], weights: [B,T,S] -> [B,T,D]"""
    if not triton_available():
        raise RuntimeError("Triton/CUDA unavailable")
    assert states.is_cuda and weights.is_cuda
    B, T, S, D = states.shape
    out = torch.empty((B, T, D), device=states.device, dtype=states.dtype)
    N = B * T
    block_d = 64
    grid = (N, triton.cdiv(D, block_d))
    _qlaf_weighted_sum_kernel[grid](states.contiguous(), weights.contiguous(), out, N, S, D, BLOCK_D=block_d)
    return out
