from __future__ import annotations
from typing import Optional, Tuple
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import OdysseyGPUConfig
from .kernels import qlaf_weighted_sum_triton, triton_available


class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(d))
        self.eps = eps
    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(dim=-1, keepdim=True) + self.eps) * self.weight


class SwiGLU(nn.Module):
    def __init__(self, d_model, d_ff):
        super().__init__()
        self.w12 = nn.Linear(d_model, 2 * d_ff, bias=False)
        self.w3 = nn.Linear(d_ff, d_model, bias=False)
    def forward(self, x):
        a, b = self.w12(x).chunk(2, dim=-1)
        return self.w3(F.silu(a) * b)


class LocalMixer(nn.Module):
    def __init__(self, d_model, kernel=5):
        super().__init__()
        self.dw = nn.Conv1d(d_model, d_model, kernel, groups=d_model, padding=kernel-1, bias=False)
        self.pw = nn.Linear(d_model, d_model, bias=False)
        self.g = nn.Linear(d_model, d_model, bias=False)
    def forward(self, x):
        y = self.dw(x.transpose(1,2))[:, :, :x.size(1)].transpose(1,2)
        return self.pw(y) * torch.sigmoid(self.g(x))


class QLAFFastPath(nn.Module):
    def __init__(self, cfg: OdysseyGPUConfig):
        super().__init__()
        self.cfg = cfg
        d, s = cfg.d_model, cfg.n_states
        self.state_proj = nn.Linear(d, d*s, bias=False)
        self.router = nn.Linear(d, s, bias=False)
        self.scale = nn.Parameter(torch.ones(s, d) / math.sqrt(d))
        self.out = nn.Linear(d, d, bias=False)
    def forward(self, x, decode=False):
        B,T,D = x.shape
        S = self.cfg.n_states
        states = torch.tanh(self.state_proj(x).view(B,T,S,D)) * self.scale.view(1,1,S,D)
        logits = self.router(x)
        if decode and self.cfg.decode_top1:
            idx = logits.argmax(dim=-1, keepdim=True)
            weights = torch.zeros_like(logits).scatter_(-1, idx, 1.0)
        else:
            weights = torch.softmax(logits, dim=-1)
        if self.cfg.use_triton and states.is_cuda and triton_available():
            try:
                combined = qlaf_weighted_sum_triton(states, weights)
            except Exception:
                combined = torch.einsum("bts,btsd->btd", weights, states)
        else:
            combined = torch.einsum("bts,btsd->btd", weights, states)
        return self.out(combined)


class AIONGate(nn.Module):
    def __init__(self, d):
        super().__init__()
        self.op = nn.Linear(d, d, bias=False)
        self.g = nn.Linear(d, 3, bias=True)
    def forward(self, x):
        return torch.softmax(self.g(torch.tanh(self.op(x))), dim=-1)


class TSCCorrection(nn.Module):
    def __init__(self, d, rank):
        super().__init__()
        self.rank = rank
        self.d = d
        self.lr = nn.Linear(d, rank*d + rank, bias=False)
        self.out = nn.Linear(d, d, bias=False)
    def forward(self, x):
        B,T,D = x.shape
        raw = self.lr(x)
        l = raw[..., :self.rank*D].view(B,T,self.rank,D)
        r = torch.softmax(raw[..., self.rank*D:], dim=-1).view(B,T,self.rank,1)
        return self.out(torch.tanh((l*r).sum(dim=2)))


class OdysseyGPUV11Block(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        d = cfg.d_model
        self.n1 = RMSNorm(d)
        self.n2 = RMSNorm(d)
        self.qlaf = QLAFFastPath(cfg)
        self.local = LocalMixer(d)
        self.tsc = TSCCorrection(d, cfg.tsc_rank)
        self.gate = AIONGate(d)
        self.ff = SwiGLU(d, cfg.d_ff)
        self.drop = nn.Dropout(cfg.dropout)

    def _run_tsc(self, h, decode):
        if decode:
            if self.cfg.tsc_decode == "off": return False
            if self.cfg.tsc_decode == "full": return True
            with torch.no_grad():
                conf = self.gate(h).max(dim=-1).values.mean()
                return bool(conf.item() < self.cfg.tsc_threshold)
        return self.cfg.tsc_train != "off"

    def forward(self, x, decode=False):
        h = self.n1(x)
        q = self.qlaf(h, decode=decode)
        l = self.local(h)
        if self._run_tsc(h, decode):
            t = self.tsc(h)
            if self.training and self.cfg.tsc_train == "lean": t = 0.5 * t
            if self.training and self.cfg.tsc_train == "detached": t = t.detach()
        else:
            t = torch.zeros_like(q)
        y = self.cfg.qlaf_ratio*q + self.cfg.local_ratio*l + self.cfg.tsc_ratio*t
        g = self.gate(h)
        ya = g[...,0:1]*q + g[...,1:2]*l + g[...,2:3]*t
        y = (1-self.cfg.adaptive_gate_ratio)*y + self.cfg.adaptive_gate_ratio*ya
        x = x + self.drop(y)
        x = x + self.drop(self.ff(self.n2(x)))
        return x


class OdysseyGPUV11LM(nn.Module):
    def __init__(self, cfg: OdysseyGPUConfig):
        super().__init__()
        self.cfg = cfg
        self.tok = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.pos = nn.Embedding(cfg.max_seq_len, cfg.d_model)
        self.blocks = nn.ModuleList([OdysseyGPUV11Block(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.head.weight = self.tok.weight
    def forward(self, idx, targets: Optional[torch.Tensor]=None, decode=False):
        B,T = idx.shape
        pos = torch.arange(T, device=idx.device).view(1,T)
        x = self.tok(idx) + self.pos(pos)
        for b in self.blocks: x = b(x, decode=decode)
        x = self.norm(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss
    @torch.no_grad()
    def generate(self, idx, max_new_tokens, temperature=1.0):
        for _ in range(max_new_tokens):
            ctx = idx[:, -self.cfg.max_seq_len:]
            logits, _ = self(ctx, decode=True)
            probs = torch.softmax(logits[:, -1, :] / max(temperature, 1e-6), dim=-1)
            idx = torch.cat([idx, torch.multinomial(probs, 1)], dim=1)
        return idx


class CausalSelfAttention(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.qkv = nn.Linear(cfg.d_model, 3*cfg.d_model, bias=False)
        self.o = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
    def forward(self, x):
        B,T,D = x.shape; H = self.cfg.n_heads; hd = D//H
        qkv = self.qkv(x).view(B,T,3,H,hd).permute(2,0,3,1,4)
        q,k,v = qkv[0], qkv[1], qkv[2]
        y = F.scaled_dot_product_attention(q,k,v,is_causal=True)
        return self.o(y.transpose(1,2).contiguous().view(B,T,D))


class TransformerBlock(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.n1 = RMSNorm(cfg.d_model); self.attn = CausalSelfAttention(cfg)
        self.n2 = RMSNorm(cfg.d_model); self.ff = SwiGLU(cfg.d_model, cfg.d_ff)
    def forward(self, x):
        x = x + self.attn(self.n1(x)); x = x + self.ff(self.n2(x)); return x


class MatchedTransformerLM(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.tok = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.pos = nn.Embedding(cfg.max_seq_len, cfg.d_model)
        self.blocks = nn.ModuleList([TransformerBlock(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.head.weight = self.tok.weight
    def forward(self, idx, targets=None, decode=False):
        B,T = idx.shape
        x = self.tok(idx) + self.pos(torch.arange(T, device=idx.device).view(1,T))
        for b in self.blocks: x = b(x)
        logits = self.head(self.norm(x)); loss=None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss


def count_parameters(model):
    return sum(p.numel() for p in model.parameters())
