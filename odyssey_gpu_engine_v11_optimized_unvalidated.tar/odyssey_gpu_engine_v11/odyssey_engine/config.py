from dataclasses import dataclass

@dataclass
class OdysseyGPUConfig:
    vocab_size: int = 32768
    d_model: int = 512
    n_layers: int = 8
    n_heads: int = 8
    d_ff: int = 2048
    max_seq_len: int = 4096
    dropout: float = 0.0
    n_states: int = 4
    tsc_rank: int = 4
    qlaf_ratio: float = 0.70
    local_ratio: float = 0.20
    tsc_ratio: float = 0.10
    adaptive_gate_ratio: float = 0.15
    decode_top1: bool = True
    tsc_decode: str = "adaptive"  # off | adaptive | full
    tsc_train: str = "lean"       # off | lean | detached | full
    tsc_threshold: float = 0.62
    use_triton: bool = True
    use_torch_compile: bool = False
    fused_qlaf_projection: bool = True
    rope: bool = False


def preset(name: str, **overrides) -> OdysseyGPUConfig:
    presets = {
        "tiny": dict(d_model=128, n_layers=2, n_heads=4, d_ff=512, max_seq_len=2048, vocab_size=8192),
        "small": dict(d_model=256, n_layers=4, n_heads=4, d_ff=1024, max_seq_len=4096, vocab_size=16384),
        "base": dict(d_model=512, n_layers=8, n_heads=8, d_ff=2048, max_seq_len=4096, vocab_size=32768),
        "large": dict(d_model=768, n_layers=12, n_heads=12, d_ff=3072, max_seq_len=8192, vocab_size=32768),
    }
    data = presets.get(name, presets["small"]).copy()
    data.update(overrides)
    return OdysseyGPUConfig(**data)
