# Odyssey GPU Engine v11 — Unvalidated Optimized GPU Implementation

This package is an optimized GPU-oriented reference implementation for the Odyssey / QLAF / AION / TSC engine family.

It includes:

- QLAF fast state path
- optional Triton fused QLAF combine kernel
- PyTorch fallback path
- AION operator-guided gate
- adaptive TSC correction branch
- separate prefill and decode engine APIs
- decode cache object
- matched transformer baseline
- A100/H100 benchmark scripts
- profiling and environment report tools
- correctness smoke tests

## Status

This package is written for GPU validation but was **not CUDA/Triton validated in this environment**. It includes CPU/PyTorch fallback paths so the code can still be imported and smoke-tested without Triton/GPU.

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## CPU smoke test

```bash
python scripts/smoke_test.py --device cpu --size tiny
```

## A100 / H100 validation

```bash
bash scripts/run_a100_full.sh
```

## Benchmark outputs

Outputs are written into `results/`:

- raw CSV
- percent speedup CSV
- memory profile CSV
- environment JSON

## Engine selection

Use `--engine odyssey_v11` for the optimized engine and `--engine transformer` for the baseline.

