# v11 Engine Notes

This pass adds a guarded Triton QLAF weighted-sum kernel and keeps the PyTorch path as the canonical fallback.

Design choices:

- QLAF remains the primary 70% path.
- Local mixer remains bounded 20% path.
- TSC remains bounded 10% correction path.
- AION gate provides small adaptive correction and routing confidence.
- Decode mode uses top-1 QLAF routing and adaptive/off TSC control.
- Prefill and decode are exposed separately through `OdysseyRuntime`.

Unvalidated items:

- Triton kernel correctness/performance on actual A100/H100.
- CUDA graph capture.
- Fused backward.
- Production-grade KV/state cache reuse.

Next pass:

- Replace guarded weighted-sum kernel with full single-pass fused kernel:
  input projection -> router -> state nonlinearity -> weighted combine -> output projection.
- Add fused backward.
- Add CUDA graph decode loop.
