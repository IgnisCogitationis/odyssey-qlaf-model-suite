#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python smoke_test_gpu.py --device cuda --dtype bf16 --size small
python benchmark_gpu.py --device cuda --dtype bf16 --size small --seqs 128 256 512 1024 2048 4096 --batch-sizes 1 2 4 --trials 20 --warmup 10 --out results/a100_gpu_benchmark_raw.csv
