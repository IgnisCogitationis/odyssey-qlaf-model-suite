# Odyssey / QLAF GPU Model Test Package

Complete CUDA-aware PyTorch test package for:

- `OdysseyGPUModel`: QLAF fast state path + AION operator gate + TSC correction + local mixer
- `MatchedTransformerLM`: matched transformer baseline
- GPU smoke tests
- forward/decode/train benchmarks
- sequence and batch scaling tests

Runs on CUDA if available and falls back to CPU.

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Smoke test

```bash
python smoke_test_gpu.py --device cuda --dtype bf16 --size small
```

CPU fallback:

```bash
python smoke_test_gpu.py --device cpu --dtype fp32 --size tiny
```

## A100 benchmark

```bash
bash run_a100.sh
```

Manual command:

```bash
python benchmark_gpu.py --device cuda --dtype bf16 --size small --seqs 128 256 512 1024 2048 4096 --batch-sizes 1 2 4 --trials 20 --warmup 10 --out results/a100_gpu_benchmark_raw.csv
```

## Outputs

- `results/a100_gpu_benchmark_raw.csv`
- `results/gpu_benchmark_percent_vs_transformer.csv`
- `results/environment_report.json`

This is a full reference GPU model and benchmark harness using PyTorch CUDA kernels and optional `torch.compile`. It is not yet a hand-written Triton/CUDA fused kernel implementation.
