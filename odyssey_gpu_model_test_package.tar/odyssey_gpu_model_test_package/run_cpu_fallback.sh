#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python smoke_test_gpu.py --device cpu --dtype fp32 --size tiny
python benchmark_gpu.py --device cpu --dtype fp32 --size tiny --seqs 64 128 256 --batch-sizes 1 --trials 3 --warmup 1 --out results/cpu_fallback_benchmark_raw.csv
