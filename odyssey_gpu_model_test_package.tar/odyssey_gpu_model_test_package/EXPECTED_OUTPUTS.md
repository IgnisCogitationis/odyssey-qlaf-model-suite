# Expected Outputs

After `benchmark_gpu.py`:

- raw benchmark CSV
- percent vs transformer CSV
- environment report JSON

Raw columns: model, mode, batch, seq, avg_s, min_s, max_s, tokens_per_s, peak_mem_mb, params.
