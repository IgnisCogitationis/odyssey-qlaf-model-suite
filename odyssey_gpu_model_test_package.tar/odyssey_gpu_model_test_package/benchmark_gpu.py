import argparse, csv, json, platform, time
from pathlib import Path
import torch
from odyssey_gpu_model import OdysseyGPUModel, MatchedTransformerLM, make_config, count_parameters

def sync(device):
    if device.type == 'cuda': torch.cuda.synchronize()

def timed(fn, device, warmup, trials):
    for _ in range(warmup): fn()
    sync(device); vals = []
    for _ in range(trials):
        t0 = time.perf_counter(); fn(); sync(device); vals.append(time.perf_counter() - t0)
    return sum(vals)/len(vals), min(vals), max(vals)

def maybe_compile(model, enabled):
    if not enabled: return model
    try: return torch.compile(model)
    except Exception as e: print('torch.compile unavailable:', repr(e)); return model

def bench(name, model, cfg, device, dtype, batch, seq, warmup, trials, mode):
    use_amp = device.type == 'cuda' and dtype != torch.float32
    x = torch.randint(0, cfg.vocab_size, (batch, seq), device=device)
    y = torch.randint(0, cfg.vocab_size, (batch, seq), device=device)
    if mode == 'forward':
        model.eval()
        def fn():
            with torch.no_grad(), torch.autocast(device_type=device.type, dtype=dtype, enabled=use_amp):
                return model(x, None, decode=False)[0]
    elif mode == 'decode':
        model.eval()
        def fn():
            with torch.no_grad(), torch.autocast(device_type=device.type, dtype=dtype, enabled=use_amp):
                return model(x, None, decode=True)[0][:, -1, :]
    elif mode == 'train':
        model.train(); opt = torch.optim.AdamW(model.parameters(), lr=1e-4)
        def fn():
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, dtype=dtype, enabled=use_amp):
                logits, loss = model(x, y, decode=False)
            loss.backward(); opt.step(); return loss
    else:
        raise ValueError(mode)
    if device.type == 'cuda': torch.cuda.reset_peak_memory_stats()
    avg, mn, mx = timed(fn, device, warmup, trials)
    peak = torch.cuda.max_memory_allocated()/1024/1024 if device.type == 'cuda' else 0.0
    return {'model': name, 'mode': mode, 'batch': batch, 'seq': seq, 'avg_s': avg, 'min_s': mn, 'max_s': mx, 'tokens_per_s': batch*seq/avg, 'peak_mem_mb': peak, 'params': count_parameters(model)}

def write_percent(rows, out):
    by = {}
    for r in rows: by.setdefault((r['mode'], r['batch'], r['seq']), {})[r['model']] = r
    pct = []
    for key, d in sorted(by.items()):
        if 'transformer' not in d: continue
        base = d['transformer']['avg_s']
        for model, r in d.items():
            ratio = base / r['avg_s']
            pct.append({'mode': key[0], 'batch': key[1], 'seq': key[2], 'model': model, 'avg_s': r['avg_s'], 'transformer_avg_s': base, 'speed_ratio_vs_transformer': ratio, 'percent_speedup_vs_transformer': (ratio-1)*100, 'tokens_per_s': r['tokens_per_s'], 'peak_mem_mb': r['peak_mem_mb'], 'params': r['params']})
    if pct:
        with open(out, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(pct[0].keys())); w.writeheader(); w.writerows(pct)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    ap.add_argument('--dtype', default='bf16', choices=['fp32','fp16','bf16'])
    ap.add_argument('--size', default='small', choices=['tiny','small','base','large'])
    ap.add_argument('--seqs', nargs='+', type=int, default=[64,128,256,512,1024])
    ap.add_argument('--batch-sizes', nargs='+', type=int, default=[1,2])
    ap.add_argument('--modes', nargs='+', default=['forward','decode','train'])
    ap.add_argument('--trials', type=int, default=10)
    ap.add_argument('--warmup', type=int, default=5)
    ap.add_argument('--compile', action='store_true')
    ap.add_argument('--out', default='results/gpu_benchmark_raw.csv')
    args = ap.parse_args()
    device = torch.device(args.device)
    dtype = {'fp32': torch.float32, 'fp16': torch.float16, 'bf16': torch.bfloat16}[args.dtype]
    cfg = make_config(args.size, vocab_size=8192, max_seq_len=max(args.seqs))
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    env = {'python': platform.python_version(), 'platform': platform.platform(), 'torch': torch.__version__, 'cuda_available': torch.cuda.is_available(), 'device': str(device), 'dtype': args.dtype, 'gpu_name': torch.cuda.get_device_name() if torch.cuda.is_available() and device.type == 'cuda' else None, 'config': cfg.__dict__}
    Path(args.out).with_name('environment_report.json').write_text(json.dumps(env, indent=2), encoding='utf-8')
    rows = []
    for batch in args.batch_sizes:
      for seq in args.seqs:
       for mode in args.modes:
        for name, builder in {'transformer': lambda: MatchedTransformerLM(cfg), 'odyssey_gpu': lambda: OdysseyGPUModel(cfg)}.items():
          model = maybe_compile(builder().to(device), args.compile)
          try:
            row = bench(name, model, cfg, device, dtype, batch, seq, args.warmup, args.trials, mode)
            rows.append(row); print(row)
          except RuntimeError as e:
            print(f'SKIP {name} mode={mode} batch={batch} seq={seq}: {e}')
          del model
          if device.type == 'cuda': torch.cuda.empty_cache()
    if rows:
      with open(args.out, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
      write_percent(rows, Path(args.out).with_name('gpu_benchmark_percent_vs_transformer.csv'))
      print('WROTE', args.out)
if __name__ == '__main__': main()
