import argparse, torch
from odyssey_gpu_model import OdysseyGPUModel, MatchedTransformerLM, make_config, count_parameters

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    ap.add_argument('--dtype', default='fp32', choices=['fp32','fp16','bf16'])
    ap.add_argument('--size', default='tiny', choices=['tiny','small','base','large'])
    args = ap.parse_args()
    device = torch.device(args.device)
    dtype = {'fp32': torch.float32, 'fp16': torch.float16, 'bf16': torch.bfloat16}[args.dtype]
    use_amp = device.type == 'cuda' and dtype != torch.float32
    cfg = make_config(args.size, vocab_size=4096, max_seq_len=512)
    x = torch.randint(0, cfg.vocab_size, (2, 64), device=device)
    y = torch.randint(0, cfg.vocab_size, (2, 64), device=device)
    for name, model in {'odyssey': OdysseyGPUModel(cfg), 'transformer': MatchedTransformerLM(cfg)}.items():
        model = model.to(device)
        model.train()
        opt = torch.optim.AdamW(model.parameters(), lr=1e-4)
        opt.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=dtype, enabled=use_amp):
            logits, loss = model(x, y, decode=False)
        assert logits.shape == (2, 64, cfg.vocab_size)
        assert loss is not None and torch.isfinite(loss)
        loss.backward(); opt.step()
        print(f'{name}: PASS params={count_parameters(model):,} loss={float(loss.detach().cpu()):.4f}')
        if name == 'odyssey':
            out = model.generate(x[:, :8], max_new_tokens=4)
            assert out.shape[1] == 12
    if device.type == 'cuda':
        print('GPU:', torch.cuda.get_device_name())
        print('peak_mem_mb:', torch.cuda.max_memory_allocated()/1024/1024)
if __name__ == '__main__': main()
