from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

@dataclass
class OdysseyConfig:
    vocab_size: int = 32000
    d_model: int = 512
    n_layers: int = 8
    n_heads: int = 8
    d_ff: int = 2048
    max_seq_len: int = 4096
    dropout: float = 0.0
    qlaf_ratio: float = 0.70
    local_ratio: float = 0.20
    tsc_ratio: float = 0.10
    n_states: int = 4
    decode_bias: bool = True
    tsc_train_mode: str = 'lean'
    tsc_decode_mode: str = 'adaptive'
    tsc_threshold: float = 0.62
    fused_qlaf_projection: bool = True

class RMSNorm(nn.Module):
    def __init__(self, d: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(d))
        self.eps = eps
    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(dim=-1, keepdim=True) + self.eps) * self.weight

class SwiGLU(nn.Module):
    def __init__(self, d_model: int, d_ff: int):
        super().__init__()
        self.w1 = nn.Linear(d_model, d_ff, bias=False)
        self.w2 = nn.Linear(d_model, d_ff, bias=False)
        self.w3 = nn.Linear(d_ff, d_model, bias=False)
    def forward(self, x):
        return self.w3(F.silu(self.w1(x)) * self.w2(x))

class LocalCausalMixer(nn.Module):
    def __init__(self, d_model: int, kernel_size: int = 5):
        super().__init__()
        self.dw = nn.Conv1d(d_model, d_model, kernel_size=kernel_size, groups=d_model, padding=kernel_size-1, bias=False)
        self.pw = nn.Linear(d_model, d_model, bias=False)
        self.gate = nn.Linear(d_model, d_model, bias=False)
    def forward(self, x):
        y = self.dw(x.transpose(1, 2))[:, :, :x.size(1)].transpose(1, 2)
        return self.pw(y) * torch.sigmoid(self.gate(x))

class QLAFFastStatePath(nn.Module):
    def __init__(self, cfg: OdysseyConfig):
        super().__init__()
        self.cfg = cfg
        d, s = cfg.d_model, cfg.n_states
        self.in_proj = nn.Linear(d, d * s, bias=False)
        self.state_gate = nn.Linear(d, s, bias=False)
        self.state_scale = nn.Parameter(torch.ones(s, d) / math.sqrt(d))
        self.out_proj = nn.Linear(d, d, bias=False)
    def forward(self, x, decode: bool = False):
        B, T, D = x.shape
        S = self.cfg.n_states
        states = torch.tanh(self.in_proj(x).view(B, T, S, D)) * self.state_scale.view(1, 1, S, D)
        logits = self.state_gate(x)
        if decode and self.cfg.decode_bias:
            idx = logits.argmax(dim=-1, keepdim=True)
            weights = torch.zeros_like(logits).scatter_(-1, idx, 1.0)
        else:
            weights = torch.softmax(logits, dim=-1)
        combined = torch.einsum('bts,btsd->btd', weights, states)
        return self.out_proj(combined)

class AIONOperatorGate(nn.Module):
    def __init__(self, d_model: int):
        super().__init__()
        self.operator = nn.Linear(d_model, d_model, bias=False)
        self.gate = nn.Linear(d_model, 3, bias=True)
    def forward(self, x):
        return torch.softmax(self.gate(torch.tanh(self.operator(x))), dim=-1)

class TSCCorrection(nn.Module):
    def __init__(self, d_model: int, rank: int = 4):
        super().__init__()
        self.rank = rank
        self.left = nn.Linear(d_model, rank * d_model, bias=False)
        self.right = nn.Linear(d_model, rank, bias=False)
        self.out = nn.Linear(d_model, d_model, bias=False)
    def forward(self, x):
        B, T, D = x.shape
        l = self.left(x).view(B, T, self.rank, D)
        r = torch.softmax(self.right(x), dim=-1).view(B, T, self.rank, 1)
        return self.out(torch.tanh((l * r).sum(dim=2)))

class OdysseyBlock(nn.Module):
    def __init__(self, cfg: OdysseyConfig):
        super().__init__()
        self.cfg = cfg
        d = cfg.d_model
        self.n1 = RMSNorm(d)
        self.n2 = RMSNorm(d)
        self.qlaf = QLAFFastStatePath(cfg)
        self.local = LocalCausalMixer(d)
        self.tsc = TSCCorrection(d, rank=max(2, cfg.n_states))
        self.aion = AIONOperatorGate(d)
        self.ff = SwiGLU(d, cfg.d_ff)
        self.drop = nn.Dropout(cfg.dropout)
    def _run_tsc(self, h, decode):
        if decode:
            if self.cfg.tsc_decode_mode == 'off':
                return False
            if self.cfg.tsc_decode_mode == 'full':
                return True
            with torch.no_grad():
                conf = self.aion(h).max(dim=-1).values.mean()
                return bool(conf.item() < self.cfg.tsc_threshold)
        return self.cfg.tsc_train_mode != 'off'
    def forward(self, x, decode: bool = False):
        h = self.n1(x)
        q = self.qlaf(h, decode=decode)
        l = self.local(h)
        if self._run_tsc(h, decode):
            t = self.tsc(h)
            if self.training and not decode and self.cfg.tsc_train_mode == 'detached':
                t = t.detach()
            if self.training and not decode and self.cfg.tsc_train_mode == 'lean':
                t = 0.5 * t
        else:
            t = torch.zeros_like(q)
        y = self.cfg.qlaf_ratio * q + self.cfg.local_ratio * l + self.cfg.tsc_ratio * t
        g = self.aion(h)
        adaptive = g[..., 0:1] * q + g[..., 1:2] * l + g[..., 2:3] * t
        y = 0.85 * y + 0.15 * adaptive
        x = x + self.drop(y)
        x = x + self.drop(self.ff(self.n2(x)))
        return x

class OdysseyGPUModel(nn.Module):
    def __init__(self, cfg: OdysseyConfig):
        super().__init__()
        self.cfg = cfg
        self.tok = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.pos = nn.Embedding(cfg.max_seq_len, cfg.d_model)
        self.blocks = nn.ModuleList([OdysseyBlock(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.lm_head.weight = self.tok.weight
    def forward(self, idx, targets: Optional[torch.Tensor] = None, decode: bool = False):
        B, T = idx.shape
        if T > self.cfg.max_seq_len:
            raise ValueError(f'seq {T} > max_seq_len {self.cfg.max_seq_len}')
        x = self.tok(idx) + self.pos(torch.arange(T, device=idx.device).unsqueeze(0))
        for b in self.blocks:
            x = b(x, decode=decode)
        logits = self.lm_head(self.norm(x))
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss
    @torch.no_grad()
    def generate(self, idx, max_new_tokens: int, temperature: float = 1.0):
        self.eval()
        for _ in range(max_new_tokens):
            ctx = idx[:, -self.cfg.max_seq_len:]
            logits, _ = self(ctx, decode=True)
            probs = torch.softmax(logits[:, -1, :] / max(temperature, 1e-6), dim=-1)
            nxt = torch.multinomial(probs, 1)
            idx = torch.cat([idx, nxt], dim=1)
        return idx

class CausalSelfAttention(nn.Module):
    def __init__(self, cfg: OdysseyConfig):
        super().__init__()
        assert cfg.d_model % cfg.n_heads == 0
        self.cfg = cfg
        self.qkv = nn.Linear(cfg.d_model, 3 * cfg.d_model, bias=False)
        self.proj = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
    def forward(self, x):
        B, T, D = x.shape
        H = self.cfg.n_heads
        hd = D // H
        qkv = self.qkv(x).view(B, T, 3, H, hd).transpose(1, 3)
        q, k, v = qkv[:, :, 0], qkv[:, :, 1], qkv[:, :, 2]
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True, dropout_p=self.cfg.dropout if self.training else 0.0)
        return self.proj(y.transpose(1, 2).contiguous().view(B, T, D))

class TransformerBlock(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.n1 = RMSNorm(cfg.d_model)
        self.attn = CausalSelfAttention(cfg)
        self.n2 = RMSNorm(cfg.d_model)
        self.ff = SwiGLU(cfg.d_model, cfg.d_ff)
        self.drop = nn.Dropout(cfg.dropout)
    def forward(self, x):
        x = x + self.drop(self.attn(self.n1(x)))
        x = x + self.drop(self.ff(self.n2(x)))
        return x

class MatchedTransformerLM(nn.Module):
    def __init__(self, cfg: OdysseyConfig):
        super().__init__()
        self.cfg = cfg
        self.tok = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.pos = nn.Embedding(cfg.max_seq_len, cfg.d_model)
        self.blocks = nn.ModuleList([TransformerBlock(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.lm_head.weight = self.tok.weight
    def forward(self, idx, targets: Optional[torch.Tensor] = None, decode: bool = False):
        B, T = idx.shape
        if T > self.cfg.max_seq_len:
            raise ValueError(f'seq {T} > max_seq_len {self.cfg.max_seq_len}')
        x = self.tok(idx) + self.pos(torch.arange(T, device=idx.device).unsqueeze(0))
        for b in self.blocks:
            x = b(x)
        logits = self.lm_head(self.norm(x))
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss

def count_parameters(model):
    return sum(p.numel() for p in model.parameters())

def make_config(size='small', **overrides):
    presets = {
        'tiny': dict(d_model=128, n_layers=2, n_heads=4, d_ff=512, max_seq_len=2048),
        'small': dict(d_model=256, n_layers=4, n_heads=4, d_ff=1024, max_seq_len=4096),
        'base': dict(d_model=512, n_layers=8, n_heads=8, d_ff=2048, max_seq_len=4096),
        'large': dict(d_model=768, n_layers=12, n_heads=12, d_ff=3072, max_seq_len=8192),
    }
    kw = presets.get(size, presets['small']).copy()
    kw.update(overrides)
    return OdysseyConfig(**kw)
