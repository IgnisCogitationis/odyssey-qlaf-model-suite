# Hugging Face Route B Repo Files

Required:

- `config.json`
- `configuration_odyssey_v39.py`
- `modeling_odyssey_v39.py`
- `generation_odyssey_v39.py`
- `model.safetensors`
- tokenizer files
- `README.md`
- `requirements.txt`

Loading:

```python
AutoModelForCausalLM.from_pretrained(
    repo,
    trust_remote_code=True,
    torch_dtype="auto",
    device_map="auto",
)
```

Warning:

The HF fallback path is for portability. Performance claims require the CUDA wheel and custom server.
