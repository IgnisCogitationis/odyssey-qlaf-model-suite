# Pipeline Status

This artifact implements the restricted-environment execution plan for:

1. independent full-forward parity;
2. parameter-matched cached decode;
3. tiny training quality table;
4. CUDA top-1 decode;
5. Route B server integration.

## What runs now

- Independent parity shard.
- Parameter sweep shard.
- Cached decode shard.
- Tiny proxy training shard.
- Aggregation.

## What is specified but not executed here

- CUDA kernel.
- Route B server.
- HF custom model repo.

## Why

The environment may not support long PyTorch/GPU runs. This pipeline breaks evidence generation into small resumable shards.
