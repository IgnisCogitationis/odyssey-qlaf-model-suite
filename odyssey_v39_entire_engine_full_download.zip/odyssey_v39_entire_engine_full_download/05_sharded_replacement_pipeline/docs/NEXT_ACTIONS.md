# Next Actions

Run:

```bash
bash scripts/run_all_cpu_shards.sh
```

Then inspect:

```text
results/aggregate_summary.json
results/parity.csv
results/param_match.csv
results/cached_decode.csv
results/tiny_training.csv
```

If smoke passes, run larger shards:

```bash
python3 scripts/run_part_01_independent_parity.py --context 16 --batch 2 --seed 1
python3 scripts/run_part_03_cached_decode.py --contexts 8,16,32,64 --seeds 1,2,3 --batch 2
python3 scripts/run_part_04_tiny_training.py --seeds 1,2,3 --steps 10
python3 scripts/aggregate_results.py
```

Then move to the PyTorch package for real gradient training and CUDA top-1 decode.
