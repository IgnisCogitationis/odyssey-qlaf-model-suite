# Odyssey V39 Sharded Replacement Pipeline

This package targets the required sequence:

1. independent full-forward parity;
2. parameter-matched cached decode;
3. tiny training quality table;
4. CUDA top-1 decode;
5. Route B server integration.

It is designed for restricted environments:
- every stage is split into small parts;
- each part writes its own CSV/JSON;
- runs can be resumed;
- CPU smoke mode is available;
- CUDA/server stages are packaged as build targets even if not executed locally.

## Quick smoke

```bash
python3 scripts/run_part_01_independent_parity.py --smoke
python3 scripts/run_part_02_param_match.py --smoke
python3 scripts/run_part_03_cached_decode.py --smoke
python3 scripts/run_part_04_tiny_training.py --smoke
python3 scripts/aggregate_results.py
```

## Full CPU shard sequence

```bash
bash scripts/run_all_cpu_shards.sh
```

## Outputs

Results are written to:

```text
results/parity.csv
results/param_match.csv
results/cached_decode.csv
results/tiny_training.csv
results/aggregate_summary.json
```

## Important

This is not a final superiority claim. It is the pipeline required to produce the evidence.
