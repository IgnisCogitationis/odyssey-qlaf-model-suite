# Route B Server Integration Plan

## Purpose

Deploy the exact V39 engine, not a Transformer wrapper.

## Required pieces

- HF custom model repo.
- safetensors weights.
- CUDA wheel.
- custom inference server.
- prefill/decode separation.
- cache ownership by request id.
- streaming generation.
- metrics endpoint.

## Server endpoints

- `/health`
- `/generate`
- `/generate_stream`
- `/metrics`
- `/cache/debug`

## Metrics

- prefill tokens/sec;
- decode tokens/sec;
- p50 latency;
- p95 latency;
- active cache elements;
- refresh count;
- fallback count;
- CUDA/reference backend.

## Integration order

1. CPU reference server.
2. PyTorch server.
3. CUDA top-1 decode server.
4. CUDA prefill server.
5. HF model card and Docker release.
