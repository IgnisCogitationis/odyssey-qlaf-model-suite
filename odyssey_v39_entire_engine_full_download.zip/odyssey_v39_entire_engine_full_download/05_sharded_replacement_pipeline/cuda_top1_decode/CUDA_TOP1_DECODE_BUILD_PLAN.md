# CUDA Top-1 Decode Build Plan

## Build after these CSVs exist

- `results/parity.csv` with independent parity passed.
- `results/cached_decode.csv` with V39 vs Transformer KV timing.
- `results/param_match.csv` with a near-matched configuration.
- `results/tiny_training.csv` or PyTorch training table.

## Kernel target

The first CUDA kernel should implement only the top-1 decode state update:

1. compute route logits;
2. select top-1 state;
3. project token to rank vector;
4. update selected state summary and weight;
5. read state bank;
6. return hidden update.

## Required parity

CUDA output must match reference top-1 decode within tolerance before any speed claim.

## Do not build first

- top-2;
- prefill scan;
- TSC;
- server batching.

Those come after top-1 decode parity.
