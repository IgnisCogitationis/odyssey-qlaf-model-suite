#pragma once

// Odyssey V39 CUDA top-1 decode ABI draft.
// This is a stub header for the future extension, not a compiled kernel.

struct OdysseyV39DecodeConfig {
    int batch;
    int hidden;
    int states;
    int rank;
    int layers;
};

extern "C" int odyssey_v39_decode_top1_forward(
    const OdysseyV39DecodeConfig* config,
    const void* token_hidden,
    void* state_summary,
    void* state_weight,
    const void* route_weight,
    const void* rank_weight,
    const void* out_weight,
    void* output_hidden
);
