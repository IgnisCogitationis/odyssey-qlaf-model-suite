#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PYTHONPATH="$ROOT/src"

python3 "$ROOT/scripts/run_part_01_independent_parity.py" --smoke
python3 "$ROOT/scripts/run_part_02_param_match.py" --smoke
python3 "$ROOT/scripts/run_part_03_cached_decode.py" --smoke
python3 "$ROOT/scripts/run_part_04_tiny_training.py" --smoke
python3 "$ROOT/scripts/aggregate_results.py"
