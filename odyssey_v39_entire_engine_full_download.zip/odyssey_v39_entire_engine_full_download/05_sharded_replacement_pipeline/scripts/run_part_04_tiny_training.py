#!/usr/bin/env python3
import argparse, json, sys, random, math
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from odyssey_v39_pipeline.numeric_models import Config, TinyV39Independent, TinyTransformerKV, make_tokens, pseudo_loss
from odyssey_v39_pipeline.csv_utils import append_csv

ap = argparse.ArgumentParser()
ap.add_argument("--seeds", default="1")
ap.add_argument("--steps", type=int, default=5)
ap.add_argument("--smoke", action="store_true")
args=ap.parse_args()
seeds=[1] if args.smoke else [int(x) for x in args.seeds.split(",") if x]
steps=2 if args.smoke else args.steps
out=Path(__file__).resolve().parents[1] / "results" / "tiny_training.csv"

# Environment-safe proxy training: evaluate multiple random seeds as checkpoints, not gradient training.
# Real PyTorch training remains in the PyTorch package.
rows=[]
for seed in seeds:
    cfg=Config()
    toks=make_tokens(2,8,cfg.vocab,seed+300)
    best_v=None; best_t=None
    for step in range(steps):
        v=TinyV39Independent(cfg,seed=seed+step)
        t=TinyTransformerKV(cfg,seed=seed+step)
        vlogits,_=v.forward_cached(toks,top_k=2,use_tsc=True)
        tlogits,_=t.forward_cached(toks)
        vl=pseudo_loss(vlogits,toks); tl=pseudo_loss(tlogits,toks)
        best_v=vl if best_v is None else min(best_v,vl)
        best_t=tl if best_t is None else min(best_t,tl)
        row={"seed":seed,"step":step,"v39_proxy_loss":vl,"transformer_proxy_loss":tl,"best_v39_proxy_loss":best_v,"best_transformer_proxy_loss":best_t}
        append_csv(out,row); rows.append(row)
print(json.dumps({"note":"proxy table only; real gradient training should be run in PyTorch package","rows":rows},indent=2))
