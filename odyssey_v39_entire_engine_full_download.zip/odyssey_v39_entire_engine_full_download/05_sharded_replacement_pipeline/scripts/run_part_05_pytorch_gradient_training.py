#!/usr/bin/env python3
import argparse, csv, json, os, sys, time
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--seed", type=int, default=1)
ap.add_argument("--steps", type=int, default=3)
ap.add_argument("--batch", type=int, default=2)
ap.add_argument("--seq", type=int, default=8)
ap.add_argument("--hidden", type=int, default=8)
ap.add_argument("--states", type=int, default=3)
ap.add_argument("--rank", type=int, default=4)
ap.add_argument("--intermediate", type=int, default=32)
ap.add_argument("--smoke", action="store_true")
args = ap.parse_args()
if args.smoke:
    args.steps, args.batch, args.seq = 1, 1, 6

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except Exception as e:
    print(json.dumps({"passed": False, "error": "torch_import_failed", "detail": repr(e)}, indent=2))
    raise SystemExit(0)

torch.manual_seed(args.seed)

class TinyV39(nn.Module):
    def __init__(self, vocab=32, hidden=8, states=3, rank=4, inter=32, max_pos=64):
        super().__init__()
        self.vocab, self.hidden, self.states, self.rank = vocab, hidden, states, rank
        self.emb = nn.Embedding(vocab, hidden)
        self.pos = nn.Embedding(max_pos, hidden)
        self.norm = nn.LayerNorm(hidden)
        self.route = nn.Linear(hidden, states, bias=False)
        self.to_rank = nn.Linear(hidden, rank, bias=False)
        self.from_state = nn.Linear(states * rank, hidden, bias=False)
        self.mlp = nn.Sequential(nn.LayerNorm(hidden), nn.Linear(hidden, inter), nn.SiLU(), nn.Linear(inter, hidden))
        self.head = nn.Linear(hidden, vocab, bias=False)

    def forward(self, x):
        B, T = x.shape
        state = x.new_zeros((B, self.states, self.rank), dtype=self.emb.weight.dtype)
        weight = x.new_zeros((B, self.states), dtype=self.emb.weight.dtype)
        outs = []
        for t in range(T):
            h = self.emb(x[:, t]) + self.pos(torch.full((B,), t, device=x.device, dtype=torch.long))
            hn = self.norm(h)
            probs = torch.softmax(self.route(hn), dim=-1)
            vals, ids = torch.topk(probs, k=2, dim=-1)
            vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
            z = self.to_rank(hn)
            bi = torch.arange(B, device=x.device)
            for j in range(2):
                sid = ids[:, j]
                w = vals[:, j]
                old_w = weight[bi, sid]
                new_w = old_w + w
                old = state[bi, sid]
                state[bi, sid] = (old * old_w[:, None] + z * w[:, None]) / new_w[:, None].clamp_min(1e-8)
                weight[bi, sid] = new_w
            flat = (state * weight[:, :, None] / weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)[:, :, None]).reshape(B, self.states * self.rank)
            h = h + self.from_state(flat)
            h = h + self.mlp(h)
            outs.append(self.head(h)[:, None, :])
        return torch.cat(outs, dim=1)

class TinyTransformer(nn.Module):
    def __init__(self, vocab=32, hidden=8, inter=32, max_pos=64):
        super().__init__()
        self.emb = nn.Embedding(vocab, hidden)
        self.pos = nn.Embedding(max_pos, hidden)
        self.norm1 = nn.LayerNorm(hidden)
        self.attn = nn.MultiheadAttention(hidden, num_heads=1, batch_first=True)
        self.norm2 = nn.LayerNorm(hidden)
        self.mlp = nn.Sequential(nn.Linear(hidden, inter), nn.SiLU(), nn.Linear(inter, hidden))
        self.head = nn.Linear(hidden, vocab, bias=False)
    def forward(self, x):
        B,T=x.shape
        pos=torch.arange(T,device=x.device).unsqueeze(0).expand(B,T)
        h=self.emb(x)+self.pos(pos)
        mask=torch.triu(torch.ones(T,T,device=x.device,dtype=torch.bool),diagonal=1)
        q=self.norm1(h)
        y,_=self.attn(q,q,q,attn_mask=mask,need_weights=False)
        h=h+y
        h=h+self.mlp(self.norm2(h))
        return self.head(h)

def make_batch(batch, seq, vocab=32):
    x=torch.randint(0,vocab,(batch,seq))
    for t in range(2,seq):
        x[:,t]=(x[:,t-1]+x[:,t-2]+(t%5))%vocab
    return x

def train(model):
    opt=torch.optim.AdamW(model.parameters(),lr=3e-3)
    losses=[]
    start=time.perf_counter()
    for _ in range(args.steps):
        x=make_batch(args.batch,args.seq)
        opt.zero_grad(set_to_none=True)
        logits=model(x)
        loss=F.cross_entropy(logits[:,:-1,:].reshape(-1,logits.size(-1)),x[:,1:].reshape(-1))
        loss.backward()
        opt.step()
        losses.append(float(loss.item()))
    return losses, time.perf_counter()-start

v39=TinyV39(hidden=args.hidden,states=args.states,rank=args.rank,inter=args.intermediate,max_pos=max(64,args.seq+4))
tr=TinyTransformer(hidden=args.hidden,inter=args.intermediate,max_pos=max(64,args.seq+4))
v_losses,v_time=train(v39)
t_losses,t_time=train(tr)

row={
    "seed":args.seed,
    "steps":args.steps,
    "batch":args.batch,
    "seq":args.seq,
    "hidden":args.hidden,
    "states":args.states,
    "rank":args.rank,
    "intermediate":args.intermediate,
    "v39_initial_loss":v_losses[0],
    "v39_final_loss":v_losses[-1],
    "v39_delta":v_losses[0]-v_losses[-1],
    "transformer_initial_loss":t_losses[0],
    "transformer_final_loss":t_losses[-1],
    "transformer_delta":t_losses[0]-t_losses[-1],
    "v39_seconds":v_time,
    "transformer_seconds":t_time,
    "passed":(v_losses[-1] <= v_losses[0] or args.steps == 1) and (t_losses[-1] <= t_losses[0] or args.steps == 1)
}
out=Path(__file__).resolve().parents[1]/"results"/"pytorch_training.csv"
out.parent.mkdir(parents=True,exist_ok=True)
exists=out.exists()
with out.open("a",newline="",encoding="utf-8") as f:
    w=csv.DictWriter(f,fieldnames=list(row.keys()))
    if not exists: w.writeheader()
    w.writerow(row)
print(json.dumps(row,indent=2))
