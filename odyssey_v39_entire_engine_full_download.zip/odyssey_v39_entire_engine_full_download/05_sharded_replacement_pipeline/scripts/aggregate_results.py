#!/usr/bin/env python3
import json, csv
from pathlib import Path
base=Path(__file__).resolve().parents[1]
results=base/"results"
summary={}
for name in ["parity","param_match","cached_decode","tiny_training","pytorch_training"]:
    path=results/f"{name}.csv"
    if path.exists():
        with path.open("r",encoding="utf-8") as f:
            rows=list(csv.DictReader(f))
        summary[name]={"rows":len(rows),"last":rows[-1] if rows else None}
    else:
        summary[name]={"rows":0,"last":None}
(results/"aggregate_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
print(json.dumps(summary,indent=2))
