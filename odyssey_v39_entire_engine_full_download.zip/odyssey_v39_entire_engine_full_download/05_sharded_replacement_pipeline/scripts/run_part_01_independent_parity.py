#!/usr/bin/env python3
import argparse, json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from odyssey_v39_pipeline.numeric_models import Config, TinyV39Independent, make_tokens, max_abs_nested
from odyssey_v39_pipeline.csv_utils import append_csv

ap = argparse.ArgumentParser()
ap.add_argument("--seed", type=int, default=1)
ap.add_argument("--context", type=int, default=8)
ap.add_argument("--batch", type=int, default=2)
ap.add_argument("--smoke", action="store_true")
args = ap.parse_args()
if args.smoke:
    args.context = 4
    args.batch = 1

cfg = Config(max_pos=max(64, args.context+4))
model = TinyV39Independent(cfg, seed=args.seed)
tokens = make_tokens(args.batch, args.context, cfg.vocab, args.seed+100)
t0 = time.perf_counter()
full = model.forward_full_independent(tokens, top_k=2, use_tsc=True)
cached, cache = model.forward_cached(tokens, top_k=2, use_tsc=True)
elapsed = time.perf_counter() - t0
diff = max_abs_nested(full, cached)
row = {
    "part": "independent_full_forward_parity",
    "seed": args.seed,
    "context": args.context,
    "batch": args.batch,
    "max_abs_diff": diff,
    "passed": diff < 1e-10,
    "elapsed_seconds": elapsed,
}
append_csv(Path(__file__).resolve().parents[1] / "results" / "parity.csv", row)
print(json.dumps(row, indent=2))
