#!/usr/bin/env python3
import argparse, json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from odyssey_v39_pipeline.numeric_models import Config, TinyV39Independent, TinyTransformerKV, make_tokens, pseudo_loss
from odyssey_v39_pipeline.csv_utils import append_csv

ap = argparse.ArgumentParser()
ap.add_argument("--contexts", default="8,16")
ap.add_argument("--seeds", default="1")
ap.add_argument("--batch", type=int, default=2)

ap.add_argument("--smoke", action="store_true")
ap.add_argument("--hidden", type=int, default=8)
ap.add_argument("--states", type=int, default=3)
ap.add_argument("--rank", type=int, default=4)
ap.add_argument("--intermediate", type=int, default=32)

args = ap.parse_args()
contexts = [4] if args.smoke else [int(x) for x in args.contexts.split(",") if x]
seeds = [1] if args.smoke else [int(x) for x in args.seeds.split(",") if x]

out = Path(__file__).resolve().parents[1] / "results" / "cached_decode.csv"
rows=[]
for seed in seeds:
    for ctx in contexts:
        cfg = Config(hidden=args.hidden, states=args.states, rank=args.rank, intermediate=args.intermediate, max_pos=max(64, ctx+4))
        toks = make_tokens(args.batch, ctx, cfg.vocab, seed+200)
        v39 = TinyV39Independent(cfg, seed=seed)
        tr = TinyTransformerKV(cfg, seed=seed)
        t0=time.perf_counter(); vlogits, vcache = v39.forward_cached(toks, top_k=1, use_tsc=False); vt=time.perf_counter()-t0
        t0=time.perf_counter(); tlogits, tcache = tr.forward_cached(toks); tt=time.perf_counter()-t0
        row = {
            "seed": seed,
            "context": ctx,
            "batch": args.batch,
            "v39_seconds": vt,
            "transformer_kv_seconds": tt,
            "v39_tokens_per_sec": args.batch*ctx/max(vt,1e-12),
            "transformer_tokens_per_sec": args.batch*ctx/max(tt,1e-12),
            "v39_speedup_vs_transformer_kv": tt/max(vt,1e-12),
            "v39_cache_elements": vcache.elements(),
            "transformer_kv_elements": tcache.elements(),
            "cache_reduction_percent": 100.0*(1.0 - vcache.elements()/max(tcache.elements(),1)),
            "v39_proxy_loss": pseudo_loss(vlogits, toks),
            "transformer_proxy_loss": pseudo_loss(tlogits, toks),
            "v39_params": v39.params(),
            "transformer_params": tr.params(),
        }
        append_csv(out,row); rows.append(row)
print(json.dumps({"rows": rows}, indent=2))
