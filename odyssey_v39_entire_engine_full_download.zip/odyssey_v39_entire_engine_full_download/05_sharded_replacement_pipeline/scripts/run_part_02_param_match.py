#!/usr/bin/env python3
import argparse, json, sys, itertools
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from odyssey_v39_pipeline.numeric_models import Config, TinyV39Independent, TinyTransformerKV
from odyssey_v39_pipeline.csv_utils import append_csv

ap = argparse.ArgumentParser()
ap.add_argument("--smoke", action="store_true")
args = ap.parse_args()

hidden_vals = [8, 16] if args.smoke else [8,16,24,32]
state_vals = [2,3] if args.smoke else [2,3,4,6,8]
rank_vals = [2,4] if args.smoke else [2,4,8,12,16]
inter_vals = [16,32] if args.smoke else [16,32,64,96]

best = None
rows = []
for h,s,r,i in itertools.product(hidden_vals,state_vals,rank_vals,inter_vals):
    cfg = Config(hidden=h, states=s, rank=r, intermediate=i)
    v = TinyV39Independent(cfg, seed=1)
    t = TinyTransformerKV(cfg, seed=1)
    vp, tp = v.params(), t.params()
    ratio = vp / max(tp,1)
    delta = abs(ratio - 1.0)
    row = {"hidden":h,"states":s,"rank":r,"intermediate":i,"v39_params":vp,"transformer_params":tp,"ratio":ratio,"abs_delta":delta}
    rows.append(row)
    if best is None or delta < best["abs_delta"]:
        best = row

out = Path(__file__).resolve().parents[1] / "results" / "param_match.csv"
for row in sorted(rows, key=lambda x: x["abs_delta"])[:20]:
    append_csv(out, row)
print(json.dumps({"best": best, "top_rows_written": min(20, len(rows))}, indent=2))
