from .numeric_models import Config, TinyV39Independent, TinyTransformerKV
