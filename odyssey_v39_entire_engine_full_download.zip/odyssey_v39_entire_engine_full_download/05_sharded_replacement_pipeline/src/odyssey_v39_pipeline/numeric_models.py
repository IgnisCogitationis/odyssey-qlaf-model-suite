import math, random, time
from dataclasses import dataclass

@dataclass
class Config:
    vocab: int = 32
    hidden: int = 16
    layers: int = 1
    states: int = 3
    rank: int = 4
    intermediate: int = 32
    max_pos: int = 512

def zeros(n):
    return [0.0] * n

def rand_vec(rng, n, scale):
    return [(rng.random() * 2.0 - 1.0) * scale for _ in range(n)]

def rand_mat(rng, rows, cols, scale):
    return [rand_vec(rng, cols, scale) for _ in range(rows)]

def dot(a, b):
    return sum(x*y for x, y in zip(a, b))

def add(a, b):
    return [x+y for x,y in zip(a,b)]

def scale(a, s):
    return [x*s for x in a]

def matvec(W, x):
    return [dot(row, x) for row in W]

def softmax(xs):
    m = max(xs)
    ex = [math.exp(x-m) for x in xs]
    s = sum(ex) or 1.0
    return [v/s for v in ex]

def layer_norm(x, eps=1e-5):
    m = sum(x)/len(x)
    v = sum((a-m)*(a-m) for a in x)/len(x)
    inv = 1.0 / math.sqrt(v + eps)
    return [(a-m)*inv for a in x]

def silu(x):
    return x / (1.0 + math.exp(-x))

def max_abs_nested(a, b):
    if isinstance(a, list) and a and isinstance(a[0], list):
        return max(max_abs_nested(x, y) for x, y in zip(a, b))
    return max(abs(x-y) for x,y in zip(a,b)) if a else 0.0

def make_tokens(batch, length, vocab, seed):
    rng = random.Random(seed)
    x = [[rng.randrange(vocab) for _ in range(length)] for _ in range(batch)]
    for row in x:
        for t in range(2, length):
            row[t] = (row[t-1] + row[t-2] + (t % 5)) % vocab
    return x

class V39Cache:
    def __init__(self, cfg, batch):
        self.cfg = cfg
        self.batch = batch
        self.summary = [[[[0.0 for _ in range(cfg.rank)] for _ in range(cfg.states)] for _ in range(cfg.layers)] for _ in range(batch)]
        self.weight = [[[0.0 for _ in range(cfg.states)] for _ in range(cfg.layers)] for _ in range(batch)]
        self.position = 0
    def elements(self):
        return self.batch*self.cfg.layers*self.cfg.states*self.cfg.rank + self.batch*self.cfg.layers*self.cfg.states
    def reset(self):
        for b in range(self.batch):
            for l in range(self.cfg.layers):
                for s in range(self.cfg.states):
                    self.weight[b][l][s] = 0.0
                    for r in range(self.cfg.rank):
                        self.summary[b][l][s][r] = 0.0
        self.position = 0

class TinyV39Independent:
    def __init__(self, cfg, seed=0):
        self.cfg = cfg
        rng = random.Random(seed)
        V,H,L,S,R,I = cfg.vocab,cfg.hidden,cfg.layers,cfg.states,cfg.rank,cfg.intermediate
        self.emb = rand_mat(rng, V, H, 0.2)
        self.pos = rand_mat(rng, cfg.max_pos, H, 0.05)
        self.route = [[rand_vec(rng, H, 0.08) for _ in range(S)] for _ in range(L)]
        self.to_rank = [rand_mat(rng, R, H, 0.08) for _ in range(L)]
        self.from_state = [rand_mat(rng, H, S*R, 0.08) for _ in range(L)]
        self.tsc = [rand_mat(rng, H, H, 0.03) for _ in range(L)]
        self.mlp1 = [rand_mat(rng, I, H, 0.06) for _ in range(L)]
        self.mlp2 = [rand_mat(rng, H, I, 0.06) for _ in range(L)]
        self.head = rand_mat(rng, V, H, 0.08)

    def token_hidden(self, tok, pos):
        return add(self.emb[tok], self.pos[pos])

    def layer_step(self, x, cache, b, li, top_k=1, use_tsc=True):
        cfg = self.cfg
        xn = layer_norm(x)
        probs = softmax([dot(self.route[li][s], xn) for s in range(cfg.states)])
        ids = sorted(range(cfg.states), key=lambda i: probs[i], reverse=True)[:top_k]
        vals = [probs[i] for i in ids]
        denom = sum(vals) or 1.0
        vals = [v/denom for v in vals]
        z = matvec(self.to_rank[li], xn)
        for sid, w in zip(ids, vals):
            old_w = cache.weight[b][li][sid]
            new_w = old_w + w
            old = cache.summary[b][li][sid]
            cache.summary[b][li][sid] = [(old[r]*old_w + z[r]*w)/max(new_w,1e-8) for r in range(cfg.rank)]
            cache.weight[b][li][sid] = new_w
        flat = []
        total_w = max(sum(cache.weight[b][li]), 1e-8)
        for s in range(cfg.states):
            sw = cache.weight[b][li][s] / total_w
            flat.extend([v * sw for v in cache.summary[b][li][s]])
        y = add(x, matvec(self.from_state[li], flat))
        if use_tsc:
            y = add(y, scale(matvec(self.tsc[li], layer_norm(y)), 0.10))
        h1 = [silu(v) for v in matvec(self.mlp1[li], layer_norm(y))]
        y = add(y, matvec(self.mlp2[li], h1))
        return y

    def decode_step(self, toks, cache, top_k=1, use_tsc=True):
        logits = []
        for b,tok in enumerate(toks):
            x = self.token_hidden(tok, cache.position)
            for li in range(self.cfg.layers):
                x = self.layer_step(x, cache, b, li, top_k=top_k, use_tsc=use_tsc)
            logits.append(matvec(self.head, layer_norm(x)))
        cache.position += 1
        return logits, cache

    def forward_cached(self, batch_tokens, top_k=2, use_tsc=True):
        B,T = len(batch_tokens), len(batch_tokens[0])
        cache = V39Cache(self.cfg, B)
        outs = []
        for t in range(T):
            logits, cache = self.decode_step([batch_tokens[b][t] for b in range(B)], cache, top_k=top_k, use_tsc=use_tsc)
            outs.append(logits)
        return [[outs[t][b] for t in range(T)] for b in range(B)], cache

    def forward_full_independent(self, batch_tokens, top_k=2, use_tsc=True):
        # Independent implementation: local arrays, no decode_step call.
        B,T = len(batch_tokens), len(batch_tokens[0])
        cfg = self.cfg
        summary = [[[[0.0 for _ in range(cfg.rank)] for _ in range(cfg.states)] for _ in range(cfg.layers)] for _ in range(B)]
        weight = [[[0.0 for _ in range(cfg.states)] for _ in range(cfg.layers)] for _ in range(B)]
        outs = [[None for _ in range(T)] for _ in range(B)]
        for t in range(T):
            for b in range(B):
                x = self.token_hidden(batch_tokens[b][t], t)
                for li in range(cfg.layers):
                    xn = layer_norm(x)
                    probs = softmax([dot(self.route[li][s], xn) for s in range(cfg.states)])
                    ids = sorted(range(cfg.states), key=lambda i: probs[i], reverse=True)[:top_k]
                    vals = [probs[i] for i in ids]
                    denom = sum(vals) or 1.0
                    vals = [v/denom for v in vals]
                    z = matvec(self.to_rank[li], xn)
                    for sid,w in zip(ids, vals):
                        old_w = weight[b][li][sid]
                        new_w = old_w + w
                        old = summary[b][li][sid]
                        summary[b][li][sid] = [(old[r]*old_w + z[r]*w)/max(new_w,1e-8) for r in range(cfg.rank)]
                        weight[b][li][sid] = new_w
                    flat = []
                    total_w = max(sum(weight[b][li]), 1e-8)
                    for s in range(cfg.states):
                        sw = weight[b][li][s] / total_w
                        flat.extend([v*sw for v in summary[b][li][s]])
                    y = add(x, matvec(self.from_state[li], flat))
                    if use_tsc:
                        y = add(y, scale(matvec(self.tsc[li], layer_norm(y)), 0.10))
                    h1 = [silu(v) for v in matvec(self.mlp1[li], layer_norm(y))]
                    x = add(y, matvec(self.mlp2[li], h1))
                outs[b][t] = matvec(self.head, layer_norm(x))
        return outs

    def params(self):
        c = self.cfg
        return c.vocab*c.hidden + c.max_pos*c.hidden + c.layers*(c.states*c.hidden + c.rank*c.hidden + c.hidden*c.states*c.rank + c.hidden*c.hidden + c.intermediate*c.hidden + c.hidden*c.intermediate) + c.vocab*c.hidden

class KVCache:
    def __init__(self, cfg, batch, max_len):
        self.cfg = cfg
        self.batch = batch
        self.max_len = max_len
        self.k = [[[[0.0 for _ in range(cfg.hidden)] for _ in range(max_len)] for _ in range(cfg.layers)] for _ in range(batch)]
        self.v = [[[[0.0 for _ in range(cfg.hidden)] for _ in range(max_len)] for _ in range(cfg.layers)] for _ in range(batch)]
        self.position = 0
    def elements(self):
        return 2*self.batch*self.cfg.layers*self.max_len*self.cfg.hidden

class TinyTransformerKV:
    def __init__(self, cfg, seed=0):
        self.cfg = cfg
        rng = random.Random(seed)
        V,H,L,I = cfg.vocab,cfg.hidden,cfg.layers,cfg.intermediate
        self.emb = rand_mat(rng, V, H, 0.2)
        self.pos = rand_mat(rng, cfg.max_pos, H, 0.05)
        self.q = [rand_mat(rng, H, H, 0.06) for _ in range(L)]
        self.k = [rand_mat(rng, H, H, 0.06) for _ in range(L)]
        self.v = [rand_mat(rng, H, H, 0.06) for _ in range(L)]
        self.o = [rand_mat(rng, H, H, 0.06) for _ in range(L)]
        self.mlp1 = [rand_mat(rng, I, H, 0.06) for _ in range(L)]
        self.mlp2 = [rand_mat(rng, H, I, 0.06) for _ in range(L)]
        self.head = rand_mat(rng, V, H, 0.08)

    def token_hidden(self, tok, pos):
        return add(self.emb[tok], self.pos[pos])

    def decode_step(self, toks, cache):
        cfg = self.cfg
        logits = []
        pos = cache.position
        for b,tok in enumerate(toks):
            x = self.token_hidden(tok, pos)
            for li in range(cfg.layers):
                xn = layer_norm(x)
                q = matvec(self.q[li], xn)
                k = matvec(self.k[li], xn)
                v = matvec(self.v[li], xn)
                cache.k[b][li][pos] = k
                cache.v[b][li][pos] = v
                scores = [dot(q, cache.k[b][li][j]) / math.sqrt(cfg.hidden) for j in range(pos+1)]
                probs = softmax(scores)
                ctx = zeros(cfg.hidden)
                for j,p in enumerate(probs):
                    ctx = add(ctx, scale(cache.v[b][li][j], p))
                y = add(x, matvec(self.o[li], ctx))
                h1 = [silu(vv) for vv in matvec(self.mlp1[li], layer_norm(y))]
                x = add(y, matvec(self.mlp2[li], h1))
            logits.append(matvec(self.head, layer_norm(x)))
        cache.position += 1
        return logits, cache

    def forward_cached(self, batch_tokens):
        B,T = len(batch_tokens), len(batch_tokens[0])
        cache = KVCache(self.cfg, B, max(T, 1))
        outs = []
        for t in range(T):
            logits, cache = self.decode_step([batch_tokens[b][t] for b in range(B)], cache)
            outs.append(logits)
        return [[outs[t][b] for t in range(T)] for b in range(B)], cache

    def params(self):
        c = self.cfg
        return c.vocab*c.hidden + c.max_pos*c.hidden + c.layers*(4*c.hidden*c.hidden + c.intermediate*c.hidden + c.hidden*c.intermediate) + c.vocab*c.hidden

def pseudo_loss(logits, tokens):
    # cheap deterministic proxy: negative log prob of next token.
    total = 0.0
    count = 0
    for b,row in enumerate(tokens):
        for t in range(len(row)-1):
            probs = softmax(logits[b][t])
            total -= math.log(max(probs[row[t+1]], 1e-12))
            count += 1
    return total / max(count, 1)
