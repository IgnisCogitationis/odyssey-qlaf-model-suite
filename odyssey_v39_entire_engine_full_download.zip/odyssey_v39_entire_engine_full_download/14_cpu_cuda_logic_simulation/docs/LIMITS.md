# Limits of CPU CUDA Simulation

A CPU can simulate the math and indexing of a CUDA kernel, but not the hardware.

CPU simulation can catch:
- transposed indexing bugs
- wrong flat index formula
- wrong selected-state update
- wrong denominator
- wrong active state selection
- wrong output projection layout

CPU simulation cannot catch:
- nvcc compile errors
- extension ABI errors
- CUDA illegal memory access
- race conditions from incorrect synchronization
- warp-level behavior
- GPU floating point differences
- launch overhead
- real latency

Therefore the next true gate remains real CUDA parity.
