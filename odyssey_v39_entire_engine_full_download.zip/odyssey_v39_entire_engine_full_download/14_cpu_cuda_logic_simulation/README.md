# Odyssey V39 CPU CUDA-Logic Simulation

This is the strongest CPU-side substitute for a CUDA parity check.

It fuzzes the intended CUDA top-1 decode kernel logic over many shapes and seeds:
- batch sizes
- hidden sizes
- state counts
- rank sizes
- randomized pseudo-thread copy schedules
- route/update/readout indexing

It does **not** prove:
- CUDA build
- CUDA device numerics
- warp/thread synchronization behavior
- GPU performance

It only proves that the intended CUDA indexing/math mirrors the reference under CPU simulation.
