import math
import time
import random
from dataclasses import dataclass, asdict

def zeros(shape):
    if len(shape) == 1:
        return [0.0 for _ in range(shape[0])]
    return [zeros(shape[1:]) for _ in range(shape[0])]

def randn(rng, shape, scale=0.02):
    if len(shape) == 1:
        return [(rng.random() * 2.0 - 1.0) * scale for _ in range(shape[0])]
    return [randn(rng, shape[1:], scale) for _ in range(shape[0])]

def dot(a, b):
    return sum(x*y for x, y in zip(a, b))

def add(a, b):
    return [x+y for x, y in zip(a, b)]

def sub(a, b):
    return [x-y for x, y in zip(a, b)]

def mul_scalar(a, s):
    return [x*s for x in a]

def softmax(xs):
    m = max(xs)
    ex = [math.exp(x-m) for x in xs]
    s = sum(ex)
    return [x/s for x in ex]

def topk(xs, k):
    return sorted(range(len(xs)), key=lambda i: xs[i], reverse=True)[:k]

def layer_norm(x, eps=1e-5):
    n = len(x)
    mean = sum(x) / n
    var = sum((v - mean) ** 2 for v in x) / n
    inv = 1.0 / math.sqrt(var + eps)
    return [(v - mean) * inv for v in x]

def matvec(W, x):
    return [dot(row, x) for row in W]

def silu(x):
    return x / (1.0 + math.exp(-x))

def max_abs_nested(a, b):
    if isinstance(a, list) and a and isinstance(a[0], list):
        return max(max_abs_nested(x, y) for x, y in zip(a, b))
    if isinstance(a, list):
        return max(abs(x-y) for x, y in zip(a, b)) if a else 0.0
    return abs(a-b)

@dataclass
class Config:
    vocab: int = 19
    hidden: int = 8
    layers: int = 1
    states: int = 3
    rank: int = 4
    max_pos: int = 32
    top1_threshold: float = 0.55
    tsc_scale: float = 0.10

class Cache:
    def __init__(self, cfg, batch):
        self.cfg = cfg
        self.batch = batch
        self.state_summary = zeros((batch, cfg.layers, cfg.states, cfg.rank))
        self.state_weight = zeros((batch, cfg.layers, cfg.states))
        self.position = 0
        self.valid = True

    def clone(self):
        import copy
        c = Cache(self.cfg, self.batch)
        c.state_summary = copy.deepcopy(self.state_summary)
        c.state_weight = copy.deepcopy(self.state_weight)
        c.position = self.position
        c.valid = self.valid
        return c

    def reset(self):
        self.state_summary = zeros((self.batch, self.cfg.layers, self.cfg.states, self.cfg.rank))
        self.state_weight = zeros((self.batch, self.cfg.layers, self.cfg.states))
        self.position = 0
        self.valid = True

class TinyV39:
    def __init__(self, cfg, seed=0):
        self.cfg = cfg
        rng = random.Random(seed)
        H, V, L, S, R = cfg.hidden, cfg.vocab, cfg.layers, cfg.states, cfg.rank
        self.emb = randn(rng, (V, H), 0.20)
        self.pos = randn(rng, (cfg.max_pos, H), 0.05)
        self.route = randn(rng, (L, S, H), 0.10)
        self.to_rank = randn(rng, (L, R, H), 0.10)
        self.from_state = randn(rng, (L, H, S*R), 0.10)
        self.tsc = randn(rng, (L, H, H), 0.04)
        self.mlp1 = randn(rng, (L, 2*H, H), 0.08)
        self.mlp2 = randn(rng, (L, H, 2*H), 0.08)
        self.head = randn(rng, (V, H), 0.10)

    def token_hidden(self, token, pos):
        return add(self.emb[token], self.pos[pos])

    def layer_step(self, x, cache, b, li, top_k=1, use_tsc=True):
        cfg = self.cfg
        xn = layer_norm(x)
        route_logits = [dot(self.route[li][s], xn) for s in range(cfg.states)]
        route_probs = softmax(route_logits)
        ids = topk(route_probs, top_k)
        vals = [route_probs[i] for i in ids]
        denom_vals = sum(vals) or 1.0
        vals = [v/denom_vals for v in vals]
        z = matvec(self.to_rank[li], xn)

        for sid, w in zip(ids, vals):
            old_w = cache.state_weight[b][li][sid]
            new_w = old_w + w
            old = cache.state_summary[b][li][sid]
            cache.state_summary[b][li][sid] = [(old[j]*old_w + z[j]*w) / max(new_w, 1e-8) for j in range(cfg.rank)]
            cache.state_weight[b][li][sid] = new_w

        flat = []
        total_w = max(sum(cache.state_weight[b][li]), 1e-8)
        for s in range(cfg.states):
            weight = cache.state_weight[b][li][s] / total_w
            flat.extend([v * weight for v in cache.state_summary[b][li][s]])
        mixed = matvec(self.from_state[li], flat)
        y = add(x, mixed)

        if use_tsc:
            corr = matvec(self.tsc[li], layer_norm(y))
            y = add(y, mul_scalar(corr, cfg.tsc_scale))

        h1 = [silu(v) for v in matvec(self.mlp1[li], layer_norm(y))]
        y = add(y, matvec(self.mlp2[li], h1))
        return y, ids, max(route_probs)

    def decode_step(self, tokens, cache, top_k=1, use_tsc=True):
        assert cache.valid
        batch = len(tokens)
        logits = []
        routes = []
        confs = []
        for b in range(batch):
            x = self.token_hidden(tokens[b], cache.position)
            route_b = []
            conf_b = []
            for li in range(self.cfg.layers):
                x, ids, conf = self.layer_step(x, cache, b, li, top_k=top_k, use_tsc=use_tsc)
                route_b.append(ids)
                conf_b.append(conf)
            logits.append(matvec(self.head, layer_norm(x)))
            routes.append(route_b)
            confs.append(conf_b)
        cache.position += 1
        return logits, cache, {"routes": routes, "confidence": confs, "top_k": top_k}

    def forward_full(self, batch_tokens, top_k=1, use_tsc=True):
        B = len(batch_tokens)
        T = len(batch_tokens[0])
        cache = Cache(self.cfg, B)
        all_logits = []
        for t in range(T):
            step_tokens = [batch_tokens[b][t] for b in range(B)]
            logits, cache, _ = self.decode_step(step_tokens, cache, top_k=top_k, use_tsc=use_tsc)
            all_logits.append(logits)
        # Return [B,T,V]
        return [[all_logits[t][b] for t in range(T)] for b in range(B)]

    def prefill_then_decode(self, batch_tokens, top_k=1, use_tsc=True):
        B = len(batch_tokens)
        T = len(batch_tokens[0])
        cache = Cache(self.cfg, B)
        all_logits = []
        for t in range(T):
            step_tokens = [batch_tokens[b][t] for b in range(B)]
            logits, cache, _ = self.decode_step(step_tokens, cache, top_k=top_k, use_tsc=use_tsc)
            all_logits.append(logits)
        return [[all_logits[t][b] for t in range(T)] for b in range(B)], cache

    def aion_decode_step(self, tokens, cache, use_tsc=True):
        # Probe top-1 confidence without committing by using a cloned cache.
        probe = cache.clone()
        _, _, info = self.decode_step(tokens, probe, top_k=1, use_tsc=use_tsc)
        min_conf = min(min(row) for row in info["confidence"])
        top_k = 2 if min_conf < self.cfg.top1_threshold else 1
        return self.decode_step(tokens, cache, top_k=top_k, use_tsc=use_tsc)

class TinyTransformer:
    def __init__(self, cfg, seed=0):
        self.cfg = cfg
        rng = random.Random(seed)
        H, V = cfg.hidden, cfg.vocab
        self.emb = randn(rng, (V, H), 0.20)
        self.pos = randn(rng, (cfg.max_pos, H), 0.05)
        self.q = randn(rng, (H, H), 0.08)
        self.k = randn(rng, (H, H), 0.08)
        self.v = randn(rng, (H, H), 0.08)
        self.o = randn(rng, (H, H), 0.08)
        self.mlp1 = randn(rng, (2*H, H), 0.08)
        self.mlp2 = randn(rng, (H, 2*H), 0.08)
        self.head = randn(rng, (V, H), 0.10)

    def forward_full(self, batch_tokens):
        B = len(batch_tokens)
        T = len(batch_tokens[0])
        outputs = []
        for b in range(B):
            hs = [add(self.emb[batch_tokens[b][t]], self.pos[t]) for t in range(T)]
            seq_logits = []
            for t in range(T):
                q = matvec(self.q, layer_norm(hs[t]))
                scores = []
                vals = []
                for j in range(t+1):
                    kj = matvec(self.k, layer_norm(hs[j]))
                    vj = matvec(self.v, layer_norm(hs[j]))
                    scores.append(dot(q, kj) / math.sqrt(self.cfg.hidden))
                    vals.append(vj)
                probs = softmax(scores)
                ctx = [0.0] * self.cfg.hidden
                for p, vj in zip(probs, vals):
                    ctx = add(ctx, mul_scalar(vj, p))
                y = add(hs[t], matvec(self.o, ctx))
                h1 = [silu(v) for v in matvec(self.mlp1, layer_norm(y))]
                y = add(y, matvec(self.mlp2, h1))
                seq_logits.append(matvec(self.head, layer_norm(y)))
            outputs.append(seq_logits)
        return outputs

def make_tokens(batch=3, length=8, vocab=19, seed=123):
    rng = random.Random(seed)
    return [[rng.randrange(vocab) for _ in range(length)] for _ in range(batch)]

def run_correctness_gates():
    cfg = Config()
    model = TinyV39(cfg, seed=10)
    tokens = make_tokens(3, 8, cfg.vocab, seed=11)

    full = model.forward_full(tokens, top_k=2, use_tsc=False)
    cached, cache = model.prefill_then_decode(tokens, top_k=2, use_tsc=False)
    parity_diff = max_abs_nested(full, cached)

    prefix = make_tokens(2, 5, cfg.vocab, seed=12)
    suffix_a = make_tokens(2, 4, cfg.vocab, seed=13)
    suffix_b = make_tokens(2, 4, cfg.vocab, seed=14)
    seq_a = [prefix[i] + suffix_a[i] for i in range(2)]
    seq_b = [prefix[i] + suffix_b[i] for i in range(2)]
    log_a = model.forward_full(seq_a, top_k=2, use_tsc=False)
    log_b = model.forward_full(seq_b, top_k=2, use_tsc=False)
    future_diff = max_abs_nested([row[:5] for row in log_a], [row[:5] for row in log_b])

    c = Cache(cfg, 2)
    c.state_summary[0][0][0][0] = 9.0
    c.state_weight[0][0][0] = 3.0
    c.position = 7
    c.reset()
    reset_ok = c.position == 0 and c.valid and max_abs_nested(c.state_summary, zeros((2, cfg.layers, cfg.states, cfg.rank))) == 0.0 and max_abs_nested(c.state_weight, zeros((2, cfg.layers, cfg.states))) == 0.0

    batch_logits = model.forward_full(tokens, top_k=2, use_tsc=False)
    single_logits = []
    for row in tokens:
        single_logits.append(model.forward_full([row], top_k=2, use_tsc=False)[0])
    batch_diff = max_abs_nested(batch_logits, single_logits)

    cache1 = Cache(cfg, 2)
    cache2 = Cache(cfg, 2)
    route_shape_ok = True
    top2_distinct = True
    for t in range(6):
        step = [tokens[b][t] for b in range(2)]
        _, cache1, info1 = model.decode_step(step, cache1, top_k=1, use_tsc=False)
        _, cache2, info2 = model.decode_step(step, cache2, top_k=2, use_tsc=False)
        for b in range(2):
            for li in range(cfg.layers):
                route_shape_ok = route_shape_ok and len(info1["routes"][b][li]) == 1 and len(info2["routes"][b][li]) == 2
                top2_distinct = top2_distinct and (info2["routes"][b][li][0] != info2["routes"][b][li][1])
    cache_diff = max_abs_nested(cache1.state_summary, cache2.state_summary)

    results = [
        {"gate": "full_forward_vs_cached_decode", "passed": parity_diff < 1e-12, "max_abs_diff": parity_diff},
        {"gate": "no_future_leakage", "passed": future_diff < 1e-12, "max_abs_diff": future_diff},
        {"gate": "cache_reset", "passed": reset_ok},
        {"gate": "batch_equivalence", "passed": batch_diff < 1e-12, "max_abs_diff": batch_diff},
        {"gate": "top1_top2_routing_behavior", "passed": bool(route_shape_ok and top2_distinct and cache_diff > 0.0), "cache_diff": cache_diff, "route_shape_ok": route_shape_ok, "top2_distinct": top2_distinct},
    ]
    return {"section": "correctness_gates", "all_passed": all(r["passed"] for r in results), "results": results}

def run_tsc_parity():
    cfg = Config()
    model = TinyV39(cfg, seed=20)
    tokens = make_tokens(3, 8, cfg.vocab, seed=21)
    full = model.forward_full(tokens, top_k=2, use_tsc=True)
    cached, _ = model.prefill_then_decode(tokens, top_k=2, use_tsc=True)
    diff = max_abs_nested(full, cached)
    off = model.forward_full(tokens, top_k=2, use_tsc=False)
    on = model.forward_full(tokens, top_k=2, use_tsc=True)
    tsc_effect = max_abs_nested(off, on)
    return {
        "section": "tsc_parity",
        "passed": diff < 1e-12 and tsc_effect > 0.0,
        "max_abs_diff_full_vs_cached": diff,
        "tsc_effect_max_abs": tsc_effect,
    }

def run_aion_adaptive_parity():
    cfg = Config(top1_threshold=0.95)
    model = TinyV39(cfg, seed=30)
    tokens = make_tokens(2, 8, cfg.vocab, seed=31)
    cache = Cache(cfg, 2)
    topks = []
    for t in range(8):
        step = [tokens[b][t] for b in range(2)]
        _, cache, info = model.aion_decode_step(step, cache, use_tsc=True)
        topks.append(info["top_k"])
    adaptive_used_top2 = any(k == 2 for k in topks)
    cache_fixed = Cache(cfg, 2)
    for t in range(8):
        step = [tokens[b][t] for b in range(2)]
        _, cache_fixed, _ = model.decode_step(step, cache_fixed, top_k=1, use_tsc=True)
    diff = max_abs_nested(cache.state_summary, cache_fixed.state_summary)
    return {
        "section": "aion_adaptive_parity",
        "passed": adaptive_used_top2 and diff > 0.0,
        "topk_sequence": topks,
        "adaptive_vs_fixed_cache_diff": diff,
    }

def run_tiny_matched_benchmark():
    cfg = Config()
    tokens = make_tokens(4, 10, cfg.vocab, seed=41)
    v39 = TinyV39(cfg, seed=40)
    tr = TinyTransformer(cfg, seed=40)

    t0 = time.perf_counter()
    out_v39 = v39.forward_full(tokens, top_k=2, use_tsc=True)
    t1 = time.perf_counter()
    out_tr = tr.forward_full(tokens)
    t2 = time.perf_counter()

    # Not training; this is a shape/runtime smoke benchmark.
    return {
        "section": "tiny_matched_transformer_benchmark",
        "passed": len(out_v39) == len(out_tr) and len(out_v39[0]) == len(out_tr[0]),
        "v39_forward_seconds": t1 - t0,
        "transformer_forward_seconds": t2 - t1,
        "speed_ratio_v39_over_transformer": (t2 - t1) / max(t1 - t0, 1e-12),
        "note": "runtime smoke only; not quality training"
    }

def run_decode_speed_benchmark(steps=200):
    cfg = Config(max_pos=max(256, steps + 4))
    tokens = make_tokens(2, steps, cfg.vocab, seed=51)
    model = TinyV39(cfg, seed=50)

    c1 = Cache(cfg, 2)
    start = time.perf_counter()
    for t in range(steps):
        step = [tokens[b][t] for b in range(2)]
        model.decode_step(step, c1, top_k=1, use_tsc=False)
    top1_time = time.perf_counter() - start

    c2 = Cache(cfg, 2)
    start = time.perf_counter()
    for t in range(steps):
        step = [tokens[b][t] for b in range(2)]
        model.decode_step(step, c2, top_k=2, use_tsc=True)
    top2_time = time.perf_counter() - start

    return {
        "section": "decode_speed_benchmark",
        "passed": top1_time < top2_time,
        "steps": steps,
        "top1_seconds": top1_time,
        "top2_tsc_seconds": top2_time,
        "top1_speedup_vs_top2_tsc": top2_time / max(top1_time, 1e-12),
    }

def run_all():
    results = [
        run_correctness_gates(),
        run_tsc_parity(),
        run_aion_adaptive_parity(),
        run_tiny_matched_benchmark(),
        run_decode_speed_benchmark(),
    ]
    return {"all_passed": all(r.get("all_passed", r.get("passed", False)) for r in results), "results": results}

if __name__ == "__main__":
    import json
    print(json.dumps(run_all(), indent=2))
