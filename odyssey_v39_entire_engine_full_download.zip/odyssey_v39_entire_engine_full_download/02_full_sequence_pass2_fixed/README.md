# Odyssey V39 Full Sequence Pass 2

This package advances the requested sequence:

1. correctness gates;
2. TSC parity;
3. AION adaptive parity;
4. tiny matched Transformer benchmark;
5. decode speed benchmark;
6. CUDA top-1 decode kernel specification;
7. prefill kernel specification;
8. full Route B HF/server package specification.

This pass is intentionally CPU-reference-first and uses a tiny pure-Python/numeric harness so the correctness gates can run without relying on PyTorch startup. It is not a production engine and not a speed superiority claim.

The goal is to lock the mathematical/runtime contracts before CUDA.
