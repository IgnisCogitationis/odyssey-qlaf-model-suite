import json
from odyssey_v39_sequence import run_all

if __name__ == "__main__":
    print(json.dumps(run_all(), indent=2))
