# Pass 2 Fixed Patch Note

The initial Pass 2 local smoke reached the decode speed benchmark and failed because the benchmark used more decode positions than the tiny model's positional table.

Patch:
- decode speed benchmark now creates a config with `max_pos >= steps + 4`.

Local run exit status:
- 0

The output is stored in `LOCAL_SEQUENCE_RESULT.json`.
