# Correctness Gates

## Gate 1: full-forward vs cached-decode parity

The reference model uses the same causal step function for full forward and cached decode. This confirms that the cache path is not a separate, inconsistent algorithm.

## Gate 2: no-future-leakage

Two sequences with identical prefixes and different suffixes must produce identical prefix logits.

## Gate 3: cache reset

State summaries, state weights, and position must reset to zero/valid.

## Gate 4: batch equivalence

Running a batch must equal concatenating independent single-sequence runs.

## Gate 5: top-1/top-2 routing behavior

Top-1 and top-2 must produce structurally different route sets and different cache states.
