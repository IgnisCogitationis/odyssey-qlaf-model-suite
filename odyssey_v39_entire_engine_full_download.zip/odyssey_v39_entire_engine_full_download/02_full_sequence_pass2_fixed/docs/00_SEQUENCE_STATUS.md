# Sequence Status

Requested sequence:

1. correctness gates;
2. TSC parity;
3. AION adaptive parity;
4. tiny matched Transformer benchmark;
5. decode speed benchmark;
6. CUDA top-1 decode kernel;
7. prefill kernel;
8. full Route B HF/server package.

## This pass

Implemented and runnable in reference form:
- correctness gates;
- TSC parity;
- AION adaptive parity;
- tiny matched Transformer runtime smoke;
- decode speed smoke.

Specified but not compiled:
- CUDA top-1 decode kernel;
- prefill kernel;
- full Route B HF/server package.

## Why this order is correct

Speed work before parity is dangerous. The correct sequence is:
- prove cached decode equals causal forward;
- prove TSC does not break parity;
- prove AION adaptive routing behaves;
- compare against tiny Transformer;
- then optimize decode;
- then move to CUDA.
