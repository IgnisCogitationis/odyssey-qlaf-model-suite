# Tiny Benchmark Plan

The included tiny benchmark is only a runtime smoke test. It does not train and does not establish quality.

Next required benchmark:

- synthetic or small local text dataset;
- matched V39 and Transformer parameter count;
- same tokenizer;
- same optimizer;
- same batch;
- same sequence length;
- same token budget;
- at least 3 seeds for smoke, 5 seeds for final.

Report:
- train loss;
- validation loss;
- tokens/sec;
- memory;
- decode speed;
- prefill speed.
