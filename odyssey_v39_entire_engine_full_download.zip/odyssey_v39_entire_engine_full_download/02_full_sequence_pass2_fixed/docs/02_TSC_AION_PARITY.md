# TSC and AION Parity

## TSC parity

TSC residual correction must preserve full-forward vs cached-decode parity when enabled.

It must also have a nonzero measurable effect, otherwise the branch is dead.

## AION adaptive parity

AION must be observable:
- top-1 during confident steps;
- top-2 during uncertainty;
- adaptive cache differs from fixed top-1.

This proves adaptive widening is wired before CUDA work begins.
