from odyssey_v39_sequence import run_all

def test_full_sequence_reference():
    report = run_all()
    assert report["all_passed"], report
