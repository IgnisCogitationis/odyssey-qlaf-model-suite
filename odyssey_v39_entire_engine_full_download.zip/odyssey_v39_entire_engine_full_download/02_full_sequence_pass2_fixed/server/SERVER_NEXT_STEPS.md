# Server Next Steps

After CUDA parity:

1. implement model loading;
2. prefill endpoint;
3. decode loop;
4. streaming response;
5. cache lifecycle;
6. request batching;
7. fallback isolation;
8. metrics endpoint;
9. Dockerfile;
10. benchmark script.
