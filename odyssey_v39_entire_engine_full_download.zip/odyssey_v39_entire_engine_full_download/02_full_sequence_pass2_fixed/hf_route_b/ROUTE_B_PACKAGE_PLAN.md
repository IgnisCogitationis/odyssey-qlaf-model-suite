# Route B HF/CUDA/Server Package Plan

## HF repo

Required:
- custom config;
- custom model;
- generation support;
- safetensors;
- tokenizer files;
- model card;
- trust_remote_code=True.

## CUDA wheel

Required:
- qlaf_decode_top1;
- qlaf_prefill;
- qlaf_route_select;
- qlaf_cache_update;
- optional tsc_residual.

## Server

Required:
- separate prefill and decode queues;
- cache owner;
- stream generation;
- batching;
- p50/p95 latency metrics;
- fallback isolation;
- refresh metrics.

## Deployment modes

1. fallback HF load;
2. accelerated local HF + CUDA wheel;
3. production Docker/custom server.
