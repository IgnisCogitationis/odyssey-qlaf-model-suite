# QLAF Prefill Kernel Specification

## Purpose

Build causal QLAF state cache for a prompt.

## Inputs

- embeddings or hidden states [B,T,H];
- route projection;
- rank projection;
- output projection;
- top-k prefill setting.

## Outputs

- logits or hidden states;
- final QLAF state cache;
- route statistics;
- confidence statistics.

## Required properties

- causal scan;
- no future leakage;
- top-2/top-4 state update;
- optional hierarchy promotion;
- parity against reference full forward.

## Optimization order

1. correctness scan;
2. tiled hidden/rank projection;
3. top-k route selection;
4. fused cache write;
5. persistent memory layout;
6. benchmark against Transformer prefill.
