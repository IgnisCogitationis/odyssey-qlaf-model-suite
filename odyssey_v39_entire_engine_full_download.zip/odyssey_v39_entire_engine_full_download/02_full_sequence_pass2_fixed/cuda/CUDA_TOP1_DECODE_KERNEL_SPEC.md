# CUDA Top-1 Decode Kernel Specification

## Purpose

Accelerate the already-correct cached top-1 decode path.

## Inputs

- token hidden vector;
- per-layer state summary;
- per-layer state weight;
- route projection;
- rank projection;
- output projection;
- optional TSC parameters.

## Outputs

- logits or hidden state;
- updated selected state summary;
- updated selected state weight;
- route confidence;
- active state id.

## Required properties

- one token per sequence step;
- batch-compatible;
- no full context read;
- no attention matrix;
- no KV cache;
- BF16/FP16 with FP32 accumulation;
- parity against Python/reference implementation.

## Optimization order

1. scalar correctness kernel;
2. vectorized rank update;
3. fused route + rank projection;
4. fused state readout;
5. graph-capture-compatible launch;
6. batch scheduler integration.
