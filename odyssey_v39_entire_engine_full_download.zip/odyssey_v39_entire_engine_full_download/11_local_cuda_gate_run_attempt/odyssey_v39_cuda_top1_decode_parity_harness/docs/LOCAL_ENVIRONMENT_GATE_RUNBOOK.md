# Local Environment Gate Runbook

## 1. Confirm CPU reference

```bash
bash scripts/run_cpu_reference.sh
```

Expected:

```text
passed: True
max_abs_y: 0.0
```

## 2. Run full local gate

```bash
bash scripts/run_local_cuda_gate.sh
```

This checks:
- CPU reference
- PyTorch import
- CUDA availability
- CUDA extension build if CUDA exists
- CUDA parity if build succeeds

Report:

```text
results/local_cuda_gate_report.json
```

## 3. Pass condition

The report must show:

```json
"parity_passed": true
```

And the parity output must satisfy:

```text
active_equal: true
max_abs_y <= 1e-4
max_abs_state <= 1e-4
max_abs_weight <= 1e-4
```

## 4. If parity passes

```bash
python3 scripts/make_timing_harness_if_parity_passed.py
PYTHONPATH=.:odyssey_v39_cuda_ext python3 scripts/run_cuda_top1_timing.py
```

## 5. If parity fails

Do not benchmark speed. Patch only `odyssey_v39_cuda/top1_decode.cu` for parity.
