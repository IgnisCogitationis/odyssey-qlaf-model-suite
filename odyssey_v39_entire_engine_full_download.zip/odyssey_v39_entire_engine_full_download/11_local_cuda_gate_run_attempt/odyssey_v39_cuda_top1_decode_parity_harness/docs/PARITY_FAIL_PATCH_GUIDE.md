# CUDA Parity Failure Patch Guide

If `scripts/run_local_cuda_gate.sh` reports `parity_passed: false`, do not run timing.

Patch only for numerical parity.

## Common failure modes

### 1. Build failure: `nvcc not found`

Install/use a CUDA-enabled PyTorch environment with CUDA toolkit available.

Check:

```bash
which nvcc
python3 - <<'PY'
import torch
print(torch.__version__)
print(torch.cuda.is_available())
print(torch.version.cuda)
PY
```

### 2. Import failure after build

Run from repo root with:

```bash
export PYTHONPATH=.:odyssey_v39_cuda_ext:$PYTHONPATH
python3 tests/test_cuda_top1_parity.py
```

### 3. `active_equal: false`

Patch route selection first. The CUDA kernel top-1 state must exactly match:

```python
active = torch.argmax(x @ route_weight.T, dim=-1)
```

Check:
- route_weight layout `[S, H]`
- x layout `[B, H]`
- no transposed indexing bug
- deterministic tie behavior

### 4. `max_abs_state` or `max_abs_weight` too high

Patch selected-state update:

```text
old_w = weight[b, active]
new_w = old_w + 1
state[b, active, r] = (old_state * old_w + z[r]) / new_w
weight[b, active] = new_w
```

Check:
- update weight after all rank entries are computed
- do not increment weight inside the rank loop more than once
- rank_weight layout `[R, H]`

### 5. `max_abs_y` too high but state/weight pass

Patch readout:

```text
flat[s,r] = new_state[s,r] * new_weight[s] / sum(new_weight)
y[h] = x[h] + sum_flat flat[k] * out_weight[h,k]
```

Check:
- out_weight layout `[H, S*R]`
- flat index is `s * R + r`
- denominator uses updated weights

## After patch

Run:

```bash
bash scripts/run_local_cuda_gate.sh
cat results/local_cuda_gate_report.json
```

Only if parity passes, create timing harness:

```bash
python3 scripts/make_timing_harness_if_parity_passed.py
```
