# Local Next Steps

```bash
bash scripts/run_local_cuda_gate.sh
cat results/local_cuda_gate_report.json
```

If parity passes:

```bash
python3 scripts/make_timing_harness_if_parity_passed.py
PYTHONPATH=.:odyssey_v39_cuda_ext python3 scripts/run_cuda_top1_timing.py
```

If parity fails, patch only for numerical parity.
