#!/usr/bin/env python3
import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

def run(cmd, timeout=None, env=None):
    start = time.perf_counter()
    try:
        p = subprocess.run(
            cmd,
            cwd=str(ROOT),
            env=env or os.environ.copy(),
            text=True,
            capture_output=True,
            timeout=timeout,
        )
        return {
            "cmd": " ".join(cmd),
            "returncode": p.returncode,
            "elapsed_seconds": time.perf_counter() - start,
            "stdout": p.stdout,
            "stderr": p.stderr,
            "ok": p.returncode == 0,
        }
    except Exception as e:
        return {
            "cmd": " ".join(cmd),
            "returncode": -1,
            "elapsed_seconds": time.perf_counter() - start,
            "stdout": "",
            "stderr": repr(e),
            "ok": False,
        }

def parse_json_loose(text):
    text = text.strip()
    if not text:
        return {}
    try:
        return json.loads(text)
    except Exception:
        pass
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        try:
            return json.loads(text[start:end+1])
        except Exception:
            return {}
    return {}

report = {
    "stage": "local_cuda_gate",
    "platform": platform.platform(),
    "python": sys.version,
    "steps": {},
    "cuda_available": False,
    "parity_passed": False,
    "next_allowed_step": "blocked",
}

# 1. CPU reference.
report["steps"]["cpu_reference"] = run([sys.executable, str(ROOT / "tests" / "test_reference_top1.py")], timeout=60)

# 2. PyTorch/CUDA probe.
torch_probe = """
import json
try:
    import torch
    print(json.dumps({
        "torch_imported": True,
        "torch_version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "torch_cuda_version": torch.version.cuda,
        "device_count": torch.cuda.device_count(),
        "device_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
    }, indent=2))
except Exception as e:
    print(json.dumps({"torch_imported": False, "error": repr(e)}, indent=2))
    raise
"""
probe = run([sys.executable, "-c", torch_probe], timeout=60)
report["steps"]["torch_cuda_probe"] = probe
probe_json = parse_json_loose(probe["stdout"])
report["torch_cuda"] = probe_json
report["cuda_available"] = bool(probe_json.get("cuda_available"))

# 3. Build and parity only if CUDA is available.
if report["cuda_available"] and report["steps"]["cpu_reference"]["ok"]:
    report["steps"]["cuda_build"] = run(["bash", str(ROOT / "scripts" / "build_cuda.sh")], timeout=300)
    if report["steps"]["cuda_build"]["ok"]:
        env = os.environ.copy()
        env["PYTHONPATH"] = f"{ROOT}:{ROOT / 'odyssey_v39_cuda_ext'}:" + env.get("PYTHONPATH", "")
        parity = run(["bash", str(ROOT / "scripts" / "run_cuda_parity.sh")], timeout=120, env=env)
        report["steps"]["cuda_parity"] = parity
        out = parity["stdout"] + "\n" + parity["stderr"]
        report["parity_raw_output"] = out
        lower = out.lower()
        report["parity_passed"] = (
            parity["ok"]
            and ("'passed': true" in lower or '"passed": true' in lower)
            and ("active_equal" not in lower or "'active_equal': true" in lower or '"active_equal": true' in lower)
        )
    else:
        report["steps"]["cuda_parity"] = {"skipped": True, "reason": "cuda_build_failed"}
else:
    report["steps"]["cuda_build"] = {"skipped": True, "reason": "cuda_unavailable_or_cpu_reference_failed"}
    report["steps"]["cuda_parity"] = {"skipped": True, "reason": "cuda_unavailable_or_cpu_reference_failed"}

if report["parity_passed"]:
    report["next_allowed_step"] = "cuda_top1_decode_timing_harness"
else:
    report["next_allowed_step"] = "patch_cuda_for_parity_only"

(RESULTS / "local_cuda_gate_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

print(json.dumps({
    "cpu_reference_ok": report["steps"]["cpu_reference"].get("ok"),
    "cuda_available": report["cuda_available"],
    "cuda_build_ok": report["steps"].get("cuda_build", {}).get("ok", False),
    "parity_passed": report["parity_passed"],
    "next_allowed_step": report["next_allowed_step"],
    "report": str(RESULTS / "local_cuda_gate_report.json"),
}, indent=2))
