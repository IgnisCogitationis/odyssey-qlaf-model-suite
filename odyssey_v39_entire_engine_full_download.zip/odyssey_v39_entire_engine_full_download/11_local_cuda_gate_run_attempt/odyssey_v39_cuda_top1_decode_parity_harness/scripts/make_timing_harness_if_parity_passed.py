#!/usr/bin/env python3
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
report_path = ROOT / "results" / "local_cuda_gate_report.json"
if not report_path.exists():
    raise SystemExit("Missing results/local_cuda_gate_report.json. Run bash scripts/run_local_cuda_gate.sh first.")

report = json.loads(report_path.read_text(encoding="utf-8"))
if not report.get("parity_passed"):
    raise SystemExit("CUDA parity did not pass. Timing harness remains blocked.")

timing = ROOT / "scripts" / "run_cuda_top1_timing.py"
timing.write_text("""#!/usr/bin/env python3
import json
import time
from pathlib import Path
import torch
from odyssey_v39_reference import make_inputs, qlaf_top1_decode_reference
import odyssey_v39_cuda

ROOT = Path(__file__).resolve().parents[1]

def bench(fn, warmup=5, trials=20):
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    vals = []
    for _ in range(trials):
        t0 = time.perf_counter()
        fn()
        torch.cuda.synchronize()
        vals.append(time.perf_counter() - t0)
    return vals

rows = []
for batch in [1, 2, 4, 8]:
    inp = make_inputs(batch=batch, hidden=8, states=3, rank=4, seed=123, device="cuda", dtype=torch.float32)

    def ref():
        return qlaf_top1_decode_reference(**inp)

    def cuda():
        return odyssey_v39_cuda.qlaf_top1_decode(
            inp["x"], inp["state_summary"], inp["state_weight"],
            inp["route_weight"], inp["rank_weight"], inp["out_weight"]
        )

    ref_vals = bench(ref)
    cuda_vals = bench(cuda)
    ref_mean = sum(ref_vals) / len(ref_vals)
    cuda_mean = sum(cuda_vals) / len(cuda_vals)
    rows.append({
        "batch": batch,
        "reference_mean_seconds": ref_mean,
        "cuda_mean_seconds": cuda_mean,
        "speedup": ref_mean / max(cuda_mean, 1e-12),
        "note": "parity-gated timing only; not optimized CUDA claim"
    })

out = {"rows": rows}
print(json.dumps(out, indent=2))
(ROOT / "results" / "cuda_top1_timing.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
""", encoding="utf-8")
timing.chmod(0o755)
print(json.dumps({"created": str(timing), "status": "timing_harness_created_after_parity"}))
