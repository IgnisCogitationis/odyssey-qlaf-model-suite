from odyssey_v39_pt.gates import run_correctness_gates, run_tsc_parity, run_aion_adaptive_parity

def test_correctness_gates_cpu():
    r = run_correctness_gates("cpu")
    assert r["all_passed"], r

def test_tsc_parity_cpu():
    r = run_tsc_parity("cpu")
    assert r["passed"], r

def test_aion_adaptive_cpu():
    r = run_aion_adaptive_parity("cpu")
    assert r["passed"], r
