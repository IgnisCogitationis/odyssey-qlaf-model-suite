# Next Steps

1. Run `python run_gates_only.py`.
2. Run `python run_all.py`.
3. Add Transformer KV-cache decode baseline.
4. Tighten parameter matching.
5. Run 3 seeds and output CSV.
6. Add CUDA top-1 decode only after PyTorch gates pass.
7. Add HF custom model wrapper and Route B server.
