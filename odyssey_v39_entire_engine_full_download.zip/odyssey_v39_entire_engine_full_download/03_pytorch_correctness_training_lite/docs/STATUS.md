# Status

This package provides the PyTorch bridge for Odyssey V39.

Included:
- QLAF causal cache correctness gates.
- TSC parity.
- AION adaptive routing parity.
- Tiny synthetic training benchmark.
- Decode speed smoke.
- Cache memory accounting.

Caution:
The decode benchmark compares against naive Transformer prefix recompute, not optimized KV-cache decode. The next fair step is a Transformer cached decode baseline.
