# Odyssey V39 PyTorch Correctness + Tiny Training Benchmark Lite

This is the PyTorch bridge artifact for:

- correctness gates;
- TSC parity;
- AION adaptive parity;
- tiny matched Transformer training benchmark;
- decode speed smoke;
- memory accounting.

The default benchmark settings are intentionally tiny so they can run locally first.
This is not a CUDA engine and not a final superiority claim.
