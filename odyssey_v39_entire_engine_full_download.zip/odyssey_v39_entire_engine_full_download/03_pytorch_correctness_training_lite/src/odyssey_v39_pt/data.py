import torch

def make_synthetic_batch(batch_size, seq_len, vocab_size, device="cpu", seed=None):
    if seed is not None:
        gen = torch.Generator(device="cpu")
        gen.manual_seed(seed)
        x = torch.randint(0, vocab_size, (batch_size, seq_len), generator=gen)
        x = x.to(device)
    else:
        x = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)
    for t in range(2, seq_len):
        x[:, t] = (x[:, t - 1] + x[:, t - 2] + (t % 5)) % vocab_size
    return x
