from dataclasses import dataclass
import torch

@dataclass
class QLAFCache:
    state_summary: torch.Tensor
    state_weight: torch.Tensor
    position: int = 0
    valid: bool = True

    @classmethod
    def empty(cls, batch_size, cfg, device=None, dtype=None):
        return cls(
            state_summary=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, cfg.state_rank, device=device, dtype=dtype),
            state_weight=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, device=device, dtype=dtype),
            position=0,
            valid=True,
        )

    def clone(self):
        return QLAFCache(self.state_summary.clone(), self.state_weight.clone(), int(self.position), bool(self.valid))

    def reset(self):
        self.state_summary.zero_()
        self.state_weight.zero_()
        self.position = 0
        self.valid = True

    def invalidate(self):
        self.valid = False

    def require_valid(self):
        if not self.valid:
            raise RuntimeError("QLAF cache is invalid")
