import time
import torch
from .config import TinyConfig
from .cache import QLAFCache
from .model_v39 import TinyOdysseyV39
from .model_transformer import TinyTransformerLM
from .data import make_synthetic_batch

def run_decode_speed_benchmark(device="cpu", steps=24, batch_size=2):
    torch.manual_seed(321)
    cfg = TinyConfig(max_positions=max(64, steps + 4))
    v39 = TinyOdysseyV39(cfg).to(device).eval()
    tr = TinyTransformerLM(cfg).to(device).eval()
    x = make_synthetic_batch(batch_size, steps, cfg.vocab_size, device=device, seed=322)

    with torch.no_grad():
        cache = QLAFCache.empty(batch_size, cfg, device=device, dtype=v39.embed.weight.dtype)
        start = time.perf_counter()
        for t in range(steps):
            v39.decode_step(x[:, t:t+1], cache, top_k=1, use_tsc=False)
        v39_top1 = time.perf_counter() - start

        start = time.perf_counter()
        for t in range(1, steps + 1):
            tr(x[:, :t])
        transformer_naive = time.perf_counter() - start

    return {
        "section": "decode_speed_benchmark",
        "passed": bool(v39_top1 < transformer_naive),
        "steps": steps,
        "v39_top1_seconds": v39_top1,
        "transformer_naive_prefix_seconds": transformer_naive,
        "v39_top1_vs_transformer_naive_speedup": transformer_naive / max(v39_top1, 1e-9),
        "note": "Transformer baseline is naive prefix recompute, not optimized KV-cache decode.",
    }
