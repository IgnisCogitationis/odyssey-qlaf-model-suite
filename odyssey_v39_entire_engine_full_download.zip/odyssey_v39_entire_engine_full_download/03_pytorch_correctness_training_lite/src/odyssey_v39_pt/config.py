from dataclasses import dataclass

@dataclass
class TinyConfig:
    vocab_size: int = 32
    hidden_size: int = 16
    num_layers: int = 1
    num_states: int = 3
    state_rank: int = 4
    max_positions: int = 64
    intermediate_size: int = 32
    tsc_scale: float = 0.10
    aion_confidence_threshold: float = 0.55
