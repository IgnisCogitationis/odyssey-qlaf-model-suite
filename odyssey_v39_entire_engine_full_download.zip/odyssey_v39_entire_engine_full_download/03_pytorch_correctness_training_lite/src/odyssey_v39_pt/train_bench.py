import time
import torch
from .config import TinyConfig
from .model_v39 import TinyOdysseyV39
from .model_transformer import TinyTransformerLM
from .data import make_synthetic_batch

def count_params(model):
    return sum(p.numel() for p in model.parameters())

def train_one(model, cfg, steps=8, batch_size=4, seq_len=12, lr=3e-3, device="cpu", is_v39=False):
    model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    losses = []
    start = time.perf_counter()
    for _ in range(steps):
        x = make_synthetic_batch(batch_size, seq_len, cfg.vocab_size, device=device)
        opt.zero_grad(set_to_none=True)
        out = model(x, labels=x, top_k=2, use_tsc=True) if is_v39 else model(x, labels=x)
        loss = out["loss"]
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        losses.append(float(loss.item()))
    elapsed = time.perf_counter() - start
    return {"initial_loss": losses[0], "final_loss": losses[-1], "loss_delta": losses[0] - losses[-1], "elapsed_seconds": elapsed, "losses": losses}

def eval_loss(model, cfg, device="cpu", is_v39=False):
    model.eval()
    vals = []
    with torch.no_grad():
        for i in range(2):
            x = make_synthetic_batch(4, 12, cfg.vocab_size, device=device, seed=100 + i)
            out = model(x, labels=x, top_k=2, use_tsc=True) if is_v39 else model(x, labels=x)
            vals.append(float(out["loss"].item()))
    return sum(vals) / len(vals)

def run_tiny_training_benchmark(device="cpu"):
    torch.manual_seed(123)
    cfg = TinyConfig()
    v39 = TinyOdysseyV39(cfg).to(device)
    torch.manual_seed(123)
    tr = TinyTransformerLM(cfg).to(device)
    v39_train = train_one(v39, cfg, device=device, is_v39=True)
    tr_train = train_one(tr, cfg, device=device, is_v39=False)
    v39_eval = eval_loss(v39, cfg, device=device, is_v39=True)
    tr_eval = eval_loss(tr, cfg, device=device, is_v39=False)
    return {
        "section": "tiny_matched_training_benchmark",
        "passed": bool(v39_train["final_loss"] < v39_train["initial_loss"] and tr_train["final_loss"] < tr_train["initial_loss"]),
        "v39_params": count_params(v39),
        "transformer_params": count_params(tr),
        "v39_train": v39_train,
        "transformer_train": tr_train,
        "v39_eval_loss": v39_eval,
        "transformer_eval_loss": tr_eval,
        "eval_loss_ratio_v39_over_transformer": v39_eval / max(tr_eval, 1e-9),
        "note": "tiny synthetic benchmark; not final quality evidence",
    }
