import torch
import torch.nn as nn
import torch.nn.functional as F

class TinyTransformerBlock(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        h = cfg.hidden_size
        heads = 4 if h % 4 == 0 else 1
        self.norm1 = nn.LayerNorm(h)
        self.attn = nn.MultiheadAttention(h, num_heads=heads, batch_first=True)
        self.norm2 = nn.LayerNorm(h)
        self.mlp = nn.Sequential(nn.Linear(h, cfg.intermediate_size), nn.SiLU(), nn.Linear(cfg.intermediate_size, h))

    def forward(self, x):
        T = x.size(1)
        mask = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
        q = self.norm1(x)
        y, _ = self.attn(q, q, q, attn_mask=mask, need_weights=False)
        x = x + y
        x = x + self.mlp(self.norm2(x))
        return x

class TinyTransformerLM(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
        self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
        self.layers = nn.ModuleList([TinyTransformerBlock(cfg) for _ in range(cfg.num_layers)])
        self.norm = nn.LayerNorm(cfg.hidden_size)
        self.lm_head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)

    def forward(self, input_ids, labels=None):
        B, T = input_ids.shape
        pos = torch.arange(T, device=input_ids.device).unsqueeze(0).expand(B, T)
        x = self.embed(input_ids) + self.pos(pos)
        for layer in self.layers:
            x = layer(x)
        logits = self.lm_head(self.norm(x))
        loss = None
        if labels is not None:
            loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
        return {"logits": logits, "loss": loss}
