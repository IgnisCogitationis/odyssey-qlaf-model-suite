import torch
from .config import TinyConfig
from .cache import QLAFCache
from .model_v39 import TinyOdysseyV39
from .data import make_synthetic_batch

def max_abs(a, b):
    return float((a - b).abs().max().item())

def run_correctness_gates(device="cpu"):
    torch.manual_seed(1)
    cfg = TinyConfig()
    model = TinyOdysseyV39(cfg).to(device).eval()
    x = make_synthetic_batch(2, 8, cfg.vocab_size, device=device, seed=2)

    with torch.no_grad():
        full = model.forward_full(x, top_k=2, use_tsc=False)
        cached, _, _ = model.forward_cached(x, top_k=2, use_tsc=False)
    parity_diff = max_abs(full, cached)

    prefix = make_synthetic_batch(2, 4, cfg.vocab_size, device=device, seed=3)
    suffix_a = make_synthetic_batch(2, 4, cfg.vocab_size, device=device, seed=4)
    suffix_b = make_synthetic_batch(2, 4, cfg.vocab_size, device=device, seed=5)
    with torch.no_grad():
        la = model.forward_full(torch.cat([prefix, suffix_a], dim=1), top_k=2, use_tsc=False)[:, :4]
        lb = model.forward_full(torch.cat([prefix, suffix_b], dim=1), top_k=2, use_tsc=False)[:, :4]
    future_diff = max_abs(la, lb)

    cache = QLAFCache.empty(2, cfg, device=device, dtype=torch.float32)
    cache.state_summary.normal_()
    cache.state_weight.uniform_()
    cache.position = 7
    cache.reset()
    reset_ok = cache.state_summary.abs().max().item() == 0.0 and cache.state_weight.abs().max().item() == 0.0 and cache.position == 0 and cache.valid

    with torch.no_grad():
        batch_logits = model.forward_full(x, top_k=2, use_tsc=False)
        single_logits = torch.cat([model.forward_full(x[i:i+1], top_k=2, use_tsc=False) for i in range(x.size(0))], dim=0)
    batch_diff = max_abs(batch_logits, single_logits)

    c1 = QLAFCache.empty(2, cfg, device=device, dtype=model.embed.weight.dtype)
    c2 = QLAFCache.empty(2, cfg, device=device, dtype=model.embed.weight.dtype)
    route_shape_ok, top2_distinct = True, True
    with torch.no_grad():
        for t in range(4):
            _, c1, info1 = model.decode_step(x[:, t:t+1], c1, top_k=1, use_tsc=False)
            _, c2, info2 = model.decode_step(x[:, t:t+1], c2, top_k=2, use_tsc=False)
            route_shape_ok = route_shape_ok and info1["route_ids"].shape[-1] == 1 and info2["route_ids"].shape[-1] == 2
            top2_distinct = top2_distinct and bool((info2["route_ids"][..., 0] != info2["route_ids"][..., 1]).all().item())
    cache_diff = float((c1.state_summary - c2.state_summary).abs().sum().item())

    results = [
        {"gate": "full_forward_vs_cached_decode", "passed": parity_diff < 1e-7, "max_abs_diff": parity_diff},
        {"gate": "no_future_leakage", "passed": future_diff < 1e-7, "max_abs_diff": future_diff},
        {"gate": "cache_reset", "passed": bool(reset_ok)},
        {"gate": "batch_equivalence", "passed": batch_diff < 1e-7, "max_abs_diff": batch_diff},
        {"gate": "top1_top2_routing_behavior", "passed": bool(route_shape_ok and top2_distinct and cache_diff > 0.0), "cache_diff": cache_diff},
    ]
    return {"section": "correctness_gates", "all_passed": all(r["passed"] for r in results), "results": results}

def run_tsc_parity(device="cpu"):
    torch.manual_seed(6)
    cfg = TinyConfig()
    model = TinyOdysseyV39(cfg).to(device).eval()
    x = make_synthetic_batch(2, 8, cfg.vocab_size, device=device, seed=7)
    with torch.no_grad():
        full = model.forward_full(x, top_k=2, use_tsc=True)
        cached, _, _ = model.forward_cached(x, top_k=2, use_tsc=True)
        off = model.forward_full(x, top_k=2, use_tsc=False)
    diff = max_abs(full, cached)
    effect = max_abs(full, off)
    return {"section": "tsc_parity", "passed": bool(diff < 1e-7 and effect > 0.0), "max_abs_diff": diff, "tsc_effect": effect}

def run_aion_adaptive_parity(device="cpu"):
    torch.manual_seed(8)
    cfg = TinyConfig(aion_confidence_threshold=0.99)
    model = TinyOdysseyV39(cfg).to(device).eval()
    x = make_synthetic_batch(2, 8, cfg.vocab_size, device=device, seed=9)
    cache = QLAFCache.empty(2, cfg, device=device, dtype=model.embed.weight.dtype)
    topks = []
    with torch.no_grad():
        for t in range(x.size(1)):
            _, cache, info = model.aion_decode_step(x[:, t:t+1], cache, use_tsc=True)
            topks.append(info["top_k"])
    used_top2 = any(k == 2 for k in topks)
    return {"section": "aion_adaptive_parity", "passed": bool(used_top2), "topk_sequence": topks}
