import torch
from .gates import run_correctness_gates, run_tsc_parity, run_aion_adaptive_parity
from .train_bench import run_tiny_training_benchmark
from .decode_bench import run_decode_speed_benchmark
from .memory import memory_table

def run_all(device=None, include_training=True):
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    results = [
        run_correctness_gates(device=device),
        run_tsc_parity(device=device),
        run_aion_adaptive_parity(device=device),
    ]
    if include_training:
        results.append(run_tiny_training_benchmark(device=device))
        results.append(run_decode_speed_benchmark(device=device))
    return {
        "device": device,
        "all_passed": all(r.get("all_passed", r.get("passed", False)) for r in results),
        "results": results,
        "memory_table": memory_table(),
    }
