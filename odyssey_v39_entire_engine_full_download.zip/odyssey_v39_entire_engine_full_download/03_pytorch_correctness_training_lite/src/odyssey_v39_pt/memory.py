def qlaf_cache_elements(batch, layers, states, rank):
    return batch * layers * states * rank + batch * layers * states

def transformer_kv_cache_elements(batch, layers, seq_len, hidden):
    return 2 * batch * layers * seq_len * hidden

def memory_table(batch=1, layers=1, states=3, rank=4, hidden=16, contexts=(128, 512, 1024, 2048, 4096, 8192)):
    q = qlaf_cache_elements(batch, layers, states, rank)
    rows = []
    for ctx in contexts:
        kv = transformer_kv_cache_elements(batch, layers, ctx, hidden)
        rows.append({"context": ctx, "qlaf_elements": q, "transformer_kv_elements": kv, "qlaf_reduction_percent": 100.0 * (1.0 - q / max(kv, 1))})
    return rows
