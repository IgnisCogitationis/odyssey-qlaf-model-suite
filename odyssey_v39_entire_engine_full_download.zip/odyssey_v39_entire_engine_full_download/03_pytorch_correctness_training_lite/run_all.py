import json
from odyssey_v39_pt.run_all import run_all

if __name__ == "__main__":
    print(json.dumps(run_all(), indent=2))
