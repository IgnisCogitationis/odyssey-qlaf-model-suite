import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch
from odyssey_v39_reference import make_inputs, qlaf_top1_decode_reference

def main():
    inp = make_inputs(seed=123)
    y1, s1, w1, a1 = qlaf_top1_decode_reference(**inp)
    y2, s2, w2, a2 = qlaf_top1_decode_reference(**inp)
    assert torch.equal(a1, a2)
    assert torch.max(torch.abs(y1 - y2)).item() == 0.0
    assert torch.max(torch.abs(s1 - s2)).item() == 0.0
    assert torch.max(torch.abs(w1 - w2)).item() == 0.0
    print({
        "passed": True,
        "active": a1.tolist(),
        "max_abs_y": float(torch.max(torch.abs(y1 - y2)).item())
    })

if __name__ == "__main__":
    main()
