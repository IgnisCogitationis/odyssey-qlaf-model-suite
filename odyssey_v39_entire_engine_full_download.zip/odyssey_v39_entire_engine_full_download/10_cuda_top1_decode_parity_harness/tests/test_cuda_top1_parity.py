import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "odyssey_v39_cuda_ext"))

import torch
from odyssey_v39_reference import make_inputs, qlaf_top1_decode_reference

def main():
    if not torch.cuda.is_available():
        print({"passed": False, "reason": "cuda_not_available"})
        return

    import odyssey_v39_cuda

    inp = make_inputs(seed=123, device="cuda", dtype=torch.float32)
    y_ref, s_ref, w_ref, a_ref = qlaf_top1_decode_reference(**inp)

    y_cuda, s_cuda, w_cuda, a_cuda = odyssey_v39_cuda.qlaf_top1_decode(
        inp["x"],
        inp["state_summary"],
        inp["state_weight"],
        inp["route_weight"],
        inp["rank_weight"],
        inp["out_weight"],
    )

    max_y = torch.max(torch.abs(y_ref - y_cuda)).item()
    max_s = torch.max(torch.abs(s_ref - s_cuda)).item()
    max_w = torch.max(torch.abs(w_ref - w_cuda)).item()
    active_equal = torch.equal(a_ref, a_cuda)

    passed = active_equal and max_y <= 1e-4 and max_s <= 1e-4 and max_w <= 1e-4
    print({
        "passed": bool(passed),
        "active_equal": bool(active_equal),
        "max_abs_y": float(max_y),
        "max_abs_state": float(max_s),
        "max_abs_weight": float(max_w),
    })

if __name__ == "__main__":
    main()
