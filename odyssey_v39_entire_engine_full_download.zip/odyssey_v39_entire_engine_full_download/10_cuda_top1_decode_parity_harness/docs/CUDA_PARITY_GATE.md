# CUDA Top-1 Decode Parity Gate

CUDA may proceed only through this order:

1. CPU reference smoke passes.
2. CUDA extension builds.
3. CUDA parity test passes.
4. `max_abs_y`, `max_abs_state`, and `max_abs_weight` are within tolerance.
5. Only then can timing be measured.

This artifact forbids CUDA speed claims. Passing this gate means only:

```text
the CUDA top-1 decode kernel is numerically equivalent to the reference top-1 decode path
```

## Why top-1 only

The previous gates showed:
- independent parity passed;
- cached decode CSV exists;
- seed-by-seed training gate passed;
- CUDA was unlocked only for a top-1 parity harness.

Top-2, prefill, TSC, and MLP are intentionally excluded.
