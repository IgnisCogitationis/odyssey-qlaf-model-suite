# Odyssey V39 CUDA Top-1 Decode Parity Harness

This artifact is **parity-only**. It is not CUDA optimization.

Goal:

```text
CUDA top-1 decode output == PyTorch/reference top-1 decode output
```

The CUDA harness only targets the first decode kernel boundary:

1. route projection;
2. top-1 state selection;
3. rank projection;
4. selected-state update;
5. full state-bank readout;
6. output hidden update.

It intentionally does **not** include:
- top-2 routing;
- prefill scan;
- TSC;
- MLP;
- server batching;
- speed claims.

## Run CPU/reference parity smoke

```bash
python3 tests/test_reference_top1.py
```

## Build CUDA extension

```bash
cd odyssey_v39_cuda_ext
python3 setup.py build_ext --inplace
```

## Run CUDA parity

```bash
PYTHONPATH=.:odyssey_v39_cuda_ext python3 tests/test_cuda_top1_parity.py
```

## Pass criterion

```text
max_abs_diff <= 1e-4 for float32
```

CUDA remains a parity target only until this passes.
