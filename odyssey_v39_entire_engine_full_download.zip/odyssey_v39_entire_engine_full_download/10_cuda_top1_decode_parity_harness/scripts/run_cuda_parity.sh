#!/usr/bin/env bash
set -euo pipefail
export PYTHONPATH=".:odyssey_v39_cuda_ext:${PYTHONPATH:-}"
python3 tests/test_cuda_top1_parity.py
