#!/usr/bin/env bash
set -euo pipefail
cd odyssey_v39_cuda_ext
python3 setup.py build_ext --inplace
