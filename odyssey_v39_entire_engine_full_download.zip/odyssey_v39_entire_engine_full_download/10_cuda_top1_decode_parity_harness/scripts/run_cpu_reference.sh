#!/usr/bin/env bash
set -euo pipefail
python3 tests/test_reference_top1.py
