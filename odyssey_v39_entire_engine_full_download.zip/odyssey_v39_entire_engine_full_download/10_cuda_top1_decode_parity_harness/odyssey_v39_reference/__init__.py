from .top1_reference import qlaf_top1_decode_reference, make_inputs
