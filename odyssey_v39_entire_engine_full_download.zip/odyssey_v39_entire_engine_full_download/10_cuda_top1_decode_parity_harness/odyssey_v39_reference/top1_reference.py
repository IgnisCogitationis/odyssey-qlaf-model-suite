import torch

def make_inputs(batch=2, hidden=8, states=3, rank=4, seed=1, device="cpu", dtype=torch.float32):
    g = torch.Generator(device="cpu")
    g.manual_seed(seed)
    def randn(*shape):
        return torch.randn(*shape, generator=g, dtype=dtype).to(device) * 0.05

    x = randn(batch, hidden)
    state_summary = randn(batch, states, rank)
    state_weight = torch.rand(batch, states, generator=g, dtype=dtype).to(device) * 0.5
    route_weight = randn(states, hidden)
    rank_weight = randn(rank, hidden)
    out_weight = randn(hidden, states * rank)
    return {
        "x": x,
        "state_summary": state_summary,
        "state_weight": state_weight,
        "route_weight": route_weight,
        "rank_weight": rank_weight,
        "out_weight": out_weight,
    }

def qlaf_top1_decode_reference(x, state_summary, state_weight, route_weight, rank_weight, out_weight):
    # x: [B,H]
    # state_summary: [B,S,R]
    # state_weight: [B,S]
    # route_weight: [S,H]
    # rank_weight: [R,H]
    # out_weight: [H,S*R]
    B, H = x.shape
    S = state_summary.shape[1]
    R = state_summary.shape[2]

    route_logits = x @ route_weight.t()
    active = torch.argmax(route_logits, dim=-1)
    z = x @ rank_weight.t()

    new_state = state_summary.clone()
    new_weight = state_weight.clone()
    bi = torch.arange(B, device=x.device)

    old_w = new_weight[bi, active]
    add_w = torch.ones_like(old_w)
    new_w = old_w + add_w
    old = new_state[bi, active]
    updated = (old * old_w[:, None] + z * add_w[:, None]) / new_w[:, None].clamp_min(1e-8)
    new_state[bi, active] = updated
    new_weight[bi, active] = new_w

    weighted = new_state * new_weight[:, :, None]
    denom = new_weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)
    flat = (weighted / denom[:, :, None]).reshape(B, S * R)
    y = x + flat @ out_weight.t()

    return y, new_state, new_weight, active
