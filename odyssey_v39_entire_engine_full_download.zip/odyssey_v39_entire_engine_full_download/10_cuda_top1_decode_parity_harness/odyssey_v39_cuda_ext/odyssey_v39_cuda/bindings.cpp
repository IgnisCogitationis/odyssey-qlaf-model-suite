#include <torch/extension.h>
#include <vector>

std::vector<torch::Tensor> qlaf_top1_decode_cuda(
    torch::Tensor x,
    torch::Tensor state_summary,
    torch::Tensor state_weight,
    torch::Tensor route_weight,
    torch::Tensor rank_weight,
    torch::Tensor out_weight
);

std::vector<torch::Tensor> qlaf_top1_decode(
    torch::Tensor x,
    torch::Tensor state_summary,
    torch::Tensor state_weight,
    torch::Tensor route_weight,
    torch::Tensor rank_weight,
    torch::Tensor out_weight
) {
    TORCH_CHECK(x.is_cuda(), "x must be CUDA");
    TORCH_CHECK(state_summary.is_cuda(), "state_summary must be CUDA");
    TORCH_CHECK(state_weight.is_cuda(), "state_weight must be CUDA");
    TORCH_CHECK(route_weight.is_cuda(), "route_weight must be CUDA");
    TORCH_CHECK(rank_weight.is_cuda(), "rank_weight must be CUDA");
    TORCH_CHECK(out_weight.is_cuda(), "out_weight must be CUDA");
    TORCH_CHECK(x.dtype() == torch::kFloat32, "parity kernel supports float32 only");
    return qlaf_top1_decode_cuda(x, state_summary, state_weight, route_weight, rank_weight, out_weight);
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("qlaf_top1_decode", &qlaf_top1_decode, "Odyssey V39 QLAF top-1 decode parity kernel");
}
