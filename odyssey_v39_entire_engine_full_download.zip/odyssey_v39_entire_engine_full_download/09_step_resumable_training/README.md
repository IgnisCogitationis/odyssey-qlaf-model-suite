# Odyssey V39 Step-Resumable Training Gate

This package exists because long Python/PyTorch runs may be interrupted.

Instead of running a full seed at once, each command runs exactly one training step for one seed and immediately saves:

- checkpoint
- per-step JSON
- per-step CSV row

CUDA remains blocked until all 3 seeds complete and aggregate cleanly.

## Run order

```bash
python3 scripts/init_seed.py --seed 1
python3 scripts/run_train_step.py --seed 1 --step 0
python3 scripts/run_train_step.py --seed 1 --step 1
...
python3 scripts/aggregate_seed.py --seed 1
```

Repeat for seeds 2 and 3, then:

```bash
python3 scripts/aggregate_all_seeds.py
```

## Gate

CUDA top-1 decode can begin only if:

```text
all 3 seeds complete
V39 train loss reduced on all 3
V39 validation does not blow up on all 3
```
