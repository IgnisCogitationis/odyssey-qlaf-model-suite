#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from common_train import import_torch, build_models, make_fixed_batch, paths, count_params

ap = argparse.ArgumentParser()
ap.add_argument("--seed", type=int, required=True)
ap.add_argument("--batch", type=int, default=2)
ap.add_argument("--seq", type=int, default=8)
ap.add_argument("--lr", type=float, default=8e-4)
args = ap.parse_args()

base = Path(__file__).resolve().parents[1]
p = paths(base, args.seed)
p["seed_dir"].mkdir(parents=True, exist_ok=True)
p["result_dir"].mkdir(parents=True, exist_ok=True)

torch, nn, F = import_torch()
device = "cuda" if torch.cuda.is_available() else "cpu"
torch.manual_seed(args.seed)
TinyV39, TinyTransformer = build_models(torch, nn, max_pos=max(64, args.seq+4))
v39 = TinyV39().to(device)
torch.manual_seed(args.seed)
tr = TinyTransformer().to(device)
vopt = torch.optim.AdamW(v39.parameters(), lr=args.lr, weight_decay=0.01)
topt = torch.optim.AdamW(tr.parameters(), lr=args.lr, weight_decay=0.01)

train_x = make_fixed_batch(torch, 10000 + args.seed, args.batch, args.seq, device=device)
val_x = make_fixed_batch(torch, 20000 + args.seed, args.batch, args.seq, device=device)

ckpt = {
    "seed": args.seed,
    "step": 0,
    "device": device,
    "batch": args.batch,
    "seq": args.seq,
    "lr": args.lr,
    "v39": v39.state_dict(),
    "transformer": tr.state_dict(),
    "vopt": vopt.state_dict(),
    "topt": topt.state_dict(),
    "train_x": train_x,
    "val_x": val_x,
    "v39_params": count_params(v39),
    "transformer_params": count_params(tr),
}
torch.save(ckpt, p["seed_dir"] / "latest.pt")
meta = {k: v for k, v in ckpt.items() if k not in ["v39","transformer","vopt","topt","train_x","val_x"]}
(p["result_dir"] / "init.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
print(json.dumps(meta, indent=2))
