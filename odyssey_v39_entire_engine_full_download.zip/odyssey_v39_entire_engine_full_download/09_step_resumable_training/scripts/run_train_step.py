#!/usr/bin/env python3
import argparse, json, csv, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from common_train import import_torch, build_models, lm_loss, paths

ap = argparse.ArgumentParser()
ap.add_argument("--seed", type=int, required=True)
ap.add_argument("--step", type=int, required=True)
args = ap.parse_args()

base = Path(__file__).resolve().parents[1]
p = paths(base, args.seed)
torch, nn, F = import_torch()
ckpt_path = p["seed_dir"] / "latest.pt"
if not ckpt_path.exists():
    raise SystemExit(f"Missing checkpoint. Run init_seed.py --seed {args.seed} first.")

ckpt = torch.load(ckpt_path, map_location="cpu")
device = ckpt["device"]
TinyV39, TinyTransformer = build_models(torch, nn, max_pos=max(64, ckpt["seq"]+4))
v39 = TinyV39().to(device)
tr = TinyTransformer().to(device)
v39.load_state_dict(ckpt["v39"])
tr.load_state_dict(ckpt["transformer"])
vopt = torch.optim.AdamW(v39.parameters(), lr=ckpt["lr"], weight_decay=0.01)
topt = torch.optim.AdamW(tr.parameters(), lr=ckpt["lr"], weight_decay=0.01)
vopt.load_state_dict(ckpt["vopt"])
topt.load_state_dict(ckpt["topt"])
train_x = ckpt["train_x"].to(device)
val_x = ckpt["val_x"].to(device)

start = time.perf_counter()

def one_step(model, opt):
    model.train()
    opt.zero_grad(set_to_none=True)
    loss = lm_loss(F, model(train_x), train_x)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)
    opt.step()
    model.eval()
    with torch.no_grad():
        val = lm_loss(F, model(val_x), val_x)
    return float(loss.item()), float(val.item())

v_train, v_val = one_step(v39, vopt)
t_train, t_val = one_step(tr, topt)
elapsed = time.perf_counter() - start

next_step = max(int(ckpt["step"]), args.step) + 1
ckpt.update({
    "step": next_step,
    "v39": v39.state_dict(),
    "transformer": tr.state_dict(),
    "vopt": vopt.state_dict(),
    "topt": topt.state_dict(),
})
torch.save(ckpt, ckpt_path)

row = {
    "seed": args.seed,
    "step": args.step,
    "next_step": next_step,
    "v39_train_loss": v_train,
    "v39_val_loss": v_val,
    "transformer_train_loss": t_train,
    "transformer_val_loss": t_val,
    "elapsed_seconds": elapsed,
}
p["result_dir"].mkdir(parents=True, exist_ok=True)
(p["result_dir"] / f"step_{args.step:04d}.json").write_text(json.dumps(row, indent=2), encoding="utf-8")
csv_path = p["result_dir"] / "steps.csv"
exists = csv_path.exists()
with csv_path.open("a", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(row.keys()))
    if not exists:
        w.writeheader()
    w.writerow(row)
print(json.dumps(row, indent=2))
