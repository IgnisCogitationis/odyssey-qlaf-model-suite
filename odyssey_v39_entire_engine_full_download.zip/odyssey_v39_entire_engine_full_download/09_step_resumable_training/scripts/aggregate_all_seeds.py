#!/usr/bin/env python3
import json, statistics
from pathlib import Path

base = Path(__file__).resolve().parents[1]
summaries = []
for seed_dir in sorted((base/"results").glob("seed_*")):
    p = seed_dir / "seed_summary.json"
    if p.exists():
        summaries.append(json.loads(p.read_text(encoding="utf-8")))

out = {
    "seeds_found": len(summaries),
    "all_complete": bool(summaries) and all(s.get("complete") for s in summaries),
    "all_passed": bool(summaries) and all(s.get("passed") for s in summaries),
    "cuda_unlocked": False,
    "seed_summaries": summaries,
}
if summaries:
    out["v39_train_delta_mean"] = statistics.mean(s.get("v39_train_delta", 0.0) for s in summaries)
    out["v39_val_delta_mean"] = statistics.mean(s.get("v39_val_delta", 0.0) for s in summaries)
out["cuda_unlocked"] = bool(len(summaries) >= 3 and out["all_complete"] and out["all_passed"])
out["cuda_gate"] = "unlocked_for_top1_decode_parity_harness_only" if out["cuda_unlocked"] else "blocked"
(base/"results"/"all_seed_summary.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
print(json.dumps(out, indent=2))
