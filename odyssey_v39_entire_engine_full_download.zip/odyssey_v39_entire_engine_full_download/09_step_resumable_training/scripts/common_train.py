import json
from pathlib import Path

def import_torch():
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    return torch, nn, F

def make_fixed_batch(torch, seed, batch, seq, vocab=32, device="cpu"):
    g = torch.Generator(device="cpu")
    g.manual_seed(seed)
    x = torch.randint(0, vocab, (batch, seq), generator=g).to(device)
    for t in range(2, seq):
        x[:, t] = (x[:, t-1] + x[:, t-2] + (t % 5)) % vocab
    return x

def lm_loss(F, logits, x):
    return F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), x[:, 1:].reshape(-1))

def build_models(torch, nn, vocab=32, hidden=8, states=3, rank=4, inter=32, max_pos=64):
    class TinyV39(nn.Module):
        def __init__(self):
            super().__init__()
            self.states = states
            self.rank = rank
            self.emb = nn.Embedding(vocab, hidden)
            self.pos = nn.Embedding(max_pos, hidden)
            self.norm = nn.LayerNorm(hidden)
            self.route = nn.Linear(hidden, states, bias=False)
            self.to_rank = nn.Linear(hidden, rank, bias=False)
            self.from_state = nn.Linear(states * rank, hidden, bias=False)
            self.tsc_norm = nn.LayerNorm(hidden)
            self.tsc = nn.Linear(hidden, hidden, bias=False)
            self.mlp_norm = nn.LayerNorm(hidden)
            self.mlp = nn.Sequential(nn.Linear(hidden, inter), nn.SiLU(), nn.Linear(inter, hidden))
            self.head = nn.Linear(hidden, vocab, bias=False)

        def forward(self, x):
            B, T = x.shape
            state = torch.zeros(B, self.states, self.rank, device=x.device, dtype=self.emb.weight.dtype)
            weight = torch.zeros(B, self.states, device=x.device, dtype=self.emb.weight.dtype)
            outs = []
            bi = torch.arange(B, device=x.device)
            for t in range(T):
                h = self.emb(x[:, t]) + self.pos(torch.full((B,), t, device=x.device, dtype=torch.long))
                hn = self.norm(h)
                probs = torch.softmax(self.route(hn), dim=-1)
                vals, ids = torch.topk(probs, k=2, dim=-1)
                vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
                z = self.to_rank(hn)
                new_state = state.clone()
                new_weight = weight.clone()
                for j in range(2):
                    sid = ids[:, j]
                    w = vals[:, j]
                    old_w = new_weight[bi, sid]
                    new_w = old_w + w
                    old = new_state[bi, sid]
                    new_state[bi, sid] = (old * old_w[:, None] + z * w[:, None]) / new_w[:, None].clamp_min(1e-8)
                    new_weight[bi, sid] = new_w
                state, weight = new_state, new_weight
                flat = (state * weight[:, :, None] / weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)[:, :, None]).reshape(B, states * rank)
                h = h + self.from_state(flat)
                h = h + 0.10 * self.tsc(self.tsc_norm(h))
                h = h + self.mlp(self.mlp_norm(h))
                outs.append(self.head(h)[:, None, :])
            return torch.cat(outs, dim=1)

    class TinyTransformer(nn.Module):
        def __init__(self):
            super().__init__()
            self.emb = nn.Embedding(vocab, hidden)
            self.pos = nn.Embedding(max_pos, hidden)
            self.norm1 = nn.LayerNorm(hidden)
            self.attn = nn.MultiheadAttention(hidden, num_heads=1, batch_first=True)
            self.norm2 = nn.LayerNorm(hidden)
            self.mlp = nn.Sequential(nn.Linear(hidden, inter), nn.SiLU(), nn.Linear(inter, hidden))
            self.head = nn.Linear(hidden, vocab, bias=False)

        def forward(self, x):
            B, T = x.shape
            pos = torch.arange(T, device=x.device).unsqueeze(0).expand(B, T)
            h = self.emb(x) + self.pos(pos)
            mask = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
            q = self.norm1(h)
            y, _ = self.attn(q, q, q, attn_mask=mask, need_weights=False)
            h = h + y
            h = h + self.mlp(self.norm2(h))
            return self.head(h)

    return TinyV39, TinyTransformer

def count_params(model):
    return sum(p.numel() for p in model.parameters())

def paths(base, seed):
    base = Path(base)
    return {
        "seed_dir": base / "checkpoints" / f"seed_{seed}",
        "result_dir": base / "results" / f"seed_{seed}",
    }
