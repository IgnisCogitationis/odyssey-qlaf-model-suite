#!/usr/bin/env python3
import argparse, csv, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from common_train import paths

ap = argparse.ArgumentParser()
ap.add_argument("--seed", type=int, required=True)
ap.add_argument("--required_steps", type=int, default=12)
args = ap.parse_args()

base = Path(__file__).resolve().parents[1]
p = paths(base, args.seed)
csv_path = p["result_dir"] / "steps.csv"
rows = []
if csv_path.exists():
    with csv_path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

summary = {
    "seed": args.seed,
    "rows": len(rows),
    "required_steps": args.required_steps,
    "complete": len(rows) >= args.required_steps,
    "passed": False,
}
if rows:
    v_train_initial = float(rows[0]["v39_train_loss"])
    v_train_final = float(rows[-1]["v39_train_loss"])
    v_val_initial = float(rows[0]["v39_val_loss"])
    v_val_final = float(rows[-1]["v39_val_loss"])
    t_train_initial = float(rows[0]["transformer_train_loss"])
    t_train_final = float(rows[-1]["transformer_train_loss"])
    t_val_initial = float(rows[0]["transformer_val_loss"])
    t_val_final = float(rows[-1]["transformer_val_loss"])
    summary.update({
        "v39_train_initial": v_train_initial,
        "v39_train_final": v_train_final,
        "v39_train_delta": v_train_initial - v_train_final,
        "v39_val_initial": v_val_initial,
        "v39_val_final": v_val_final,
        "v39_val_delta": v_val_initial - v_val_final,
        "transformer_train_initial": t_train_initial,
        "transformer_train_final": t_train_final,
        "transformer_train_delta": t_train_initial - t_train_final,
        "transformer_val_initial": t_val_initial,
        "transformer_val_final": t_val_final,
        "transformer_val_delta": t_val_initial - t_val_final,
        "v39_train_reduced": v_train_final <= v_train_initial,
        "v39_val_not_blowup": v_val_final <= v_val_initial + 0.05,
        "transformer_train_reduced": t_train_final <= t_train_initial,
        "transformer_val_not_blowup": t_val_final <= t_val_initial + 0.05,
    })
    summary["passed"] = bool(summary["complete"] and summary["v39_train_reduced"] and summary["v39_val_not_blowup"])

(p["result_dir"] / "seed_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
