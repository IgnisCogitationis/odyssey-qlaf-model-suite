#!/usr/bin/env bash
set -euo pipefail
python3 scripts/init_seed.py --seed 1
for s in 0 1 2 3 4 5 6 7 8 9 10 11; do
  python3 scripts/run_train_step.py --seed 1 --step "$s"
done
python3 scripts/aggregate_seed.py --seed 1 --required_steps 12
