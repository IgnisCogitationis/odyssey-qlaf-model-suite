# Step-Resumable Training Runbook

Run seed 1:

```bash
python3 scripts/init_seed.py --seed 1
python3 scripts/run_train_step.py --seed 1 --step 0
python3 scripts/run_train_step.py --seed 1 --step 1
python3 scripts/run_train_step.py --seed 1 --step 2
...
python3 scripts/run_train_step.py --seed 1 --step 11
python3 scripts/aggregate_seed.py --seed 1 --required_steps 12
```

Repeat for seeds 2 and 3.

Aggregate:

```bash
python3 scripts/aggregate_all_seeds.py
```

CUDA remains blocked unless `results/all_seed_summary.json` says:

```json
"cuda_unlocked": true
```
