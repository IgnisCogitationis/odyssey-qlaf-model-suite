
# Odyssey V39 Full Engine Audit Pass 6

Date: 2026-04-28

## Scope

This pass audits the engine against the entire project stack:

**QLAF causal state cache + AION adaptive hierarchy + TSC residual correction + decode-branch specialization + Route B CUDA/HF deployment.**

It incorporates the latest gates:

- independent full-forward parity has passed in the sharded reference pipeline;
- scaled cached-decode proxy exists for contexts 8, 16, 32, 64 across 3 seeds;
- seed-by-seed PyTorch training gate completed for 3 seeds;
- CUDA top-1 decode parity harness exists;
- local CUDA gate was attempted here, but CUDA was unavailable in this environment.

## Executive verdict

The project has moved from pure scaffold into **pre-CUDA evidence-gated engineering**.

The strongest replacement path remains correct:

> Replace Transformer attention/KV cache in the dominant decode path with a QLAF causal state cache; use AION to avoid collapse and widen/refresh only when needed; keep TSC as residual correction; serve through decode-branch specialization; deploy through Route B only after CUDA parity passes.

Current status:

| Gate | Status |
|---|---|
| independent full-forward parity | passed in reference pipeline |
| parameter matching | passed at tiny scale, ~0.7–3% depending artifact/config |
| cached decode vs explicit KV baseline | scaled proxy passed; V39 improves with context |
| 3-seed stabilized training | passed |
| CUDA top-1 reference parity harness | CPU reference passed |
| CUDA build/parity | blocked here because CUDA unavailable |
| CUDA timing | blocked until CUDA parity passes |
| prefill CUDA | blocked |
| Route B server | planned, not unlocked |

## Hard truth

This is not yet a complete Transformer replacement. It is now a credible **path to a replacement**, with the next decisive blocker being CUDA parity on a real CUDA machine.

The engine cannot claim full superiority until:

1. CUDA top-1 decode parity passes;
2. CUDA top-1 timing is measured;
3. PyTorch/CUDA V39 is compared to an optimized cached Transformer baseline;
4. training is moved beyond tiny synthetic tasks;
5. prefill and Route B server are integrated.

## Latest measured/proxy evidence

### Seed-by-seed training gate

```json
{
  "seeds_found": 3,
  "all_seeds_complete": true,
  "all_v39_train_reduced": true,
  "all_v39_val_not_blowup": true,
  "all_transformer_train_reduced": true,
  "all_transformer_val_not_blowup": true,
  "v39_train_delta_mean": 0.17383305231730142,
  "v39_val_delta_mean": 0.01929783821105957,
  "transformer_train_delta_mean": 0.20308883984883627,
  "transformer_val_delta_mean": 0.027557373046875,
  "v39_final_train_loss_mean": 3.551933447519938,
  "transformer_final_train_loss_mean": 3.7313548723856607,
  "cuda_unlocked": true,
  "cuda_gate": "unlocked_for_top1_decode_parity_harness_only"
}
```

### Scaled cached-decode summary

```json
{
  "8": {
    "n": 3,
    "speedup_mean": 1.1597298272575591,
    "speedup_min": 1.1296716311850552,
    "speedup_max": 1.204626962190028,
    "cache_reduction_mean": 88.28125
  },
  "16": {
    "n": 3,
    "speedup_mean": 1.057807015459949,
    "speedup_min": 0.5779477267039632,
    "speedup_max": 1.3498995824774906,
    "cache_reduction_mean": 94.140625
  },
  "32": {
    "n": 3,
    "speedup_mean": 1.4839930520299198,
    "speedup_min": 1.4748488206932453,
    "speedup_max": 1.4894746320834489,
    "cache_reduction_mean": 97.0703125
  },
  "64": {
    "n": 3,
    "speedup_mean": 1.901087833687838,
    "speedup_min": 1.7513033547308055,
    "speedup_max": 2.036402923530997,
    "cache_reduction_mean": 98.53515625
  }
}
```

### Local CUDA gate attempt

```json
{
  "stage": "local_cuda_gate",
  "platform": "Linux-4.4.0-x86_64-with-glibc2.41",
  "python": "3.13.5 (main, Jun 25 2025, 18:55:22) [GCC 14.2.0]",
  "cuda_available": false,
  "parity_passed": false,
  "next_allowed_step": "patch_cuda_for_parity_only",
  "torch_cuda": {
    "torch_imported": true,
    "torch_version": "2.10.0+cpu",
    "cuda_available": false,
    "torch_cuda_version": null,
    "device_count": 0,
    "device_name": null
  }
}
```

---

# Architecture-level review

## 1. QLAF causal state cache

### What is right

The cache concept is now real enough to test. Across artifacts, QLAF state is represented as:

- `state_summary`;
- `state_weight`;
- active top-1/top-2 routing;
- causal updates;
- cache element accounting.

The cache-memory evidence is directionally strong: at context 64, the proxy cache reduction reached about 98.5% because QLAF cache size is state/rank bounded while Transformer KV grows with sequence length.

### What is still weak

Current QLAF cache implementations are reference-level:

- clone-heavy;
- Python-loop-heavy;
- tiny shapes;
- no production batch repacking;
- no persistent request-id cache manager;
- no mixed precision;
- no CUDA parity yet;
- no hierarchy tensor in the final runtime path.

### Required replacement patch

The production cache must become:

```text
state_summary: [batch, layers, states, rank]
state_weight: [batch, layers, states]
active_state_ids: [batch, layers, top_k]
route_confidence: [batch, layers]
hierarchy_level: [batch, layers, states]
refresh_counter: [batch, layers]
position: [batch]
valid: [batch]
```

The cache manager must support:

- request ownership;
- row reset;
- batch repacking;
- partial refresh;
- dtype/device/kernel version validation;
- cache memory reporting.

## 2. AION adaptive hierarchy

### What is right

AION is correctly positioned as the anti-collapse and adaptive widening controller. It should decide when top-1 is safe and when top-2/top-4 refresh is needed.

### What is still weak

Current AION is mostly a policy stub:

- confidence threshold;
- periodic refresh;
- forced top-2 tests.

It does not yet implement true hierarchy:

- state split;
- state merge/collapse;
- local/global state bands;
- long-context promotion;
- stale-state repair;
- route-margin triggers.

### Required replacement patch

AION needs deterministic outputs:

```text
top_k
refresh_scope
target_states
hierarchy_action
tsc_scale
fallback_flag
```

And it must consume:

```text
route_confidence
route_margin
entropy
position
refresh_counter
stale_flag
cache_age
```

## 3. TSC residual correction

### What is right

TSC is being kept in the correct role: a small residual correction branch, not a second full sequence mixer.

### What is still weak

There is no serious ablation yet proving TSC improves quality enough for its cost.

### Required replacement patch

Run ablations:

1. QLAF only;
2. QLAF + AION;
3. QLAF + TSC;
4. QLAF + AION + TSC.

Report:

- train loss;
- validation loss;
- cached decode time;
- memory;
- route entropy;
- top-1/top-2 frequency.

## 4. Decode-branch specialization

### What is right

The project correctly prioritizes decode over prefill. Decode is where QLAF has the cleanest chance to beat the Transformer because KV-cache cost grows with context.

### What is still weak

The decode branch is not yet distilled from a richer training branch. The current tests use tiny direct training and proxy decode.

### Required replacement patch

Train with:

- richer top-2/top-4 path;
- decode top-1 path;
- consistency KL;
- optional teacher Transformer KL;
- refresh penalty.

Serve with:

- top-1 default;
- AION widening only when needed;
- TSC low/optional.

## 5. CUDA top-1 decode

### What is right

The CUDA parity harness is exactly the correct next step. It has:

- PyTorch reference;
- CUDA extension skeleton;
- scalar parity-first kernel;
- build script;
- parity test;
- local gate runner.

### What is still weak

CUDA has not been built or tested because CUDA is unavailable in this environment.

The CUDA kernel is intentionally scalar/simple. It is not optimized, and should not be optimized until parity passes.

### Required replacement patch

On a CUDA machine:

```bash
bash scripts/run_local_cuda_gate.sh
cat results/local_cuda_gate_report.json
```

If parity passes:

```bash
python3 scripts/make_timing_harness_if_parity_passed.py
PYTHONPATH=.:odyssey_v39_cuda_ext python3 scripts/run_cuda_top1_timing.py
```

If parity fails:

- patch route top-1 first;
- then state update;
- then readout;
- do not benchmark.

## 6. Route B CUDA/HF deployment

### What is right

Route B remains the strongest deployment route:

- custom HF architecture;
- `trust_remote_code=True`;
- custom CUDA wheel;
- custom inference server;
- Docker/server metrics.

### What is still weak

Route B is not unlocked yet. It must wait for CUDA parity and timing.

### Required replacement patch

After CUDA parity and timing:

1. wrap V39 as `AutoModelForCausalLM`;
2. store weights in safetensors;
3. expose fallback PyTorch path;
4. load CUDA wheel if available;
5. separate prefill/decode APIs;
6. add custom server cache manager.

---

# Line-by-line audit summary

Audited file count: 186

The full line-numbered appendix is included separately. Key file families:

| Family | Purpose | Status |
|---|---|---|
| `engine_stack_pass1` | architecture contract | useful, but interface-level |
| `correctness_gates` | early parity tests | superseded by sharded pipeline |
| `pytorch_training_lite` | PyTorch bridge | useful, but tiny |
| `cached_decode_fair` | explicit KV baseline | useful, needs CUDA/local run |
| `sharded_pipeline` | environment-safe execution | successful |
| `seed_training` | 3-seed training gate | passed |
| `cuda_parity_harness` | top-1 CUDA parity | CPU ref passed, CUDA pending |
| `local_cuda_gate` | local CUDA diagnostic | CUDA unavailable here |

---

# What must be done to thoroughly replace Transformer

## Minimum replacement proof

V39 must show all of this:

1. no attention in dominant decode path;
2. no KV cache in dominant decode path;
3. independent full-forward parity;
4. cached decode parity;
5. training loss reduces across seeds;
6. validation does not blow up;
7. CUDA top-1 parity passes;
8. CUDA top-1 timing beats PyTorch reference;
9. V39 cached decode competes with optimized Transformer cached decode;
10. memory advantage increases with context.

## Strong replacement proof

After minimum proof:

1. real text dataset;
2. matched tokenizer;
3. 5 seeds;
4. contexts 512/1024/2048/4096/8192;
5. p50/p95 latency;
6. peak GPU memory;
7. ablation table;
8. Route B reproducibility bundle.

## Full replacement proof

Only after all of the above:

1. pretrained V39 checkpoint;
2. HF custom repo;
3. CUDA wheel;
4. server;
5. public reproducibility logs;
6. comparison against optimized Transformer backend.

---

# Current recommendation

Do not work on Route B server yet.

Do not optimize CUDA yet.

Do not start prefill CUDA yet.

The only correct next action is:

> Run the local CUDA gate on a CUDA machine, patch only parity if needed, then create the CUDA top-1 decode timing harness if and only if parity passes.

That is the cleanest path from the current state to a real Transformer replacement.
