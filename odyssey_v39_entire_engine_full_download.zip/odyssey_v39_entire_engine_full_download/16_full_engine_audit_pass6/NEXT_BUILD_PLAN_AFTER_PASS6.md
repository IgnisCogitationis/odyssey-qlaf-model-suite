
# Odyssey V39 Next Build Plan After Pass 6

## Current lock state

Unlocked:
- independent parity
- cached decode proxy scaling
- 3-seed tiny training
- CUDA top-1 parity harness

Blocked:
- CUDA timing until CUDA parity passes
- CUDA optimization until timing baseline exists
- prefill CUDA until top-1 decode timing is understood
- Route B server until CUDA path is stable

## Exact next sequence

### Step 1: CUDA machine parity

Run:

```bash
bash scripts/run_local_cuda_gate.sh
cat results/local_cuda_gate_report.json
```

### Step 2A: If parity fails

Patch only one component at a time:

1. route argmax;
2. rank projection;
3. selected-state update;
4. weight update;
5. state-bank readout;
6. output projection.

No timing.

### Step 2B: If parity passes

Create timing harness:

```bash
python3 scripts/make_timing_harness_if_parity_passed.py
PYTHONPATH=.:odyssey_v39_cuda_ext python3 scripts/run_cuda_top1_timing.py
```

### Step 3: Timing interpretation

Only ask:

```text
Does CUDA top-1 beat PyTorch reference top-1?
```

Do not compare to production Transformer yet.

### Step 4: CUDA corrected timing

If scalar kernel is slower, optimize only after parity remains passing.

Optimization order:

1. one block per batch row, parallel H/S/R loops;
2. shared memory route logits;
3. parallel rank projection;
4. parallel readout;
5. reduce launch overhead;
6. fuse route+rank+update+read.

### Step 5: Transformer comparison

Only after CUDA top-1 beats PyTorch reference:

- compare against explicit Transformer KV baseline;
- then compare against optimized backend.

### Step 6: Route B

Only after CUDA top-1 has parity and meaningful timing.

Deliver:
- HF repo;
- CUDA wheel;
- server;
- Docker;
- metrics.
