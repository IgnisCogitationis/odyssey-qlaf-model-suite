# Odyssey V39 Entire Engine Full Download

This bundle contains the current Odyssey V39 / QLAF-AION-TSC engine artifacts from the latest workstream.

## Included engine pieces

- correctness gates
- full sequence pass
- PyTorch tiny correctness/training bridge
- cached-decode fair benchmark scaffold
- sharded replacement pipeline
- scaled cached-decode results
- stabilized and seed-by-seed training results
- step-resumable training runner
- CUDA top-1 decode parity harness
- local CUDA gate runner/attempt
- CPU surrogate CUDA sequence
- CPU CUDA-logic simulation
- full engine audits Pass 5, Pass 6, Pass 7
- original zip artifacts where available

## Current verified gates

- independent parity: passed in reference/sharded pipeline
- 3-seed stabilized training: passed
- CPU CUDA-logic simulation: 3,240 / 3,240 cases passed
- CPU reference top-1 parity: passed
- real CUDA parity: not run here, CUDA unavailable

## Next true gate

Run the CUDA top-1 decode parity harness on a real CUDA machine:

```bash
cd 10_cuda_top1_decode_parity_harness
bash scripts/run_local_cuda_gate.sh
cat results/local_cuda_gate_report.json
```

Only if parity passes:

```bash
python3 scripts/make_timing_harness_if_parity_passed.py
PYTHONPATH=.:odyssey_v39_cuda_ext python3 scripts/run_cuda_top1_timing.py
```

## Important

This full download is not a final production Transformer replacement. It is the complete current gated engine package. CUDA timing, prefill CUDA, and Route B server remain blocked until real CUDA top-1 parity passes.
