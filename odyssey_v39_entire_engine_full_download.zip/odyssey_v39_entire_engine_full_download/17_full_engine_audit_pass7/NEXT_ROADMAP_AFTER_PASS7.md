
# Odyssey V39 Replacement Roadmap After Pass 7

## Status

CPU-side evidence is saturated enough for the current stage.

Passed:
- independent parity
- 3-seed training gate
- cached decode proxy
- CPU CUDA-logic fuzzing

Blocked:
- real CUDA parity
- CUDA timing
- prefill CUDA
- Route B deployment

## Next exact command on CUDA machine

```bash
unzip odyssey_v39_local_cuda_gate_runner.zip
cd odyssey_v39_cuda_top1_decode_parity_harness
bash scripts/run_local_cuda_gate.sh
cat results/local_cuda_gate_report.json
```

## If parity passes

```bash
python3 scripts/make_timing_harness_if_parity_passed.py
PYTHONPATH=.:odyssey_v39_cuda_ext python3 scripts/run_cuda_top1_timing.py
```

## If parity fails

Patch in this order:

1. active state argmax
2. rank projection
3. selected-state update
4. state-weight update
5. denominator
6. flat index
7. output projection

## After timing

Only then build:
- optimized CUDA top-1
- explicit KV comparison
- prefill CUDA
- Route B HF/server
