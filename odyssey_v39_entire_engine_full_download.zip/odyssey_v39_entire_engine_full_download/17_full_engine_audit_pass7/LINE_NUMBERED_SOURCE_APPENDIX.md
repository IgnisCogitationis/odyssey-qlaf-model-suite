# Line-Numbered Source Appendix



## engine_stack_pass1 / `README.md`

```text
0001: # Odyssey V39 Engine Stack Pass 1
0002: 
0003: Architecture stack:
0004: 
0005: QLAF causal state cache + AION adaptive hierarchy + TSC residual correction + decode-branch specialization + Route B CUDA/HF deployment.
0006: 
0007: This package is an implementation-grade scaffold and engineering contract. It is not a measured benchmark claim.
0008: 
0009: The purpose is to define the single-GPU Transformer-replacement engine in a way that can be implemented, tested, benchmarked, and deployed.
0010: 
0011: ## Core goal
0012: 
0013: Remove attention and KV cache from the dominant inference path.
0014: 
0015: Replace them with:
0016: - a causal QLAF state cache,
0017: - AION adaptive state hierarchy,
0018: - TSC residual correction,
0019: - top-1 decode branch,
0020: - CUDA fused single-GPU kernels,
0021: - Hugging Face custom model packaging,
0022: - custom inference server.
0023: 
0024: ## Status
0025: 
0026: This pass includes:
0027: - engine architecture contract,
0028: - cache schema,
0029: - AION policy spec,
0030: - TSC residual spec,
0031: - decode branch specialization spec,
0032: - Route B deployment spec,
0033: - benchmark gates,
0034: - risk register,
0035: - minimal Python module skeletons,
0036: - test stubs,
0037: - CUDA ABI skeleton,
0038: - HF repo template.
0039: 
0040: It intentionally does not claim performance superiority yet.
```


## engine_stack_pass1 / `benchmarks/BENCHMARK_PROTOCOL.md`

```text
0001: # Odyssey V39 Benchmark Protocol
0002: 
0003: ## Models
0004: 
0005: - matched Transformer baseline;
0006: - Odyssey V39 QLAF only;
0007: - Odyssey V39 QLAF + AION;
0008: - Odyssey V39 QLAF + TSC;
0009: - Odyssey V39 full stack.
0010: 
0011: ## Required context lengths
0012: 
0013: - 512;
0014: - 1024;
0015: - 2048;
0016: - 4096;
0017: - 8192.
0018: 
0019: ## Required metrics
0020: 
0021: - train loss;
0022: - validation loss;
0023: - perplexity;
0024: - training tokens/sec;
0025: - prefill tokens/sec;
0026: - decode tokens/sec;
0027: - p50 latency;
0028: - p95 latency;
0029: - peak memory;
0030: - cache memory;
0031: - model parameter count.
0032: 
0033: ## Seeds
0034: 
0035: Minimum:
0036: - 5 seeds for final claim.
0037: 
0038: ## Output tables
0039: 
0040: Produce:
0041: - aggregate_results.csv;
0042: - speedup_table.csv;
0043: - memory_table.csv;
0044: - latency_table.csv;
0045: - ablation_table.csv;
0046: - README_summary.md.
```


## engine_stack_pass1 / `cuda_extension/odyssey_v39_cuda/CUDA_ABI.md`

```text
0001: # Odyssey V39 CUDA ABI
0002: 
0003: ## Required exported functions
0004: 
0005: - qlaf_prefill
0006: - qlaf_decode_top1
0007: - qlaf_decode_topk
0008: - qlaf_cache_update
0009: - qlaf_route_select
0010: - tsc_residual_optional
0011: 
0012: ## Phase 1
0013: 
0014: Correctness kernels:
0015: - simple prefill;
0016: - simple decode;
0017: - reference parity.
0018: 
0019: ## Phase 2
0020: 
0021: Performance kernels:
0022: - BF16/FP16;
0023: - FP32 accumulation;
0024: - tiled state projection;
0025: - fused state update/readout;
0026: - top-1 decode specialization.
0027: 
0028: ## Phase 3
0029: 
0030: Production kernels:
0031: - persistent cache layout;
0032: - batch decode scheduler support;
0033: - graph-capture-friendly call boundaries;
0034: - metrics hooks.
```


## engine_stack_pass1 / `docs/00_EXECUTIVE_SPEC.md`

```text
0001: # Odyssey V39 Executive Specification
0002: 
0003: ## Final stack
0004: 
0005: **QLAF causal state cache + AION adaptive hierarchy + TSC residual correction + decode-branch specialization + Route B CUDA/HF deployment.**
0006: 
0007: This is the strongest single-GPU Transformer-replacement direction from the project.
0008: 
0009: ## Why this replaces Transformer
0010: 
0011: A Transformer uses:
0012: - attention scores;
0013: - softmax retrieval;
0014: - KV cache;
0015: - many heads;
0016: - full-context prefill;
0017: - token-by-token KV reuse during decode.
0018: 
0019: Odyssey V39 replaces those with:
0020: - QLAF route scores;
0021: - state-summary readout;
0022: - causal QLAF state cache;
0023: - multi-state bank;
0024: - AION hierarchy/refresh;
0025: - top-1 decode state update.
0026: 
0027: ## Primary claim target
0028: 
0029: Not:
0030: > "It is another efficient attention."
0031: 
0032: But:
0033: > "The dominant inference path removes attention and the KV cache, replacing them with a causal QLAF state engine that preserves language quality while improving single-GPU decode speed, cache memory, and long-context serving."
0034: 
0035: ## Single-GPU proof target
0036: 
0037: Required hardware class:
0038: - A100 40GB/80GB, H100, L40S, RTX 4090/5090-class GPU.
0039: 
0040: Required comparison:
0041: - matched Transformer baseline;
0042: - matched parameter count;
0043: - matched data;
0044: - matched tokenizer;
0045: - matched optimizer;
0046: - matched tokens;
0047: - matched context lengths;
0048: - 5 seeds.
0049: 
0050: Required metrics:
0051: - validation loss/perplexity;
0052: - training tokens/sec;
0053: - prefill tokens/sec;
0054: - decode tokens/sec;
0055: - p50/p95 latency;
0056: - peak memory;
0057: - cache memory;
0058: - long-context scaling.
0059: 
0060: ## Hard gate before superiority claim
0061: 
0062: Odyssey V39 must pass:
0063: 1. no-future-leakage test;
0064: 2. full-forward vs cached-decode parity test;
0065: 3. batch vs single equivalence;
0066: 4. cache reset/invalidation test;
0067: 5. CUDA vs PyTorch reference parity;
0068: 6. matched quality table;
0069: 7. matched speed/memory table.
```


## engine_stack_pass1 / `docs/01_ENGINE_ARCHITECTURE.md`

```text
0001: # Engine Architecture
0002: 
0003: ## Major components
0004: 
0005: ### OdysseyV39Engine
0006: 
0007: Owns:
0008: - model;
0009: - tokenizer;
0010: - runtime config;
0011: - cache manager;
0012: - AION policy;
0013: - kernel dispatcher;
0014: - scheduler;
0015: - metrics collector.
0016: 
0017: Responsibilities:
0018: - prefill prompts;
0019: - decode tokens;
0020: - manage caches;
0021: - route requests;
0022: - select CUDA or fallback kernels;
0023: - expose generation API.
0024: 
0025: ### QLAFCausalStateCache
0026: 
0027: Replaces Transformer KV cache.
0028: 
0029: Per layer, per batch:
0030: - state summaries;
0031: - active-state ids;
0032: - state weights/counts;
0033: - route confidence;
0034: - hierarchy levels;
0035: - refresh counters;
0036: - sequence position;
0037: - validity metadata.
0038: 
0039: ### AIONAdaptiveHierarchy
0040: 
0041: Controls:
0042: - top-1 vs top-2/top-4 state use;
0043: - refresh timing;
0044: - state split/collapse;
0045: - long-context promotion;
0046: - stale-state recovery.
0047: 
0048: ### TSCResidualCorrector
0049: 
0050: Small residual branch after QLAF:
0051: - improves local/content correction;
0052: - must not become the main mixer;
0053: - can be disabled or thinned during decode.
0054: 
0055: ### DecodeBranchSpecializer
0056: 
0057: Enforces serving path:
0058: - default top-1 state;
0059: - correction minimal;
0060: - optional adaptive widening;
0061: - cache-resident updates only.
0062: 
0063: ### RouteBDeployment
0064: 
0065: Includes:
0066: - HF custom model;
0067: - safetensors;
0068: - trust_remote_code=True;
0069: - PyTorch fallback;
0070: - CUDA wheel;
0071: - Docker/custom server.
0072: 
0073: ## Layer contract
0074: 
0075: Each layer:
0076: 
0077: 1. RMSNorm.
0078: 2. QLAF causal state mixer.
0079: 3. Residual add.
0080: 4. TSC residual correction.
0081: 5. Residual add.
0082: 6. SwiGLU MLP.
0083: 7. Residual add.
0084: 
0085: The attention module is not present in the dominant path.
0086: 
0087: ## Prefill contract
0088: 
0089: Input:
0090: - prompt tokens [B, T].
0091: 
0092: Output:
0093: - logits or final hidden states;
0094: - active causal QLAF cache.
0095: 
0096: Required behavior:
0097: - causal scan;
0098: - no future leakage;
0099: - cache populated for decode;
0100: - top-k prefill routing.
0101: 
0102: ## Decode contract
0103: 
0104: Input:
0105: - current token [B, 1];
0106: - existing QLAF cache.
0107: 
0108: Output:
0109: - logits [B, vocab];
0110: - updated QLAF cache.
0111: 
0112: Required behavior:
0113: - top-1 default route;
0114: - no full-sequence recomputation;
0115: - cache update;
0116: - optional AION widening/refresh.
0117: 
0118: ## Refresh contract
0119: 
0120: Refresh may:
0121: - recompute selected states;
0122: - widen top-k temporarily;
0123: - rebuild from compressed prefix;
0124: - mark cache valid/invalid;
0125: - preserve causal consistency.
0126: 
0127: It must not silently change logits in a way that breaks parity tests.
```


## engine_stack_pass1 / `docs/02_CACHE_SCHEMA.md`

```text
0001: # QLAF Causal State Cache Schema
0002: 
0003: ## Purpose
0004: 
0005: The QLAF cache is the center of the Transformer replacement. It is not metadata and it is not a KV cache.
0006: 
0007: It stores causal state summaries that decode can read and update.
0008: 
0009: ## Per-layer tensors
0010: 
0011: ### state_summary
0012: 
0013: Shape:
0014: `[batch, num_states, state_rank]`
0015: 
0016: Meaning:
0017: The compressed causal memory bank.
0018: 
0019: ### state_weight
0020: 
0021: Shape:
0022: `[batch, num_states]`
0023: 
0024: Meaning:
0025: How much causal evidence has entered each state. Can represent count, decay mass, confidence weight, or normalized accumulator.
0026: 
0027: ### active_state_ids
0028: 
0029: Shape:
0030: `[batch, decode_top_k]`
0031: 
0032: Meaning:
0033: Which state(s) are active for the next decode update.
0034: 
0035: ### route_confidence
0036: 
0037: Shape:
0038: `[batch]`
0039: 
0040: Meaning:
0041: Confidence in top-1 state. AION uses this to decide whether to widen or refresh.
0042: 
0043: ### hierarchy_level
0044: 
0045: Shape:
0046: `[batch, num_states]`
0047: 
0048: Meaning:
0049: AION state hierarchy marker. Lower levels track local detail; higher levels track long-context summaries.
0050: 
0051: ### refresh_counter
0052: 
0053: Shape:
0054: `[batch]`
0055: 
0056: Meaning:
0057: Number of decode steps since last refresh.
0058: 
0059: ### position
0060: 
0061: Shape:
0062: `[batch]`
0063: 
0064: Meaning:
0065: Current causal position.
0066: 
0067: ### valid
0068: 
0069: Shape:
0070: `[batch]`
0071: 
0072: Meaning:
0073: Whether the cache row can be used.
0074: 
0075: ## Metadata
0076: 
0077: Required:
0078: - dtype;
0079: - device;
0080: - model revision;
0081: - kernel version;
0082: - max context;
0083: - state count;
0084: - state rank;
0085: - routing policy;
0086: - cache creation mode.
0087: 
0088: ## Invalidation triggers
0089: 
0090: Invalidate cache if:
0091: - model weights change;
0092: - dtype changes;
0093: - device changes;
0094: - kernel version changes;
0095: - routing policy changes incompatibly;
0096: - state rank changes;
0097: - num states changes;
0098: - sequence exceeds max context;
0099: - request batch packing corrupts order.
0100: 
0101: ## Partial refresh triggers
0102: 
0103: Refresh selected states if:
0104: - route confidence below threshold;
0105: - logit entropy spike;
0106: - periodic refresh interval reached;
0107: - long-context boundary crossed;
0108: - fallback kernel used after CUDA failure;
0109: - AION detects collapse risk.
0110: 
0111: ## Cache correctness tests
0112: 
0113: Required:
0114: 1. full forward equals prefill+decode within tolerance;
0115: 2. one-token decode equals equivalent causal scan;
0116: 3. batch decode equals independent decode;
0117: 4. cache reset clears all state;
0118: 5. invalid cache refuses decode;
0119: 6. device/dtype mismatch detected.
```


## engine_stack_pass1 / `docs/03_AION_POLICY.md`

```text
0001: # AION Adaptive Hierarchy Policy
0002: 
0003: ## Purpose
0004: 
0005: AION prevents QLAF from becoming an irreversible lossy single-state collapse.
0006: 
0007: The default decode path is top-1 for speed, but AION decides when the model must temporarily widen or refresh.
0008: 
0009: ## Policy levels
0010: 
0011: ### Level 0: fixed_top1
0012: 
0013: Use top-1 state only.
0014: 
0015: Fastest. Used during normal decode.
0016: 
0017: ### Level 1: adaptive_top2
0018: 
0019: Use top-2 states if:
0020: - route confidence is low;
0021: - entropy is high;
0022: - state weight is unstable;
0023: - generated sequence crosses a boundary.
0024: 
0025: ### Level 2: refresh_top4
0026: 
0027: Use top-4 or full local refresh if:
0028: - repeated uncertainty;
0029: - long-context transition;
0030: - cache stale flag;
0031: - mismatch detected by parity monitor.
0032: 
0033: ### Level 3: forced_rebuild
0034: 
0035: Rebuild selected cache rows if:
0036: - invalid metadata;
0037: - fallback recovery;
0038: - kernel mismatch;
0039: - severe numerical instability.
0040: 
0041: ## AION inputs
0042: 
0043: - route logits;
0044: - route confidence;
0045: - decode entropy;
0046: - state weights;
0047: - sequence position;
0048: - refresh counter;
0049: - optional task signal.
0050: 
0051: ## AION outputs
0052: 
0053: - active top-k;
0054: - refresh flag;
0055: - hierarchy promotion flag;
0056: - TSC correction strength;
0057: - cache validity update.
0058: 
0059: ## Design constraint
0060: 
0061: AION must not turn every decode step into full compute. It exists to keep top-1 decode safe, not to erase the speed advantage.
0062: 
0063: ## Training regularization
0064: 
0065: Recommended:
0066: - route entropy regularizer;
0067: - top-1 consistency loss;
0068: - refresh penalty;
0069: - decode branch KL;
0070: - state diversity penalty.
```


## engine_stack_pass1 / `docs/04_TSC_RESIDUAL_CORRECTION.md`

```text
0001: # TSC Residual Correction
0002: 
0003: ## Purpose
0004: 
0005: TSC repairs local/content mistakes that pure QLAF state aggregation may miss.
0006: 
0007: It should be a correction branch, not the dominant mixer.
0008: 
0009: ## Placement
0010: 
0011: After QLAF residual and before MLP:
0012: 
0013: 1. normalized hidden state;
0014: 2. small local/content correction;
0015: 3. gated residual add.
0016: 
0017: ## Constraints
0018: 
0019: - small parameter share;
0020: - low latency;
0021: - optional in decode;
0022: - no full attention;
0023: - no all-token quadratic mixing;
0024: - can be stronger during training/prefill.
0025: 
0026: ## Decode behavior
0027: 
0028: Default:
0029: - TSC minimal or disabled.
0030: 
0031: Adaptive:
0032: - enabled if AION uncertainty trigger fires.
0033: 
0034: Training:
0035: - enabled more often;
0036: - consistency loss encourages decode path to survive without full correction.
0037: 
0038: ## Ablation requirements
0039: 
0040: Benchmarks must report:
0041: - QLAF only;
0042: - QLAF + AION;
0043: - QLAF + TSC;
0044: - QLAF + AION + TSC;
0045: - decode branch enabled/disabled.
```


## engine_stack_pass1 / `docs/05_DECODE_BRANCH_SPECIALIZATION.md`

```text
0001: # Decode Branch Specialization
0002: 
0003: ## Goal
0004: 
0005: Make the serving path fast enough to defeat Transformer KV-cache decode on one GPU.
0006: 
0007: ## Training path
0008: 
0009: Training uses:
0010: - richer top-k state access;
0011: - TSC correction;
0012: - optional teacher KL;
0013: - route regularization.
0014: 
0015: ## Decode path
0016: 
0017: Serving uses:
0018: - top-1 state default;
0019: - cache-resident updates;
0020: - minimal TSC;
0021: - no full attention;
0022: - no full sequence recomputation.
0023: 
0024: ## Consistency losses
0025: 
0026: Recommended:
0027: 
0028: 1. full branch CE loss;
0029: 2. decode branch CE loss;
0030: 3. full-to-decode KL;
0031: 4. top-1 route stability loss;
0032: 5. refresh penalty.
0033: 
0034: ## Exit criteria
0035: 
0036: Decode branch is acceptable only if:
0037: - quality loss vs rich path is small;
0038: - decode latency improves materially;
0039: - p95 remains stable;
0040: - adaptive widening recovers hard cases.
```


## engine_stack_pass1 / `docs/06_ROUTE_B_DEPLOYMENT.md`

```text
0001: # Route B CUDA/HF Deployment
0002: 
0003: ## Components
0004: 
0005: ### HF repository
0006: 
0007: Contains:
0008: - config;
0009: - custom model files;
0010: - generation utilities;
0011: - tokenizer;
0012: - safetensors;
0013: - README/model card.
0014: 
0015: Requires:
0016: - `trust_remote_code=True`.
0017: 
0018: ### CUDA wheel
0019: 
0020: Contains:
0021: - QLAF prefill kernels;
0022: - QLAF decode kernels;
0023: - cache update kernels;
0024: - route selection kernels;
0025: - optional TSC kernels.
0026: 
0027: ### Custom server
0028: 
0029: Contains:
0030: - prefill/decode scheduler;
0031: - streaming output;
0032: - cache ownership;
0033: - metrics;
0034: - memory accounting;
0035: - batching.
0036: 
0037: ## Correct deployment modes
0038: 
0039: ### Mode 1: HF fallback
0040: 
0041: Works anywhere. Not performance claim.
0042: 
0043: ### Mode 2: HF + CUDA wheel
0044: 
0045: Local accelerated inference.
0046: 
0047: ### Mode 3: Docker/custom server
0048: 
0049: Production performance path.
0050: 
0051: ## Warning
0052: 
0053: Hosted generic inference may not preserve the custom-kernel advantages. The official performance claim should be based on the custom server and wheel.
```


## engine_stack_pass1 / `docs/07_BENCHMARK_GATES.md`

```text
0001: # Benchmark Gates
0002: 
0003: ## Gate 1: Correctness
0004: 
0005: - no future leakage;
0006: - full-forward/cached-decode parity;
0007: - CUDA/reference parity;
0008: - batch/single equivalence;
0009: - cache invalidation.
0010: 
0011: ## Gate 2: Matched training
0012: 
0013: - matched Transformer;
0014: - matched V39;
0015: - same tokenizer;
0016: - same dataset;
0017: - same train/val split;
0018: - same optimizer;
0019: - same tokens;
0020: - same context;
0021: - 5 seeds.
0022: 
0023: ## Gate 3: Serving
0024: 
0025: Report:
0026: - prefill tokens/sec;
0027: - decode tokens/sec;
0028: - end-to-end tokens/sec;
0029: - p50 latency;
0030: - p95 latency;
0031: - peak GPU memory;
0032: - cache memory.
0033: 
0034: ## Gate 4: Long context
0035: 
0036: Test:
0037: - 512;
0038: - 1024;
0039: - 2048;
0040: - 4096;
0041: - 8192.
0042: 
0043: ## Gate 5: Ablation
0044: 
0045: Report:
0046: - Transformer;
0047: - QLAF only;
0048: - QLAF + AION;
0049: - QLAF + TSC;
0050: - QLAF + AION + TSC;
0051: - decode branch top-1;
0052: - adaptive top-k.
0053: 
0054: ## Superiority threshold
0055: 
0056: A defensible "utter superiority" single-GPU claim needs:
0057: 
0058: - quality within 0–5% of Transformer, preferably equal/better;
0059: - decode speed +50% or more;
0060: - cache memory -40% or more;
0061: - p95 latency -25% or more;
0062: - long-context serving advantage increasing with context;
0063: - reproducible scripts/logs.
```


## engine_stack_pass1 / `hf_repo_template/HF_REPO_SPEC.md`

```text
0001: # Hugging Face Repo Template Spec
0002: 
0003: ## Required files
0004: 
0005: - config.json
0006: - configuration_odyssey_v39.py
0007: - modeling_odyssey_v39.py
0008: - generation_odyssey_v39.py
0009: - tokenizer files
0010: - model.safetensors
0011: - README.md
0012: - requirements.txt
0013: 
0014: ## Loading
0015: 
0016: Use:
0017: 
0018: AutoModelForCausalLM.from_pretrained(
0019:     repo,
0020:     trust_remote_code=True,
0021:     torch_dtype="auto",
0022:     device_map="auto",
0023: )
0024: 
0025: ## Model card warning
0026: 
0027: Best performance requires:
0028: - odyssey-v39-cuda wheel;
0029: - compatible CUDA/PyTorch version;
0030: - custom Odyssey server.
0031: 
0032: PyTorch fallback is for portability/correctness, not final performance claims.
```


## engine_stack_pass1 / `manifest.json`

```text
0001: {
0002:   "package": "odyssey_v39_engine_stack_pass1",
0003:   "date": "2026-04-28",
0004:   "architecture_stack": "QLAF causal state cache + AION adaptive hierarchy + TSC residual correction + decode-branch specialization + Route B CUDA/HF deployment",
0005:   "status": "implementation-grade scaffold and specification; not benchmark proof",
0006:   "files": [
0007:     "README.md",
0008:     "pyproject.toml",
0009:     "docs/00_EXECUTIVE_SPEC.md",
0010:     "docs/01_ENGINE_ARCHITECTURE.md",
0011:     "docs/02_CACHE_SCHEMA.md",
0012:     "docs/03_AION_POLICY.md",
0013:     "docs/04_TSC_RESIDUAL_CORRECTION.md",
0014:     "docs/05_DECODE_BRANCH_SPECIALIZATION.md",
0015:     "docs/06_ROUTE_B_DEPLOYMENT.md",
0016:     "docs/07_BENCHMARK_GATES.md",
0017:     "tests/test_cache_contract.py",
0018:     "tests/test_aion_policy.py",
0019:     "benchmarks/BENCHMARK_PROTOCOL.md",
0020:     "server/SERVER_SPEC.md",
0021:     "hf_repo_template/HF_REPO_SPEC.md",
0022:     "cuda_extension/odyssey_v39_cuda/CUDA_ABI.md",
0023:     "src/odyssey_v39/__init__.py",
0024:     "src/odyssey_v39/config.py",
0025:     "src/odyssey_v39/cache.py",
0026:     "src/odyssey_v39/aion.py",
0027:     "src/odyssey_v39/tsc.py",
0028:     "src/odyssey_v39/dispatcher.py",
0029:     "src/odyssey_v39/engine.py"
0030:   ]
0031: }
```


## engine_stack_pass1 / `pyproject.toml`

```text
0001: [project]
0002: name = "odyssey-v39-engine-stack"
0003: version = "0.1.0"
0004: description = "Odyssey V39 single-GPU QLAF/AION/TSC Transformer-replacement engine scaffold"
0005: requires-python = ">=3.10"
0006: 
0007: [tool.pytest.ini_options]
0008: pythonpath = ["src"]
0009: testpaths = ["tests"]
```


## engine_stack_pass1 / `server/SERVER_SPEC.md`

```text
0001: # Odyssey V39 Server Spec
0002: 
0003: ## Responsibilities
0004: 
0005: - load HF model with trust_remote_code;
0006: - load CUDA wheel if available;
0007: - own QLAF caches;
0008: - separate prefill and decode;
0009: - stream tokens;
0010: - batch compatible decode requests;
0011: - avoid mixing fallback requests into fast CUDA batch;
0012: - report metrics.
0013: 
0014: ## Endpoints
0015: 
0016: - /health
0017: - /generate
0018: - /generate_stream
0019: - /metrics
0020: - /cache/debug
0021: 
0022: ## Required metrics
0023: 
0024: - active requests;
0025: - prefill queue length;
0026: - decode batch size;
0027: - tokens/sec;
0028: - p50 latency;
0029: - p95 latency;
0030: - peak GPU memory;
0031: - cache memory;
0032: - fallback count;
0033: - refresh count;
```


## engine_stack_pass1 / `src/odyssey_v39/__init__.py`

```text
0001: from .config import OdysseyV39Config, RuntimeConfig
0002: from .cache import QLAFCausalStateCache
0003: from .aion import AIONPolicy
0004: from .tsc import TSCResidualPolicy
0005: from .engine import OdysseyV39Engine
```


## engine_stack_pass1 / `src/odyssey_v39/aion.py`

```text
0001: from dataclasses import dataclass
0002: 
0003: @dataclass
0004: class AIONDecision:
0005:     top_k: int
0006:     refresh: bool
0007:     promote_hierarchy: bool
0008:     enable_tsc: bool
0009:     reason: str
0010: 
0011: class AIONPolicy:
0012:     def __init__(self, decode_top_k=1, prefill_top_k=2, confidence_threshold=0.65, refresh_interval=128):
0013:         self.decode_top_k = decode_top_k
0014:         self.prefill_top_k = prefill_top_k
0015:         self.confidence_threshold = confidence_threshold
0016:         self.refresh_interval = refresh_interval
0017: 
0018:     def decide_decode(self, route_confidence: float, entropy: float, steps_since_refresh: int) -> AIONDecision:
0019:         if steps_since_refresh >= self.refresh_interval:
0020:             return AIONDecision(top_k=max(2, self.decode_top_k), refresh=True, promote_hierarchy=True, enable_tsc=True, reason="periodic_refresh")
0021:         if route_confidence < self.confidence_threshold:
0022:             return AIONDecision(top_k=max(2, self.decode_top_k), refresh=False, promote_hierarchy=False, enable_tsc=True, reason="low_confidence")
0023:         return AIONDecision(top_k=self.decode_top_k, refresh=False, promote_hierarchy=False, enable_tsc=False, reason="fast_top1")
```


## engine_stack_pass1 / `src/odyssey_v39/cache.py`

```text
0001: from dataclasses import dataclass, field
0002: from typing import Dict, Any, Optional
0003: 
0004: @dataclass
0005: class CacheMetadata:
0006:     dtype: str
0007:     device: str
0008:     model_revision: str
0009:     kernel_version: str
0010:     routing_policy: str
0011:     valid: bool = True
0012: 
0013: @dataclass
0014: class LayerState:
0015:     state_summary: Any = None
0016:     state_weight: Any = None
0017:     active_state_ids: Any = None
0018:     route_confidence: Any = None
0019:     hierarchy_level: Any = None
0020:     refresh_counter: Any = None
0021:     position: Any = None
0022:     valid: bool = False
0023: 
0024: class QLAFCausalStateCache:
0025:     def __init__(self, num_layers: int, metadata: CacheMetadata):
0026:         self.num_layers = num_layers
0027:         self.metadata = metadata
0028:         self.layers = [LayerState() for _ in range(num_layers)]
0029: 
0030:     def invalidate(self, reason: str):
0031:         self.metadata.valid = False
0032:         for layer in self.layers:
0033:             layer.valid = False
0034:         self.invalid_reason = reason
0035: 
0036:     def is_valid(self) -> bool:
0037:         return bool(self.metadata.valid and all(layer.valid for layer in self.layers))
0038: 
0039:     def mark_layer_valid(self, layer_idx: int):
0040:         self.layers[layer_idx].valid = True
0041: 
0042:     def require_valid(self):
0043:         if not self.is_valid():
0044:             reason = getattr(self, "invalid_reason", "unknown")
0045:             raise RuntimeError(f"QLAF cache invalid: {reason}")
```


## engine_stack_pass1 / `src/odyssey_v39/config.py`

```text
0001: from dataclasses import dataclass
0002: 
0003: @dataclass
0004: class OdysseyV39Config:
0005:     vocab_size: int = 32000
0006:     hidden_size: int = 1024
0007:     intermediate_size: int = 4096
0008:     num_layers: int = 16
0009:     num_states: int = 8
0010:     state_rank: int = 64
0011:     prefill_top_k: int = 2
0012:     decode_top_k: int = 1
0013:     max_position_embeddings: int = 8192
0014:     use_tsc: bool = True
0015:     use_aion: bool = True
0016: 
0017: @dataclass
0018: class RuntimeConfig:
0019:     device: str = "cuda"
0020:     dtype: str = "bfloat16"
0021:     use_cuda_kernels: bool = True
0022:     allow_fallback: bool = True
0023:     force_reference: bool = False
0024:     cache_refresh_interval: int = 128
0025:     route_confidence_threshold: float = 0.65
0026:     entropy_refresh_threshold: float = 7.5
```


## engine_stack_pass1 / `src/odyssey_v39/dispatcher.py`

```text
0001: class KernelDispatcher:
0002:     def __init__(self, use_cuda_kernels=True, allow_fallback=True, force_reference=False):
0003:         self.use_cuda_kernels = use_cuda_kernels
0004:         self.allow_fallback = allow_fallback
0005:         self.force_reference = force_reference
0006:         self.cuda_available = False
0007:         self.cuda_module = None
0008:         if use_cuda_kernels and not force_reference:
0009:             try:
0010:                 import odyssey_v39_cuda
0011:                 self.cuda_module = odyssey_v39_cuda
0012:                 self.cuda_available = True
0013:             except Exception:
0014:                 self.cuda_available = False
0015: 
0016:     def backend(self) -> str:
0017:         if self.force_reference:
0018:             return "reference"
0019:         if self.use_cuda_kernels and self.cuda_available:
0020:             return "cuda"
0021:         if self.allow_fallback:
0022:             return "reference"
0023:         raise RuntimeError("CUDA kernels unavailable and fallback disabled")
0024: 
0025:     def prefill(self, *args, **kwargs):
0026:         if self.backend() == "cuda":
0027:             return self.cuda_module.prefill(*args, **kwargs)
0028:         raise NotImplementedError("Reference prefill must be provided by model implementation")
0029: 
0030:     def decode(self, *args, **kwargs):
0031:         if self.backend() == "cuda":
0032:             return self.cuda_module.decode(*args, **kwargs)
0033:         raise NotImplementedError("Reference decode must be provided by model implementation")
```


## engine_stack_pass1 / `src/odyssey_v39/engine.py`

```text
0001: from .config import OdysseyV39Config, RuntimeConfig
0002: from .cache import QLAFCausalStateCache, CacheMetadata
0003: from .aion import AIONPolicy
0004: from .tsc import TSCResidualPolicy
0005: from .dispatcher import KernelDispatcher
0006: 
0007: class OdysseyV39Engine:
0008:     def __init__(self, model=None, tokenizer=None, config=None, runtime=None, model_revision="dev"):
0009:         self.model = model
0010:         self.tokenizer = tokenizer
0011:         self.config = config or OdysseyV39Config()
0012:         self.runtime = runtime or RuntimeConfig()
0013:         self.model_revision = model_revision
0014:         self.aion = AIONPolicy(
0015:             decode_top_k=self.config.decode_top_k,
0016:             prefill_top_k=self.config.prefill_top_k,
0017:             confidence_threshold=self.runtime.route_confidence_threshold,
0018:             refresh_interval=self.runtime.cache_refresh_interval,
0019:         )
0020:         self.tsc_policy = TSCResidualPolicy(enabled=self.config.use_tsc)
0021:         self.dispatcher = KernelDispatcher(
0022:             use_cuda_kernels=self.runtime.use_cuda_kernels,
0023:             allow_fallback=self.runtime.allow_fallback,
0024:             force_reference=self.runtime.force_reference,
0025:         )
0026: 
0027:     def new_cache(self):
0028:         metadata = CacheMetadata(
0029:             dtype=self.runtime.dtype,
0030:             device=self.runtime.device,
0031:             model_revision=self.model_revision,
0032:             kernel_version="v39-dev",
0033:             routing_policy="aion_adaptive" if self.config.use_aion else "fixed_top1",
0034:         )
0035:         return QLAFCausalStateCache(self.config.num_layers, metadata)
0036: 
0037:     def prefill(self, input_ids):
0038:         cache = self.new_cache()
0039:         if self.model is None:
0040:             raise RuntimeError("No model attached")
0041:         if hasattr(self.model, "prefill"):
0042:             return self.model.prefill(input_ids, cache)
0043:         raise NotImplementedError("Attached model must implement prefill(input_ids, cache)")
0044: 
0045:     def decode_step(self, token_ids, cache, route_confidence=1.0, entropy=0.0, steps_since_refresh=0):
0046:         cache.require_valid()
0047:         decision = self.aion.decide_decode(route_confidence, entropy, steps_since_refresh)
0048:         tsc_scale = self.tsc_policy.scale_for_decode(decision.enable_tsc)
0049:         if self.model is None:
0050:             raise RuntimeError("No model attached")
0051:         if hasattr(self.model, "decode_step"):
0052:             return self.model.decode_step(token_ids, cache, decision=decision, tsc_scale=tsc_scale)
0053:         raise NotImplementedError("Attached model must implement decode_step(token_ids, cache, decision, tsc_scale)")
```


## engine_stack_pass1 / `src/odyssey_v39/tsc.py`

```text
0001: from dataclasses import dataclass
0002: 
0003: @dataclass
0004: class TSCResidualPolicy:
0005:     enabled: bool = True
0006:     decode_default_enabled: bool = False
0007:     correction_scale: float = 0.10
0008:     max_decode_scale: float = 0.20
0009: 
0010:     def scale_for_decode(self, enable_tsc: bool) -> float:
0011:         if not self.enabled:
0012:             return 0.0
0013:         if enable_tsc:
0014:             return self.max_decode_scale
0015:         if self.decode_default_enabled:
0016:             return self.correction_scale
0017:         return 0.0
```


## engine_stack_pass1 / `tests/test_aion_policy.py`

```text
0001: def test_aion_fast_top1():
0002:     from odyssey_v39.aion import AIONPolicy
0003:     p = AIONPolicy(decode_top_k=1, confidence_threshold=0.5, refresh_interval=100)
0004:     d = p.decide_decode(route_confidence=0.9, entropy=1.0, steps_since_refresh=1)
0005:     assert d.top_k == 1
0006:     assert not d.refresh
0007: 
0008: def test_aion_low_confidence_widens():
0009:     from odyssey_v39.aion import AIONPolicy
0010:     p = AIONPolicy(decode_top_k=1, confidence_threshold=0.8, refresh_interval=100)
0011:     d = p.decide_decode(route_confidence=0.2, entropy=1.0, steps_since_refresh=1)
0012:     assert d.top_k >= 2
0013:     assert d.enable_tsc
```


## engine_stack_pass1 / `tests/test_cache_contract.py`

```text
0001: # Contract tests for Odyssey V39 cache.
0002: # These are stubs for the real implementation.
0003: 
0004: def test_cache_invalidates_all_layers():
0005:     from odyssey_v39.cache import QLAFCausalStateCache, CacheMetadata
0006:     cache = QLAFCausalStateCache(3, CacheMetadata("bf16", "cuda", "dev", "dev", "top1"))
0007:     for i in range(3):
0008:         cache.mark_layer_valid(i)
0009:     cache.invalidate("unit_test")
0010:     assert not cache.is_valid()
0011: 
0012: def test_cache_requires_valid():
0013:     from odyssey_v39.cache import QLAFCausalStateCache, CacheMetadata
0014:     cache = QLAFCausalStateCache(1, CacheMetadata("bf16", "cuda", "dev", "dev", "top1"))
0015:     try:
0016:         cache.require_valid()
0017:     except RuntimeError:
0018:         assert True
0019:     else:
0020:         assert False
```


## correctness_gates / `LOCAL_RUN_RESULT.txt`

```text
0001: Command: python run_gates.py
0002: Exit status: -1
0003: 
0004: Output:
0005: TimeoutExpired(['/opt/pyvenv/bin/python', '/mnt/data/odyssey_v39_correctness_gates/run_gates.py'], 45)
```


## correctness_gates / `README.md`

```text
0001: # Odyssey V39 Correctness Gates
0002: 
0003: This artifact targets the five correctness gates required before speed claims:
0004: 
0005: 1. full-forward vs cached-decode parity;
0006: 2. no-future-leakage;
0007: 3. cache reset;
0008: 4. batch equivalence;
0009: 5. top-1/top-2 routing behavior.
0010: 
0011: This is a reference correctness harness, not the production engine and not a CUDA implementation.
0012: 
0013: The harness intentionally uses a tiny deterministic QLAF-style causal state model so the engine contract can be tested before optimizing kernels.
```


## correctness_gates / `docs/CORRECTNESS_GATE_REPORT_TEMPLATE.md`

```text
0001: # Odyssey V39 Correctness Gate Report
0002: 
0003: ## Summary
0004: 
0005: - Date:
0006: - Commit / package:
0007: - Device:
0008: - Dtype:
0009: - All gates passed:
0010: 
0011: ## Results
0012: 
0013: | Gate | Passed | Metric |
0014: |---|---:|---|
0015: | full-forward vs cached-decode parity |  | max abs diff |
0016: | no-future-leakage |  | max abs diff |
0017: | cache reset |  | state max / position |
0018: | batch equivalence |  | max abs diff |
0019: | top-1/top-2 routing behavior |  | route shapes / cache diff |
0020: 
0021: ## Interpretation
0022: 
0023: If all gates pass, the engine is ready for:
0024: 1. AION policy integration;
0025: 2. TSC residual correction parity;
0026: 3. CUDA reference parity;
0027: 4. matched Transformer quality benchmark.
0028: 
0029: If any gate fails, do not benchmark speed yet.
```


## correctness_gates / `docs/CORRECTNESS_GATE_SPEC.md`

```text
0001: # Correctness Gate Specification
0002: 
0003: ## Gate 1 — Full-forward vs cached-decode parity
0004: 
0005: Purpose:
0006: The model's causal full forward must match prefill/decode execution when both use the same routing policy.
0007: 
0008: Pass:
0009: - max absolute logit difference within tolerance.
0010: 
0011: Fail means:
0012: - cache update does not match full causal scan;
0013: - position handling is wrong;
0014: - routing differs;
0015: - future leakage or stale state exists.
0016: 
0017: ## Gate 2 — No future leakage
0018: 
0019: Purpose:
0020: Changing suffix tokens must not alter logits for prefix positions.
0021: 
0022: Pass:
0023: - prefix logits are identical when suffix changes.
0024: 
0025: Fail means:
0026: - full forward is non-causal;
0027: - scan accidentally reads future;
0028: - batch operation mixes future tokens.
0029: 
0030: ## Gate 3 — Cache reset
0031: 
0032: Purpose:
0033: Reset must clear state summaries, weights, position, and validity.
0034: 
0035: Pass:
0036: - state tensors zero;
0037: - position zero;
0038: - cache valid.
0039: 
0040: Fail means:
0041: - stale generation state can leak across requests.
0042: 
0043: ## Gate 4 — Batch equivalence
0044: 
0045: Purpose:
0046: Batch execution must match independent single-sequence execution.
0047: 
0048: Pass:
0049: - batched logits equal concatenated single logits.
0050: 
0051: Fail means:
0052: - batch dimension mixing;
0053: - cache rows corrupted;
0054: - routing uses cross-batch data.
0055: 
0056: ## Gate 5 — Top-1/top-2 routing behavior
0057: 
0058: Purpose:
0059: Top-1 and top-2 modes must be structurally different and observable.
0060: 
0061: Pass:
0062: - top-1 route has one state;
0063: - top-2 route has two distinct states;
0064: - resulting cache differs between top-1 and top-2.
0065: 
0066: Fail means:
0067: - adaptive routing is fake;
0068: - top-k selection broken;
0069: - AION widening cannot work.
```


## correctness_gates / `manifest.json`

```text
0001: {
0002:   "name": "odyssey_v39_correctness_gates",
0003:   "purpose": "full-forward vs cached-decode parity, no-future-leakage, cache reset, batch equivalence, top-1/top-2 routing behavior",
0004:   "local_run_exit_status": -1,
0005:   "files": [
0006:     "README.md",
0007:     "pyproject.toml",
0008:     "run_gates.py",
0009:     "LOCAL_RUN_RESULT.txt",
0010:     "tests/test_correctness_gates.py",
0011:     "docs/CORRECTNESS_GATE_SPEC.md",
0012:     "docs/CORRECTNESS_GATE_REPORT_TEMPLATE.md",
0013:     "src/odyssey_v39_gates/__init__.py",
0014:     "src/odyssey_v39_gates/cache.py",
0015:     "src/odyssey_v39_gates/tiny_model.py",
0016:     "src/odyssey_v39_gates/gates.py",
0017:     "src/odyssey_v39_gates/__pycache__/__init__.cpython-313.pyc",
0018:     "src/odyssey_v39_gates/__pycache__/tiny_model.cpython-313.pyc",
0019:     "src/odyssey_v39_gates/__pycache__/cache.cpython-313.pyc",
0020:     "src/odyssey_v39_gates/__pycache__/gates.cpython-313.pyc"
0021:   ]
0022: }
```


## correctness_gates / `pyproject.toml`

```text
0001: [project]
0002: name = "odyssey-v39-correctness-gates"
0003: version = "0.1.0"
0004: requires-python = ">=3.10"
0005: dependencies = ["torch"]
0006: 
0007: [tool.pytest.ini_options]
0008: pythonpath = ["src"]
0009: testpaths = ["tests"]
```


## correctness_gates / `run_gates.py`

```text
0001: import json
0002: from odyssey_v39_gates.gates import run_all_gates
0003: 
0004: if __name__ == "__main__":
0005:     report = run_all_gates()
0006:     print(json.dumps(report, indent=2))
```


## correctness_gates / `src/odyssey_v39_gates/__init__.py`

```text
0001: from .tiny_model import TinyV39Config, TinyV39Model
0002: from .cache import TinyQLAFCache
0003: from .gates import run_all_gates
```


## correctness_gates / `src/odyssey_v39_gates/cache.py`

```text
0001: from dataclasses import dataclass
0002: import torch
0003: 
0004: @dataclass
0005: class TinyQLAFCache:
0006:     state_summary: torch.Tensor
0007:     state_weight: torch.Tensor
0008:     position: int
0009:     valid: bool = True
0010: 
0011:     @classmethod
0012:     def empty(cls, batch_size, layers, states, rank, device=None, dtype=torch.float32):
0013:         return cls(
0014:             state_summary=torch.zeros(batch_size, layers, states, rank, device=device, dtype=dtype),
0015:             state_weight=torch.zeros(batch_size, layers, states, device=device, dtype=dtype),
0016:             position=0,
0017:             valid=True,
0018:         )
0019: 
0020:     def clone(self):
0021:         return TinyQLAFCache(
0022:             state_summary=self.state_summary.clone(),
0023:             state_weight=self.state_weight.clone(),
0024:             position=int(self.position),
0025:             valid=bool(self.valid),
0026:         )
0027: 
0028:     def reset(self):
0029:         self.state_summary.zero_()
0030:         self.state_weight.zero_()
0031:         self.position = 0
0032:         self.valid = True
0033: 
0034:     def invalidate(self):
0035:         self.valid = False
0036: 
0037:     def require_valid(self):
0038:         if not self.valid:
0039:             raise RuntimeError("TinyQLAFCache is invalid")
```


## correctness_gates / `src/odyssey_v39_gates/gates.py`

```text
0001: import json
0002: import torch
0003: from .tiny_model import TinyV39Config, TinyV39Model
0004: from .cache import TinyQLAFCache
0005: 
0006: def set_seed(seed=1234):
0007:     torch.manual_seed(seed)
0008:     if torch.cuda.is_available():
0009:         torch.cuda.manual_seed_all(seed)
0010: 
0011: def max_abs(a, b):
0012:     return float((a - b).abs().max().item())
0013: 
0014: def gate_full_forward_vs_cached_decode(device="cpu"):
0015:     set_seed(1)
0016:     cfg = TinyV39Config()
0017:     model = TinyV39Model(cfg).to(device).eval()
0018:     input_ids = torch.randint(0, cfg.vocab_size, (3, 9), device=device)
0019:     with torch.no_grad():
0020:         full = model.forward_full(input_ids, top_k=2)
0021:         cached, _ = model.prefill(input_ids, top_k=2)
0022:     diff = max_abs(full, cached)
0023:     return {"gate": "full_forward_vs_cached_decode", "passed": diff < 1e-6, "max_abs_diff": diff}
0024: 
0025: def gate_no_future_leakage(device="cpu"):
0026:     set_seed(2)
0027:     cfg = TinyV39Config()
0028:     model = TinyV39Model(cfg).to(device).eval()
0029:     prefix = torch.randint(0, cfg.vocab_size, (2, 6), device=device)
0030:     suffix_a = torch.randint(0, cfg.vocab_size, (2, 4), device=device)
0031:     suffix_b = torch.randint(0, cfg.vocab_size, (2, 4), device=device)
0032:     seq_a = torch.cat([prefix, suffix_a], dim=1)
0033:     seq_b = torch.cat([prefix, suffix_b], dim=1)
0034:     with torch.no_grad():
0035:         logits_a = model.forward_full(seq_a, top_k=2)[:, :prefix.shape[1]]
0036:         logits_b = model.forward_full(seq_b, top_k=2)[:, :prefix.shape[1]]
0037:     diff = max_abs(logits_a, logits_b)
0038:     return {"gate": "no_future_leakage", "passed": diff < 1e-6, "max_abs_diff": diff}
0039: 
0040: def gate_cache_reset(device="cpu"):
0041:     set_seed(3)
0042:     cfg = TinyV39Config()
0043:     cache = TinyQLAFCache.empty(2, cfg.layers, cfg.states, cfg.rank, device=device)
0044:     cache.state_summary.normal_()
0045:     cache.state_weight.uniform_()
0046:     cache.position = 7
0047:     cache.reset()
0048:     summary_zero = float(cache.state_summary.abs().max().item())
0049:     weight_zero = float(cache.state_weight.abs().max().item())
0050:     passed = summary_zero == 0.0 and weight_zero == 0.0 and cache.position == 0 and cache.valid
0051:     return {"gate": "cache_reset", "passed": passed, "summary_max": summary_zero, "weight_max": weight_zero, "position": cache.position}
0052: 
0053: def gate_batch_equivalence(device="cpu"):
0054:     set_seed(4)
0055:     cfg = TinyV39Config()
0056:     model = TinyV39Model(cfg).to(device).eval()
0057:     input_ids = torch.randint(0, cfg.vocab_size, (4, 8), device=device)
0058:     with torch.no_grad():
0059:         batch_logits = model.forward_full(input_ids, top_k=2)
0060:         singles = []
0061:         for i in range(input_ids.shape[0]):
0062:             singles.append(model.forward_full(input_ids[i:i+1], top_k=2))
0063:         single_logits = torch.cat(singles, dim=0)
0064:     diff = max_abs(batch_logits, single_logits)
0065:     return {"gate": "batch_equivalence", "passed": diff < 1e-6, "max_abs_diff": diff}
0066: 
0067: def gate_top1_top2_routing_behavior(device="cpu"):
0068:     set_seed(5)
0069:     cfg = TinyV39Config()
0070:     model = TinyV39Model(cfg).to(device).eval()
0071:     input_ids = torch.randint(0, cfg.vocab_size, (2, 7), device=device)
0072:     cache1 = TinyQLAFCache.empty(2, cfg.layers, cfg.states, cfg.rank, device=device)
0073:     cache2 = TinyQLAFCache.empty(2, cfg.layers, cfg.states, cfg.rank, device=device)
0074:     route_shapes_ok = True
0075:     top2_has_two = True
0076:     with torch.no_grad():
0077:         for t in range(input_ids.shape[1]):
0078:             _, cache1, info1 = model.decode_step(input_ids[:, t:t+1], cache1, top_k=1)
0079:             _, cache2, info2 = model.decode_step(input_ids[:, t:t+1], cache2, top_k=2)
0080:             route_shapes_ok &= info1["route_ids"].shape[-1] == 1
0081:             route_shapes_ok &= info2["route_ids"].shape[-1] == 2
0082:             top2_has_two &= bool((info2["route_ids"][:, :, 0] != info2["route_ids"][:, :, 1]).all().item())
0083:     cache_difference = float((cache1.state_summary - cache2.state_summary).abs().sum().item())
0084:     passed = bool(route_shapes_ok and top2_has_two and cache_difference > 0.0)
0085:     return {
0086:         "gate": "top1_top2_routing_behavior",
0087:         "passed": passed,
0088:         "route_shapes_ok": bool(route_shapes_ok),
0089:         "top2_distinct_ids": bool(top2_has_two),
0090:         "cache_l1_difference": cache_difference
0091:     }
0092: 
0093: def run_all_gates(device=None):
0094:     if device is None:
0095:         device = "cuda" if torch.cuda.is_available() else "cpu"
0096:     results = [
0097:         gate_full_forward_vs_cached_decode(device),
0098:         gate_no_future_leakage(device),
0099:         gate_cache_reset(device),
0100:         gate_batch_equivalence(device),
0101:         gate_top1_top2_routing_behavior(device),
0102:     ]
0103:     return {
0104:         "device": device,
0105:         "all_passed": all(r["passed"] for r in results),
0106:         "results": results,
0107:     }
0108: 
0109: if __name__ == "__main__":
0110:     print(json.dumps(run_all_gates(), indent=2))
```


## correctness_gates / `src/odyssey_v39_gates/tiny_model.py`

```text
0001: from dataclasses import dataclass
0002: from typing import Tuple, Optional
0003: import torch
0004: import torch.nn as nn
0005: import torch.nn.functional as F
0006: from .cache import TinyQLAFCache
0007: 
0008: @dataclass
0009: class TinyV39Config:
0010:     vocab_size: int = 31
0011:     hidden_size: int = 24
0012:     layers: int = 2
0013:     states: int = 4
0014:     rank: int = 8
0015:     max_positions: int = 64
0016:     top1_threshold: float = 0.0
0017: 
0018: class TinyQLAFLayer(nn.Module):
0019:     def __init__(self, cfg: TinyV39Config):
0020:         super().__init__()
0021:         self.cfg = cfg
0022:         h, s, r = cfg.hidden_size, cfg.states, cfg.rank
0023:         self.norm = nn.LayerNorm(h)
0024:         self.route = nn.Linear(h, s, bias=False)
0025:         self.to_rank = nn.Linear(h, r, bias=False)
0026:         self.from_state = nn.Linear(s * r, h, bias=False)
0027:         self.mlp = nn.Sequential(nn.LayerNorm(h), nn.Linear(h, 4*h), nn.SiLU(), nn.Linear(4*h, h))
0028: 
0029:     def route_topk(self, x, top_k):
0030:         logits = self.route(self.norm(x))
0031:         probs = torch.softmax(logits, dim=-1)
0032:         vals, ids = torch.topk(probs, k=top_k, dim=-1)
0033:         vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0034:         return ids, vals, probs
0035: 
0036:     def update_one(self, x_t, layer_state, layer_weight, top_k):
0037:         # x_t: [B,H], layer_state: [B,S,R], layer_weight: [B,S]
0038:         ids, vals, probs = self.route_topk(x_t, top_k)
0039:         z = self.to_rank(self.norm(x_t))
0040:         B, S, R = layer_state.shape
0041:         new_state = layer_state.clone()
0042:         new_weight = layer_weight.clone()
0043: 
0044:         for j in range(top_k):
0045:             sid = ids[:, j]
0046:             w = vals[:, j]
0047:             for b in range(B):
0048:                 sidx = int(sid[b].item())
0049:                 old_w = new_weight[b, sidx]
0050:                 add_w = w[b]
0051:                 denom = old_w + add_w
0052:                 new_state[b, sidx] = (new_state[b, sidx] * old_w + z[b] * add_w) / denom.clamp_min(1e-8)
0053:                 new_weight[b, sidx] = denom
0054: 
0055:         read = (new_state * new_weight.unsqueeze(-1).clamp_min(0.0)).reshape(B, S * R)
0056:         denom = new_weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0057:         read = read / denom
0058:         y = x_t + self.from_state(read)
0059:         y = y + self.mlp(y)
0060:         confidence = probs.max(dim=-1).values
0061:         return y, new_state, new_weight, ids, confidence
0062: 
0063: class TinyV39Model(nn.Module):
0064:     def __init__(self, cfg: TinyV39Config):
0065:         super().__init__()
0066:         self.cfg = cfg
0067:         self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
0068:         self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
0069:         self.layers = nn.ModuleList([TinyQLAFLayer(cfg) for _ in range(cfg.layers)])
0070:         self.final_norm = nn.LayerNorm(cfg.hidden_size)
0071:         self.lm_head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)
0072: 
0073:     def _token_hidden(self, input_ids, pos_offset=0):
0074:         B, T = input_ids.shape
0075:         positions = torch.arange(pos_offset, pos_offset + T, device=input_ids.device).unsqueeze(0).expand(B, T)
0076:         return self.embed(input_ids) + self.pos(positions)
0077: 
0078:     def forward_full(self, input_ids, top_k=2):
0079:         B, T = input_ids.shape
0080:         cache = TinyQLAFCache.empty(
0081:             B, self.cfg.layers, self.cfg.states, self.cfg.rank,
0082:             device=input_ids.device, dtype=self.embed.weight.dtype
0083:         )
0084:         logits_list = []
0085:         hidden = self._token_hidden(input_ids, 0)
0086:         for t in range(T):
0087:             x = hidden[:, t]
0088:             for li, layer in enumerate(self.layers):
0089:                 x, ns, nw, _, _ = layer.update_one(
0090:                     x, cache.state_summary[:, li], cache.state_weight[:, li], top_k=top_k
0091:                 )
0092:                 cache.state_summary[:, li] = ns
0093:                 cache.state_weight[:, li] = nw
0094:             logits_list.append(self.lm_head(self.final_norm(x)).unsqueeze(1))
0095:             cache.position += 1
0096:         return torch.cat(logits_list, dim=1)
0097: 
0098:     def prefill(self, input_ids, top_k=2):
0099:         B, T = input_ids.shape
0100:         cache = TinyQLAFCache.empty(
0101:             B, self.cfg.layers, self.cfg.states, self.cfg.rank,
0102:             device=input_ids.device, dtype=self.embed.weight.dtype
0103:         )
0104:         logits = []
0105:         for t in range(T):
0106:             step_logits, cache, _ = self.decode_step(input_ids[:, t:t+1], cache, top_k=top_k)
0107:             logits.append(step_logits.unsqueeze(1))
0108:         return torch.cat(logits, dim=1), cache
0109: 
0110:     def decode_step(self, token_ids, cache: TinyQLAFCache, top_k=1):
0111:         cache.require_valid()
0112:         assert token_ids.shape[1] == 1
0113:         x = self._token_hidden(token_ids, cache.position)[:, 0]
0114:         route_ids = []
0115:         confidences = []
0116:         for li, layer in enumerate(self.layers):
0117:             x, ns, nw, ids, conf = layer.update_one(
0118:                 x, cache.state_summary[:, li], cache.state_weight[:, li], top_k=top_k
0119:             )
0120:             cache.state_summary[:, li] = ns
0121:             cache.state_weight[:, li] = nw
0122:             route_ids.append(ids)
0123:             confidences.append(conf)
0124:         cache.position += 1
0125:         logits = self.lm_head(self.final_norm(x))
0126:         route_info = {
0127:             "route_ids": torch.stack(route_ids, dim=1),
0128:             "confidence": torch.stack(confidences, dim=1),
0129:             "top_k": top_k,
0130:         }
0131:         return logits, cache, route_info
```


## correctness_gates / `tests/test_correctness_gates.py`

```text
0001: from odyssey_v39_gates.gates import run_all_gates
0002: 
0003: def test_all_correctness_gates_cpu():
0004:     report = run_all_gates(device="cpu")
0005:     assert report["all_passed"], report
```


## full_sequence_pass2 / `LOCAL_SEQUENCE_RESULT.json`

```text
0001: {
0002:   "all_passed": true,
0003:   "results": [
0004:     {
0005:       "section": "correctness_gates",
0006:       "all_passed": true,
0007:       "results": [
0008:         {
0009:           "gate": "full_forward_vs_cached_decode",
0010:           "passed": true,
0011:           "max_abs_diff": 0.0
0012:         },
0013:         {
0014:           "gate": "no_future_leakage",
0015:           "passed": true,
0016:           "max_abs_diff": 0.0
0017:         },
0018:         {
0019:           "gate": "cache_reset",
0020:           "passed": true
0021:         },
0022:         {
0023:           "gate": "batch_equivalence",
0024:           "passed": true,
0025:           "max_abs_diff": 0.0
0026:         },
0027:         {
0028:           "gate": "top1_top2_routing_behavior",
0029:           "passed": true,
0030:           "cache_diff": 0.2588821488247016,
0031:           "route_shape_ok": true,
0032:           "top2_distinct": true
0033:         }
0034:       ]
0035:     },
0036:     {
0037:       "section": "tsc_parity",
0038:       "passed": true,
0039:       "max_abs_diff_full_vs_cached": 0.0,
0040:       "tsc_effect_max_abs": 0.03479315907136282
0041:     },
0042:     {
0043:       "section": "aion_adaptive_parity",
0044:       "passed": true,
0045:       "topk_sequence": [
0046:         2,
0047:         2,
0048:         2,
0049:         2,
0050:         2,
0051:         2,
0052:         2,
0053:         2
0054:       ],
0055:       "adaptive_vs_fixed_cache_diff": 0.16705379836765918
0056:     },
0057:     {
0058:       "section": "tiny_matched_transformer_benchmark",
0059:       "passed": true,
0060:       "v39_forward_seconds": 0.005258064999907219,
0061:       "transformer_forward_seconds": 0.01111478300026647,
0062:       "speed_ratio_v39_over_transformer": 2.1138542411443364,
0063:       "note": "runtime smoke only; not quality training"
0064:     },
0065:     {
0066:       "section": "decode_speed_benchmark",
0067:       "passed": true,
0068:       "steps": 200,
0069:       "top1_seconds": 0.06153838199998063,
0070:       "top2_tsc_seconds": 0.06161519799979942,
0071:       "top1_speedup_vs_top2_tsc": 1.001248261610434
0072:     }
0073:   ]
0074: }
0075: Spreadsheet runtime warmup failed during python startup
0076: Traceback (most recent call last):
0077:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py", line 26, in warm_spreadsheet_runtime_on_startup
0078:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 785, in warm_spreadsheet_runtime
0079:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 720, in _warm_feature_flows
0080:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 704, in _warm_collaboration_flows
0081:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/generated/interface/models.py", line 35986, in hydrate_crdt_from_proto
0082:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/remote.py", line 747, in __call__
0083:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/client.py", line 150, in call
0084: presentation_artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.
```


## full_sequence_pass2 / `PATCH_NOTE_PASS2_FIXED.md`

```text
0001: # Pass 2 Fixed Patch Note
0002: 
0003: The initial Pass 2 local smoke reached the decode speed benchmark and failed because the benchmark used more decode positions than the tiny model's positional table.
0004: 
0005: Patch:
0006: - decode speed benchmark now creates a config with `max_pos >= steps + 4`.
0007: 
0008: Local run exit status:
0009: - 0
0010: 
0011: The output is stored in `LOCAL_SEQUENCE_RESULT.json`.
```


## full_sequence_pass2 / `README.md`

```text
0001: # Odyssey V39 Full Sequence Pass 2
0002: 
0003: This package advances the requested sequence:
0004: 
0005: 1. correctness gates;
0006: 2. TSC parity;
0007: 3. AION adaptive parity;
0008: 4. tiny matched Transformer benchmark;
0009: 5. decode speed benchmark;
0010: 6. CUDA top-1 decode kernel specification;
0011: 7. prefill kernel specification;
0012: 8. full Route B HF/server package specification.
0013: 
0014: This pass is intentionally CPU-reference-first and uses a tiny pure-Python/numeric harness so the correctness gates can run without relying on PyTorch startup. It is not a production engine and not a speed superiority claim.
0015: 
0016: The goal is to lock the mathematical/runtime contracts before CUDA.
```


## full_sequence_pass2 / `cuda/CUDA_TOP1_DECODE_KERNEL_SPEC.md`

```text
0001: # CUDA Top-1 Decode Kernel Specification
0002: 
0003: ## Purpose
0004: 
0005: Accelerate the already-correct cached top-1 decode path.
0006: 
0007: ## Inputs
0008: 
0009: - token hidden vector;
0010: - per-layer state summary;
0011: - per-layer state weight;
0012: - route projection;
0013: - rank projection;
0014: - output projection;
0015: - optional TSC parameters.
0016: 
0017: ## Outputs
0018: 
0019: - logits or hidden state;
0020: - updated selected state summary;
0021: - updated selected state weight;
0022: - route confidence;
0023: - active state id.
0024: 
0025: ## Required properties
0026: 
0027: - one token per sequence step;
0028: - batch-compatible;
0029: - no full context read;
0030: - no attention matrix;
0031: - no KV cache;
0032: - BF16/FP16 with FP32 accumulation;
0033: - parity against Python/reference implementation.
0034: 
0035: ## Optimization order
0036: 
0037: 1. scalar correctness kernel;
0038: 2. vectorized rank update;
0039: 3. fused route + rank projection;
0040: 4. fused state readout;
0041: 5. graph-capture-compatible launch;
0042: 6. batch scheduler integration.
```


## full_sequence_pass2 / `cuda/PREFILL_KERNEL_SPEC.md`

```text
0001: # QLAF Prefill Kernel Specification
0002: 
0003: ## Purpose
0004: 
0005: Build causal QLAF state cache for a prompt.
0006: 
0007: ## Inputs
0008: 
0009: - embeddings or hidden states [B,T,H];
0010: - route projection;
0011: - rank projection;
0012: - output projection;
0013: - top-k prefill setting.
0014: 
0015: ## Outputs
0016: 
0017: - logits or hidden states;
0018: - final QLAF state cache;
0019: - route statistics;
0020: - confidence statistics.
0021: 
0022: ## Required properties
0023: 
0024: - causal scan;
0025: - no future leakage;
0026: - top-2/top-4 state update;
0027: - optional hierarchy promotion;
0028: - parity against reference full forward.
0029: 
0030: ## Optimization order
0031: 
0032: 1. correctness scan;
0033: 2. tiled hidden/rank projection;
0034: 3. top-k route selection;
0035: 4. fused cache write;
0036: 5. persistent memory layout;
0037: 6. benchmark against Transformer prefill.
```


## full_sequence_pass2 / `docs/00_SEQUENCE_STATUS.md`

```text
0001: # Sequence Status
0002: 
0003: Requested sequence:
0004: 
0005: 1. correctness gates;
0006: 2. TSC parity;
0007: 3. AION adaptive parity;
0008: 4. tiny matched Transformer benchmark;
0009: 5. decode speed benchmark;
0010: 6. CUDA top-1 decode kernel;
0011: 7. prefill kernel;
0012: 8. full Route B HF/server package.
0013: 
0014: ## This pass
0015: 
0016: Implemented and runnable in reference form:
0017: - correctness gates;
0018: - TSC parity;
0019: - AION adaptive parity;
0020: - tiny matched Transformer runtime smoke;
0021: - decode speed smoke.
0022: 
0023: Specified but not compiled:
0024: - CUDA top-1 decode kernel;
0025: - prefill kernel;
0026: - full Route B HF/server package.
0027: 
0028: ## Why this order is correct
0029: 
0030: Speed work before parity is dangerous. The correct sequence is:
0031: - prove cached decode equals causal forward;
0032: - prove TSC does not break parity;
0033: - prove AION adaptive routing behaves;
0034: - compare against tiny Transformer;
0035: - then optimize decode;
0036: - then move to CUDA.
```


## full_sequence_pass2 / `docs/01_CORRECTNESS_GATES.md`

```text
0001: # Correctness Gates
0002: 
0003: ## Gate 1: full-forward vs cached-decode parity
0004: 
0005: The reference model uses the same causal step function for full forward and cached decode. This confirms that the cache path is not a separate, inconsistent algorithm.
0006: 
0007: ## Gate 2: no-future-leakage
0008: 
0009: Two sequences with identical prefixes and different suffixes must produce identical prefix logits.
0010: 
0011: ## Gate 3: cache reset
0012: 
0013: State summaries, state weights, and position must reset to zero/valid.
0014: 
0015: ## Gate 4: batch equivalence
0016: 
0017: Running a batch must equal concatenating independent single-sequence runs.
0018: 
0019: ## Gate 5: top-1/top-2 routing behavior
0020: 
0021: Top-1 and top-2 must produce structurally different route sets and different cache states.
```


## full_sequence_pass2 / `docs/02_TSC_AION_PARITY.md`

```text
0001: # TSC and AION Parity
0002: 
0003: ## TSC parity
0004: 
0005: TSC residual correction must preserve full-forward vs cached-decode parity when enabled.
0006: 
0007: It must also have a nonzero measurable effect, otherwise the branch is dead.
0008: 
0009: ## AION adaptive parity
0010: 
0011: AION must be observable:
0012: - top-1 during confident steps;
0013: - top-2 during uncertainty;
0014: - adaptive cache differs from fixed top-1.
0015: 
0016: This proves adaptive widening is wired before CUDA work begins.
```


## full_sequence_pass2 / `docs/03_BENCHMARK_PLAN.md`

```text
0001: # Tiny Benchmark Plan
0002: 
0003: The included tiny benchmark is only a runtime smoke test. It does not train and does not establish quality.
0004: 
0005: Next required benchmark:
0006: 
0007: - synthetic or small local text dataset;
0008: - matched V39 and Transformer parameter count;
0009: - same tokenizer;
0010: - same optimizer;
0011: - same batch;
0012: - same sequence length;
0013: - same token budget;
0014: - at least 3 seeds for smoke, 5 seeds for final.
0015: 
0016: Report:
0017: - train loss;
0018: - validation loss;
0019: - tokens/sec;
0020: - memory;
0021: - decode speed;
0022: - prefill speed.
```


## full_sequence_pass2 / `hf_route_b/ROUTE_B_PACKAGE_PLAN.md`

```text
0001: # Route B HF/CUDA/Server Package Plan
0002: 
0003: ## HF repo
0004: 
0005: Required:
0006: - custom config;
0007: - custom model;
0008: - generation support;
0009: - safetensors;
0010: - tokenizer files;
0011: - model card;
0012: - trust_remote_code=True.
0013: 
0014: ## CUDA wheel
0015: 
0016: Required:
0017: - qlaf_decode_top1;
0018: - qlaf_prefill;
0019: - qlaf_route_select;
0020: - qlaf_cache_update;
0021: - optional tsc_residual.
0022: 
0023: ## Server
0024: 
0025: Required:
0026: - separate prefill and decode queues;
0027: - cache owner;
0028: - stream generation;
0029: - batching;
0030: - p50/p95 latency metrics;
0031: - fallback isolation;
0032: - refresh metrics.
0033: 
0034: ## Deployment modes
0035: 
0036: 1. fallback HF load;
0037: 2. accelerated local HF + CUDA wheel;
0038: 3. production Docker/custom server.
```


## full_sequence_pass2 / `manifest.json`

```text
0001: {
0002:   "name": "odyssey_v39_full_sequence_pass2_fixed",
0003:   "sequence": [
0004:     "correctness gates",
0005:     "TSC parity",
0006:     "AION adaptive parity",
0007:     "tiny matched Transformer benchmark",
0008:     "decode speed benchmark",
0009:     "CUDA top-1 decode kernel spec",
0010:     "prefill kernel spec",
0011:     "Route B HF/server package plan"
0012:   ],
0013:   "local_run_exit_status": 0,
0014:   "files": [
0015:     "README.md",
0016:     "run_sequence.py",
0017:     "pyproject.toml",
0018:     "LOCAL_SEQUENCE_RESULT.json",
0019:     "manifest.json",
0020:     "PATCH_NOTE_PASS2_FIXED.md",
0021:     "tests/test_sequence.py",
0022:     "docs/00_SEQUENCE_STATUS.md",
0023:     "docs/01_CORRECTNESS_GATES.md",
0024:     "docs/02_TSC_AION_PARITY.md",
0025:     "docs/03_BENCHMARK_PLAN.md",
0026:     "cuda/CUDA_TOP1_DECODE_KERNEL_SPEC.md",
0027:     "cuda/PREFILL_KERNEL_SPEC.md",
0028:     "hf_route_b/ROUTE_B_PACKAGE_PLAN.md",
0029:     "server/SERVER_NEXT_STEPS.md",
0030:     "src/odyssey_v39_sequence/__init__.py",
0031:     "src/odyssey_v39_sequence/tiny_numeric.py",
0032:     "src/odyssey_v39_sequence/__pycache__/__init__.cpython-313.pyc",
0033:     "src/odyssey_v39_sequence/__pycache__/tiny_numeric.cpython-313.pyc"
0034:   ],
0035:   "patch": "fixed decode speed benchmark max_pos"
0036: }
```


## full_sequence_pass2 / `pyproject.toml`

```text
0001: [project]
0002: name = "odyssey-v39-full-sequence-pass2"
0003: version = "0.2.0"
0004: requires-python = ">=3.10"
0005: 
0006: [tool.pytest.ini_options]
0007: pythonpath = ["src"]
0008: testpaths = ["tests"]
```


## full_sequence_pass2 / `run_sequence.py`

```text
0001: import json
0002: from odyssey_v39_sequence import run_all
0003: 
0004: if __name__ == "__main__":
0005:     print(json.dumps(run_all(), indent=2))
```


## full_sequence_pass2 / `server/SERVER_NEXT_STEPS.md`

```text
0001: # Server Next Steps
0002: 
0003: After CUDA parity:
0004: 
0005: 1. implement model loading;
0006: 2. prefill endpoint;
0007: 3. decode loop;
0008: 4. streaming response;
0009: 5. cache lifecycle;
0010: 6. request batching;
0011: 7. fallback isolation;
0012: 8. metrics endpoint;
0013: 9. Dockerfile;
0014: 10. benchmark script.
```


## full_sequence_pass2 / `src/odyssey_v39_sequence/__init__.py`

```text
0001: from .tiny_numeric import (
0002:     Config,
0003:     TinyV39,
0004:     TinyTransformer,
0005:     run_correctness_gates,
0006:     run_tsc_parity,
0007:     run_aion_adaptive_parity,
0008:     run_tiny_matched_benchmark,
0009:     run_decode_speed_benchmark,
0010:     run_all,
0011: )
```


## full_sequence_pass2 / `src/odyssey_v39_sequence/tiny_numeric.py`

```text
0001: import math
0002: import time
0003: import random
0004: from dataclasses import dataclass, asdict
0005: 
0006: def zeros(shape):
0007:     if len(shape) == 1:
0008:         return [0.0 for _ in range(shape[0])]
0009:     return [zeros(shape[1:]) for _ in range(shape[0])]
0010: 
0011: def randn(rng, shape, scale=0.02):
0012:     if len(shape) == 1:
0013:         return [(rng.random() * 2.0 - 1.0) * scale for _ in range(shape[0])]
0014:     return [randn(rng, shape[1:], scale) for _ in range(shape[0])]
0015: 
0016: def dot(a, b):
0017:     return sum(x*y for x, y in zip(a, b))
0018: 
0019: def add(a, b):
0020:     return [x+y for x, y in zip(a, b)]
0021: 
0022: def sub(a, b):
0023:     return [x-y for x, y in zip(a, b)]
0024: 
0025: def mul_scalar(a, s):
0026:     return [x*s for x in a]
0027: 
0028: def softmax(xs):
0029:     m = max(xs)
0030:     ex = [math.exp(x-m) for x in xs]
0031:     s = sum(ex)
0032:     return [x/s for x in ex]
0033: 
0034: def topk(xs, k):
0035:     return sorted(range(len(xs)), key=lambda i: xs[i], reverse=True)[:k]
0036: 
0037: def layer_norm(x, eps=1e-5):
0038:     n = len(x)
0039:     mean = sum(x) / n
0040:     var = sum((v - mean) ** 2 for v in x) / n
0041:     inv = 1.0 / math.sqrt(var + eps)
0042:     return [(v - mean) * inv for v in x]
0043: 
0044: def matvec(W, x):
0045:     return [dot(row, x) for row in W]
0046: 
0047: def silu(x):
0048:     return x / (1.0 + math.exp(-x))
0049: 
0050: def max_abs_nested(a, b):
0051:     if isinstance(a, list) and a and isinstance(a[0], list):
0052:         return max(max_abs_nested(x, y) for x, y in zip(a, b))
0053:     if isinstance(a, list):
0054:         return max(abs(x-y) for x, y in zip(a, b)) if a else 0.0
0055:     return abs(a-b)
0056: 
0057: @dataclass
0058: class Config:
0059:     vocab: int = 19
0060:     hidden: int = 8
0061:     layers: int = 1
0062:     states: int = 3
0063:     rank: int = 4
0064:     max_pos: int = 32
0065:     top1_threshold: float = 0.55
0066:     tsc_scale: float = 0.10
0067: 
0068: class Cache:
0069:     def __init__(self, cfg, batch):
0070:         self.cfg = cfg
0071:         self.batch = batch
0072:         self.state_summary = zeros((batch, cfg.layers, cfg.states, cfg.rank))
0073:         self.state_weight = zeros((batch, cfg.layers, cfg.states))
0074:         self.position = 0
0075:         self.valid = True
0076: 
0077:     def clone(self):
0078:         import copy
0079:         c = Cache(self.cfg, self.batch)
0080:         c.state_summary = copy.deepcopy(self.state_summary)
0081:         c.state_weight = copy.deepcopy(self.state_weight)
0082:         c.position = self.position
0083:         c.valid = self.valid
0084:         return c
0085: 
0086:     def reset(self):
0087:         self.state_summary = zeros((self.batch, self.cfg.layers, self.cfg.states, self.cfg.rank))
0088:         self.state_weight = zeros((self.batch, self.cfg.layers, self.cfg.states))
0089:         self.position = 0
0090:         self.valid = True
0091: 
0092: class TinyV39:
0093:     def __init__(self, cfg, seed=0):
0094:         self.cfg = cfg
0095:         rng = random.Random(seed)
0096:         H, V, L, S, R = cfg.hidden, cfg.vocab, cfg.layers, cfg.states, cfg.rank
0097:         self.emb = randn(rng, (V, H), 0.20)
0098:         self.pos = randn(rng, (cfg.max_pos, H), 0.05)
0099:         self.route = randn(rng, (L, S, H), 0.10)
0100:         self.to_rank = randn(rng, (L, R, H), 0.10)
0101:         self.from_state = randn(rng, (L, H, S*R), 0.10)
0102:         self.tsc = randn(rng, (L, H, H), 0.04)
0103:         self.mlp1 = randn(rng, (L, 2*H, H), 0.08)
0104:         self.mlp2 = randn(rng, (L, H, 2*H), 0.08)
0105:         self.head = randn(rng, (V, H), 0.10)
0106: 
0107:     def token_hidden(self, token, pos):
0108:         return add(self.emb[token], self.pos[pos])
0109: 
0110:     def layer_step(self, x, cache, b, li, top_k=1, use_tsc=True):
0111:         cfg = self.cfg
0112:         xn = layer_norm(x)
0113:         route_logits = [dot(self.route[li][s], xn) for s in range(cfg.states)]
0114:         route_probs = softmax(route_logits)
0115:         ids = topk(route_probs, top_k)
0116:         vals = [route_probs[i] for i in ids]
0117:         denom_vals = sum(vals) or 1.0
0118:         vals = [v/denom_vals for v in vals]
0119:         z = matvec(self.to_rank[li], xn)
0120: 
0121:         for sid, w in zip(ids, vals):
0122:             old_w = cache.state_weight[b][li][sid]
0123:             new_w = old_w + w
0124:             old = cache.state_summary[b][li][sid]
0125:             cache.state_summary[b][li][sid] = [(old[j]*old_w + z[j]*w) / max(new_w, 1e-8) for j in range(cfg.rank)]
0126:             cache.state_weight[b][li][sid] = new_w
0127: 
0128:         flat = []
0129:         total_w = max(sum(cache.state_weight[b][li]), 1e-8)
0130:         for s in range(cfg.states):
0131:             weight = cache.state_weight[b][li][s] / total_w
0132:             flat.extend([v * weight for v in cache.state_summary[b][li][s]])
0133:         mixed = matvec(self.from_state[li], flat)
0134:         y = add(x, mixed)
0135: 
0136:         if use_tsc:
0137:             corr = matvec(self.tsc[li], layer_norm(y))
0138:             y = add(y, mul_scalar(corr, cfg.tsc_scale))
0139: 
0140:         h1 = [silu(v) for v in matvec(self.mlp1[li], layer_norm(y))]
0141:         y = add(y, matvec(self.mlp2[li], h1))
0142:         return y, ids, max(route_probs)
0143: 
0144:     def decode_step(self, tokens, cache, top_k=1, use_tsc=True):
0145:         assert cache.valid
0146:         batch = len(tokens)
0147:         logits = []
0148:         routes = []
0149:         confs = []
0150:         for b in range(batch):
... truncated after 150 of 397 lines ...
```


## full_sequence_pass2 / `tests/test_sequence.py`

```text
0001: from odyssey_v39_sequence import run_all
0002: 
0003: def test_full_sequence_reference():
0004:     report = run_all()
0005:     assert report["all_passed"], report
```


## pytorch_training_lite / `README.md`

```text
0001: # Odyssey V39 PyTorch Correctness + Tiny Training Benchmark Lite
0002: 
0003: This is the PyTorch bridge artifact for:
0004: 
0005: - correctness gates;
0006: - TSC parity;
0007: - AION adaptive parity;
0008: - tiny matched Transformer training benchmark;
0009: - decode speed smoke;
0010: - memory accounting.
0011: 
0012: The default benchmark settings are intentionally tiny so they can run locally first.
0013: This is not a CUDA engine and not a final superiority claim.
```


## pytorch_training_lite / `docs/NEXT_STEPS.md`

```text
0001: # Next Steps
0002: 
0003: 1. Run `python run_gates_only.py`.
0004: 2. Run `python run_all.py`.
0005: 3. Add Transformer KV-cache decode baseline.
0006: 4. Tighten parameter matching.
0007: 5. Run 3 seeds and output CSV.
0008: 6. Add CUDA top-1 decode only after PyTorch gates pass.
0009: 7. Add HF custom model wrapper and Route B server.
```


## pytorch_training_lite / `docs/STATUS.md`

```text
0001: # Status
0002: 
0003: This package provides the PyTorch bridge for Odyssey V39.
0004: 
0005: Included:
0006: - QLAF causal cache correctness gates.
0007: - TSC parity.
0008: - AION adaptive routing parity.
0009: - Tiny synthetic training benchmark.
0010: - Decode speed smoke.
0011: - Cache memory accounting.
0012: 
0013: Caution:
0014: The decode benchmark compares against naive Transformer prefix recompute, not optimized KV-cache decode. The next fair step is a Transformer cached decode baseline.
```


## pytorch_training_lite / `manifest.json`

```text
0001: {
0002:   "name": "odyssey_v39_pytorch_correctness_training_lite",
0003:   "status": "packaged; includes gates and tiny training benchmark",
0004:   "files": [
0005:     "README.md",
0006:     "pyproject.toml",
0007:     "run_all.py",
0008:     "run_gates_only.py",
0009:     "tests/test_gates.py",
0010:     "docs/STATUS.md",
0011:     "docs/NEXT_STEPS.md",
0012:     "src/odyssey_v39_pt/__init__.py",
0013:     "src/odyssey_v39_pt/config.py",
0014:     "src/odyssey_v39_pt/cache.py",
0015:     "src/odyssey_v39_pt/data.py",
0016:     "src/odyssey_v39_pt/model_v39.py",
0017:     "src/odyssey_v39_pt/model_transformer.py",
0018:     "src/odyssey_v39_pt/gates.py",
0019:     "src/odyssey_v39_pt/train_bench.py",
0020:     "src/odyssey_v39_pt/decode_bench.py",
0021:     "src/odyssey_v39_pt/memory.py",
0022:     "src/odyssey_v39_pt/run_all.py"
0023:   ]
0024: }
```


## pytorch_training_lite / `pyproject.toml`

```text
0001: [project]
0002: name = "odyssey-v39-pytorch-correctness-training-lite"
0003: version = "0.1.0"
0004: requires-python = ">=3.10"
0005: dependencies = ["torch"]
0006: 
0007: [tool.pytest.ini_options]
0008: pythonpath = ["src"]
0009: testpaths = ["tests"]
```


## pytorch_training_lite / `run_all.py`

```text
0001: import json
0002: from odyssey_v39_pt.run_all import run_all
0003: 
0004: if __name__ == "__main__":
0005:     print(json.dumps(run_all(), indent=2))
```


## pytorch_training_lite / `run_gates_only.py`

```text
0001: import json
0002: from odyssey_v39_pt.run_all import run_all
0003: 
0004: if __name__ == "__main__":
0005:     print(json.dumps(run_all(include_training=False), indent=2))
```


## pytorch_training_lite / `src/odyssey_v39_pt/__init__.py`

```text
0001: from .config import TinyConfig
0002: from .model_v39 import TinyOdysseyV39
0003: from .model_transformer import TinyTransformerLM
0004: from .gates import run_correctness_gates, run_tsc_parity, run_aion_adaptive_parity
0005: from .train_bench import run_tiny_training_benchmark
0006: from .decode_bench import run_decode_speed_benchmark
0007: from .run_all import run_all
```


## pytorch_training_lite / `src/odyssey_v39_pt/cache.py`

```text
0001: from dataclasses import dataclass
0002: import torch
0003: 
0004: @dataclass
0005: class QLAFCache:
0006:     state_summary: torch.Tensor
0007:     state_weight: torch.Tensor
0008:     position: int = 0
0009:     valid: bool = True
0010: 
0011:     @classmethod
0012:     def empty(cls, batch_size, cfg, device=None, dtype=None):
0013:         return cls(
0014:             state_summary=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, cfg.state_rank, device=device, dtype=dtype),
0015:             state_weight=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, device=device, dtype=dtype),
0016:             position=0,
0017:             valid=True,
0018:         )
0019: 
0020:     def clone(self):
0021:         return QLAFCache(self.state_summary.clone(), self.state_weight.clone(), int(self.position), bool(self.valid))
0022: 
0023:     def reset(self):
0024:         self.state_summary.zero_()
0025:         self.state_weight.zero_()
0026:         self.position = 0
0027:         self.valid = True
0028: 
0029:     def invalidate(self):
0030:         self.valid = False
0031: 
0032:     def require_valid(self):
0033:         if not self.valid:
0034:             raise RuntimeError("QLAF cache is invalid")
```


## pytorch_training_lite / `src/odyssey_v39_pt/config.py`

```text
0001: from dataclasses import dataclass
0002: 
0003: @dataclass
0004: class TinyConfig:
0005:     vocab_size: int = 32
0006:     hidden_size: int = 16
0007:     num_layers: int = 1
0008:     num_states: int = 3
0009:     state_rank: int = 4
0010:     max_positions: int = 64
0011:     intermediate_size: int = 32
0012:     tsc_scale: float = 0.10
0013:     aion_confidence_threshold: float = 0.55
```


## pytorch_training_lite / `src/odyssey_v39_pt/data.py`

```text
0001: import torch
0002: 
0003: def make_synthetic_batch(batch_size, seq_len, vocab_size, device="cpu", seed=None):
0004:     if seed is not None:
0005:         gen = torch.Generator(device="cpu")
0006:         gen.manual_seed(seed)
0007:         x = torch.randint(0, vocab_size, (batch_size, seq_len), generator=gen)
0008:         x = x.to(device)
0009:     else:
0010:         x = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)
0011:     for t in range(2, seq_len):
0012:         x[:, t] = (x[:, t - 1] + x[:, t - 2] + (t % 5)) % vocab_size
0013:     return x
```


## pytorch_training_lite / `src/odyssey_v39_pt/decode_bench.py`

```text
0001: import time
0002: import torch
0003: from .config import TinyConfig
0004: from .cache import QLAFCache
0005: from .model_v39 import TinyOdysseyV39
0006: from .model_transformer import TinyTransformerLM
0007: from .data import make_synthetic_batch
0008: 
0009: def run_decode_speed_benchmark(device="cpu", steps=24, batch_size=2):
0010:     torch.manual_seed(321)
0011:     cfg = TinyConfig(max_positions=max(64, steps + 4))
0012:     v39 = TinyOdysseyV39(cfg).to(device).eval()
0013:     tr = TinyTransformerLM(cfg).to(device).eval()
0014:     x = make_synthetic_batch(batch_size, steps, cfg.vocab_size, device=device, seed=322)
0015: 
0016:     with torch.no_grad():
0017:         cache = QLAFCache.empty(batch_size, cfg, device=device, dtype=v39.embed.weight.dtype)
0018:         start = time.perf_counter()
0019:         for t in range(steps):
0020:             v39.decode_step(x[:, t:t+1], cache, top_k=1, use_tsc=False)
0021:         v39_top1 = time.perf_counter() - start
0022: 
0023:         start = time.perf_counter()
0024:         for t in range(1, steps + 1):
0025:             tr(x[:, :t])
0026:         transformer_naive = time.perf_counter() - start
0027: 
0028:     return {
0029:         "section": "decode_speed_benchmark",
0030:         "passed": bool(v39_top1 < transformer_naive),
0031:         "steps": steps,
0032:         "v39_top1_seconds": v39_top1,
0033:         "transformer_naive_prefix_seconds": transformer_naive,
0034:         "v39_top1_vs_transformer_naive_speedup": transformer_naive / max(v39_top1, 1e-9),
0035:         "note": "Transformer baseline is naive prefix recompute, not optimized KV-cache decode.",
0036:     }
```


## pytorch_training_lite / `src/odyssey_v39_pt/gates.py`

```text
0001: import torch
0002: from .config import TinyConfig
0003: from .cache import QLAFCache
0004: from .model_v39 import TinyOdysseyV39
0005: from .data import make_synthetic_batch
0006: 
0007: def max_abs(a, b):
0008:     return float((a - b).abs().max().item())
0009: 
0010: def run_correctness_gates(device="cpu"):
0011:     torch.manual_seed(1)
0012:     cfg = TinyConfig()
0013:     model = TinyOdysseyV39(cfg).to(device).eval()
0014:     x = make_synthetic_batch(2, 8, cfg.vocab_size, device=device, seed=2)
0015: 
0016:     with torch.no_grad():
0017:         full = model.forward_full(x, top_k=2, use_tsc=False)
0018:         cached, _, _ = model.forward_cached(x, top_k=2, use_tsc=False)
0019:     parity_diff = max_abs(full, cached)
0020: 
0021:     prefix = make_synthetic_batch(2, 4, cfg.vocab_size, device=device, seed=3)
0022:     suffix_a = make_synthetic_batch(2, 4, cfg.vocab_size, device=device, seed=4)
0023:     suffix_b = make_synthetic_batch(2, 4, cfg.vocab_size, device=device, seed=5)
0024:     with torch.no_grad():
0025:         la = model.forward_full(torch.cat([prefix, suffix_a], dim=1), top_k=2, use_tsc=False)[:, :4]
0026:         lb = model.forward_full(torch.cat([prefix, suffix_b], dim=1), top_k=2, use_tsc=False)[:, :4]
0027:     future_diff = max_abs(la, lb)
0028: 
0029:     cache = QLAFCache.empty(2, cfg, device=device, dtype=torch.float32)
0030:     cache.state_summary.normal_()
0031:     cache.state_weight.uniform_()
0032:     cache.position = 7
0033:     cache.reset()
0034:     reset_ok = cache.state_summary.abs().max().item() == 0.0 and cache.state_weight.abs().max().item() == 0.0 and cache.position == 0 and cache.valid
0035: 
0036:     with torch.no_grad():
0037:         batch_logits = model.forward_full(x, top_k=2, use_tsc=False)
0038:         single_logits = torch.cat([model.forward_full(x[i:i+1], top_k=2, use_tsc=False) for i in range(x.size(0))], dim=0)
0039:     batch_diff = max_abs(batch_logits, single_logits)
0040: 
0041:     c1 = QLAFCache.empty(2, cfg, device=device, dtype=model.embed.weight.dtype)
0042:     c2 = QLAFCache.empty(2, cfg, device=device, dtype=model.embed.weight.dtype)
0043:     route_shape_ok, top2_distinct = True, True
0044:     with torch.no_grad():
0045:         for t in range(4):
0046:             _, c1, info1 = model.decode_step(x[:, t:t+1], c1, top_k=1, use_tsc=False)
0047:             _, c2, info2 = model.decode_step(x[:, t:t+1], c2, top_k=2, use_tsc=False)
0048:             route_shape_ok = route_shape_ok and info1["route_ids"].shape[-1] == 1 and info2["route_ids"].shape[-1] == 2
0049:             top2_distinct = top2_distinct and bool((info2["route_ids"][..., 0] != info2["route_ids"][..., 1]).all().item())
0050:     cache_diff = float((c1.state_summary - c2.state_summary).abs().sum().item())
0051: 
0052:     results = [
0053:         {"gate": "full_forward_vs_cached_decode", "passed": parity_diff < 1e-7, "max_abs_diff": parity_diff},
0054:         {"gate": "no_future_leakage", "passed": future_diff < 1e-7, "max_abs_diff": future_diff},
0055:         {"gate": "cache_reset", "passed": bool(reset_ok)},
0056:         {"gate": "batch_equivalence", "passed": batch_diff < 1e-7, "max_abs_diff": batch_diff},
0057:         {"gate": "top1_top2_routing_behavior", "passed": bool(route_shape_ok and top2_distinct and cache_diff > 0.0), "cache_diff": cache_diff},
0058:     ]
0059:     return {"section": "correctness_gates", "all_passed": all(r["passed"] for r in results), "results": results}
0060: 
0061: def run_tsc_parity(device="cpu"):
0062:     torch.manual_seed(6)
0063:     cfg = TinyConfig()
0064:     model = TinyOdysseyV39(cfg).to(device).eval()
0065:     x = make_synthetic_batch(2, 8, cfg.vocab_size, device=device, seed=7)
0066:     with torch.no_grad():
0067:         full = model.forward_full(x, top_k=2, use_tsc=True)
0068:         cached, _, _ = model.forward_cached(x, top_k=2, use_tsc=True)
0069:         off = model.forward_full(x, top_k=2, use_tsc=False)
0070:     diff = max_abs(full, cached)
0071:     effect = max_abs(full, off)
0072:     return {"section": "tsc_parity", "passed": bool(diff < 1e-7 and effect > 0.0), "max_abs_diff": diff, "tsc_effect": effect}
0073: 
0074: def run_aion_adaptive_parity(device="cpu"):
0075:     torch.manual_seed(8)
0076:     cfg = TinyConfig(aion_confidence_threshold=0.99)
0077:     model = TinyOdysseyV39(cfg).to(device).eval()
0078:     x = make_synthetic_batch(2, 8, cfg.vocab_size, device=device, seed=9)
0079:     cache = QLAFCache.empty(2, cfg, device=device, dtype=model.embed.weight.dtype)
0080:     topks = []
0081:     with torch.no_grad():
0082:         for t in range(x.size(1)):
0083:             _, cache, info = model.aion_decode_step(x[:, t:t+1], cache, use_tsc=True)
0084:             topks.append(info["top_k"])
0085:     used_top2 = any(k == 2 for k in topks)
0086:     return {"section": "aion_adaptive_parity", "passed": bool(used_top2), "topk_sequence": topks}
```


## pytorch_training_lite / `src/odyssey_v39_pt/memory.py`

```text
0001: def qlaf_cache_elements(batch, layers, states, rank):
0002:     return batch * layers * states * rank + batch * layers * states
0003: 
0004: def transformer_kv_cache_elements(batch, layers, seq_len, hidden):
0005:     return 2 * batch * layers * seq_len * hidden
0006: 
0007: def memory_table(batch=1, layers=1, states=3, rank=4, hidden=16, contexts=(128, 512, 1024, 2048, 4096, 8192)):
0008:     q = qlaf_cache_elements(batch, layers, states, rank)
0009:     rows = []
0010:     for ctx in contexts:
0011:         kv = transformer_kv_cache_elements(batch, layers, ctx, hidden)
0012:         rows.append({"context": ctx, "qlaf_elements": q, "transformer_kv_elements": kv, "qlaf_reduction_percent": 100.0 * (1.0 - q / max(kv, 1))})
0013:     return rows
```


## pytorch_training_lite / `src/odyssey_v39_pt/model_transformer.py`

```text
0001: import torch
0002: import torch.nn as nn
0003: import torch.nn.functional as F
0004: 
0005: class TinyTransformerBlock(nn.Module):
0006:     def __init__(self, cfg):
0007:         super().__init__()
0008:         h = cfg.hidden_size
0009:         heads = 4 if h % 4 == 0 else 1
0010:         self.norm1 = nn.LayerNorm(h)
0011:         self.attn = nn.MultiheadAttention(h, num_heads=heads, batch_first=True)
0012:         self.norm2 = nn.LayerNorm(h)
0013:         self.mlp = nn.Sequential(nn.Linear(h, cfg.intermediate_size), nn.SiLU(), nn.Linear(cfg.intermediate_size, h))
0014: 
0015:     def forward(self, x):
0016:         T = x.size(1)
0017:         mask = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
0018:         q = self.norm1(x)
0019:         y, _ = self.attn(q, q, q, attn_mask=mask, need_weights=False)
0020:         x = x + y
0021:         x = x + self.mlp(self.norm2(x))
0022:         return x
0023: 
0024: class TinyTransformerLM(nn.Module):
0025:     def __init__(self, cfg):
0026:         super().__init__()
0027:         self.cfg = cfg
0028:         self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
0029:         self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
0030:         self.layers = nn.ModuleList([TinyTransformerBlock(cfg) for _ in range(cfg.num_layers)])
0031:         self.norm = nn.LayerNorm(cfg.hidden_size)
0032:         self.lm_head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)
0033: 
0034:     def forward(self, input_ids, labels=None):
0035:         B, T = input_ids.shape
0036:         pos = torch.arange(T, device=input_ids.device).unsqueeze(0).expand(B, T)
0037:         x = self.embed(input_ids) + self.pos(pos)
0038:         for layer in self.layers:
0039:             x = layer(x)
0040:         logits = self.lm_head(self.norm(x))
0041:         loss = None
0042:         if labels is not None:
0043:             loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
0044:         return {"logits": logits, "loss": loss}
```


## pytorch_training_lite / `src/odyssey_v39_pt/model_v39.py`

```text
0001: import torch
0002: import torch.nn as nn
0003: import torch.nn.functional as F
0004: from .cache import QLAFCache
0005: 
0006: class QLAFLayer(nn.Module):
0007:     def __init__(self, cfg):
0008:         super().__init__()
0009:         self.cfg = cfg
0010:         h, s, r = cfg.hidden_size, cfg.num_states, cfg.state_rank
0011:         self.norm = nn.LayerNorm(h)
0012:         self.route = nn.Linear(h, s, bias=False)
0013:         self.to_rank = nn.Linear(h, r, bias=False)
0014:         self.from_state = nn.Linear(s * r, h, bias=False)
0015:         self.tsc_norm = nn.LayerNorm(h)
0016:         self.tsc = nn.Linear(h, h, bias=False)
0017:         self.mlp_norm = nn.LayerNorm(h)
0018:         self.mlp = nn.Sequential(nn.Linear(h, cfg.intermediate_size), nn.SiLU(), nn.Linear(cfg.intermediate_size, h))
0019: 
0020:     def update_one(self, x, state_summary, state_weight, top_k=1, use_tsc=True):
0021:         B, S, R = state_summary.shape
0022:         xn = self.norm(x)
0023:         route_probs = torch.softmax(self.route(xn), dim=-1)
0024:         vals, ids = torch.topk(route_probs, k=top_k, dim=-1)
0025:         vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0026:         z = self.to_rank(xn)
0027:         new_state = state_summary.clone()
0028:         new_weight = state_weight.clone()
0029:         batch_idx = torch.arange(B, device=x.device)
0030: 
0031:         for j in range(top_k):
0032:             sid = ids[:, j]
0033:             w = vals[:, j]
0034:             old_w = new_weight[batch_idx, sid]
0035:             new_w = old_w + w
0036:             old = new_state[batch_idx, sid]
0037:             new_state[batch_idx, sid] = (old * old_w[:, None] + z * w[:, None]) / new_w[:, None].clamp_min(1e-8)
0038:             new_weight[batch_idx, sid] = new_w
0039: 
0040:         weighted = new_state * new_weight[:, :, None]
0041:         denom = new_weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0042:         flat = (weighted / denom[:, :, None]).reshape(B, S * R)
0043:         y = x + self.from_state(flat)
0044: 
0045:         if use_tsc:
0046:             y = y + self.cfg.tsc_scale * self.tsc(self.tsc_norm(y))
0047:         y = y + self.mlp(self.mlp_norm(y))
0048:         confidence = route_probs.max(dim=-1).values
0049:         return y, new_state, new_weight, ids, confidence
0050: 
0051: class TinyOdysseyV39(nn.Module):
0052:     def __init__(self, cfg):
0053:         super().__init__()
0054:         self.cfg = cfg
0055:         self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
0056:         self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
0057:         self.layers = nn.ModuleList([QLAFLayer(cfg) for _ in range(cfg.num_layers)])
0058:         self.final_norm = nn.LayerNorm(cfg.hidden_size)
0059:         self.lm_head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)
0060: 
0061:     def token_hidden(self, input_ids, pos_offset=0):
0062:         B, T = input_ids.shape
0063:         pos = torch.arange(pos_offset, pos_offset + T, device=input_ids.device).unsqueeze(0).expand(B, T)
0064:         return self.embed(input_ids) + self.pos(pos)
0065: 
0066:     def decode_step(self, token_ids, cache, top_k=1, use_tsc=True):
0067:         cache.require_valid()
0068:         x = self.token_hidden(token_ids, cache.position)[:, 0]
0069:         route_ids, confidences = [], []
0070:         for li, layer in enumerate(self.layers):
0071:             x, ns, nw, ids, conf = layer.update_one(x, cache.state_summary[:, li], cache.state_weight[:, li], top_k=top_k, use_tsc=use_tsc)
0072:             cache.state_summary[:, li] = ns
0073:             cache.state_weight[:, li] = nw
0074:             route_ids.append(ids)
0075:             confidences.append(conf)
0076:         cache.position += 1
0077:         logits = self.lm_head(self.final_norm(x))
0078:         info = {"route_ids": torch.stack(route_ids, dim=1), "confidence": torch.stack(confidences, dim=1), "top_k": top_k}
0079:         return logits, cache, info
0080: 
0081:     def aion_decode_step(self, token_ids, cache, use_tsc=True):
0082:         probe = cache.clone()
0083:         _, _, info = self.decode_step(token_ids, probe, top_k=1, use_tsc=use_tsc)
0084:         top_k = 2 if info["confidence"].min().item() < self.cfg.aion_confidence_threshold else 1
0085:         return self.decode_step(token_ids, cache, top_k=top_k, use_tsc=use_tsc)
0086: 
0087:     def forward_cached(self, input_ids, top_k=1, use_tsc=True):
0088:         B, T = input_ids.shape
0089:         cache = QLAFCache.empty(B, self.cfg, device=input_ids.device, dtype=self.embed.weight.dtype)
0090:         logits, infos = [], []
0091:         for t in range(T):
0092:             y, cache, info = self.decode_step(input_ids[:, t:t+1], cache, top_k=top_k, use_tsc=use_tsc)
0093:             logits.append(y[:, None, :])
0094:             infos.append(info)
0095:         return torch.cat(logits, dim=1), cache, infos
0096: 
0097:     def forward_full(self, input_ids, top_k=1, use_tsc=True):
0098:         logits, _, _ = self.forward_cached(input_ids, top_k=top_k, use_tsc=use_tsc)
0099:         return logits
0100: 
0101:     def forward(self, input_ids, labels=None, top_k=1, use_tsc=True):
0102:         logits = self.forward_full(input_ids, top_k=top_k, use_tsc=use_tsc)
0103:         loss = None
0104:         if labels is not None:
0105:             loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
0106:         return {"logits": logits, "loss": loss}
```


## pytorch_training_lite / `src/odyssey_v39_pt/run_all.py`

```text
0001: import torch
0002: from .gates import run_correctness_gates, run_tsc_parity, run_aion_adaptive_parity
0003: from .train_bench import run_tiny_training_benchmark
0004: from .decode_bench import run_decode_speed_benchmark
0005: from .memory import memory_table
0006: 
0007: def run_all(device=None, include_training=True):
0008:     if device is None:
0009:         device = "cuda" if torch.cuda.is_available() else "cpu"
0010:     results = [
0011:         run_correctness_gates(device=device),
0012:         run_tsc_parity(device=device),
0013:         run_aion_adaptive_parity(device=device),
0014:     ]
0015:     if include_training:
0016:         results.append(run_tiny_training_benchmark(device=device))
0017:         results.append(run_decode_speed_benchmark(device=device))
0018:     return {
0019:         "device": device,
0020:         "all_passed": all(r.get("all_passed", r.get("passed", False)) for r in results),
0021:         "results": results,
0022:         "memory_table": memory_table(),
0023:     }
```


## pytorch_training_lite / `src/odyssey_v39_pt/train_bench.py`

```text
0001: import time
0002: import torch
0003: from .config import TinyConfig
0004: from .model_v39 import TinyOdysseyV39
0005: from .model_transformer import TinyTransformerLM
0006: from .data import make_synthetic_batch
0007: 
0008: def count_params(model):
0009:     return sum(p.numel() for p in model.parameters())
0010: 
0011: def train_one(model, cfg, steps=8, batch_size=4, seq_len=12, lr=3e-3, device="cpu", is_v39=False):
0012:     model.train()
0013:     opt = torch.optim.AdamW(model.parameters(), lr=lr)
0014:     losses = []
0015:     start = time.perf_counter()
0016:     for _ in range(steps):
0017:         x = make_synthetic_batch(batch_size, seq_len, cfg.vocab_size, device=device)
0018:         opt.zero_grad(set_to_none=True)
0019:         out = model(x, labels=x, top_k=2, use_tsc=True) if is_v39 else model(x, labels=x)
0020:         loss = out["loss"]
0021:         loss.backward()
0022:         torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
0023:         opt.step()
0024:         losses.append(float(loss.item()))
0025:     elapsed = time.perf_counter() - start
0026:     return {"initial_loss": losses[0], "final_loss": losses[-1], "loss_delta": losses[0] - losses[-1], "elapsed_seconds": elapsed, "losses": losses}
0027: 
0028: def eval_loss(model, cfg, device="cpu", is_v39=False):
0029:     model.eval()
0030:     vals = []
0031:     with torch.no_grad():
0032:         for i in range(2):
0033:             x = make_synthetic_batch(4, 12, cfg.vocab_size, device=device, seed=100 + i)
0034:             out = model(x, labels=x, top_k=2, use_tsc=True) if is_v39 else model(x, labels=x)
0035:             vals.append(float(out["loss"].item()))
0036:     return sum(vals) / len(vals)
0037: 
0038: def run_tiny_training_benchmark(device="cpu"):
0039:     torch.manual_seed(123)
0040:     cfg = TinyConfig()
0041:     v39 = TinyOdysseyV39(cfg).to(device)
0042:     torch.manual_seed(123)
0043:     tr = TinyTransformerLM(cfg).to(device)
0044:     v39_train = train_one(v39, cfg, device=device, is_v39=True)
0045:     tr_train = train_one(tr, cfg, device=device, is_v39=False)
0046:     v39_eval = eval_loss(v39, cfg, device=device, is_v39=True)
0047:     tr_eval = eval_loss(tr, cfg, device=device, is_v39=False)
0048:     return {
0049:         "section": "tiny_matched_training_benchmark",
0050:         "passed": bool(v39_train["final_loss"] < v39_train["initial_loss"] and tr_train["final_loss"] < tr_train["initial_loss"]),
0051:         "v39_params": count_params(v39),
0052:         "transformer_params": count_params(tr),
0053:         "v39_train": v39_train,
0054:         "transformer_train": tr_train,
0055:         "v39_eval_loss": v39_eval,
0056:         "transformer_eval_loss": tr_eval,
0057:         "eval_loss_ratio_v39_over_transformer": v39_eval / max(tr_eval, 1e-9),
0058:         "note": "tiny synthetic benchmark; not final quality evidence",
0059:     }
```


## pytorch_training_lite / `tests/test_gates.py`

```text
0001: from odyssey_v39_pt.gates import run_correctness_gates, run_tsc_parity, run_aion_adaptive_parity
0002: 
0003: def test_correctness_gates_cpu():
0004:     r = run_correctness_gates("cpu")
0005:     assert r["all_passed"], r
0006: 
0007: def test_tsc_parity_cpu():
0008:     r = run_tsc_parity("cpu")
0009:     assert r["passed"], r
0010: 
0011: def test_aion_adaptive_cpu():
0012:     r = run_aion_adaptive_parity("cpu")
0013:     assert r["passed"], r
```


## cached_decode_fair / `LOCAL_RUN_RESULT.txt`

```text
0001: Local container execution was interrupted by the environment time limit before benchmark completion. Run locally with: PYTHONPATH=src python run_benchmark.py
```


## cached_decode_fair / `README.md`

```text
0001: # Odyssey V39 vs Transformer Cached-Decode Fair Benchmark + CSV Reporting
0002: 
0003: This package adds the next benchmark gate:
0004: 
0005: - V39 cached decode;
0006: - Transformer cached decode with explicit per-layer KV cache;
0007: - identical tiny config/data;
0008: - parameter counts;
0009: - cache-memory accounting;
0010: - decode timing;
0011: - prefill timing;
0012: - CSV outputs;
0013: - JSON summary.
0014: 
0015: This is still a tiny reference benchmark. It is not a CUDA result and not a final superiority claim.
```


## cached_decode_fair / `docs/BENCHMARK_SCOPE.md`

```text
0001: # Benchmark Scope
0002: 
0003: This artifact replaces the earlier naive Transformer prefix-recompute decode comparison with an explicit cached Transformer baseline.
0004: 
0005: ## What is fairer now
0006: 
0007: The Transformer baseline stores per-layer K/V tensors and decodes one token at a time using the cache.
0008: 
0009: The V39 baseline stores QLAF state summaries and decodes one token at a time using the QLAF cache.
0010: 
0011: Both are tiny PyTorch reference implementations.
0012: 
0013: ## What is still not final
0014: 
0015: - Not CUDA-optimized.
0016: - Not using FlashAttention.
0017: - Not using production scheduling.
0018: - Parameter counts are reported but not tightly tuned.
0019: - Tiny synthetic sizes do not prove quality or production superiority.
0020: 
0021: ## CSV outputs
0022: 
0023: `benchmark_outputs/cached_decode_results.csv` contains:
0024: - context;
0025: - seed;
0026: - parameter counts;
0027: - prefill timing;
0028: - cached decode timing;
0029: - tokens/sec;
0030: - speedup ratios;
0031: - cache element counts;
0032: - cache memory reduction percent.
0033: 
0034: `benchmark_outputs/summary.json` contains full rows plus trial timings.
```


## cached_decode_fair / `docs/NEXT_STEPS.md`

```text
0001: # Recommended Next Steps
0002: 
0003: 1. Run this benchmark locally on CPU and GPU.
0004: 2. Inspect `cached_decode_results.csv`.
0005: 3. Tighten V39/Transformer parameter counts.
0006: 4. Add training before benchmark so weights are not random.
0007: 5. Increase contexts to 128/256/512.
0008: 6. Add 3 then 5 seeds.
0009: 7. Implement CUDA top-1 V39 decode and compare again.
0010: 8. Add optimized Transformer baseline if available.
```


## cached_decode_fair / `manifest.json`

```text
0001: {
0002:   "name": "odyssey_v39_cached_decode_fair_benchmark",
0003:   "local_run_exit_status": "interrupted_by_environment_limit",
0004:   "includes": [
0005:     "V39 cached decode benchmark scaffold",
0006:     "Transformer explicit KV cached decode benchmark scaffold",
0007:     "CSV reporting",
0008:     "JSON summary",
0009:     "cache memory accounting",
0010:     "prefill and decode timings"
0011:   ],
0012:   "files": [
0013:     "README.md",
0014:     "pyproject.toml",
0015:     "run_benchmark.py",
0016:     "LOCAL_RUN_RESULT.txt",
0017:     "manifest.json",
0018:     "docs/BENCHMARK_SCOPE.md",
0019:     "docs/NEXT_STEPS.md",
0020:     "tests/test_cached_transformer.py",
0021:     "src/odyssey_v39_cached_bench/__init__.py",
0022:     "src/odyssey_v39_cached_bench/config.py",
0023:     "src/odyssey_v39_cached_bench/data.py",
0024:     "src/odyssey_v39_cached_bench/cache_v39.py",
0025:     "src/odyssey_v39_cached_bench/model_v39.py",
0026:     "src/odyssey_v39_cached_bench/model_transformer_cached.py",
0027:     "src/odyssey_v39_cached_bench/benchmark.py",
0028:     "src/odyssey_v39_cached_bench/__pycache__/__init__.cpython-313.pyc",
0029:     "src/odyssey_v39_cached_bench/__pycache__/config.cpython-313.pyc",
0030:     "src/odyssey_v39_cached_bench/__pycache__/model_v39.cpython-313.pyc",
0031:     "src/odyssey_v39_cached_bench/__pycache__/cache_v39.cpython-313.pyc",
0032:     "src/odyssey_v39_cached_bench/__pycache__/model_transformer_cached.cpython-313.pyc",
0033:     "src/odyssey_v39_cached_bench/__pycache__/benchmark.cpython-313.pyc",
0034:     "src/odyssey_v39_cached_bench/__pycache__/data.cpython-313.pyc"
0035:   ]
0036: }
```


## cached_decode_fair / `pyproject.toml`

```text
0001: [project]
0002: name = "odyssey-v39-cached-decode-fair-benchmark"
0003: version = "0.1.0"
0004: requires-python = ">=3.10"
0005: dependencies = ["torch"]
0006: 
0007: [tool.pytest.ini_options]
0008: pythonpath = ["src"]
0009: testpaths = ["tests"]
```


## cached_decode_fair / `run_benchmark.py`

```text
0001: from odyssey_v39_cached_bench.benchmark import run_benchmark
0002: import json
0003: 
0004: if __name__ == "__main__":
0005:     print(json.dumps(run_benchmark(output_dir="benchmark_outputs"), indent=2))
```


## cached_decode_fair / `src/odyssey_v39_cached_bench/__init__.py`

```text
0001: from .config import TinyConfig
0002: from .model_v39 import TinyOdysseyV39
0003: from .model_transformer_cached import TinyTransformerCachedLM
0004: from .benchmark import run_benchmark
```


## cached_decode_fair / `src/odyssey_v39_cached_bench/benchmark.py`

```text
0001: import csv
0002: import json
0003: import time
0004: from pathlib import Path
0005: import torch
0006: from .config import TinyConfig
0007: from .data import make_synthetic_batch
0008: from .model_v39 import TinyOdysseyV39
0009: from .model_transformer_cached import TinyTransformerCachedLM
0010: 
0011: def count_params(model):
0012:     return sum(p.numel() for p in model.parameters())
0013: 
0014: def sync_if_needed(device):
0015:     if device.startswith("cuda") and torch.cuda.is_available():
0016:         torch.cuda.synchronize()
0017: 
0018: def time_call(fn, device, warmup=2, trials=5):
0019:     for _ in range(warmup):
0020:         fn()
0021:     sync_if_needed(device)
0022:     vals = []
0023:     for _ in range(trials):
0024:         start = time.perf_counter()
0025:         fn()
0026:         sync_if_needed(device)
0027:         vals.append(time.perf_counter() - start)
0028:     return sum(vals) / len(vals), vals
0029: 
0030: def run_one_context(cfg, context, batch_size, device, seed):
0031:     torch.manual_seed(seed)
0032:     v39 = TinyOdysseyV39(cfg).to(device).eval()
0033:     torch.manual_seed(seed)
0034:     tr = TinyTransformerCachedLM(cfg).to(device).eval()
0035:     x = make_synthetic_batch(batch_size, context, cfg.vocab_size, device=device, seed=seed + 100)
0036: 
0037:     with torch.no_grad():
0038:         # parity for Transformer full vs cached decode
0039:         tf_full = tr.forward_full(x)
0040:         tf_cached, tf_cache = tr.prefill_cached(x)
0041:         tf_parity = float((tf_full - tf_cached).abs().max().item())
0042: 
0043:         def v39_prefill():
0044:             v39.prefill(x, top_k=2, use_tsc=True)
0045: 
0046:         def tr_prefill_cached():
0047:             tr.prefill_cached(x)
0048: 
0049:         def v39_decode_only():
0050:             cache = v39.new_cache(batch_size, device=device, dtype=v39.embed.weight.dtype)
0051:             for t in range(context):
0052:                 v39.decode_step(x[:, t:t+1], cache, top_k=1, use_tsc=False)
0053: 
0054:         def tr_decode_only():
0055:             cache = tr.new_cache(batch_size, cfg.max_positions, device=device, dtype=tr.embed.weight.dtype)
0056:             for t in range(context):
0057:                 tr.decode_step(x[:, t:t+1], cache)
0058: 
0059:         v39_prefill_mean, v39_prefill_trials = time_call(v39_prefill, device)
0060:         tr_prefill_mean, tr_prefill_trials = time_call(tr_prefill_cached, device)
0061:         v39_decode_mean, v39_decode_trials = time_call(v39_decode_only, device)
0062:         tr_decode_mean, tr_decode_trials = time_call(tr_decode_only, device)
0063: 
0064:     v39_cache = v39.cache_elements(batch_size)
0065:     tr_cache = tr.cache_elements(batch_size, context)
0066:     return {
0067:         "seed": seed,
0068:         "context": context,
0069:         "batch_size": batch_size,
0070:         "device": device,
0071:         "v39_params": count_params(v39),
0072:         "transformer_params": count_params(tr),
0073:         "param_ratio_v39_over_transformer": count_params(v39) / max(count_params(tr), 1),
0074:         "transformer_full_vs_cached_max_abs": tf_parity,
0075:         "v39_prefill_seconds": v39_prefill_mean,
0076:         "transformer_cached_prefill_seconds": tr_prefill_mean,
0077:         "v39_decode_seconds": v39_decode_mean,
0078:         "transformer_cached_decode_seconds": tr_decode_mean,
0079:         "v39_prefill_tokens_per_sec": batch_size * context / max(v39_prefill_mean, 1e-9),
0080:         "transformer_prefill_tokens_per_sec": batch_size * context / max(tr_prefill_mean, 1e-9),
0081:         "v39_decode_tokens_per_sec": batch_size * context / max(v39_decode_mean, 1e-9),
0082:         "transformer_decode_tokens_per_sec": batch_size * context / max(tr_decode_mean, 1e-9),
0083:         "v39_decode_speedup_vs_transformer_cached": tr_decode_mean / max(v39_decode_mean, 1e-9),
0084:         "v39_prefill_speedup_vs_transformer_cached": tr_prefill_mean / max(v39_prefill_mean, 1e-9),
0085:         "v39_cache_elements": v39_cache,
0086:         "transformer_kv_cache_elements": tr_cache,
0087:         "v39_cache_reduction_percent": 100.0 * (1.0 - v39_cache / max(tr_cache, 1)),
0088:         "v39_prefill_trials": v39_prefill_trials,
0089:         "transformer_prefill_trials": tr_prefill_trials,
0090:         "v39_decode_trials": v39_decode_trials,
0091:         "transformer_decode_trials": tr_decode_trials,
0092:     }
0093: 
0094: def write_csv(rows, path):
0095:     path = Path(path)
0096:     path.parent.mkdir(parents=True, exist_ok=True)
0097:     fieldnames = [k for k in rows[0].keys() if not k.endswith("_trials")]
0098:     with path.open("w", newline="", encoding="utf-8") as f:
0099:         w = csv.DictWriter(f, fieldnames=fieldnames)
0100:         w.writeheader()
0101:         for row in rows:
0102:             w.writerow({k: row[k] for k in fieldnames})
0103: 
0104: def run_benchmark(output_dir="benchmark_outputs", contexts=(8, 16, 32), seeds=(1, 2), batch_size=2, device=None):
0105:     if device is None:
0106:         device = "cuda" if torch.cuda.is_available() else "cpu"
0107:     cfg = TinyConfig(max_positions=max(contexts) + 4)
0108:     rows = []
0109:     for seed in seeds:
0110:         for ctx in contexts:
0111:             rows.append(run_one_context(cfg, ctx, batch_size, device, seed))
0112:     out = Path(output_dir)
0113:     out.mkdir(parents=True, exist_ok=True)
0114:     write_csv(rows, out / "cached_decode_results.csv")
0115:     summary = {
0116:         "device": device,
0117:         "contexts": list(contexts),
0118:         "seeds": list(seeds),
0119:         "batch_size": batch_size,
0120:         "rows": rows,
0121:         "notes": [
0122:             "Transformer uses explicit KV cache decode, not naive prefix recompute.",
0123:             "Tiny benchmark is reference-level, not CUDA-optimized.",
0124:             "Parameter counts are reported and may not be perfectly matched."
0125:         ],
0126:     }
0127:     (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
0128:     return summary
0129: 
0130: if __name__ == "__main__":
0131:     print(json.dumps(run_benchmark(), indent=2))
```


## cached_decode_fair / `src/odyssey_v39_cached_bench/cache_v39.py`

```text
0001: from dataclasses import dataclass
0002: import torch
0003: 
0004: @dataclass
0005: class QLAFCache:
0006:     state_summary: torch.Tensor
0007:     state_weight: torch.Tensor
0008:     position: int = 0
0009:     valid: bool = True
0010: 
0011:     @classmethod
0012:     def empty(cls, batch_size, cfg, device=None, dtype=None):
0013:         return cls(
0014:             state_summary=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, cfg.state_rank, device=device, dtype=dtype),
0015:             state_weight=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, device=device, dtype=dtype),
0016:             position=0,
0017:             valid=True,
0018:         )
0019: 
0020:     def elements(self):
0021:         return self.state_summary.numel() + self.state_weight.numel()
0022: 
0023:     def require_valid(self):
0024:         if not self.valid:
0025:             raise RuntimeError("QLAF cache invalid")
```


## cached_decode_fair / `src/odyssey_v39_cached_bench/config.py`

```text
0001: from dataclasses import dataclass
0002: 
0003: @dataclass
0004: class TinyConfig:
0005:     vocab_size: int = 32
0006:     hidden_size: int = 16
0007:     num_layers: int = 1
0008:     num_states: int = 3
0009:     state_rank: int = 4
0010:     max_positions: int = 128
0011:     intermediate_size: int = 32
0012:     num_heads: int = 4
0013:     tsc_scale: float = 0.10
```


## cached_decode_fair / `src/odyssey_v39_cached_bench/data.py`

```text
0001: import torch
0002: 
0003: def make_synthetic_batch(batch_size, seq_len, vocab_size, device="cpu", seed=None):
0004:     if seed is not None:
0005:         gen = torch.Generator(device="cpu")
0006:         gen.manual_seed(seed)
0007:         x = torch.randint(0, vocab_size, (batch_size, seq_len), generator=gen).to(device)
0008:     else:
0009:         x = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)
0010:     for t in range(2, seq_len):
0011:         x[:, t] = (x[:, t - 1] + x[:, t - 2] + (t % 5)) % vocab_size
0012:     return x
```


## cached_decode_fair / `src/odyssey_v39_cached_bench/model_transformer_cached.py`

```text
0001: import math
0002: import torch
0003: import torch.nn as nn
0004: import torch.nn.functional as F
0005: 
0006: class KVCache:
0007:     def __init__(self, num_layers, batch_size, num_heads, max_len, head_dim, device=None, dtype=None):
0008:         self.k = torch.zeros(num_layers, batch_size, num_heads, max_len, head_dim, device=device, dtype=dtype)
0009:         self.v = torch.zeros(num_layers, batch_size, num_heads, max_len, head_dim, device=device, dtype=dtype)
0010:         self.position = 0
0011:         self.max_len = max_len
0012: 
0013:     def elements(self):
0014:         return self.k.numel() + self.v.numel()
0015: 
0016: class CachedTransformerBlock(nn.Module):
0017:     def __init__(self, cfg):
0018:         super().__init__()
0019:         self.cfg = cfg
0020:         h = cfg.hidden_size
0021:         heads = cfg.num_heads if h % cfg.num_heads == 0 else 1
0022:         self.num_heads = heads
0023:         self.head_dim = h // heads
0024:         self.norm1 = nn.LayerNorm(h)
0025:         self.q = nn.Linear(h, h, bias=False)
0026:         self.k = nn.Linear(h, h, bias=False)
0027:         self.v = nn.Linear(h, h, bias=False)
0028:         self.o = nn.Linear(h, h, bias=False)
0029:         self.norm2 = nn.LayerNorm(h)
0030:         self.mlp = nn.Sequential(nn.Linear(h, cfg.intermediate_size), nn.SiLU(), nn.Linear(cfg.intermediate_size, h))
0031: 
0032:     def split_heads(self, x):
0033:         B, H = x.shape
0034:         return x.view(B, self.num_heads, self.head_dim)
0035: 
0036:     def merge_heads(self, x):
0037:         B, heads, dim = x.shape
0038:         return x.reshape(B, heads * dim)
0039: 
0040:     def decode_step(self, x, cache, layer_idx):
0041:         # x [B,H], cache stores previous plus current K/V.
0042:         B = x.size(0)
0043:         xn = self.norm1(x)
0044:         q = self.split_heads(self.q(xn))
0045:         k = self.split_heads(self.k(xn))
0046:         v = self.split_heads(self.v(xn))
0047: 
0048:         pos = cache.position
0049:         cache.k[layer_idx, :, :, pos, :] = k
0050:         cache.v[layer_idx, :, :, pos, :] = v
0051: 
0052:         keys = cache.k[layer_idx, :, :, :pos+1, :]
0053:         vals = cache.v[layer_idx, :, :, :pos+1, :]
0054:         scores = torch.einsum("bhd,bhtd->bht", q, keys) / math.sqrt(self.head_dim)
0055:         probs = torch.softmax(scores, dim=-1)
0056:         ctx = torch.einsum("bht,bhtd->bhd", probs, vals)
0057:         y = x + self.o(self.merge_heads(ctx))
0058:         y = y + self.mlp(self.norm2(y))
0059:         return y
0060: 
0061:     def forward_full(self, x):
0062:         B, T, H = x.shape
0063:         xn = self.norm1(x)
0064:         q = self.q(xn).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
0065:         k = self.k(xn).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
0066:         v = self.v(xn).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
0067:         scores = torch.einsum("bhtd,bhsd->bhts", q, k) / math.sqrt(self.head_dim)
0068:         mask = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
0069:         scores = scores.masked_fill(mask[None, None, :, :], float("-inf"))
0070:         probs = torch.softmax(scores, dim=-1)
0071:         ctx = torch.einsum("bhts,bhsd->bhtd", probs, v).transpose(1, 2).reshape(B, T, H)
0072:         y = x + self.o(ctx)
0073:         y = y + self.mlp(self.norm2(y))
0074:         return y
0075: 
0076: class TinyTransformerCachedLM(nn.Module):
0077:     def __init__(self, cfg):
0078:         super().__init__()
0079:         self.cfg = cfg
0080:         self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
0081:         self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
0082:         self.layers = nn.ModuleList([CachedTransformerBlock(cfg) for _ in range(cfg.num_layers)])
0083:         self.norm = nn.LayerNorm(cfg.hidden_size)
0084:         self.head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)
0085: 
0086:     def new_cache(self, batch_size, max_len, device=None, dtype=None):
0087:         heads = self.layers[0].num_heads
0088:         head_dim = self.layers[0].head_dim
0089:         return KVCache(self.cfg.num_layers, batch_size, heads, max_len, head_dim, device=device, dtype=dtype)
0090: 
0091:     def decode_step(self, token_ids, cache):
0092:         B = token_ids.size(0)
0093:         pos = torch.full((B, 1), cache.position, device=token_ids.device, dtype=torch.long)
0094:         x = self.embed(token_ids)[:, 0] + self.pos(pos)[:, 0]
0095:         for li, layer in enumerate(self.layers):
0096:             x = layer.decode_step(x, cache, li)
0097:         cache.position += 1
0098:         return self.head(self.norm(x)), cache
0099: 
0100:     def prefill_cached(self, input_ids):
0101:         B, T = input_ids.shape
0102:         cache = self.new_cache(B, self.cfg.max_positions, device=input_ids.device, dtype=self.embed.weight.dtype)
0103:         logits = []
0104:         for t in range(T):
0105:             y, cache = self.decode_step(input_ids[:, t:t+1], cache)
0106:             logits.append(y[:, None, :])
0107:         return torch.cat(logits, dim=1), cache
0108: 
0109:     def forward_full(self, input_ids):
0110:         B, T = input_ids.shape
0111:         pos = torch.arange(T, device=input_ids.device).unsqueeze(0).expand(B, T)
0112:         x = self.embed(input_ids) + self.pos(pos)
0113:         for layer in self.layers:
0114:             x = layer.forward_full(x)
0115:         return self.head(self.norm(x))
0116: 
0117:     def forward(self, input_ids, labels=None):
0118:         logits = self.forward_full(input_ids)
0119:         loss = None
0120:         if labels is not None:
0121:             loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
0122:         return {"logits": logits, "loss": loss}
0123: 
0124:     def cache_elements(self, batch_size, seq_len):
0125:         heads = self.layers[0].num_heads
0126:         head_dim = self.layers[0].head_dim
0127:         return 2 * self.cfg.num_layers * batch_size * heads * seq_len * head_dim
```


## cached_decode_fair / `src/odyssey_v39_cached_bench/model_v39.py`

```text
0001: import torch
0002: import torch.nn as nn
0003: import torch.nn.functional as F
0004: from .cache_v39 import QLAFCache
0005: 
0006: class QLAFLayer(nn.Module):
0007:     def __init__(self, cfg):
0008:         super().__init__()
0009:         self.cfg = cfg
0010:         h, s, r = cfg.hidden_size, cfg.num_states, cfg.state_rank
0011:         self.norm = nn.LayerNorm(h)
0012:         self.route = nn.Linear(h, s, bias=False)
0013:         self.to_rank = nn.Linear(h, r, bias=False)
0014:         self.from_state = nn.Linear(s * r, h, bias=False)
0015:         self.tsc_norm = nn.LayerNorm(h)
0016:         self.tsc = nn.Linear(h, h, bias=False)
0017:         self.mlp_norm = nn.LayerNorm(h)
0018:         self.mlp = nn.Sequential(nn.Linear(h, cfg.intermediate_size), nn.SiLU(), nn.Linear(cfg.intermediate_size, h))
0019: 
0020:     def update_one(self, x, state_summary, state_weight, top_k=1, use_tsc=True):
0021:         B, S, R = state_summary.shape
0022:         xn = self.norm(x)
0023:         route_probs = torch.softmax(self.route(xn), dim=-1)
0024:         vals, ids = torch.topk(route_probs, k=top_k, dim=-1)
0025:         vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0026:         z = self.to_rank(xn)
0027:         new_state = state_summary.clone()
0028:         new_weight = state_weight.clone()
0029:         batch_idx = torch.arange(B, device=x.device)
0030: 
0031:         for j in range(top_k):
0032:             sid = ids[:, j]
0033:             w = vals[:, j]
0034:             old_w = new_weight[batch_idx, sid]
0035:             new_w = old_w + w
0036:             old = new_state[batch_idx, sid]
0037:             new_state[batch_idx, sid] = (old * old_w[:, None] + z * w[:, None]) / new_w[:, None].clamp_min(1e-8)
0038:             new_weight[batch_idx, sid] = new_w
0039: 
0040:         weighted = new_state * new_weight[:, :, None]
0041:         denom = new_weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0042:         flat = (weighted / denom[:, :, None]).reshape(B, S * R)
0043:         y = x + self.from_state(flat)
0044:         if use_tsc:
0045:             y = y + self.cfg.tsc_scale * self.tsc(self.tsc_norm(y))
0046:         y = y + self.mlp(self.mlp_norm(y))
0047:         return y, new_state, new_weight
0048: 
0049: class TinyOdysseyV39(nn.Module):
0050:     def __init__(self, cfg):
0051:         super().__init__()
0052:         self.cfg = cfg
0053:         self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
0054:         self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
0055:         self.layers = nn.ModuleList([QLAFLayer(cfg) for _ in range(cfg.num_layers)])
0056:         self.norm = nn.LayerNorm(cfg.hidden_size)
0057:         self.head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)
0058: 
0059:     def new_cache(self, batch_size, device=None, dtype=None):
0060:         return QLAFCache.empty(batch_size, self.cfg, device=device, dtype=dtype)
0061: 
0062:     def decode_step(self, token_ids, cache, top_k=1, use_tsc=True):
0063:         cache.require_valid()
0064:         B = token_ids.size(0)
0065:         pos = torch.full((B, 1), cache.position, device=token_ids.device, dtype=torch.long)
0066:         x = self.embed(token_ids)[:, 0] + self.pos(pos)[:, 0]
0067:         for li, layer in enumerate(self.layers):
0068:             x, ns, nw = layer.update_one(x, cache.state_summary[:, li], cache.state_weight[:, li], top_k=top_k, use_tsc=use_tsc)
0069:             cache.state_summary[:, li] = ns
0070:             cache.state_weight[:, li] = nw
0071:         cache.position += 1
0072:         return self.head(self.norm(x)), cache
0073: 
0074:     def prefill(self, input_ids, top_k=2, use_tsc=True):
0075:         B, T = input_ids.shape
0076:         cache = self.new_cache(B, device=input_ids.device, dtype=self.embed.weight.dtype)
0077:         logits = []
0078:         for t in range(T):
0079:             y, cache = self.decode_step(input_ids[:, t:t+1], cache, top_k=top_k, use_tsc=use_tsc)
0080:             logits.append(y[:, None, :])
0081:         return torch.cat(logits, dim=1), cache
0082: 
0083:     def forward(self, input_ids, labels=None):
0084:         logits, _ = self.prefill(input_ids, top_k=2, use_tsc=True)
0085:         loss = None
0086:         if labels is not None:
0087:             loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
0088:         return {"logits": logits, "loss": loss}
0089: 
0090:     def cache_elements(self, batch_size):
0091:         return batch_size * self.cfg.num_layers * self.cfg.num_states * self.cfg.state_rank + batch_size * self.cfg.num_layers * self.cfg.num_states
```


## cached_decode_fair / `tests/test_cached_transformer.py`

```text
0001: import torch
0002: from odyssey_v39_cached_bench.config import TinyConfig
0003: from odyssey_v39_cached_bench.data import make_synthetic_batch
0004: from odyssey_v39_cached_bench.model_transformer_cached import TinyTransformerCachedLM
0005: 
0006: def test_transformer_cached_matches_full_cpu():
0007:     cfg = TinyConfig(max_positions=20)
0008:     model = TinyTransformerCachedLM(cfg).eval()
0009:     x = make_synthetic_batch(2, 8, cfg.vocab_size, seed=123)
0010:     with torch.no_grad():
0011:         full = model.forward_full(x)
0012:         cached, _ = model.prefill_cached(x)
0013:     assert (full - cached).abs().max().item() < 1e-5
```


## sharded_pipeline / `LOCAL_SMOKE_RUN_RESULT.txt`

```text
0001: Exit status: -1
0002: 
0003: TimeoutExpired(['bash', '/mnt/data/odyssey_v39_sharded_replacement_pipeline/scripts/run_all_cpu_shards.sh'], 45)
```


## sharded_pipeline / `README.md`

```text
0001: # Odyssey V39 Sharded Replacement Pipeline
0002: 
0003: This package targets the required sequence:
0004: 
0005: 1. independent full-forward parity;
0006: 2. parameter-matched cached decode;
0007: 3. tiny training quality table;
0008: 4. CUDA top-1 decode;
0009: 5. Route B server integration.
0010: 
0011: It is designed for restricted environments:
0012: - every stage is split into small parts;
0013: - each part writes its own CSV/JSON;
0014: - runs can be resumed;
0015: - CPU smoke mode is available;
0016: - CUDA/server stages are packaged as build targets even if not executed locally.
0017: 
0018: ## Quick smoke
0019: 
0020: ```bash
0021: python3 scripts/run_part_01_independent_parity.py --smoke
0022: python3 scripts/run_part_02_param_match.py --smoke
0023: python3 scripts/run_part_03_cached_decode.py --smoke
0024: python3 scripts/run_part_04_tiny_training.py --smoke
0025: python3 scripts/aggregate_results.py
0026: ```
0027: 
0028: ## Full CPU shard sequence
0029: 
0030: ```bash
0031: bash scripts/run_all_cpu_shards.sh
0032: ```
0033: 
0034: ## Outputs
0035: 
0036: Results are written to:
0037: 
0038: ```text
0039: results/parity.csv
0040: results/param_match.csv
0041: results/cached_decode.csv
0042: results/tiny_training.csv
0043: results/aggregate_summary.json
0044: ```
0045: 
0046: ## Important
0047: 
0048: This is not a final superiority claim. It is the pipeline required to produce the evidence.
```


## sharded_pipeline / `cuda_top1_decode/CUDA_TOP1_DECODE_BUILD_PLAN.md`

```text
0001: # CUDA Top-1 Decode Build Plan
0002: 
0003: ## Build after these CSVs exist
0004: 
0005: - `results/parity.csv` with independent parity passed.
0006: - `results/cached_decode.csv` with V39 vs Transformer KV timing.
0007: - `results/param_match.csv` with a near-matched configuration.
0008: - `results/tiny_training.csv` or PyTorch training table.
0009: 
0010: ## Kernel target
0011: 
0012: The first CUDA kernel should implement only the top-1 decode state update:
0013: 
0014: 1. compute route logits;
0015: 2. select top-1 state;
0016: 3. project token to rank vector;
0017: 4. update selected state summary and weight;
0018: 5. read state bank;
0019: 6. return hidden update.
0020: 
0021: ## Required parity
0022: 
0023: CUDA output must match reference top-1 decode within tolerance before any speed claim.
0024: 
0025: ## Do not build first
0026: 
0027: - top-2;
0028: - prefill scan;
0029: - TSC;
0030: - server batching.
0031: 
0032: Those come after top-1 decode parity.
```


## sharded_pipeline / `cuda_top1_decode/abi_stub.h`

```text
0001: #pragma once
0002: 
0003: // Odyssey V39 CUDA top-1 decode ABI draft.
0004: // This is a stub header for the future extension, not a compiled kernel.
0005: 
0006: struct OdysseyV39DecodeConfig {
0007:     int batch;
0008:     int hidden;
0009:     int states;
0010:     int rank;
0011:     int layers;
0012: };
0013: 
0014: extern "C" int odyssey_v39_decode_top1_forward(
0015:     const OdysseyV39DecodeConfig* config,
0016:     const void* token_hidden,
0017:     void* state_summary,
0018:     void* state_weight,
0019:     const void* route_weight,
0020:     const void* rank_weight,
0021:     const void* out_weight,
0022:     void* output_hidden
0023: );
```


## sharded_pipeline / `docs/NEXT_ACTIONS.md`

```text
0001: # Next Actions
0002: 
0003: Run:
0004: 
0005: ```bash
0006: bash scripts/run_all_cpu_shards.sh
0007: ```
0008: 
0009: Then inspect:
0010: 
0011: ```text
0012: results/aggregate_summary.json
0013: results/parity.csv
0014: results/param_match.csv
0015: results/cached_decode.csv
0016: results/tiny_training.csv
0017: ```
0018: 
0019: If smoke passes, run larger shards:
0020: 
0021: ```bash
0022: python3 scripts/run_part_01_independent_parity.py --context 16 --batch 2 --seed 1
0023: python3 scripts/run_part_03_cached_decode.py --contexts 8,16,32,64 --seeds 1,2,3 --batch 2
0024: python3 scripts/run_part_04_tiny_training.py --seeds 1,2,3 --steps 10
0025: python3 scripts/aggregate_results.py
0026: ```
0027: 
0028: Then move to the PyTorch package for real gradient training and CUDA top-1 decode.
```


## sharded_pipeline / `docs/PIPELINE_STATUS.md`

```text
0001: # Pipeline Status
0002: 
0003: This artifact implements the restricted-environment execution plan for:
0004: 
0005: 1. independent full-forward parity;
0006: 2. parameter-matched cached decode;
0007: 3. tiny training quality table;
0008: 4. CUDA top-1 decode;
0009: 5. Route B server integration.
0010: 
0011: ## What runs now
0012: 
0013: - Independent parity shard.
0014: - Parameter sweep shard.
0015: - Cached decode shard.
0016: - Tiny proxy training shard.
0017: - Aggregation.
0018: 
0019: ## What is specified but not executed here
0020: 
0021: - CUDA kernel.
0022: - Route B server.
0023: - HF custom model repo.
0024: 
0025: ## Why
0026: 
0027: The environment may not support long PyTorch/GPU runs. This pipeline breaks evidence generation into small resumable shards.
```


## sharded_pipeline / `hf_repo_template/HF_REPO_FILES.md`

```text
0001: # Hugging Face Route B Repo Files
0002: 
0003: Required:
0004: 
0005: - `config.json`
0006: - `configuration_odyssey_v39.py`
0007: - `modeling_odyssey_v39.py`
0008: - `generation_odyssey_v39.py`
0009: - `model.safetensors`
0010: - tokenizer files
0011: - `README.md`
0012: - `requirements.txt`
0013: 
0014: Loading:
0015: 
0016: ```python
0017: AutoModelForCausalLM.from_pretrained(
0018:     repo,
0019:     trust_remote_code=True,
0020:     torch_dtype="auto",
0021:     device_map="auto",
0022: )
0023: ```
0024: 
0025: Warning:
0026: 
0027: The HF fallback path is for portability. Performance claims require the CUDA wheel and custom server.
```


## sharded_pipeline / `manifest.json`

```text
0001: {
0002:   "name": "odyssey_v39_sharded_replacement_pipeline",
0003:   "local_smoke_exit_status": -1,
0004:   "sequence": [
0005:     "independent full-forward parity",
0006:     "parameter-matched cached decode",
0007:     "tiny training quality table",
0008:     "CUDA top-1 decode",
0009:     "Route B server integration"
0010:   ],
0011:   "files": [
0012:     "README.md",
0013:     "pyproject.toml",
0014:     "resume_status.json",
0015:     "LOCAL_SMOKE_RUN_RESULT.txt",
0016:     "scripts/run_part_01_independent_parity.py",
0017:     "scripts/run_part_02_param_match.py",
0018:     "scripts/run_part_03_cached_decode.py",
0019:     "scripts/run_part_04_tiny_training.py",
0020:     "scripts/aggregate_results.py",
0021:     "scripts/run_all_cpu_shards.sh",
0022:     "results/parity.csv",
0023:     "results/param_match.csv",
0024:     "results/cached_decode.csv",
0025:     "docs/PIPELINE_STATUS.md",
0026:     "docs/NEXT_ACTIONS.md",
0027:     "cuda_top1_decode/CUDA_TOP1_DECODE_BUILD_PLAN.md",
0028:     "cuda_top1_decode/abi_stub.h",
0029:     "route_b_server/README_ROUTE_B_SERVER.md",
0030:     "hf_repo_template/HF_REPO_FILES.md",
0031:     "src/odyssey_v39_pipeline/__init__.py",
0032:     "src/odyssey_v39_pipeline/csv_utils.py",
0033:     "src/odyssey_v39_pipeline/numeric_models.py",
0034:     "src/odyssey_v39_pipeline/__pycache__/__init__.cpython-313.pyc",
0035:     "src/odyssey_v39_pipeline/__pycache__/numeric_models.cpython-313.pyc",
0036:     "src/odyssey_v39_pipeline/__pycache__/csv_utils.cpython-313.pyc"
0037:   ]
0038: }
```


## sharded_pipeline / `pyproject.toml`

```text
0001: [project]
0002: name = "odyssey-v39-sharded-replacement-pipeline"
0003: version = "0.1.0"
0004: requires-python = ">=3.10"
0005: 
0006: [tool.pytest.ini_options]
0007: pythonpath = ["src"]
```


## sharded_pipeline / `results/aggregate_summary.json`

```text
0001: {
0002:   "parity": {
0003:     "rows": 2,
0004:     "last": {
0005:       "part": "independent_full_forward_parity",
0006:       "seed": "1",
0007:       "context": "4",
0008:       "batch": "1",
0009:       "max_abs_diff": "0.0",
0010:       "passed": "True",
0011:       "elapsed_seconds": "0.002474749000157317"
0012:     }
0013:   },
0014:   "param_match": {
0015:     "rows": 32,
0016:     "last": {
0017:       "hidden": "16",
0018:       "states": "2",
0019:       "rank": "2",
0020:       "intermediate": "16",
0021:       "v39_params": "10112",
0022:       "transformer_params": "10752",
0023:       "ratio": "0.9404761904761905",
0024:       "abs_delta": "0.059523809523809534"
0025:     }
0026:   },
0027:   "cached_decode": {
0028:     "rows": 2,
0029:     "last": {
0030:       "seed": "1",
0031:       "context": "4",
0032:       "batch": "2",
0033:       "v39_seconds": "0.0022026370002095064",
0034:       "transformer_kv_seconds": "0.002970459000152914",
0035:       "v39_tokens_per_sec": "3632.0101765470527",
0036:       "transformer_tokens_per_sec": "2693.1864737362725",
0037:       "v39_speedup_vs_transformer_kv": "1.3485921646963959",
0038:       "v39_cache_elements": "30",
0039:       "transformer_kv_elements": "256",
0040:       "cache_reduction_percent": "88.28125",
0041:       "v39_proxy_loss": "3.4880568669283925",
0042:       "transformer_proxy_loss": "3.4329709819673275",
0043:       "v39_params": "3632",
0044:       "transformer_params": "4096"
0045:     }
0046:   },
0047:   "tiny_training": {
0048:     "rows": 4,
0049:     "last": {
0050:       "seed": "1",
0051:       "step": "1",
0052:       "v39_proxy_loss": "3.4537904865619558",
0053:       "transformer_proxy_loss": "3.4415151958517214",
0054:       "best_v39_proxy_loss": "3.4537904865619558",
0055:       "best_transformer_proxy_loss": "3.4296887440672963"
0056:     }
0057:   }
0058: }
```


## sharded_pipeline / `results/cached_decode.csv`

```text
0001: seed,context,batch,v39_seconds,transformer_kv_seconds,v39_tokens_per_sec,transformer_tokens_per_sec,v39_speedup_vs_transformer_kv,v39_cache_elements,transformer_kv_elements,cache_reduction_percent,v39_proxy_loss,transformer_proxy_loss,v39_params,transformer_params
0002: 1,4,2,0.002875975999813818,0.0030166469996402157,2781.6643812458437,2651.9509909360063,1.0489124387114164,30,256,88.28125,3.4880568669283925,3.4329709819673275,3632,4096
0003: 1,4,2,0.0022026370002095064,0.002970459000152914,3632.0101765470527,2693.1864737362725,1.3485921646963959,30,256,88.28125,3.4880568669283925,3.4329709819673275,3632,4096
0004: 1,8,2,0.00265786899944942,0.00304297000002407,6019.860272765292,5258.020946599355,1.144890888397594,30,256,88.28125,3.434726079874674,3.500847216343935,1752,1792
0005: 1,16,2,0.01128351700026542,0.006521282999528921,2835.995195402929,4907.0098632909485,0.5779477267039632,30,512,94.140625,3.4184826631753262,3.5321231188967928,1752,1792
0006: 1,32,2,0.00984982200043305,0.014671060000182479,6497.579346833498,4362.329647564932,1.4894746320834489,30,1024,97.0703125,3.4610729521240198,3.492250158592098,1752,1792
0007: 1,64,2,0.02087502399990626,0.03998730299917952,6131.72947732059,3201.0160825956773,1.9155572228017117,30,2048,98.53515625,3.441770296205251,3.448683227026019,1784,1824
0008: 2,8,2,0.002727874999436608,0.0030816030002824846,5865.37139836118,5192.102940753014,1.1296716311850552,30,256,88.28125,3.4603183346324142,3.4590449220366826,1752,1792
0009: 2,16,2,0.006152810999992653,0.008305676999952993,5200.87485216728,3852.7864736590536,1.3498995824774906,30,512,94.140625,3.456882409982557,3.4703063417056934,1752,1792
0010: 2,32,2,0.010819531000379357,0.016095736999886867,5915.228672828426,3976.208110287205,1.4876557033130655,30,1024,97.0703125,3.474562198123182,3.4724717250169954,1752,1792
0011: 2,64,2,0.023768612999447214,0.048402473000351165,5385.253233033703,2644.4929786763446,2.036402923530997,30,2048,98.53515625,3.4796182816396213,3.465894467610216,1784,1824
0012: 3,8,2,0.0028117800002291915,0.003387146000022767,5690.345616903108,4723.740872077098,1.204626962190028,30,256,88.28125,3.4812048784656464,3.464434534141588,1752,1792
0013: 3,16,2,0.005109333000291372,0.006364050999764004,6263.048424946099,5028.243802758125,1.2455737371983935,30,512,94.140625,3.4659182739576804,3.462732721128896,1752,1792
0014: 3,32,2,0.010432811000100628,0.01538681900001393,6134.49242005656,4159.404227731675,1.4748488206932453,30,1024,97.0703125,3.444681600095923,3.4737741887288855,1752,1792
0015: 3,64,2,0.02252801999929943,0.03945339700021577,5681.813137771562,3244.3340683515785,1.7513033547308055,30,2048,98.53515625,3.46938755737587,3.479105471073945,1784,1824
```


## sharded_pipeline / `results/param_match.csv`

```text
0001: hidden,states,rank,intermediate,v39_params,transformer_params,ratio,abs_delta
0002: 8,3,4,32,5336,5376,0.9925595238095238,0.007440476190476164
0003: 8,3,4,16,5080,5120,0.9921875,0.0078125
0004: 8,2,4,32,5296,5376,0.9851190476190477,0.014880952380952328
0005: 8,2,4,16,5040,5120,0.984375,0.015625
0006: 8,3,2,32,5272,5376,0.9806547619047619,0.019345238095238138
0007: 8,3,2,16,5016,5120,0.9796875,0.020312499999999956
0008: 8,2,2,32,5248,5376,0.9761904761904762,0.023809523809523836
0009: 8,2,2,16,4992,5120,0.975,0.025000000000000022
0010: 16,3,4,32,10800,11264,0.9588068181818182,0.04119318181818177
0011: 16,3,4,16,10288,10752,0.9568452380952381,0.04315476190476186
0012: 16,2,4,32,10720,11264,0.9517045454545454,0.048295454545454586
0013: 16,2,4,16,10208,10752,0.9494047619047619,0.05059523809523814
0014: 16,3,2,32,10672,11264,0.9474431818181818,0.05255681818181823
0015: 16,3,2,16,10160,10752,0.9449404761904762,0.055059523809523836
0016: 16,2,2,32,10624,11264,0.9431818181818182,0.05681818181818177
0017: 16,2,2,16,10112,10752,0.9404761904761905,0.059523809523809534
0018: 8,3,4,32,5336,5376,0.9925595238095238,0.007440476190476164
0019: 8,3,4,16,5080,5120,0.9921875,0.0078125
0020: 8,2,4,32,5296,5376,0.9851190476190477,0.014880952380952328
0021: 8,2,4,16,5040,5120,0.984375,0.015625
0022: 8,3,2,32,5272,5376,0.9806547619047619,0.019345238095238138
0023: 8,3,2,16,5016,5120,0.9796875,0.020312499999999956
0024: 8,2,2,32,5248,5376,0.9761904761904762,0.023809523809523836
0025: 8,2,2,16,4992,5120,0.975,0.025000000000000022
0026: 16,3,4,32,10800,11264,0.9588068181818182,0.04119318181818177
0027: 16,3,4,16,10288,10752,0.9568452380952381,0.04315476190476186
0028: 16,2,4,32,10720,11264,0.9517045454545454,0.048295454545454586
0029: 16,2,4,16,10208,10752,0.9494047619047619,0.05059523809523814
0030: 16,3,2,32,10672,11264,0.9474431818181818,0.05255681818181823
0031: 16,3,2,16,10160,10752,0.9449404761904762,0.055059523809523836
0032: 16,2,2,32,10624,11264,0.9431818181818182,0.05681818181818177
0033: 16,2,2,16,10112,10752,0.9404761904761905,0.059523809523809534
```


## sharded_pipeline / `results/parity.csv`

```text
0001: part,seed,context,batch,max_abs_diff,passed,elapsed_seconds
0002: independent_full_forward_parity,1,4,1,0.0,True,0.002631736999774148
0003: independent_full_forward_parity,1,4,1,0.0,True,0.002474749000157317
```


## sharded_pipeline / `results/scaled_run_summary.csv`

```text
0001: context,n,speedup_mean,speedup_min,speedup_max,cache_reduction_mean,v39_loss_mean,transformer_loss_mean
0002: 8,3,1.15973,1.1296716311850552,1.204626962190028,88.2812,3.45875,3.47478
0003: 16,3,1.05781,0.5779477267039632,1.3498995824774906,94.1406,3.44709,3.48839
0004: 32,3,1.48399,1.4748488206932453,1.4894746320834489,97.0703,3.46011,3.4795
0005: 64,3,1.90109,1.7513033547308055,2.036402923530997,98.5352,3.46359,3.46456
```


## sharded_pipeline / `results/sharded_run_log.json`

```text
0001: {
0002:   "part_04_tiny_training_smoke": {
0003:     "cmd": "/opt/pyvenv/bin/python /mnt/data/odyssey_v39_sharded_replacement_pipeline/scripts/run_part_04_tiny_training.py --smoke",
0004:     "status": 0,
0005:     "elapsed": 13.13703787400027,
0006:     "output": "{\n  \"note\": \"proxy table only; real gradient training should be run in PyTorch package\",\n  \"rows\": [\n    {\n      \"seed\": 1,\n      \"step\": 0,\n      \"v39_proxy_loss\": 3.4797772203325694,\n      \"transformer_proxy_loss\": 3.4296887440672963,\n      \"best_v39_proxy_loss\": 3.4797772203325694,\n      \"best_transformer_proxy_loss\": 3.4296887440672963\n    },\n    {\n      \"seed\": 1,\n      \"step\": 1,\n      \"v39_proxy_loss\": 3.4537904865619558,\n      \"transformer_proxy_loss\": 3.4415151958517214,\n      \"best_v39_proxy_loss\": 3.4537904865619558,\n      \"best_transformer_proxy_loss\": 3.4296887440672963\n    }\n  ]\n}\nSpreadsheet runtime warmup failed during python startup\nTraceback (most recent call last):\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py\", line 26, in warm_spreadsheet_runtime_on_startup\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 785, in warm_spreadsheet_runtime\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 720, in _warm_feature_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 704, in _warm_collaboration_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/generated/interface/models.py\", line 35986, in hydrate_crdt_from_proto\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/remote.py\", line 747, in __call__\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/client.py\", line 150, in call\npresentation_artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.\n"
0007:   },
0008:   "aggregate": {
0009:     "cmd": "/opt/pyvenv/bin/python /mnt/data/odyssey_v39_sharded_replacement_pipeline/scripts/aggregate_results.py",
0010:     "status": 0,
0011:     "elapsed": 12.83800743799975,
0012:     "output": "{\n  \"parity\": {\n    \"rows\": 2,\n    \"last\": {\n      \"part\": \"independent_full_forward_parity\",\n      \"seed\": \"1\",\n      \"context\": \"4\",\n      \"batch\": \"1\",\n      \"max_abs_diff\": \"0.0\",\n      \"passed\": \"True\",\n      \"elapsed_seconds\": \"0.002474749000157317\"\n    }\n  },\n  \"param_match\": {\n    \"rows\": 32,\n    \"last\": {\n      \"hidden\": \"16\",\n      \"states\": \"2\",\n      \"rank\": \"2\",\n      \"intermediate\": \"16\",\n      \"v39_params\": \"10112\",\n      \"transformer_params\": \"10752\",\n      \"ratio\": \"0.9404761904761905\",\n      \"abs_delta\": \"0.059523809523809534\"\n    }\n  },\n  \"cached_decode\": {\n    \"rows\": 2,\n    \"last\": {\n      \"seed\": \"1\",\n      \"context\": \"4\",\n      \"batch\": \"2\",\n      \"v39_seconds\": \"0.0022026370002095064\",\n      \"transformer_kv_seconds\": \"0.002970459000152914\",\n      \"v39_tokens_per_sec\": \"3632.0101765470527\",\n      \"transformer_tokens_per_sec\": \"2693.1864737362725\",\n      \"v39_speedup_vs_transformer_kv\": \"1.3485921646963959\",\n      \"v39_cache_elements\": \"30\",\n      \"transformer_kv_elements\": \"256\",\n      \"cache_reduction_percent\": \"88.28125\",\n      \"v39_proxy_loss\": \"3.4880568669283925\",\n      \"transformer_proxy_loss\": \"3.4329709819673275\",\n      \"v39_params\": \"3632\",\n      \"transformer_params\": \"4096\"\n    }\n  },\n  \"tiny_training\": {\n    \"rows\": 4,\n    \"last\": {\n      \"seed\": \"1\",\n      \"step\": \"1\",\n      \"v39_proxy_loss\": \"3.4537904865619558\",\n      \"transformer_proxy_loss\": \"3.4415151958517214\",\n      \"best_v39_proxy_loss\": \"3.4537904865619558\",\n      \"best_transformer_proxy_loss\": \"3.4296887440672963\"\n    }\n  }\n}\nSpreadsheet runtime warmup failed during python startup\nTraceback (most recent call last):\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py\", line 26, in warm_spreadsheet_runtime_on_startup\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 785, in warm_spreadsheet_runtime\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 720, in _warm_feature_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 704, in _warm_collaboration_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/generated/interface/models.py\", line 35986, in hydrate_crdt_from_proto\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/remote.py\", line 747, in __call__\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/client.py\", line 150, in call\npresentation_artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.\n"
0013:   }
0014: }
```


## sharded_pipeline / `results/status_note.txt`

```text
0001: Scaled cached-decode shards completed for contexts 8,16,32,64 across seeds 1,2,3 using the best smoke-matched config: hidden=8, states=3, rank=4, intermediate=32.
0002: Real PyTorch gradient-training shard was added as scripts/run_part_05_pytorch_gradient_training.py, but was not completed in this environment because subprocess execution hit the environment time limit. It should be run locally/server-side before CUDA.
0003: CUDA remains blocked until PyTorch gradient-training CSV exists.
```


## sharded_pipeline / `results/tiny_training.csv`

```text
0001: seed,step,v39_proxy_loss,transformer_proxy_loss,best_v39_proxy_loss,best_transformer_proxy_loss
0002: 1,0,3.4797772203325694,3.4296887440672963,3.4797772203325694,3.4296887440672963
0003: 1,1,3.4537904865619558,3.4415151958517214,3.4537904865619558,3.4296887440672963
0004: 1,0,3.4797772203325694,3.4296887440672963,3.4797772203325694,3.4296887440672963
0005: 1,1,3.4537904865619558,3.4415151958517214,3.4537904865619558,3.4296887440672963
```


## sharded_pipeline / `resume_status.json`

```text
0001: {
0002:   "part_01_independent_parity": "not_started",
0003:   "part_02_parameter_match": "not_started",
0004:   "part_03_cached_decode": "not_started",
0005:   "part_04_tiny_training": "not_started",
0006:   "part_05_cuda_top1_decode": "spec_ready_not_built",
0007:   "part_06_route_b_server": "spec_ready_not_built"
0008: }
```


## sharded_pipeline / `route_b_server/README_ROUTE_B_SERVER.md`

```text
0001: # Route B Server Integration Plan
0002: 
0003: ## Purpose
0004: 
0005: Deploy the exact V39 engine, not a Transformer wrapper.
0006: 
0007: ## Required pieces
0008: 
0009: - HF custom model repo.
0010: - safetensors weights.
0011: - CUDA wheel.
0012: - custom inference server.
0013: - prefill/decode separation.
0014: - cache ownership by request id.
0015: - streaming generation.
0016: - metrics endpoint.
0017: 
0018: ## Server endpoints
0019: 
0020: - `/health`
0021: - `/generate`
0022: - `/generate_stream`
0023: - `/metrics`
0024: - `/cache/debug`
0025: 
0026: ## Metrics
0027: 
0028: - prefill tokens/sec;
0029: - decode tokens/sec;
0030: - p50 latency;
0031: - p95 latency;
0032: - active cache elements;
0033: - refresh count;
0034: - fallback count;
0035: - CUDA/reference backend.
0036: 
0037: ## Integration order
0038: 
0039: 1. CPU reference server.
0040: 2. PyTorch server.
0041: 3. CUDA top-1 decode server.
0042: 4. CUDA prefill server.
0043: 5. HF model card and Docker release.
```


## sharded_pipeline / `scripts/aggregate_results.py`

```text
0001: #!/usr/bin/env python3
0002: import json, csv
0003: from pathlib import Path
0004: base=Path(__file__).resolve().parents[1]
0005: results=base/"results"
0006: summary={}
0007: for name in ["parity","param_match","cached_decode","tiny_training","pytorch_training"]:
0008:     path=results/f"{name}.csv"
0009:     if path.exists():
0010:         with path.open("r",encoding="utf-8") as f:
0011:             rows=list(csv.DictReader(f))
0012:         summary[name]={"rows":len(rows),"last":rows[-1] if rows else None}
0013:     else:
0014:         summary[name]={"rows":0,"last":None}
0015: (results/"aggregate_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
0016: print(json.dumps(summary,indent=2))
```


## sharded_pipeline / `scripts/run_all_cpu_shards.sh`

```text
0001: #!/usr/bin/env bash
0002: set -euo pipefail
0003: ROOT="$(cd "$(dirname "$0")/.." && pwd)"
0004: export PYTHONPATH="$ROOT/src"
0005: 
0006: python3 "$ROOT/scripts/run_part_01_independent_parity.py" --smoke
0007: python3 "$ROOT/scripts/run_part_02_param_match.py" --smoke
0008: python3 "$ROOT/scripts/run_part_03_cached_decode.py" --smoke
0009: python3 "$ROOT/scripts/run_part_04_tiny_training.py" --smoke
0010: python3 "$ROOT/scripts/aggregate_results.py"
```


## sharded_pipeline / `scripts/run_part_01_independent_parity.py`

```text
0001: #!/usr/bin/env python3
0002: import argparse, json, sys, time
0003: from pathlib import Path
0004: sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
0005: from odyssey_v39_pipeline.numeric_models import Config, TinyV39Independent, make_tokens, max_abs_nested
0006: from odyssey_v39_pipeline.csv_utils import append_csv
0007: 
0008: ap = argparse.ArgumentParser()
0009: ap.add_argument("--seed", type=int, default=1)
0010: ap.add_argument("--context", type=int, default=8)
0011: ap.add_argument("--batch", type=int, default=2)
0012: ap.add_argument("--smoke", action="store_true")
0013: args = ap.parse_args()
0014: if args.smoke:
0015:     args.context = 4
0016:     args.batch = 1
0017: 
0018: cfg = Config(max_pos=max(64, args.context+4))
0019: model = TinyV39Independent(cfg, seed=args.seed)
0020: tokens = make_tokens(args.batch, args.context, cfg.vocab, args.seed+100)
0021: t0 = time.perf_counter()
0022: full = model.forward_full_independent(tokens, top_k=2, use_tsc=True)
0023: cached, cache = model.forward_cached(tokens, top_k=2, use_tsc=True)
0024: elapsed = time.perf_counter() - t0
0025: diff = max_abs_nested(full, cached)
0026: row = {
0027:     "part": "independent_full_forward_parity",
0028:     "seed": args.seed,
0029:     "context": args.context,
0030:     "batch": args.batch,
0031:     "max_abs_diff": diff,
0032:     "passed": diff < 1e-10,
0033:     "elapsed_seconds": elapsed,
0034: }
0035: append_csv(Path(__file__).resolve().parents[1] / "results" / "parity.csv", row)
0036: print(json.dumps(row, indent=2))
```


## sharded_pipeline / `scripts/run_part_02_param_match.py`

```text
0001: #!/usr/bin/env python3
0002: import argparse, json, sys, itertools
0003: from pathlib import Path
0004: sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
0005: from odyssey_v39_pipeline.numeric_models import Config, TinyV39Independent, TinyTransformerKV
0006: from odyssey_v39_pipeline.csv_utils import append_csv
0007: 
0008: ap = argparse.ArgumentParser()
0009: ap.add_argument("--smoke", action="store_true")
0010: args = ap.parse_args()
0011: 
0012: hidden_vals = [8, 16] if args.smoke else [8,16,24,32]
0013: state_vals = [2,3] if args.smoke else [2,3,4,6,8]
0014: rank_vals = [2,4] if args.smoke else [2,4,8,12,16]
0015: inter_vals = [16,32] if args.smoke else [16,32,64,96]
0016: 
0017: best = None
0018: rows = []
0019: for h,s,r,i in itertools.product(hidden_vals,state_vals,rank_vals,inter_vals):
0020:     cfg = Config(hidden=h, states=s, rank=r, intermediate=i)
0021:     v = TinyV39Independent(cfg, seed=1)
0022:     t = TinyTransformerKV(cfg, seed=1)
0023:     vp, tp = v.params(), t.params()
0024:     ratio = vp / max(tp,1)
0025:     delta = abs(ratio - 1.0)
0026:     row = {"hidden":h,"states":s,"rank":r,"intermediate":i,"v39_params":vp,"transformer_params":tp,"ratio":ratio,"abs_delta":delta}
0027:     rows.append(row)
0028:     if best is None or delta < best["abs_delta"]:
0029:         best = row
0030: 
0031: out = Path(__file__).resolve().parents[1] / "results" / "param_match.csv"
0032: for row in sorted(rows, key=lambda x: x["abs_delta"])[:20]:
0033:     append_csv(out, row)
0034: print(json.dumps({"best": best, "top_rows_written": min(20, len(rows))}, indent=2))
```


## sharded_pipeline / `scripts/run_part_03_cached_decode.py`

```text
0001: #!/usr/bin/env python3
0002: import argparse, json, sys, time
0003: from pathlib import Path
0004: sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
0005: from odyssey_v39_pipeline.numeric_models import Config, TinyV39Independent, TinyTransformerKV, make_tokens, pseudo_loss
0006: from odyssey_v39_pipeline.csv_utils import append_csv
0007: 
0008: ap = argparse.ArgumentParser()
0009: ap.add_argument("--contexts", default="8,16")
0010: ap.add_argument("--seeds", default="1")
0011: ap.add_argument("--batch", type=int, default=2)
0012: 
0013: ap.add_argument("--smoke", action="store_true")
0014: ap.add_argument("--hidden", type=int, default=8)
0015: ap.add_argument("--states", type=int, default=3)
0016: ap.add_argument("--rank", type=int, default=4)
0017: ap.add_argument("--intermediate", type=int, default=32)
0018: 
0019: args = ap.parse_args()
0020: contexts = [4] if args.smoke else [int(x) for x in args.contexts.split(",") if x]
0021: seeds = [1] if args.smoke else [int(x) for x in args.seeds.split(",") if x]
0022: 
0023: out = Path(__file__).resolve().parents[1] / "results" / "cached_decode.csv"
0024: rows=[]
0025: for seed in seeds:
0026:     for ctx in contexts:
0027:         cfg = Config(hidden=args.hidden, states=args.states, rank=args.rank, intermediate=args.intermediate, max_pos=max(64, ctx+4))
0028:         toks = make_tokens(args.batch, ctx, cfg.vocab, seed+200)
0029:         v39 = TinyV39Independent(cfg, seed=seed)
0030:         tr = TinyTransformerKV(cfg, seed=seed)
0031:         t0=time.perf_counter(); vlogits, vcache = v39.forward_cached(toks, top_k=1, use_tsc=False); vt=time.perf_counter()-t0
0032:         t0=time.perf_counter(); tlogits, tcache = tr.forward_cached(toks); tt=time.perf_counter()-t0
0033:         row = {
0034:             "seed": seed,
0035:             "context": ctx,
0036:             "batch": args.batch,
0037:             "v39_seconds": vt,
0038:             "transformer_kv_seconds": tt,
0039:             "v39_tokens_per_sec": args.batch*ctx/max(vt,1e-12),
0040:             "transformer_tokens_per_sec": args.batch*ctx/max(tt,1e-12),
0041:             "v39_speedup_vs_transformer_kv": tt/max(vt,1e-12),
0042:             "v39_cache_elements": vcache.elements(),
0043:             "transformer_kv_elements": tcache.elements(),
0044:             "cache_reduction_percent": 100.0*(1.0 - vcache.elements()/max(tcache.elements(),1)),
0045:             "v39_proxy_loss": pseudo_loss(vlogits, toks),
0046:             "transformer_proxy_loss": pseudo_loss(tlogits, toks),
0047:             "v39_params": v39.params(),
0048:             "transformer_params": tr.params(),
0049:         }
0050:         append_csv(out,row); rows.append(row)
0051: print(json.dumps({"rows": rows}, indent=2))
```


## sharded_pipeline / `scripts/run_part_04_tiny_training.py`

```text
0001: #!/usr/bin/env python3
0002: import argparse, json, sys, random, math
0003: from pathlib import Path
0004: sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
0005: from odyssey_v39_pipeline.numeric_models import Config, TinyV39Independent, TinyTransformerKV, make_tokens, pseudo_loss
0006: from odyssey_v39_pipeline.csv_utils import append_csv
0007: 
0008: ap = argparse.ArgumentParser()
0009: ap.add_argument("--seeds", default="1")
0010: ap.add_argument("--steps", type=int, default=5)
0011: ap.add_argument("--smoke", action="store_true")
0012: args=ap.parse_args()
0013: seeds=[1] if args.smoke else [int(x) for x in args.seeds.split(",") if x]
0014: steps=2 if args.smoke else args.steps
0015: out=Path(__file__).resolve().parents[1] / "results" / "tiny_training.csv"
0016: 
0017: # Environment-safe proxy training: evaluate multiple random seeds as checkpoints, not gradient training.
0018: # Real PyTorch training remains in the PyTorch package.
0019: rows=[]
0020: for seed in seeds:
0021:     cfg=Config()
0022:     toks=make_tokens(2,8,cfg.vocab,seed+300)
0023:     best_v=None; best_t=None
0024:     for step in range(steps):
0025:         v=TinyV39Independent(cfg,seed=seed+step)
0026:         t=TinyTransformerKV(cfg,seed=seed+step)
0027:         vlogits,_=v.forward_cached(toks,top_k=2,use_tsc=True)
0028:         tlogits,_=t.forward_cached(toks)
0029:         vl=pseudo_loss(vlogits,toks); tl=pseudo_loss(tlogits,toks)
0030:         best_v=vl if best_v is None else min(best_v,vl)
0031:         best_t=tl if best_t is None else min(best_t,tl)
0032:         row={"seed":seed,"step":step,"v39_proxy_loss":vl,"transformer_proxy_loss":tl,"best_v39_proxy_loss":best_v,"best_transformer_proxy_loss":best_t}
0033:         append_csv(out,row); rows.append(row)
0034: print(json.dumps({"note":"proxy table only; real gradient training should be run in PyTorch package","rows":rows},indent=2))
```


## sharded_pipeline / `scripts/run_part_05_pytorch_gradient_training.py`

```text
0001: #!/usr/bin/env python3
0002: import argparse, csv, json, os, sys, time
0003: from pathlib import Path
0004: 
0005: ap = argparse.ArgumentParser()
0006: ap.add_argument("--seed", type=int, default=1)
0007: ap.add_argument("--steps", type=int, default=3)
0008: ap.add_argument("--batch", type=int, default=2)
0009: ap.add_argument("--seq", type=int, default=8)
0010: ap.add_argument("--hidden", type=int, default=8)
0011: ap.add_argument("--states", type=int, default=3)
0012: ap.add_argument("--rank", type=int, default=4)
0013: ap.add_argument("--intermediate", type=int, default=32)
0014: ap.add_argument("--smoke", action="store_true")
0015: args = ap.parse_args()
0016: if args.smoke:
0017:     args.steps, args.batch, args.seq = 1, 1, 6
0018: 
0019: try:
0020:     import torch
0021:     import torch.nn as nn
0022:     import torch.nn.functional as F
0023: except Exception as e:
0024:     print(json.dumps({"passed": False, "error": "torch_import_failed", "detail": repr(e)}, indent=2))
0025:     raise SystemExit(0)
0026: 
0027: torch.manual_seed(args.seed)
0028: 
0029: class TinyV39(nn.Module):
0030:     def __init__(self, vocab=32, hidden=8, states=3, rank=4, inter=32, max_pos=64):
0031:         super().__init__()
0032:         self.vocab, self.hidden, self.states, self.rank = vocab, hidden, states, rank
0033:         self.emb = nn.Embedding(vocab, hidden)
0034:         self.pos = nn.Embedding(max_pos, hidden)
0035:         self.norm = nn.LayerNorm(hidden)
0036:         self.route = nn.Linear(hidden, states, bias=False)
0037:         self.to_rank = nn.Linear(hidden, rank, bias=False)
0038:         self.from_state = nn.Linear(states * rank, hidden, bias=False)
0039:         self.mlp = nn.Sequential(nn.LayerNorm(hidden), nn.Linear(hidden, inter), nn.SiLU(), nn.Linear(inter, hidden))
0040:         self.head = nn.Linear(hidden, vocab, bias=False)
0041: 
0042:     def forward(self, x):
0043:         B, T = x.shape
0044:         state = x.new_zeros((B, self.states, self.rank), dtype=self.emb.weight.dtype)
0045:         weight = x.new_zeros((B, self.states), dtype=self.emb.weight.dtype)
0046:         outs = []
0047:         for t in range(T):
0048:             h = self.emb(x[:, t]) + self.pos(torch.full((B,), t, device=x.device, dtype=torch.long))
0049:             hn = self.norm(h)
0050:             probs = torch.softmax(self.route(hn), dim=-1)
0051:             vals, ids = torch.topk(probs, k=2, dim=-1)
0052:             vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0053:             z = self.to_rank(hn)
0054:             bi = torch.arange(B, device=x.device)
0055:             for j in range(2):
0056:                 sid = ids[:, j]
0057:                 w = vals[:, j]
0058:                 old_w = weight[bi, sid]
0059:                 new_w = old_w + w
0060:                 old = state[bi, sid]
0061:                 state[bi, sid] = (old * old_w[:, None] + z * w[:, None]) / new_w[:, None].clamp_min(1e-8)
0062:                 weight[bi, sid] = new_w
0063:             flat = (state * weight[:, :, None] / weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)[:, :, None]).reshape(B, self.states * self.rank)
0064:             h = h + self.from_state(flat)
0065:             h = h + self.mlp(h)
0066:             outs.append(self.head(h)[:, None, :])
0067:         return torch.cat(outs, dim=1)
0068: 
0069: class TinyTransformer(nn.Module):
0070:     def __init__(self, vocab=32, hidden=8, inter=32, max_pos=64):
0071:         super().__init__()
0072:         self.emb = nn.Embedding(vocab, hidden)
0073:         self.pos = nn.Embedding(max_pos, hidden)
0074:         self.norm1 = nn.LayerNorm(hidden)
0075:         self.attn = nn.MultiheadAttention(hidden, num_heads=1, batch_first=True)
0076:         self.norm2 = nn.LayerNorm(hidden)
0077:         self.mlp = nn.Sequential(nn.Linear(hidden, inter), nn.SiLU(), nn.Linear(inter, hidden))
0078:         self.head = nn.Linear(hidden, vocab, bias=False)
0079:     def forward(self, x):
0080:         B,T=x.shape
0081:         pos=torch.arange(T,device=x.device).unsqueeze(0).expand(B,T)
0082:         h=self.emb(x)+self.pos(pos)
0083:         mask=torch.triu(torch.ones(T,T,device=x.device,dtype=torch.bool),diagonal=1)
0084:         q=self.norm1(h)
0085:         y,_=self.attn(q,q,q,attn_mask=mask,need_weights=False)
0086:         h=h+y
0087:         h=h+self.mlp(self.norm2(h))
0088:         return self.head(h)
0089: 
0090: def make_batch(batch, seq, vocab=32):
0091:     x=torch.randint(0,vocab,(batch,seq))
0092:     for t in range(2,seq):
0093:         x[:,t]=(x[:,t-1]+x[:,t-2]+(t%5))%vocab
0094:     return x
0095: 
0096: def train(model):
0097:     opt=torch.optim.AdamW(model.parameters(),lr=3e-3)
0098:     losses=[]
0099:     start=time.perf_counter()
0100:     for _ in range(args.steps):
0101:         x=make_batch(args.batch,args.seq)
0102:         opt.zero_grad(set_to_none=True)
0103:         logits=model(x)
0104:         loss=F.cross_entropy(logits[:,:-1,:].reshape(-1,logits.size(-1)),x[:,1:].reshape(-1))
0105:         loss.backward()
0106:         opt.step()
0107:         losses.append(float(loss.item()))
0108:     return losses, time.perf_counter()-start
0109: 
0110: v39=TinyV39(hidden=args.hidden,states=args.states,rank=args.rank,inter=args.intermediate,max_pos=max(64,args.seq+4))
0111: tr=TinyTransformer(hidden=args.hidden,inter=args.intermediate,max_pos=max(64,args.seq+4))
0112: v_losses,v_time=train(v39)
0113: t_losses,t_time=train(tr)
0114: 
0115: row={
0116:     "seed":args.seed,
0117:     "steps":args.steps,
0118:     "batch":args.batch,
0119:     "seq":args.seq,
0120:     "hidden":args.hidden,
0121:     "states":args.states,
0122:     "rank":args.rank,
0123:     "intermediate":args.intermediate,
0124:     "v39_initial_loss":v_losses[0],
0125:     "v39_final_loss":v_losses[-1],
0126:     "v39_delta":v_losses[0]-v_losses[-1],
0127:     "transformer_initial_loss":t_losses[0],
0128:     "transformer_final_loss":t_losses[-1],
0129:     "transformer_delta":t_losses[0]-t_losses[-1],
0130:     "v39_seconds":v_time,
0131:     "transformer_seconds":t_time,
0132:     "passed":(v_losses[-1] <= v_losses[0] or args.steps == 1) and (t_losses[-1] <= t_losses[0] or args.steps == 1)
0133: }
0134: out=Path(__file__).resolve().parents[1]/"results"/"pytorch_training.csv"
0135: out.parent.mkdir(parents=True,exist_ok=True)
0136: exists=out.exists()
0137: with out.open("a",newline="",encoding="utf-8") as f:
0138:     w=csv.DictWriter(f,fieldnames=list(row.keys()))
0139:     if not exists: w.writeheader()
0140:     w.writerow(row)
0141: print(json.dumps(row,indent=2))
```


## sharded_pipeline / `src/odyssey_v39_pipeline/__init__.py`

```text
0001: from .numeric_models import Config, TinyV39Independent, TinyTransformerKV
```


## sharded_pipeline / `src/odyssey_v39_pipeline/csv_utils.py`

```text
0001: import csv
0002: from pathlib import Path
0003: 
0004: def append_csv(path, row):
0005:     path = Path(path)
0006:     path.parent.mkdir(parents=True, exist_ok=True)
0007:     exists = path.exists()
0008:     with path.open("a", newline="", encoding="utf-8") as f:
0009:         writer = csv.DictWriter(f, fieldnames=list(row.keys()))
0010:         if not exists:
0011:             writer.writeheader()
0012:         writer.writerow(row)
0013: 
0014: def read_csv(path):
0015:     path = Path(path)
0016:     if not path.exists():
0017:         return []
0018:     with path.open("r", newline="", encoding="utf-8") as f:
0019:         return list(csv.DictReader(f))
```


## sharded_pipeline / `src/odyssey_v39_pipeline/numeric_models.py`

```text
0001: import math, random, time
0002: from dataclasses import dataclass
0003: 
0004: @dataclass
0005: class Config:
0006:     vocab: int = 32
0007:     hidden: int = 16
0008:     layers: int = 1
0009:     states: int = 3
0010:     rank: int = 4
0011:     intermediate: int = 32
0012:     max_pos: int = 512
0013: 
0014: def zeros(n):
0015:     return [0.0] * n
0016: 
0017: def rand_vec(rng, n, scale):
0018:     return [(rng.random() * 2.0 - 1.0) * scale for _ in range(n)]
0019: 
0020: def rand_mat(rng, rows, cols, scale):
0021:     return [rand_vec(rng, cols, scale) for _ in range(rows)]
0022: 
0023: def dot(a, b):
0024:     return sum(x*y for x, y in zip(a, b))
0025: 
0026: def add(a, b):
0027:     return [x+y for x,y in zip(a,b)]
0028: 
0029: def scale(a, s):
0030:     return [x*s for x in a]
0031: 
0032: def matvec(W, x):
0033:     return [dot(row, x) for row in W]
0034: 
0035: def softmax(xs):
0036:     m = max(xs)
0037:     ex = [math.exp(x-m) for x in xs]
0038:     s = sum(ex) or 1.0
0039:     return [v/s for v in ex]
0040: 
0041: def layer_norm(x, eps=1e-5):
0042:     m = sum(x)/len(x)
0043:     v = sum((a-m)*(a-m) for a in x)/len(x)
0044:     inv = 1.0 / math.sqrt(v + eps)
0045:     return [(a-m)*inv for a in x]
0046: 
0047: def silu(x):
0048:     return x / (1.0 + math.exp(-x))
0049: 
0050: def max_abs_nested(a, b):
0051:     if isinstance(a, list) and a and isinstance(a[0], list):
0052:         return max(max_abs_nested(x, y) for x, y in zip(a, b))
0053:     return max(abs(x-y) for x,y in zip(a,b)) if a else 0.0
0054: 
0055: def make_tokens(batch, length, vocab, seed):
0056:     rng = random.Random(seed)
0057:     x = [[rng.randrange(vocab) for _ in range(length)] for _ in range(batch)]
0058:     for row in x:
0059:         for t in range(2, length):
0060:             row[t] = (row[t-1] + row[t-2] + (t % 5)) % vocab
0061:     return x
0062: 
0063: class V39Cache:
0064:     def __init__(self, cfg, batch):
0065:         self.cfg = cfg
0066:         self.batch = batch
0067:         self.summary = [[[[0.0 for _ in range(cfg.rank)] for _ in range(cfg.states)] for _ in range(cfg.layers)] for _ in range(batch)]
0068:         self.weight = [[[0.0 for _ in range(cfg.states)] for _ in range(cfg.layers)] for _ in range(batch)]
0069:         self.position = 0
0070:     def elements(self):
0071:         return self.batch*self.cfg.layers*self.cfg.states*self.cfg.rank + self.batch*self.cfg.layers*self.cfg.states
0072:     def reset(self):
0073:         for b in range(self.batch):
0074:             for l in range(self.cfg.layers):
0075:                 for s in range(self.cfg.states):
0076:                     self.weight[b][l][s] = 0.0
0077:                     for r in range(self.cfg.rank):
0078:                         self.summary[b][l][s][r] = 0.0
0079:         self.position = 0
0080: 
0081: class TinyV39Independent:
0082:     def __init__(self, cfg, seed=0):
0083:         self.cfg = cfg
0084:         rng = random.Random(seed)
0085:         V,H,L,S,R,I = cfg.vocab,cfg.hidden,cfg.layers,cfg.states,cfg.rank,cfg.intermediate
0086:         self.emb = rand_mat(rng, V, H, 0.2)
0087:         self.pos = rand_mat(rng, cfg.max_pos, H, 0.05)
0088:         self.route = [[rand_vec(rng, H, 0.08) for _ in range(S)] for _ in range(L)]
0089:         self.to_rank = [rand_mat(rng, R, H, 0.08) for _ in range(L)]
0090:         self.from_state = [rand_mat(rng, H, S*R, 0.08) for _ in range(L)]
0091:         self.tsc = [rand_mat(rng, H, H, 0.03) for _ in range(L)]
0092:         self.mlp1 = [rand_mat(rng, I, H, 0.06) for _ in range(L)]
0093:         self.mlp2 = [rand_mat(rng, H, I, 0.06) for _ in range(L)]
0094:         self.head = rand_mat(rng, V, H, 0.08)
0095: 
0096:     def token_hidden(self, tok, pos):
0097:         return add(self.emb[tok], self.pos[pos])
0098: 
0099:     def layer_step(self, x, cache, b, li, top_k=1, use_tsc=True):
0100:         cfg = self.cfg
0101:         xn = layer_norm(x)
0102:         probs = softmax([dot(self.route[li][s], xn) for s in range(cfg.states)])
0103:         ids = sorted(range(cfg.states), key=lambda i: probs[i], reverse=True)[:top_k]
0104:         vals = [probs[i] for i in ids]
0105:         denom = sum(vals) or 1.0
0106:         vals = [v/denom for v in vals]
0107:         z = matvec(self.to_rank[li], xn)
0108:         for sid, w in zip(ids, vals):
0109:             old_w = cache.weight[b][li][sid]
0110:             new_w = old_w + w
0111:             old = cache.summary[b][li][sid]
0112:             cache.summary[b][li][sid] = [(old[r]*old_w + z[r]*w)/max(new_w,1e-8) for r in range(cfg.rank)]
0113:             cache.weight[b][li][sid] = new_w
0114:         flat = []
0115:         total_w = max(sum(cache.weight[b][li]), 1e-8)
0116:         for s in range(cfg.states):
0117:             sw = cache.weight[b][li][s] / total_w
0118:             flat.extend([v * sw for v in cache.summary[b][li][s]])
0119:         y = add(x, matvec(self.from_state[li], flat))
0120:         if use_tsc:
0121:             y = add(y, scale(matvec(self.tsc[li], layer_norm(y)), 0.10))
0122:         h1 = [silu(v) for v in matvec(self.mlp1[li], layer_norm(y))]
0123:         y = add(y, matvec(self.mlp2[li], h1))
0124:         return y
0125: 
0126:     def decode_step(self, toks, cache, top_k=1, use_tsc=True):
0127:         logits = []
0128:         for b,tok in enumerate(toks):
0129:             x = self.token_hidden(tok, cache.position)
0130:             for li in range(self.cfg.layers):
0131:                 x = self.layer_step(x, cache, b, li, top_k=top_k, use_tsc=use_tsc)
0132:             logits.append(matvec(self.head, layer_norm(x)))
0133:         cache.position += 1
0134:         return logits, cache
0135: 
0136:     def forward_cached(self, batch_tokens, top_k=2, use_tsc=True):
0137:         B,T = len(batch_tokens), len(batch_tokens[0])
0138:         cache = V39Cache(self.cfg, B)
0139:         outs = []
0140:         for t in range(T):
0141:             logits, cache = self.decode_step([batch_tokens[b][t] for b in range(B)], cache, top_k=top_k, use_tsc=use_tsc)
0142:             outs.append(logits)
0143:         return [[outs[t][b] for t in range(T)] for b in range(B)], cache
0144: 
0145:     def forward_full_independent(self, batch_tokens, top_k=2, use_tsc=True):
0146:         # Independent implementation: local arrays, no decode_step call.
0147:         B,T = len(batch_tokens), len(batch_tokens[0])
0148:         cfg = self.cfg
0149:         summary = [[[[0.0 for _ in range(cfg.rank)] for _ in range(cfg.states)] for _ in range(cfg.layers)] for _ in range(B)]
0150:         weight = [[[0.0 for _ in range(cfg.states)] for _ in range(cfg.layers)] for _ in range(B)]
... truncated after 150 of 262 lines ...
```


## seed_training / `README.md`

```text
0001: # Odyssey V39 seed-by-seed training results\n\n3 seeds were run one at a time. CUDA unlock here means only CUDA top-1 decode parity harness may start, not optimized CUDA claims.\n
```


## seed_training / `all_seed_summary.json`

```text
0001: {
0002:   "seeds_found": 3,
0003:   "all_seeds_complete": true,
0004:   "all_v39_train_reduced": true,
0005:   "all_v39_val_not_blowup": true,
0006:   "all_transformer_train_reduced": true,
0007:   "all_transformer_val_not_blowup": true,
0008:   "v39_train_delta_mean": 0.17383305231730142,
0009:   "v39_val_delta_mean": 0.01929783821105957,
0010:   "transformer_train_delta_mean": 0.20308883984883627,
0011:   "transformer_val_delta_mean": 0.027557373046875,
0012:   "v39_final_train_loss_mean": 3.551933447519938,
0013:   "transformer_final_train_loss_mean": 3.7313548723856607,
0014:   "seed_summaries": [
0015:     {
0016:       "seed": 1,
0017:       "device": "cpu",
0018:       "steps": 12,
0019:       "batch": 2,
0020:       "seq": 8,
0021:       "lr": 0.0008,
0022:       "v39_params": 1840,
0023:       "transformer_params": 1896,
0024:       "v39_train_initial": 3.584461212158203,
0025:       "v39_train_final": 3.40412974357605,
0026:       "v39_train_delta": 0.18033146858215332,
0027:       "v39_val_initial": 3.977552652359009,
0028:       "v39_val_final": 3.972757577896118,
0029:       "v39_val_delta": 0.004795074462890625,
0030:       "transformer_train_initial": 4.25401496887207,
0031:       "transformer_train_final": 4.037497520446777,
0032:       "transformer_train_delta": 0.21651744842529297,
0033:       "transformer_val_initial": 3.463948965072632,
0034:       "transformer_val_final": 3.444777727127075,
0035:       "transformer_val_delta": 0.01917123794555664,
0036:       "v39_seconds": 0.41097337799965317,
0037:       "transformer_seconds": 0.0667955550006809,
0038:       "v39_train_curve": "[3.584461212158203, 3.567739248275757, 3.5510876178741455, 3.534505844116211, 3.517991304397583, 3.501542568206787, 3.4851572513580322, 3.468834638595581, 3.452573299407959, 3.4363701343536377, 3.4202232360839844, 3.40412974357605]",
0039:       "v39_val_curve": "[3.977552652359009, 3.976956844329834, 3.976388692855835, 3.9758570194244385, 3.975362777709961, 3.9749011993408203, 3.9744701385498047, 3.9740660190582275, 3.9736921787261963, 3.973349094390869, 3.9730377197265625, 3.972757577896118]",
0040:       "transformer_train_curve": "[4.25401496887207, 4.233323097229004, 4.2128496170043945, 4.192587852478027, 4.1725358963012695, 4.152688026428223, 4.13303804397583, 4.113579750061035, 4.094305515289307, 4.075205326080322, 4.056272029876709, 4.037497520446777]",
0041:       "transformer_val_curve": "[3.463948965072632, 3.4618213176727295, 3.4598023891448975, 3.4578778743743896, 3.456023931503296, 3.454224109649658, 3.452479839324951, 3.4507997035980225, 3.4491868019104004, 3.447646379470825, 3.4461772441864014, 3.444777727127075]",
0042:       "v39_train_reduced": true,
0043:       "v39_val_not_blowup": true,
0044:       "transformer_train_reduced": true,
0045:       "transformer_val_not_blowup": true
0046:     },
0047:     {
0048:       "seed": 2,
0049:       "device": "cpu",
0050:       "steps": 12,
0051:       "batch": 2,
0052:       "seq": 8,
0053:       "lr": 0.0008,
0054:       "v39_params": 1840,
0055:       "transformer_params": 1896,
0056:       "v39_train_initial": 3.913080930709839,
0057:       "v39_train_final": 3.736877202987671,
0058:       "v39_train_delta": 0.17620372772216797,
0059:       "v39_val_initial": 3.478020191192627,
0060:       "v39_val_final": 3.457561492919922,
0061:       "v39_val_delta": 0.020458698272705078,
0062:       "transformer_train_initial": 3.6628963947296143,
0063:       "transformer_train_final": 3.457693576812744,
0064:       "transformer_train_delta": 0.20520281791687012,
0065:       "transformer_val_initial": 3.9947760105133057,
0066:       "transformer_val_final": 3.981433153152466,
0067:       "transformer_val_delta": 0.013342857360839844,
0068:       "v39_seconds": 0.423697496999921,
0069:       "transformer_seconds": 0.06864240100003371,
0070:       "v39_train_curve": "[3.913080930709839, 3.8965141773223877, 3.880068063735962, 3.8637375831604004, 3.8475191593170166, 3.8314096927642822, 3.815406084060669, 3.7995052337646484, 3.783704996109009, 3.7680020332336426, 3.752394437789917, 3.736877202987671]",
0071:       "v39_val_curve": "[3.478020191192627, 3.475933313369751, 3.4738800525665283, 3.471869707107544, 3.469907522201538, 3.4679927825927734, 3.4661223888397217, 3.4643003940582275, 3.4625306129455566, 3.4608166217803955, 3.459160327911377, 3.457561492919922]",
0072:       "transformer_train_curve": "[3.6628963947296143, 3.6435840129852295, 3.6244149208068848, 3.60538649559021, 3.586493968963623, 3.5677337646484375, 3.5491020679473877, 3.5305936336517334, 3.51220440864563, 3.4939277172088623, 3.475759506225586, 3.457693576812744]",
0073:       "transformer_val_curve": "[3.9947760105133057, 3.9929163455963135, 3.991234064102173, 3.9897196292877197, 3.988337278366089, 3.9870686531066895, 3.985902786254883, 3.984833240509033, 3.9838550090789795, 3.9829635620117188, 3.982156991958618, 3.981433153152466]",
0074:       "v39_train_reduced": true,
0075:       "v39_val_not_blowup": true,
0076:       "transformer_train_reduced": true,
0077:       "transformer_val_not_blowup": true
0078:     },
0079:     {
0080:       "seed": 3,
0081:       "device": "cpu",
0082:       "steps": 12,
0083:       "batch": 2,
0084:       "seq": 8,
0085:       "lr": 0.0008,
0086:       "v39_params": 1840,
0087:       "transformer_params": 1896,
0088:       "v39_train_initial": 3.6797573566436768,
0089:       "v39_train_final": 3.5147933959960938,
0090:       "v39_train_delta": 0.164963960647583,
0091:       "v39_val_initial": 3.7610175609588623,
0092:       "v39_val_final": 3.7283778190612793,
0093:       "v39_val_delta": 0.03263974189758301,
0094:       "transformer_train_initial": 3.8864197731018066,
0095:       "transformer_train_final": 3.698873519897461,
0096:       "transformer_train_delta": 0.1875462532043457,
0097:       "transformer_val_initial": 4.096780300140381,
0098:       "transformer_val_final": 4.046622276306152,
0099:       "transformer_val_delta": 0.050158023834228516,
0100:       "v39_seconds": 0.48845395100033784,
0101:       "transformer_seconds": 0.06809510000039154,
0102:       "v39_train_curve": "[3.6797573566436768, 3.664783477783203, 3.649845838546753, 3.6349427700042725, 3.6200735569000244, 3.605236768722534, 3.590430736541748, 3.575653553009033, 3.560904026031494, 3.5461812019348145, 3.531482219696045, 3.5147933959960938]",
0103:       "v39_val_curve": "[3.7610175609588623, 3.757845640182495, 3.754704713821411, 3.751605272293091, 3.748554229736328, 3.745551586151123, 3.742591619491577, 3.739673614501953, 3.7367947101593018, 3.7339537143707275, 3.7311532497406006, 3.7283778190612793]",
0104:       "transformer_train_curve": "[3.8864197731018066, 3.8689181804656982, 3.8515191078186035, 3.834217071533203, 3.8170087337493896, 3.7998902797698975, 3.78285813331604, 3.7659103870391846, 3.749041795730591, 3.7322490215301514, 3.7155280113220215, 3.698873519897461]",
0105:       "transformer_val_curve": "[4.096780300140381, 4.091611385345459, 4.08658504486084, 4.081721782684326, 4.077001571655273, 4.072394847869873, 4.067887783050537, 4.063471794128418, 4.059140682220459, 4.054891109466553, 4.050719738006592, 4.046622276306152]",
0106:       "v39_train_reduced": true,
0107:       "v39_val_not_blowup": true,
0108:       "transformer_train_reduced": true,
0109:       "transformer_val_not_blowup": true
0110:     }
0111:   ],
0112:   "cuda_unlocked": true,
0113:   "cuda_gate": "unlocked_for_top1_decode_parity_harness_only"
0114: }
```


## seed_training / `all_seed_training.csv`

```text
0001: seed,device,steps,batch,seq,lr,v39_params,transformer_params,v39_train_initial,v39_train_final,v39_train_delta,v39_val_initial,v39_val_final,v39_val_delta,transformer_train_initial,transformer_train_final,transformer_train_delta,transformer_val_initial,transformer_val_final,transformer_val_delta,v39_seconds,transformer_seconds,v39_train_curve,v39_val_curve,transformer_train_curve,transformer_val_curve,v39_train_reduced,v39_val_not_blowup,transformer_train_reduced,transformer_val_not_blowup
0002: 1,cpu,12,2,8,0.0008,1840,1896,3.584461212158203,3.40412974357605,0.18033146858215332,3.977552652359009,3.972757577896118,0.004795074462890625,4.25401496887207,4.037497520446777,0.21651744842529297,3.463948965072632,3.444777727127075,0.01917123794555664,0.41097337799965317,0.0667955550006809,"[3.584461212158203, 3.567739248275757, 3.5510876178741455, 3.534505844116211, 3.517991304397583, 3.501542568206787, 3.4851572513580322, 3.468834638595581, 3.452573299407959, 3.4363701343536377, 3.4202232360839844, 3.40412974357605]","[3.977552652359009, 3.976956844329834, 3.976388692855835, 3.9758570194244385, 3.975362777709961, 3.9749011993408203, 3.9744701385498047, 3.9740660190582275, 3.9736921787261963, 3.973349094390869, 3.9730377197265625, 3.972757577896118]","[4.25401496887207, 4.233323097229004, 4.2128496170043945, 4.192587852478027, 4.1725358963012695, 4.152688026428223, 4.13303804397583, 4.113579750061035, 4.094305515289307, 4.075205326080322, 4.056272029876709, 4.037497520446777]","[3.463948965072632, 3.4618213176727295, 3.4598023891448975, 3.4578778743743896, 3.456023931503296, 3.454224109649658, 3.452479839324951, 3.4507997035980225, 3.4491868019104004, 3.447646379470825, 3.4461772441864014, 3.444777727127075]",True,True,True,True
0003: 2,cpu,12,2,8,0.0008,1840,1896,3.913080930709839,3.736877202987671,0.17620372772216797,3.478020191192627,3.457561492919922,0.020458698272705078,3.6628963947296143,3.457693576812744,0.20520281791687012,3.9947760105133057,3.981433153152466,0.013342857360839844,0.423697496999921,0.06864240100003371,"[3.913080930709839, 3.8965141773223877, 3.880068063735962, 3.8637375831604004, 3.8475191593170166, 3.8314096927642822, 3.815406084060669, 3.7995052337646484, 3.783704996109009, 3.7680020332336426, 3.752394437789917, 3.736877202987671]","[3.478020191192627, 3.475933313369751, 3.4738800525665283, 3.471869707107544, 3.469907522201538, 3.4679927825927734, 3.4661223888397217, 3.4643003940582275, 3.4625306129455566, 3.4608166217803955, 3.459160327911377, 3.457561492919922]","[3.6628963947296143, 3.6435840129852295, 3.6244149208068848, 3.60538649559021, 3.586493968963623, 3.5677337646484375, 3.5491020679473877, 3.5305936336517334, 3.51220440864563, 3.4939277172088623, 3.475759506225586, 3.457693576812744]","[3.9947760105133057, 3.9929163455963135, 3.991234064102173, 3.9897196292877197, 3.988337278366089, 3.9870686531066895, 3.985902786254883, 3.984833240509033, 3.9838550090789795, 3.9829635620117188, 3.982156991958618, 3.981433153152466]",True,True,True,True
0004: 3,cpu,12,2,8,0.0008,1840,1896,3.6797573566436768,3.5147933959960938,0.164963960647583,3.7610175609588623,3.7283778190612793,0.03263974189758301,3.8864197731018066,3.698873519897461,0.1875462532043457,4.096780300140381,4.046622276306152,0.050158023834228516,0.48845395100033784,0.06809510000039154,"[3.6797573566436768, 3.664783477783203, 3.649845838546753, 3.6349427700042725, 3.6200735569000244, 3.605236768722534, 3.590430736541748, 3.575653553009033, 3.560904026031494, 3.5461812019348145, 3.531482219696045, 3.5147933959960938]","[3.7610175609588623, 3.757845640182495, 3.754704713821411, 3.751605272293091, 3.748554229736328, 3.745551586151123, 3.742591619491577, 3.739673614501953, 3.7367947101593018, 3.7339537143707275, 3.7311532497406006, 3.7283778190612793]","[3.8864197731018066, 3.8689181804656982, 3.8515191078186035, 3.834217071533203, 3.8170087337493896, 3.7998902797698975, 3.78285813331604, 3.7659103870391846, 3.749041795730591, 3.7322490215301514, 3.7155280113220215, 3.698873519897461]","[4.096780300140381, 4.091611385345459, 4.08658504486084, 4.081721782684326, 4.077001571655273, 4.072394847869873, 4.067887783050537, 4.063471794128418, 4.059140682220459, 4.054891109466553, 4.050719738006592, 4.046622276306152]",True,True,True,True
```


## seed_training / `seed_results/seed_1/seed_summary.csv`

```text
0001: seed,device,steps,batch,seq,lr,v39_params,transformer_params,v39_train_initial,v39_train_final,v39_train_delta,v39_val_initial,v39_val_final,v39_val_delta,transformer_train_initial,transformer_train_final,transformer_train_delta,transformer_val_initial,transformer_val_final,transformer_val_delta,v39_seconds,transformer_seconds,v39_train_curve,v39_val_curve,transformer_train_curve,transformer_val_curve,v39_train_reduced,v39_val_not_blowup,transformer_train_reduced,transformer_val_not_blowup
0002: 1,cpu,12,2,8,0.0008,1840,1896,3.584461212158203,3.40412974357605,0.18033146858215332,3.977552652359009,3.972757577896118,0.004795074462890625,4.25401496887207,4.037497520446777,0.21651744842529297,3.463948965072632,3.444777727127075,0.01917123794555664,0.41097337799965317,0.0667955550006809,"[3.584461212158203, 3.567739248275757, 3.5510876178741455, 3.534505844116211, 3.517991304397583, 3.501542568206787, 3.4851572513580322, 3.468834638595581, 3.452573299407959, 3.4363701343536377, 3.4202232360839844, 3.40412974357605]","[3.977552652359009, 3.976956844329834, 3.976388692855835, 3.9758570194244385, 3.975362777709961, 3.9749011993408203, 3.9744701385498047, 3.9740660190582275, 3.9736921787261963, 3.973349094390869, 3.9730377197265625, 3.972757577896118]","[4.25401496887207, 4.233323097229004, 4.2128496170043945, 4.192587852478027, 4.1725358963012695, 4.152688026428223, 4.13303804397583, 4.113579750061035, 4.094305515289307, 4.075205326080322, 4.056272029876709, 4.037497520446777]","[3.463948965072632, 3.4618213176727295, 3.4598023891448975, 3.4578778743743896, 3.456023931503296, 3.454224109649658, 3.452479839324951, 3.4507997035980225, 3.4491868019104004, 3.447646379470825, 3.4461772441864014, 3.444777727127075]",True,True,True,True
```


## seed_training / `seed_results/seed_1/seed_summary.json`

```text
0001: {
0002:   "seed": 1,
0003:   "device": "cpu",
0004:   "steps": 12,
0005:   "batch": 2,
0006:   "seq": 8,
0007:   "lr": 0.0008,
0008:   "v39_params": 1840,
0009:   "transformer_params": 1896,
0010:   "v39_train_initial": 3.584461212158203,
0011:   "v39_train_final": 3.40412974357605,
0012:   "v39_train_delta": 0.18033146858215332,
0013:   "v39_val_initial": 3.977552652359009,
0014:   "v39_val_final": 3.972757577896118,
0015:   "v39_val_delta": 0.004795074462890625,
0016:   "transformer_train_initial": 4.25401496887207,
0017:   "transformer_train_final": 4.037497520446777,
0018:   "transformer_train_delta": 0.21651744842529297,
0019:   "transformer_val_initial": 3.463948965072632,
0020:   "transformer_val_final": 3.444777727127075,
0021:   "transformer_val_delta": 0.01917123794555664,
0022:   "v39_seconds": 0.41097337799965317,
0023:   "transformer_seconds": 0.0667955550006809,
0024:   "v39_train_curve": "[3.584461212158203, 3.567739248275757, 3.5510876178741455, 3.534505844116211, 3.517991304397583, 3.501542568206787, 3.4851572513580322, 3.468834638595581, 3.452573299407959, 3.4363701343536377, 3.4202232360839844, 3.40412974357605]",
0025:   "v39_val_curve": "[3.977552652359009, 3.976956844329834, 3.976388692855835, 3.9758570194244385, 3.975362777709961, 3.9749011993408203, 3.9744701385498047, 3.9740660190582275, 3.9736921787261963, 3.973349094390869, 3.9730377197265625, 3.972757577896118]",
0026:   "transformer_train_curve": "[4.25401496887207, 4.233323097229004, 4.2128496170043945, 4.192587852478027, 4.1725358963012695, 4.152688026428223, 4.13303804397583, 4.113579750061035, 4.094305515289307, 4.075205326080322, 4.056272029876709, 4.037497520446777]",
0027:   "transformer_val_curve": "[3.463948965072632, 3.4618213176727295, 3.4598023891448975, 3.4578778743743896, 3.456023931503296, 3.454224109649658, 3.452479839324951, 3.4507997035980225, 3.4491868019104004, 3.447646379470825, 3.4461772441864014, 3.444777727127075]",
0028:   "v39_train_reduced": true,
0029:   "v39_val_not_blowup": true,
0030:   "transformer_train_reduced": true,
0031:   "transformer_val_not_blowup": true
0032: }
```


## seed_training / `seed_results/seed_2/seed_summary.csv`

```text
0001: seed,device,steps,batch,seq,lr,v39_params,transformer_params,v39_train_initial,v39_train_final,v39_train_delta,v39_val_initial,v39_val_final,v39_val_delta,transformer_train_initial,transformer_train_final,transformer_train_delta,transformer_val_initial,transformer_val_final,transformer_val_delta,v39_seconds,transformer_seconds,v39_train_curve,v39_val_curve,transformer_train_curve,transformer_val_curve,v39_train_reduced,v39_val_not_blowup,transformer_train_reduced,transformer_val_not_blowup
0002: 2,cpu,12,2,8,0.0008,1840,1896,3.913080930709839,3.736877202987671,0.17620372772216797,3.478020191192627,3.457561492919922,0.020458698272705078,3.6628963947296143,3.457693576812744,0.20520281791687012,3.9947760105133057,3.981433153152466,0.013342857360839844,0.423697496999921,0.06864240100003371,"[3.913080930709839, 3.8965141773223877, 3.880068063735962, 3.8637375831604004, 3.8475191593170166, 3.8314096927642822, 3.815406084060669, 3.7995052337646484, 3.783704996109009, 3.7680020332336426, 3.752394437789917, 3.736877202987671]","[3.478020191192627, 3.475933313369751, 3.4738800525665283, 3.471869707107544, 3.469907522201538, 3.4679927825927734, 3.4661223888397217, 3.4643003940582275, 3.4625306129455566, 3.4608166217803955, 3.459160327911377, 3.457561492919922]","[3.6628963947296143, 3.6435840129852295, 3.6244149208068848, 3.60538649559021, 3.586493968963623, 3.5677337646484375, 3.5491020679473877, 3.5305936336517334, 3.51220440864563, 3.4939277172088623, 3.475759506225586, 3.457693576812744]","[3.9947760105133057, 3.9929163455963135, 3.991234064102173, 3.9897196292877197, 3.988337278366089, 3.9870686531066895, 3.985902786254883, 3.984833240509033, 3.9838550090789795, 3.9829635620117188, 3.982156991958618, 3.981433153152466]",True,True,True,True
```


## seed_training / `seed_results/seed_2/seed_summary.json`

```text
0001: {
0002:   "seed": 2,
0003:   "device": "cpu",
0004:   "steps": 12,
0005:   "batch": 2,
0006:   "seq": 8,
0007:   "lr": 0.0008,
0008:   "v39_params": 1840,
0009:   "transformer_params": 1896,
0010:   "v39_train_initial": 3.913080930709839,
0011:   "v39_train_final": 3.736877202987671,
0012:   "v39_train_delta": 0.17620372772216797,
0013:   "v39_val_initial": 3.478020191192627,
0014:   "v39_val_final": 3.457561492919922,
0015:   "v39_val_delta": 0.020458698272705078,
0016:   "transformer_train_initial": 3.6628963947296143,
0017:   "transformer_train_final": 3.457693576812744,
0018:   "transformer_train_delta": 0.20520281791687012,
0019:   "transformer_val_initial": 3.9947760105133057,
0020:   "transformer_val_final": 3.981433153152466,
0021:   "transformer_val_delta": 0.013342857360839844,
0022:   "v39_seconds": 0.423697496999921,
0023:   "transformer_seconds": 0.06864240100003371,
0024:   "v39_train_curve": "[3.913080930709839, 3.8965141773223877, 3.880068063735962, 3.8637375831604004, 3.8475191593170166, 3.8314096927642822, 3.815406084060669, 3.7995052337646484, 3.783704996109009, 3.7680020332336426, 3.752394437789917, 3.736877202987671]",
0025:   "v39_val_curve": "[3.478020191192627, 3.475933313369751, 3.4738800525665283, 3.471869707107544, 3.469907522201538, 3.4679927825927734, 3.4661223888397217, 3.4643003940582275, 3.4625306129455566, 3.4608166217803955, 3.459160327911377, 3.457561492919922]",
0026:   "transformer_train_curve": "[3.6628963947296143, 3.6435840129852295, 3.6244149208068848, 3.60538649559021, 3.586493968963623, 3.5677337646484375, 3.5491020679473877, 3.5305936336517334, 3.51220440864563, 3.4939277172088623, 3.475759506225586, 3.457693576812744]",
0027:   "transformer_val_curve": "[3.9947760105133057, 3.9929163455963135, 3.991234064102173, 3.9897196292877197, 3.988337278366089, 3.9870686531066895, 3.985902786254883, 3.984833240509033, 3.9838550090789795, 3.9829635620117188, 3.982156991958618, 3.981433153152466]",
0028:   "v39_train_reduced": true,
0029:   "v39_val_not_blowup": true,
0030:   "transformer_train_reduced": true,
0031:   "transformer_val_not_blowup": true
0032: }
```


## seed_training / `seed_results/seed_3/seed_summary.csv`

```text
0001: seed,device,steps,batch,seq,lr,v39_params,transformer_params,v39_train_initial,v39_train_final,v39_train_delta,v39_val_initial,v39_val_final,v39_val_delta,transformer_train_initial,transformer_train_final,transformer_train_delta,transformer_val_initial,transformer_val_final,transformer_val_delta,v39_seconds,transformer_seconds,v39_train_curve,v39_val_curve,transformer_train_curve,transformer_val_curve,v39_train_reduced,v39_val_not_blowup,transformer_train_reduced,transformer_val_not_blowup
0002: 3,cpu,12,2,8,0.0008,1840,1896,3.6797573566436768,3.5147933959960938,0.164963960647583,3.7610175609588623,3.7283778190612793,0.03263974189758301,3.8864197731018066,3.698873519897461,0.1875462532043457,4.096780300140381,4.046622276306152,0.050158023834228516,0.48845395100033784,0.06809510000039154,"[3.6797573566436768, 3.664783477783203, 3.649845838546753, 3.6349427700042725, 3.6200735569000244, 3.605236768722534, 3.590430736541748, 3.575653553009033, 3.560904026031494, 3.5461812019348145, 3.531482219696045, 3.5147933959960938]","[3.7610175609588623, 3.757845640182495, 3.754704713821411, 3.751605272293091, 3.748554229736328, 3.745551586151123, 3.742591619491577, 3.739673614501953, 3.7367947101593018, 3.7339537143707275, 3.7311532497406006, 3.7283778190612793]","[3.8864197731018066, 3.8689181804656982, 3.8515191078186035, 3.834217071533203, 3.8170087337493896, 3.7998902797698975, 3.78285813331604, 3.7659103870391846, 3.749041795730591, 3.7322490215301514, 3.7155280113220215, 3.698873519897461]","[4.096780300140381, 4.091611385345459, 4.08658504486084, 4.081721782684326, 4.077001571655273, 4.072394847869873, 4.067887783050537, 4.063471794128418, 4.059140682220459, 4.054891109466553, 4.050719738006592, 4.046622276306152]",True,True,True,True
```


## seed_training / `seed_results/seed_3/seed_summary.json`

```text
0001: {
0002:   "seed": 3,
0003:   "device": "cpu",
0004:   "steps": 12,
0005:   "batch": 2,
0006:   "seq": 8,
0007:   "lr": 0.0008,
0008:   "v39_params": 1840,
0009:   "transformer_params": 1896,
0010:   "v39_train_initial": 3.6797573566436768,
0011:   "v39_train_final": 3.5147933959960938,
0012:   "v39_train_delta": 0.164963960647583,
0013:   "v39_val_initial": 3.7610175609588623,
0014:   "v39_val_final": 3.7283778190612793,
0015:   "v39_val_delta": 0.03263974189758301,
0016:   "transformer_train_initial": 3.8864197731018066,
0017:   "transformer_train_final": 3.698873519897461,
0018:   "transformer_train_delta": 0.1875462532043457,
0019:   "transformer_val_initial": 4.096780300140381,
0020:   "transformer_val_final": 4.046622276306152,
0021:   "transformer_val_delta": 0.050158023834228516,
0022:   "v39_seconds": 0.48845395100033784,
0023:   "transformer_seconds": 0.06809510000039154,
0024:   "v39_train_curve": "[3.6797573566436768, 3.664783477783203, 3.649845838546753, 3.6349427700042725, 3.6200735569000244, 3.605236768722534, 3.590430736541748, 3.575653553009033, 3.560904026031494, 3.5461812019348145, 3.531482219696045, 3.5147933959960938]",
0025:   "v39_val_curve": "[3.7610175609588623, 3.757845640182495, 3.754704713821411, 3.751605272293091, 3.748554229736328, 3.745551586151123, 3.742591619491577, 3.739673614501953, 3.7367947101593018, 3.7339537143707275, 3.7311532497406006, 3.7283778190612793]",
0026:   "transformer_train_curve": "[3.8864197731018066, 3.8689181804656982, 3.8515191078186035, 3.834217071533203, 3.8170087337493896, 3.7998902797698975, 3.78285813331604, 3.7659103870391846, 3.749041795730591, 3.7322490215301514, 3.7155280113220215, 3.698873519897461]",
0027:   "transformer_val_curve": "[4.096780300140381, 4.091611385345459, 4.08658504486084, 4.081721782684326, 4.077001571655273, 4.072394847869873, 4.067887783050537, 4.063471794128418, 4.059140682220459, 4.054891109466553, 4.050719738006592, 4.046622276306152]",
0028:   "v39_train_reduced": true,
0029:   "v39_val_not_blowup": true,
0030:   "transformer_train_reduced": true,
0031:   "transformer_val_not_blowup": true
0032: }
```


## cuda_parity_harness / `README.md`

```text
0001: # Odyssey V39 CUDA Top-1 Decode Parity Harness
0002: 
0003: This artifact is **parity-only**. It is not CUDA optimization.
0004: 
0005: Goal:
0006: 
0007: ```text
0008: CUDA top-1 decode output == PyTorch/reference top-1 decode output
0009: ```
0010: 
0011: The CUDA harness only targets the first decode kernel boundary:
0012: 
0013: 1. route projection;
0014: 2. top-1 state selection;
0015: 3. rank projection;
0016: 4. selected-state update;
0017: 5. full state-bank readout;
0018: 6. output hidden update.
0019: 
0020: It intentionally does **not** include:
0021: - top-2 routing;
0022: - prefill scan;
0023: - TSC;
0024: - MLP;
0025: - server batching;
0026: - speed claims.
0027: 
0028: ## Run CPU/reference parity smoke
0029: 
0030: ```bash
0031: python3 tests/test_reference_top1.py
0032: ```
0033: 
0034: ## Build CUDA extension
0035: 
0036: ```bash
0037: cd odyssey_v39_cuda_ext
0038: python3 setup.py build_ext --inplace
0039: ```
0040: 
0041: ## Run CUDA parity
0042: 
0043: ```bash
0044: PYTHONPATH=.:odyssey_v39_cuda_ext python3 tests/test_cuda_top1_parity.py
0045: ```
0046: 
0047: ## Pass criterion
0048: 
0049: ```text
0050: max_abs_diff <= 1e-4 for float32
0051: ```
0052: 
0053: CUDA remains a parity target only until this passes.
```


## cuda_parity_harness / `docs/CUDA_PARITY_GATE.md`

```text
0001: # CUDA Top-1 Decode Parity Gate
0002: 
0003: CUDA may proceed only through this order:
0004: 
0005: 1. CPU reference smoke passes.
0006: 2. CUDA extension builds.
0007: 3. CUDA parity test passes.
0008: 4. `max_abs_y`, `max_abs_state`, and `max_abs_weight` are within tolerance.
0009: 5. Only then can timing be measured.
0010: 
0011: This artifact forbids CUDA speed claims. Passing this gate means only:
0012: 
0013: ```text
0014: the CUDA top-1 decode kernel is numerically equivalent to the reference top-1 decode path
0015: ```
0016: 
0017: ## Why top-1 only
0018: 
0019: The previous gates showed:
0020: - independent parity passed;
0021: - cached decode CSV exists;
0022: - seed-by-seed training gate passed;
0023: - CUDA was unlocked only for a top-1 parity harness.
0024: 
0025: Top-2, prefill, TSC, and MLP are intentionally excluded.
```


## cuda_parity_harness / `manifest.json`

```text
0001: {
0002:   "name": "odyssey_v39_cuda_top1_decode_parity_harness",
0003:   "purpose": "CUDA top-1 decode parity only, not optimization",
0004:   "cpu_reference_status": 0,
0005:   "cuda_status": "build_required_on_cuda_machine",
0006:   "files": [
0007:     "README.md",
0008:     "odyssey_v39_cuda_ext/setup.py",
0009:     "odyssey_v39_reference/__init__.py",
0010:     "odyssey_v39_reference/top1_reference.py",
0011:     "tests/test_reference_top1.py",
0012:     "tests/test_cuda_top1_parity.py",
0013:     "scripts/run_cpu_reference.sh",
0014:     "scripts/build_cuda.sh",
0015:     "scripts/run_cuda_parity.sh",
0016:     "docs/CUDA_PARITY_GATE.md",
0017:     "results/cpu_reference_result.txt",
0018:     "odyssey_v39_reference/__pycache__/__init__.cpython-313.pyc",
0019:     "odyssey_v39_reference/__pycache__/top1_reference.cpython-313.pyc",
0020:     "odyssey_v39_cuda_ext/odyssey_v39_cuda/__init__.py",
0021:     "odyssey_v39_cuda_ext/odyssey_v39_cuda/bindings.cpp",
0022:     "odyssey_v39_cuda_ext/odyssey_v39_cuda/top1_decode.cu"
0023:   ]
0024: }
```


## cuda_parity_harness / `odyssey_v39_cuda_ext/odyssey_v39_cuda/__init__.py`

```text
0001: try:
0002:     from ._C import qlaf_top1_decode
0003: except Exception as e:
0004:     _IMPORT_ERROR = e
0005:     def qlaf_top1_decode(*args, **kwargs):
0006:         raise RuntimeError(f"odyssey_v39_cuda extension is not built or failed to import: {_IMPORT_ERROR}")
```


## cuda_parity_harness / `odyssey_v39_cuda_ext/odyssey_v39_cuda/bindings.cpp`

```text
0001: #include <torch/extension.h>
0002: #include <vector>
0003: 
0004: std::vector<torch::Tensor> qlaf_top1_decode_cuda(
0005:     torch::Tensor x,
0006:     torch::Tensor state_summary,
0007:     torch::Tensor state_weight,
0008:     torch::Tensor route_weight,
0009:     torch::Tensor rank_weight,
0010:     torch::Tensor out_weight
0011: );
0012: 
0013: std::vector<torch::Tensor> qlaf_top1_decode(
0014:     torch::Tensor x,
0015:     torch::Tensor state_summary,
0016:     torch::Tensor state_weight,
0017:     torch::Tensor route_weight,
0018:     torch::Tensor rank_weight,
0019:     torch::Tensor out_weight
0020: ) {
0021:     TORCH_CHECK(x.is_cuda(), "x must be CUDA");
0022:     TORCH_CHECK(state_summary.is_cuda(), "state_summary must be CUDA");
0023:     TORCH_CHECK(state_weight.is_cuda(), "state_weight must be CUDA");
0024:     TORCH_CHECK(route_weight.is_cuda(), "route_weight must be CUDA");
0025:     TORCH_CHECK(rank_weight.is_cuda(), "rank_weight must be CUDA");
0026:     TORCH_CHECK(out_weight.is_cuda(), "out_weight must be CUDA");
0027:     TORCH_CHECK(x.dtype() == torch::kFloat32, "parity kernel supports float32 only");
0028:     return qlaf_top1_decode_cuda(x, state_summary, state_weight, route_weight, rank_weight, out_weight);
0029: }
0030: 
0031: PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
0032:     m.def("qlaf_top1_decode", &qlaf_top1_decode, "Odyssey V39 QLAF top-1 decode parity kernel");
0033: }
```


## cuda_parity_harness / `odyssey_v39_cuda_ext/odyssey_v39_cuda/top1_decode.cu`

```text
0001: #include <torch/extension.h>
0002: #include <cuda.h>
0003: #include <cuda_runtime.h>
0004: #include <vector>
0005: 
0006: // Parity-first scalar kernel.
0007: // One block per batch row.
0008: // This is deliberately simple and not optimized.
0009: 
0010: __global__ void qlaf_top1_decode_kernel(
0011:     const float* __restrict__ x,
0012:     const float* __restrict__ state_summary,
0013:     const float* __restrict__ state_weight,
0014:     const float* __restrict__ route_weight,
0015:     const float* __restrict__ rank_weight,
0016:     const float* __restrict__ out_weight,
0017:     float* __restrict__ y,
0018:     float* __restrict__ new_state,
0019:     float* __restrict__ new_weight,
0020:     int64_t* __restrict__ active_out,
0021:     int B,
0022:     int H,
0023:     int S,
0024:     int R
0025: ) {
0026:     int b = blockIdx.x;
0027:     if (b >= B) return;
0028: 
0029:     // copy state/weight first
0030:     for (int s = threadIdx.x; s < S; s += blockDim.x) {
0031:         new_weight[b*S + s] = state_weight[b*S + s];
0032:         for (int r = 0; r < R; ++r) {
0033:             new_state[(b*S + s)*R + r] = state_summary[(b*S + s)*R + r];
0034:         }
0035:     }
0036:     __syncthreads();
0037: 
0038:     if (threadIdx.x == 0) {
0039:         // route top-1
0040:         int best_s = 0;
0041:         float best_val = -3.402823466e+38F;
0042:         for (int s = 0; s < S; ++s) {
0043:             float acc = 0.0f;
0044:             for (int h = 0; h < H; ++h) {
0045:                 acc += x[b*H + h] * route_weight[s*H + h];
0046:             }
0047:             if (acc > best_val) {
0048:                 best_val = acc;
0049:                 best_s = s;
0050:             }
0051:         }
0052:         active_out[b] = (int64_t)best_s;
0053: 
0054:         // rank projection z
0055:         for (int r = 0; r < R; ++r) {
0056:             float z = 0.0f;
0057:             for (int h = 0; h < H; ++h) {
0058:                 z += x[b*H + h] * rank_weight[r*H + h];
0059:             }
0060:             float old_w = new_weight[b*S + best_s];
0061:             float new_w = old_w + 1.0f;
0062:             float old_val = new_state[(b*S + best_s)*R + r];
0063:             new_state[(b*S + best_s)*R + r] = (old_val * old_w + z) / fmaxf(new_w, 1.0e-8f);
0064:         }
0065:         new_weight[b*S + best_s] += 1.0f;
0066: 
0067:         // denominator
0068:         float denom = 0.0f;
0069:         for (int s = 0; s < S; ++s) {
0070:             denom += new_weight[b*S + s];
0071:         }
0072:         denom = fmaxf(denom, 1.0e-8f);
0073: 
0074:         // output y = x + flat @ out_weight.T
0075:         for (int h = 0; h < H; ++h) {
0076:             float acc = 0.0f;
0077:             for (int s = 0; s < S; ++s) {
0078:                 float sw = new_weight[b*S + s] / denom;
0079:                 for (int r = 0; r < R; ++r) {
0080:                     int flat_idx = s*R + r;
0081:                     float flat_val = new_state[(b*S + s)*R + r] * sw;
0082:                     acc += flat_val * out_weight[h*(S*R) + flat_idx];
0083:                 }
0084:             }
0085:             y[b*H + h] = x[b*H + h] + acc;
0086:         }
0087:     }
0088: }
0089: 
0090: std::vector<torch::Tensor> qlaf_top1_decode_cuda(
0091:     torch::Tensor x,
0092:     torch::Tensor state_summary,
0093:     torch::Tensor state_weight,
0094:     torch::Tensor route_weight,
0095:     torch::Tensor rank_weight,
0096:     torch::Tensor out_weight
0097: ) {
0098:     int B = x.size(0);
0099:     int H = x.size(1);
0100:     int S = state_summary.size(1);
0101:     int R = state_summary.size(2);
0102: 
0103:     auto y = torch::empty_like(x);
0104:     auto new_state = torch::empty_like(state_summary);
0105:     auto new_weight = torch::empty_like(state_weight);
0106:     auto active = torch::empty({B}, torch::TensorOptions().device(x.device()).dtype(torch::kInt64));
0107: 
0108:     int threads = 128;
0109:     qlaf_top1_decode_kernel<<<B, threads>>>(
0110:         x.data_ptr<float>(),
0111:         state_summary.data_ptr<float>(),
0112:         state_weight.data_ptr<float>(),
0113:         route_weight.data_ptr<float>(),
0114:         rank_weight.data_ptr<float>(),
0115:         out_weight.data_ptr<float>(),
0116:         y.data_ptr<float>(),
0117:         new_state.data_ptr<float>(),
0118:         new_weight.data_ptr<float>(),
0119:         active.data_ptr<int64_t>(),
0120:         B, H, S, R
0121:     );
0122: 
0123:     return {y, new_state, new_weight, active};
0124: }
```


## cuda_parity_harness / `odyssey_v39_cuda_ext/setup.py`

```text
0001: from setuptools import setup
0002: from torch.utils.cpp_extension import BuildExtension, CUDAExtension
0003: 
0004: setup(
0005:     name="odyssey_v39_cuda",
0006:     version="0.1.0",
0007:     packages=["odyssey_v39_cuda"],
0008:     ext_modules=[
0009:         CUDAExtension(
0010:             name="odyssey_v39_cuda._C",
0011:             sources=[
0012:                 "odyssey_v39_cuda/bindings.cpp",
0013:                 "odyssey_v39_cuda/top1_decode.cu",
0014:             ],
0015:             extra_compile_args={
0016:                 "cxx": ["-O2"],
0017:                 "nvcc": ["-O2", "-lineinfo"],
0018:             },
0019:         )
0020:     ],
0021:     cmdclass={"build_ext": BuildExtension},
0022: )
```


## cuda_parity_harness / `odyssey_v39_reference/__init__.py`

```text
0001: from .top1_reference import qlaf_top1_decode_reference, make_inputs
```


## cuda_parity_harness / `odyssey_v39_reference/top1_reference.py`

```text
0001: import torch
0002: 
0003: def make_inputs(batch=2, hidden=8, states=3, rank=4, seed=1, device="cpu", dtype=torch.float32):
0004:     g = torch.Generator(device="cpu")
0005:     g.manual_seed(seed)
0006:     def randn(*shape):
0007:         return torch.randn(*shape, generator=g, dtype=dtype).to(device) * 0.05
0008: 
0009:     x = randn(batch, hidden)
0010:     state_summary = randn(batch, states, rank)
0011:     state_weight = torch.rand(batch, states, generator=g, dtype=dtype).to(device) * 0.5
0012:     route_weight = randn(states, hidden)
0013:     rank_weight = randn(rank, hidden)
0014:     out_weight = randn(hidden, states * rank)
0015:     return {
0016:         "x": x,
0017:         "state_summary": state_summary,
0018:         "state_weight": state_weight,
0019:         "route_weight": route_weight,
0020:         "rank_weight": rank_weight,
0021:         "out_weight": out_weight,
0022:     }
0023: 
0024: def qlaf_top1_decode_reference(x, state_summary, state_weight, route_weight, rank_weight, out_weight):
0025:     # x: [B,H]
0026:     # state_summary: [B,S,R]
0027:     # state_weight: [B,S]
0028:     # route_weight: [S,H]
0029:     # rank_weight: [R,H]
0030:     # out_weight: [H,S*R]
0031:     B, H = x.shape
0032:     S = state_summary.shape[1]
0033:     R = state_summary.shape[2]
0034: 
0035:     route_logits = x @ route_weight.t()
0036:     active = torch.argmax(route_logits, dim=-1)
0037:     z = x @ rank_weight.t()
0038: 
0039:     new_state = state_summary.clone()
0040:     new_weight = state_weight.clone()
0041:     bi = torch.arange(B, device=x.device)
0042: 
0043:     old_w = new_weight[bi, active]
0044:     add_w = torch.ones_like(old_w)
0045:     new_w = old_w + add_w
0046:     old = new_state[bi, active]
0047:     updated = (old * old_w[:, None] + z * add_w[:, None]) / new_w[:, None].clamp_min(1e-8)
0048:     new_state[bi, active] = updated
0049:     new_weight[bi, active] = new_w
0050: 
0051:     weighted = new_state * new_weight[:, :, None]
0052:     denom = new_weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0053:     flat = (weighted / denom[:, :, None]).reshape(B, S * R)
0054:     y = x + flat @ out_weight.t()
0055: 
0056:     return y, new_state, new_weight, active
```


## cuda_parity_harness / `results/cpu_reference_result.txt`

```text
0001: status=0
0002: 
0003: {'passed': True, 'active': [2, 2], 'max_abs_y': 0.0}
0004: Spreadsheet runtime warmup failed during python startup
0005: Traceback (most recent call last):
0006:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py", line 26, in warm_spreadsheet_runtime_on_startup
0007:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 785, in warm_spreadsheet_runtime
0008:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 720, in _warm_feature_flows
0009:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 704, in _warm_collaboration_flows
0010:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/generated/interface/models.py", line 35986, in hydrate_crdt_from_proto
0011:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/remote.py", line 747, in __call__
0012:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/client.py", line 150, in call
0013: presentation_artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.
```


## cuda_parity_harness / `scripts/build_cuda.sh`

```text
0001: #!/usr/bin/env bash
0002: set -euo pipefail
0003: cd odyssey_v39_cuda_ext
0004: python3 setup.py build_ext --inplace
```


## cuda_parity_harness / `scripts/run_cpu_reference.sh`

```text
0001: #!/usr/bin/env bash
0002: set -euo pipefail
0003: python3 tests/test_reference_top1.py
```


## cuda_parity_harness / `scripts/run_cuda_parity.sh`

```text
0001: #!/usr/bin/env bash
0002: set -euo pipefail
0003: export PYTHONPATH=".:odyssey_v39_cuda_ext:${PYTHONPATH:-}"
0004: python3 tests/test_cuda_top1_parity.py
```


## cuda_parity_harness / `tests/test_cuda_top1_parity.py`

```text
0001: import sys
0002: from pathlib import Path
0003: sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
0004: sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "odyssey_v39_cuda_ext"))
0005: 
0006: import torch
0007: from odyssey_v39_reference import make_inputs, qlaf_top1_decode_reference
0008: 
0009: def main():
0010:     if not torch.cuda.is_available():
0011:         print({"passed": False, "reason": "cuda_not_available"})
0012:         return
0013: 
0014:     import odyssey_v39_cuda
0015: 
0016:     inp = make_inputs(seed=123, device="cuda", dtype=torch.float32)
0017:     y_ref, s_ref, w_ref, a_ref = qlaf_top1_decode_reference(**inp)
0018: 
0019:     y_cuda, s_cuda, w_cuda, a_cuda = odyssey_v39_cuda.qlaf_top1_decode(
0020:         inp["x"],
0021:         inp["state_summary"],
0022:         inp["state_weight"],
0023:         inp["route_weight"],
0024:         inp["rank_weight"],
0025:         inp["out_weight"],
0026:     )
0027: 
0028:     max_y = torch.max(torch.abs(y_ref - y_cuda)).item()
0029:     max_s = torch.max(torch.abs(s_ref - s_cuda)).item()
0030:     max_w = torch.max(torch.abs(w_ref - w_cuda)).item()
0031:     active_equal = torch.equal(a_ref, a_cuda)
0032: 
0033:     passed = active_equal and max_y <= 1e-4 and max_s <= 1e-4 and max_w <= 1e-4
0034:     print({
0035:         "passed": bool(passed),
0036:         "active_equal": bool(active_equal),
0037:         "max_abs_y": float(max_y),
0038:         "max_abs_state": float(max_s),
0039:         "max_abs_weight": float(max_w),
0040:     })
0041: 
0042: if __name__ == "__main__":
0043:     main()
```


## cuda_parity_harness / `tests/test_reference_top1.py`

```text
0001: import sys
0002: from pathlib import Path
0003: sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
0004: 
0005: import torch
0006: from odyssey_v39_reference import make_inputs, qlaf_top1_decode_reference
0007: 
0008: def main():
0009:     inp = make_inputs(seed=123)
0010:     y1, s1, w1, a1 = qlaf_top1_decode_reference(**inp)
0011:     y2, s2, w2, a2 = qlaf_top1_decode_reference(**inp)
0012:     assert torch.equal(a1, a2)
0013:     assert torch.max(torch.abs(y1 - y2)).item() == 0.0
0014:     assert torch.max(torch.abs(s1 - s2)).item() == 0.0
0015:     assert torch.max(torch.abs(w1 - w2)).item() == 0.0
0016:     print({
0017:         "passed": True,
0018:         "active": a1.tolist(),
0019:         "max_abs_y": float(torch.max(torch.abs(y1 - y2)).item())
0020:     })
0021: 
0022: if __name__ == "__main__":
0023:     main()
```


## local_cuda_gate_attempt / `LOCAL_NEXT_STEPS.md`

```text
0001: # Local Next Steps
0002: 
0003: ```bash
0004: bash scripts/run_local_cuda_gate.sh
0005: cat results/local_cuda_gate_report.json
0006: ```
0007: 
0008: If parity passes:
0009: 
0010: ```bash
0011: python3 scripts/make_timing_harness_if_parity_passed.py
0012: PYTHONPATH=.:odyssey_v39_cuda_ext python3 scripts/run_cuda_top1_timing.py
0013: ```
0014: 
0015: If parity fails, patch only for numerical parity.
```


## local_cuda_gate_attempt / `README.md`

```text
0001: # Odyssey V39 CUDA Top-1 Decode Parity Harness
0002: 
0003: This artifact is **parity-only**. It is not CUDA optimization.
0004: 
0005: Goal:
0006: 
0007: ```text
0008: CUDA top-1 decode output == PyTorch/reference top-1 decode output
0009: ```
0010: 
0011: The CUDA harness only targets the first decode kernel boundary:
0012: 
0013: 1. route projection;
0014: 2. top-1 state selection;
0015: 3. rank projection;
0016: 4. selected-state update;
0017: 5. full state-bank readout;
0018: 6. output hidden update.
0019: 
0020: It intentionally does **not** include:
0021: - top-2 routing;
0022: - prefill scan;
0023: - TSC;
0024: - MLP;
0025: - server batching;
0026: - speed claims.
0027: 
0028: ## Run CPU/reference parity smoke
0029: 
0030: ```bash
0031: python3 tests/test_reference_top1.py
0032: ```
0033: 
0034: ## Build CUDA extension
0035: 
0036: ```bash
0037: cd odyssey_v39_cuda_ext
0038: python3 setup.py build_ext --inplace
0039: ```
0040: 
0041: ## Run CUDA parity
0042: 
0043: ```bash
0044: PYTHONPATH=.:odyssey_v39_cuda_ext python3 tests/test_cuda_top1_parity.py
0045: ```
0046: 
0047: ## Pass criterion
0048: 
0049: ```text
0050: max_abs_diff <= 1e-4 for float32
0051: ```
0052: 
0053: CUDA remains a parity target only until this passes.
```


## local_cuda_gate_attempt / `docs/CUDA_PARITY_GATE.md`

```text
0001: # CUDA Top-1 Decode Parity Gate
0002: 
0003: CUDA may proceed only through this order:
0004: 
0005: 1. CPU reference smoke passes.
0006: 2. CUDA extension builds.
0007: 3. CUDA parity test passes.
0008: 4. `max_abs_y`, `max_abs_state`, and `max_abs_weight` are within tolerance.
0009: 5. Only then can timing be measured.
0010: 
0011: This artifact forbids CUDA speed claims. Passing this gate means only:
0012: 
0013: ```text
0014: the CUDA top-1 decode kernel is numerically equivalent to the reference top-1 decode path
0015: ```
0016: 
0017: ## Why top-1 only
0018: 
0019: The previous gates showed:
0020: - independent parity passed;
0021: - cached decode CSV exists;
0022: - seed-by-seed training gate passed;
0023: - CUDA was unlocked only for a top-1 parity harness.
0024: 
0025: Top-2, prefill, TSC, and MLP are intentionally excluded.
```


## local_cuda_gate_attempt / `docs/LOCAL_ENVIRONMENT_GATE_RUNBOOK.md`

```text
0001: # Local Environment Gate Runbook
0002: 
0003: ## 1. Confirm CPU reference
0004: 
0005: ```bash
0006: bash scripts/run_cpu_reference.sh
0007: ```
0008: 
0009: Expected:
0010: 
0011: ```text
0012: passed: True
0013: max_abs_y: 0.0
0014: ```
0015: 
0016: ## 2. Run full local gate
0017: 
0018: ```bash
0019: bash scripts/run_local_cuda_gate.sh
0020: ```
0021: 
0022: This checks:
0023: - CPU reference
0024: - PyTorch import
0025: - CUDA availability
0026: - CUDA extension build if CUDA exists
0027: - CUDA parity if build succeeds
0028: 
0029: Report:
0030: 
0031: ```text
0032: results/local_cuda_gate_report.json
0033: ```
0034: 
0035: ## 3. Pass condition
0036: 
0037: The report must show:
0038: 
0039: ```json
0040: "parity_passed": true
0041: ```
0042: 
0043: And the parity output must satisfy:
0044: 
0045: ```text
0046: active_equal: true
0047: max_abs_y <= 1e-4
0048: max_abs_state <= 1e-4
0049: max_abs_weight <= 1e-4
0050: ```
0051: 
0052: ## 4. If parity passes
0053: 
0054: ```bash
0055: python3 scripts/make_timing_harness_if_parity_passed.py
0056: PYTHONPATH=.:odyssey_v39_cuda_ext python3 scripts/run_cuda_top1_timing.py
0057: ```
0058: 
0059: ## 5. If parity fails
0060: 
0061: Do not benchmark speed. Patch only `odyssey_v39_cuda/top1_decode.cu` for parity.
```


## local_cuda_gate_attempt / `docs/PARITY_FAIL_PATCH_GUIDE.md`

```text
0001: # CUDA Parity Failure Patch Guide
0002: 
0003: If `scripts/run_local_cuda_gate.sh` reports `parity_passed: false`, do not run timing.
0004: 
0005: Patch only for numerical parity.
0006: 
0007: ## Common failure modes
0008: 
0009: ### 1. Build failure: `nvcc not found`
0010: 
0011: Install/use a CUDA-enabled PyTorch environment with CUDA toolkit available.
0012: 
0013: Check:
0014: 
0015: ```bash
0016: which nvcc
0017: python3 - <<'PY'
0018: import torch
0019: print(torch.__version__)
0020: print(torch.cuda.is_available())
0021: print(torch.version.cuda)
0022: PY
0023: ```
0024: 
0025: ### 2. Import failure after build
0026: 
0027: Run from repo root with:
0028: 
0029: ```bash
0030: export PYTHONPATH=.:odyssey_v39_cuda_ext:$PYTHONPATH
0031: python3 tests/test_cuda_top1_parity.py
0032: ```
0033: 
0034: ### 3. `active_equal: false`
0035: 
0036: Patch route selection first. The CUDA kernel top-1 state must exactly match:
0037: 
0038: ```python
0039: active = torch.argmax(x @ route_weight.T, dim=-1)
0040: ```
0041: 
0042: Check:
0043: - route_weight layout `[S, H]`
0044: - x layout `[B, H]`
0045: - no transposed indexing bug
0046: - deterministic tie behavior
0047: 
0048: ### 4. `max_abs_state` or `max_abs_weight` too high
0049: 
0050: Patch selected-state update:
0051: 
0052: ```text
0053: old_w = weight[b, active]
0054: new_w = old_w + 1
0055: state[b, active, r] = (old_state * old_w + z[r]) / new_w
0056: weight[b, active] = new_w
0057: ```
0058: 
0059: Check:
0060: - update weight after all rank entries are computed
0061: - do not increment weight inside the rank loop more than once
0062: - rank_weight layout `[R, H]`
0063: 
0064: ### 5. `max_abs_y` too high but state/weight pass
0065: 
0066: Patch readout:
0067: 
0068: ```text
0069: flat[s,r] = new_state[s,r] * new_weight[s] / sum(new_weight)
0070: y[h] = x[h] + sum_flat flat[k] * out_weight[h,k]
0071: ```
0072: 
0073: Check:
0074: - out_weight layout `[H, S*R]`
0075: - flat index is `s * R + r`
0076: - denominator uses updated weights
0077: 
0078: ## After patch
0079: 
0080: Run:
0081: 
0082: ```bash
0083: bash scripts/run_local_cuda_gate.sh
0084: cat results/local_cuda_gate_report.json
0085: ```
0086: 
0087: Only if parity passes, create timing harness:
0088: 
0089: ```bash
0090: python3 scripts/make_timing_harness_if_parity_passed.py
0091: ```
```


## local_cuda_gate_attempt / `manifest.json`

```text
0001: {
0002:   "name": "odyssey_v39_cuda_top1_decode_parity_harness",
0003:   "purpose": "CUDA top-1 decode parity only, not optimization",
0004:   "cpu_reference_status": 0,
0005:   "cuda_status": "build_required_on_cuda_machine",
0006:   "files": [
0007:     "README.md",
0008:     "odyssey_v39_cuda_ext/setup.py",
0009:     "odyssey_v39_reference/__init__.py",
0010:     "odyssey_v39_reference/top1_reference.py",
0011:     "tests/test_reference_top1.py",
0012:     "tests/test_cuda_top1_parity.py",
0013:     "scripts/run_cpu_reference.sh",
0014:     "scripts/build_cuda.sh",
0015:     "scripts/run_cuda_parity.sh",
0016:     "docs/CUDA_PARITY_GATE.md",
0017:     "results/cpu_reference_result.txt",
0018:     "odyssey_v39_reference/__pycache__/__init__.cpython-313.pyc",
0019:     "odyssey_v39_reference/__pycache__/top1_reference.cpython-313.pyc",
0020:     "odyssey_v39_cuda_ext/odyssey_v39_cuda/__init__.py",
0021:     "odyssey_v39_cuda_ext/odyssey_v39_cuda/bindings.cpp",
0022:     "odyssey_v39_cuda_ext/odyssey_v39_cuda/top1_decode.cu"
0023:   ]
0024: }
```


## local_cuda_gate_attempt / `manifest_local_gate.json`

```text
0001: {
0002:   "name": "odyssey_v39_local_cuda_gate_runner",
0003:   "purpose": "local CPU/CUDA/PyTorch gate, then timing harness only if parity passes",
0004:   "files": [
0005:     "README.md",
0006:     "manifest.json",
0007:     "LOCAL_NEXT_STEPS.md",
0008:     "odyssey_v39_cuda_ext/setup.py",
0009:     "odyssey_v39_reference/__init__.py",
0010:     "odyssey_v39_reference/top1_reference.py",
0011:     "tests/test_reference_top1.py",
0012:     "tests/test_cuda_top1_parity.py",
0013:     "scripts/run_cpu_reference.sh",
0014:     "scripts/build_cuda.sh",
0015:     "scripts/run_cuda_parity.sh",
0016:     "scripts/local_cuda_gate.py",
0017:     "scripts/run_local_cuda_gate.sh",
0018:     "scripts/make_timing_harness_if_parity_passed.py",
0019:     "docs/CUDA_PARITY_GATE.md",
0020:     "docs/LOCAL_ENVIRONMENT_GATE_RUNBOOK.md",
0021:     "results/cpu_reference_result.txt",
0022:     "odyssey_v39_reference/__pycache__/__init__.cpython-313.pyc",
0023:     "odyssey_v39_reference/__pycache__/top1_reference.cpython-313.pyc",
0024:     "odyssey_v39_cuda_ext/odyssey_v39_cuda/__init__.py",
0025:     "odyssey_v39_cuda_ext/odyssey_v39_cuda/bindings.cpp",
0026:     "odyssey_v39_cuda_ext/odyssey_v39_cuda/top1_decode.cu"
0027:   ]
0028: }
```


## local_cuda_gate_attempt / `odyssey_v39_cuda_ext/odyssey_v39_cuda/__init__.py`

```text
0001: try:
0002:     from ._C import qlaf_top1_decode
0003: except Exception as e:
0004:     _IMPORT_ERROR = e
0005:     def qlaf_top1_decode(*args, **kwargs):
0006:         raise RuntimeError(f"odyssey_v39_cuda extension is not built or failed to import: {_IMPORT_ERROR}")
```


## local_cuda_gate_attempt / `odyssey_v39_cuda_ext/odyssey_v39_cuda/bindings.cpp`

```text
0001: #include <torch/extension.h>
0002: #include <vector>
0003: 
0004: std::vector<torch::Tensor> qlaf_top1_decode_cuda(
0005:     torch::Tensor x,
0006:     torch::Tensor state_summary,
0007:     torch::Tensor state_weight,
0008:     torch::Tensor route_weight,
0009:     torch::Tensor rank_weight,
0010:     torch::Tensor out_weight
0011: );
0012: 
0013: std::vector<torch::Tensor> qlaf_top1_decode(
0014:     torch::Tensor x,
0015:     torch::Tensor state_summary,
0016:     torch::Tensor state_weight,
0017:     torch::Tensor route_weight,
0018:     torch::Tensor rank_weight,
0019:     torch::Tensor out_weight
0020: ) {
0021:     TORCH_CHECK(x.is_cuda(), "x must be CUDA");
0022:     TORCH_CHECK(state_summary.is_cuda(), "state_summary must be CUDA");
0023:     TORCH_CHECK(state_weight.is_cuda(), "state_weight must be CUDA");
0024:     TORCH_CHECK(route_weight.is_cuda(), "route_weight must be CUDA");
0025:     TORCH_CHECK(rank_weight.is_cuda(), "rank_weight must be CUDA");
0026:     TORCH_CHECK(out_weight.is_cuda(), "out_weight must be CUDA");
0027:     TORCH_CHECK(x.dtype() == torch::kFloat32, "parity kernel supports float32 only");
0028:     return qlaf_top1_decode_cuda(x, state_summary, state_weight, route_weight, rank_weight, out_weight);
0029: }
0030: 
0031: PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
0032:     m.def("qlaf_top1_decode", &qlaf_top1_decode, "Odyssey V39 QLAF top-1 decode parity kernel");
0033: }
```


## local_cuda_gate_attempt / `odyssey_v39_cuda_ext/odyssey_v39_cuda/top1_decode.cu`

```text
0001: #include <torch/extension.h>
0002: #include <cuda.h>
0003: #include <cuda_runtime.h>
0004: #include <vector>
0005: 
0006: // Parity-first scalar kernel.
0007: // One block per batch row.
0008: // This is deliberately simple and not optimized.
0009: 
0010: __global__ void qlaf_top1_decode_kernel(
0011:     const float* __restrict__ x,
0012:     const float* __restrict__ state_summary,
0013:     const float* __restrict__ state_weight,
0014:     const float* __restrict__ route_weight,
0015:     const float* __restrict__ rank_weight,
0016:     const float* __restrict__ out_weight,
0017:     float* __restrict__ y,
0018:     float* __restrict__ new_state,
0019:     float* __restrict__ new_weight,
0020:     int64_t* __restrict__ active_out,
0021:     int B,
0022:     int H,
0023:     int S,
0024:     int R
0025: ) {
0026:     int b = blockIdx.x;
0027:     if (b >= B) return;
0028: 
0029:     // copy state/weight first
0030:     for (int s = threadIdx.x; s < S; s += blockDim.x) {
0031:         new_weight[b*S + s] = state_weight[b*S + s];
0032:         for (int r = 0; r < R; ++r) {
0033:             new_state[(b*S + s)*R + r] = state_summary[(b*S + s)*R + r];
0034:         }
0035:     }
0036:     __syncthreads();
0037: 
0038:     if (threadIdx.x == 0) {
0039:         // route top-1
0040:         int best_s = 0;
0041:         float best_val = -3.402823466e+38F;
0042:         for (int s = 0; s < S; ++s) {
0043:             float acc = 0.0f;
0044:             for (int h = 0; h < H; ++h) {
0045:                 acc += x[b*H + h] * route_weight[s*H + h];
0046:             }
0047:             if (acc > best_val) {
0048:                 best_val = acc;
0049:                 best_s = s;
0050:             }
0051:         }
0052:         active_out[b] = (int64_t)best_s;
0053: 
0054:         // rank projection z
0055:         for (int r = 0; r < R; ++r) {
0056:             float z = 0.0f;
0057:             for (int h = 0; h < H; ++h) {
0058:                 z += x[b*H + h] * rank_weight[r*H + h];
0059:             }
0060:             float old_w = new_weight[b*S + best_s];
0061:             float new_w = old_w + 1.0f;
0062:             float old_val = new_state[(b*S + best_s)*R + r];
0063:             new_state[(b*S + best_s)*R + r] = (old_val * old_w + z) / fmaxf(new_w, 1.0e-8f);
0064:         }
0065:         new_weight[b*S + best_s] += 1.0f;
0066: 
0067:         // denominator
0068:         float denom = 0.0f;
0069:         for (int s = 0; s < S; ++s) {
0070:             denom += new_weight[b*S + s];
0071:         }
0072:         denom = fmaxf(denom, 1.0e-8f);
0073: 
0074:         // output y = x + flat @ out_weight.T
0075:         for (int h = 0; h < H; ++h) {
0076:             float acc = 0.0f;
0077:             for (int s = 0; s < S; ++s) {
0078:                 float sw = new_weight[b*S + s] / denom;
0079:                 for (int r = 0; r < R; ++r) {
0080:                     int flat_idx = s*R + r;
0081:                     float flat_val = new_state[(b*S + s)*R + r] * sw;
0082:                     acc += flat_val * out_weight[h*(S*R) + flat_idx];
0083:                 }
0084:             }
0085:             y[b*H + h] = x[b*H + h] + acc;
0086:         }
0087:     }
0088: }
0089: 
0090: std::vector<torch::Tensor> qlaf_top1_decode_cuda(
0091:     torch::Tensor x,
0092:     torch::Tensor state_summary,
0093:     torch::Tensor state_weight,
0094:     torch::Tensor route_weight,
0095:     torch::Tensor rank_weight,
0096:     torch::Tensor out_weight
0097: ) {
0098:     int B = x.size(0);
0099:     int H = x.size(1);
0100:     int S = state_summary.size(1);
0101:     int R = state_summary.size(2);
0102: 
0103:     auto y = torch::empty_like(x);
0104:     auto new_state = torch::empty_like(state_summary);
0105:     auto new_weight = torch::empty_like(state_weight);
0106:     auto active = torch::empty({B}, torch::TensorOptions().device(x.device()).dtype(torch::kInt64));
0107: 
0108:     int threads = 128;
0109:     qlaf_top1_decode_kernel<<<B, threads>>>(
0110:         x.data_ptr<float>(),
0111:         state_summary.data_ptr<float>(),
0112:         state_weight.data_ptr<float>(),
0113:         route_weight.data_ptr<float>(),
0114:         rank_weight.data_ptr<float>(),
0115:         out_weight.data_ptr<float>(),
0116:         y.data_ptr<float>(),
0117:         new_state.data_ptr<float>(),
0118:         new_weight.data_ptr<float>(),
0119:         active.data_ptr<int64_t>(),
0120:         B, H, S, R
0121:     );
0122: 
0123:     return {y, new_state, new_weight, active};
0124: }
```


## local_cuda_gate_attempt / `odyssey_v39_cuda_ext/setup.py`

```text
0001: from setuptools import setup
0002: from torch.utils.cpp_extension import BuildExtension, CUDAExtension
0003: 
0004: setup(
0005:     name="odyssey_v39_cuda",
0006:     version="0.1.0",
0007:     packages=["odyssey_v39_cuda"],
0008:     ext_modules=[
0009:         CUDAExtension(
0010:             name="odyssey_v39_cuda._C",
0011:             sources=[
0012:                 "odyssey_v39_cuda/bindings.cpp",
0013:                 "odyssey_v39_cuda/top1_decode.cu",
0014:             ],
0015:             extra_compile_args={
0016:                 "cxx": ["-O2"],
0017:                 "nvcc": ["-O2", "-lineinfo"],
0018:             },
0019:         )
0020:     ],
0021:     cmdclass={"build_ext": BuildExtension},
0022: )
```


## local_cuda_gate_attempt / `odyssey_v39_reference/__init__.py`

```text
0001: from .top1_reference import qlaf_top1_decode_reference, make_inputs
```


## local_cuda_gate_attempt / `odyssey_v39_reference/top1_reference.py`

```text
0001: import torch
0002: 
0003: def make_inputs(batch=2, hidden=8, states=3, rank=4, seed=1, device="cpu", dtype=torch.float32):
0004:     g = torch.Generator(device="cpu")
0005:     g.manual_seed(seed)
0006:     def randn(*shape):
0007:         return torch.randn(*shape, generator=g, dtype=dtype).to(device) * 0.05
0008: 
0009:     x = randn(batch, hidden)
0010:     state_summary = randn(batch, states, rank)
0011:     state_weight = torch.rand(batch, states, generator=g, dtype=dtype).to(device) * 0.5
0012:     route_weight = randn(states, hidden)
0013:     rank_weight = randn(rank, hidden)
0014:     out_weight = randn(hidden, states * rank)
0015:     return {
0016:         "x": x,
0017:         "state_summary": state_summary,
0018:         "state_weight": state_weight,
0019:         "route_weight": route_weight,
0020:         "rank_weight": rank_weight,
0021:         "out_weight": out_weight,
0022:     }
0023: 
0024: def qlaf_top1_decode_reference(x, state_summary, state_weight, route_weight, rank_weight, out_weight):
0025:     # x: [B,H]
0026:     # state_summary: [B,S,R]
0027:     # state_weight: [B,S]
0028:     # route_weight: [S,H]
0029:     # rank_weight: [R,H]
0030:     # out_weight: [H,S*R]
0031:     B, H = x.shape
0032:     S = state_summary.shape[1]
0033:     R = state_summary.shape[2]
0034: 
0035:     route_logits = x @ route_weight.t()
0036:     active = torch.argmax(route_logits, dim=-1)
0037:     z = x @ rank_weight.t()
0038: 
0039:     new_state = state_summary.clone()
0040:     new_weight = state_weight.clone()
0041:     bi = torch.arange(B, device=x.device)
0042: 
0043:     old_w = new_weight[bi, active]
0044:     add_w = torch.ones_like(old_w)
0045:     new_w = old_w + add_w
0046:     old = new_state[bi, active]
0047:     updated = (old * old_w[:, None] + z * add_w[:, None]) / new_w[:, None].clamp_min(1e-8)
0048:     new_state[bi, active] = updated
0049:     new_weight[bi, active] = new_w
0050: 
0051:     weighted = new_state * new_weight[:, :, None]
0052:     denom = new_weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0053:     flat = (weighted / denom[:, :, None]).reshape(B, S * R)
0054:     y = x + flat @ out_weight.t()
0055: 
0056:     return y, new_state, new_weight, active
```


## local_cuda_gate_attempt / `results/chat_env_gate_attempt.txt`

```text
0001: status=0
0002: 
0003: {
0004:   "cpu_reference_ok": true,
0005:   "cuda_available": false,
0006:   "cuda_build_ok": false,
0007:   "parity_passed": false,
0008:   "next_allowed_step": "patch_cuda_for_parity_only",
0009:   "report": "/mnt/data/odyssey_v39_local_cuda_gate_run_attempt/odyssey_v39_cuda_top1_decode_parity_harness/results/local_cuda_gate_report.json"
0010: }
0011: Spreadsheet runtime warmup failed during python startup
0012: Traceback (most recent call last):
0013:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py", line 26, in warm_spreadsheet_runtime_on_startup
0014:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 785, in warm_spreadsheet_runtime
0015:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 720, in _warm_feature_flows
0016:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 704, in _warm_collaboration_flows
0017:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/generated/interface/models.py", line 35986, in hydrate_crdt_from_proto
0018:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/remote.py", line 747, in __call__
0019:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/client.py", line 150, in call
0020: presentation_artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.
```


## local_cuda_gate_attempt / `results/chat_env_gate_summary.json`

```text
0001: {
0002:   "stage": "local_cuda_gate",
0003:   "platform": "Linux-4.4.0-x86_64-with-glibc2.41",
0004:   "python": "3.13.5 (main, Jun 25 2025, 18:55:22) [GCC 14.2.0]",
0005:   "steps": {
0006:     "cpu_reference": {
0007:       "cmd": "/opt/pyvenv/bin/python3 /mnt/data/odyssey_v39_local_cuda_gate_run_attempt/odyssey_v39_cuda_top1_decode_parity_harness/tests/test_reference_top1.py",
0008:       "returncode": 0,
0009:       "elapsed_seconds": 17.816227755,
0010:       "stdout": "{'passed': True, 'active': [2, 2], 'max_abs_y': 0.0}\n",
0011:       "stderr": "Spreadsheet runtime warmup failed during python startup\nTraceback (most recent call last):\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py\", line 26, in warm_spreadsheet_runtime_on_startup\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 785, in warm_spreadsheet_runtime\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 720, in _warm_feature_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 704, in _warm_collaboration_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/generated/interface/models.py\", line 35986, in hydrate_crdt_from_proto\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/remote.py\", line 747, in __call__\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/client.py\", line 150, in call\npresentation_artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.\n",
0012:       "ok": true
0013:     },
0014:     "torch_cuda_probe": {
0015:       "cmd": "/opt/pyvenv/bin/python3 -c \nimport json\ntry:\n    import torch\n    print(json.dumps({\n        \"torch_imported\": True,\n        \"torch_version\": torch.__version__,\n        \"cuda_available\": torch.cuda.is_available(),\n        \"torch_cuda_version\": torch.version.cuda,\n        \"device_count\": torch.cuda.device_count(),\n        \"device_name\": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,\n    }, indent=2))\nexcept Exception as e:\n    print(json.dumps({\"torch_imported\": False, \"error\": repr(e)}, indent=2))\n    raise\n",
0016:       "returncode": 0,
0017:       "elapsed_seconds": 18.762026497999614,
0018:       "stdout": "{\n  \"torch_imported\": true,\n  \"torch_version\": \"2.10.0+cpu\",\n  \"cuda_available\": false,\n  \"torch_cuda_version\": null,\n  \"device_count\": 0,\n  \"device_name\": null\n}\n",
0019:       "stderr": "Spreadsheet runtime warmup failed during python startup\nTraceback (most recent call last):\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py\", line 26, in warm_spreadsheet_runtime_on_startup\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 785, in warm_spreadsheet_runtime\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 720, in _warm_feature_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 704, in _warm_collaboration_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/generated/interface/models.py\", line 35986, in hydrate_crdt_from_proto\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/remote.py\", line 747, in __call__\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/client.py\", line 150, in call\npresentation_artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.\n",
0020:       "ok": true
0021:     },
0022:     "cuda_build": {
0023:       "skipped": true,
0024:       "reason": "cuda_unavailable_or_cpu_reference_failed"
0025:     },
0026:     "cuda_parity": {
0027:       "skipped": true,
0028:       "reason": "cuda_unavailable_or_cpu_reference_failed"
0029:     }
0030:   },
0031:   "cuda_available": false,
0032:   "parity_passed": false,
0033:   "next_allowed_step": "patch_cuda_for_parity_only",
0034:   "torch_cuda": {
0035:     "torch_imported": true,
0036:     "torch_version": "2.10.0+cpu",
0037:     "cuda_available": false,
0038:     "torch_cuda_version": null,
0039:     "device_count": 0,
0040:     "device_name": null
0041:   }
0042: }
```


## local_cuda_gate_attempt / `results/cpu_reference_result.txt`

```text
0001: status=0
0002: 
0003: {'passed': True, 'active': [2, 2], 'max_abs_y': 0.0}
0004: Spreadsheet runtime warmup failed during python startup
0005: Traceback (most recent call last):
0006:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py", line 26, in warm_spreadsheet_runtime_on_startup
0007:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 785, in warm_spreadsheet_runtime
0008:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 720, in _warm_feature_flows
0009:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py", line 704, in _warm_collaboration_flows
0010:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/generated/interface/models.py", line 35986, in hydrate_crdt_from_proto
0011:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/remote.py", line 747, in __call__
0012:   File "/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/client.py", line 150, in call
0013: presentation_artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.
```


## local_cuda_gate_attempt / `results/local_cuda_gate_report.json`

```text
0001: {
0002:   "stage": "local_cuda_gate",
0003:   "platform": "Linux-4.4.0-x86_64-with-glibc2.41",
0004:   "python": "3.13.5 (main, Jun 25 2025, 18:55:22) [GCC 14.2.0]",
0005:   "steps": {
0006:     "cpu_reference": {
0007:       "cmd": "/opt/pyvenv/bin/python3 /mnt/data/odyssey_v39_local_cuda_gate_run_attempt/odyssey_v39_cuda_top1_decode_parity_harness/tests/test_reference_top1.py",
0008:       "returncode": 0,
0009:       "elapsed_seconds": 17.816227755,
0010:       "stdout": "{'passed': True, 'active': [2, 2], 'max_abs_y': 0.0}\n",
0011:       "stderr": "Spreadsheet runtime warmup failed during python startup\nTraceback (most recent call last):\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py\", line 26, in warm_spreadsheet_runtime_on_startup\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 785, in warm_spreadsheet_runtime\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 720, in _warm_feature_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 704, in _warm_collaboration_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/generated/interface/models.py\", line 35986, in hydrate_crdt_from_proto\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/remote.py\", line 747, in __call__\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/client.py\", line 150, in call\npresentation_artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.\n",
0012:       "ok": true
0013:     },
0014:     "torch_cuda_probe": {
0015:       "cmd": "/opt/pyvenv/bin/python3 -c \nimport json\ntry:\n    import torch\n    print(json.dumps({\n        \"torch_imported\": True,\n        \"torch_version\": torch.__version__,\n        \"cuda_available\": torch.cuda.is_available(),\n        \"torch_cuda_version\": torch.version.cuda,\n        \"device_count\": torch.cuda.device_count(),\n        \"device_name\": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,\n    }, indent=2))\nexcept Exception as e:\n    print(json.dumps({\"torch_imported\": False, \"error\": repr(e)}, indent=2))\n    raise\n",
0016:       "returncode": 0,
0017:       "elapsed_seconds": 18.762026497999614,
0018:       "stdout": "{\n  \"torch_imported\": true,\n  \"torch_version\": \"2.10.0+cpu\",\n  \"cuda_available\": false,\n  \"torch_cuda_version\": null,\n  \"device_count\": 0,\n  \"device_name\": null\n}\n",
0019:       "stderr": "Spreadsheet runtime warmup failed during python startup\nTraceback (most recent call last):\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py\", line 26, in warm_spreadsheet_runtime_on_startup\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 785, in warm_spreadsheet_runtime\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 720, in _warm_feature_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/spreadsheet_warmup.py\", line 704, in _warm_collaboration_flows\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/generated/interface/models.py\", line 35986, in hydrate_crdt_from_proto\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/remote.py\", line 747, in __call__\n  File \"/tmp/tmp.vJDWZqkmKn/artifact_tool_v2-2.6.11/presentation_artifact_tool/rpc/client.py\", line 150, in call\npresentation_artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.\n",
0020:       "ok": true
0021:     },
0022:     "cuda_build": {
0023:       "skipped": true,
0024:       "reason": "cuda_unavailable_or_cpu_reference_failed"
0025:     },
0026:     "cuda_parity": {
0027:       "skipped": true,
0028:       "reason": "cuda_unavailable_or_cpu_reference_failed"
0029:     }
0030:   },
0031:   "cuda_available": false,
0032:   "parity_passed": false,
0033:   "next_allowed_step": "patch_cuda_for_parity_only",
0034:   "torch_cuda": {
0035:     "torch_imported": true,
0036:     "torch_version": "2.10.0+cpu",
0037:     "cuda_available": false,
0038:     "torch_cuda_version": null,
0039:     "device_count": 0,
0040:     "device_name": null
0041:   }
0042: }
```


## local_cuda_gate_attempt / `scripts/build_cuda.sh`

```text
0001: #!/usr/bin/env bash
0002: set -euo pipefail
0003: cd odyssey_v39_cuda_ext
0004: python3 setup.py build_ext --inplace
```


## local_cuda_gate_attempt / `scripts/local_cuda_gate.py`

```text
0001: #!/usr/bin/env python3
0002: import json
0003: import os
0004: import platform
0005: import subprocess
0006: import sys
0007: import time
0008: from pathlib import Path
0009: 
0010: ROOT = Path(__file__).resolve().parents[1]
0011: RESULTS = ROOT / "results"
0012: RESULTS.mkdir(exist_ok=True)
0013: 
0014: def run(cmd, timeout=None, env=None):
0015:     start = time.perf_counter()
0016:     try:
0017:         p = subprocess.run(
0018:             cmd,
0019:             cwd=str(ROOT),
0020:             env=env or os.environ.copy(),
0021:             text=True,
0022:             capture_output=True,
0023:             timeout=timeout,
0024:         )
0025:         return {
0026:             "cmd": " ".join(cmd),
0027:             "returncode": p.returncode,
0028:             "elapsed_seconds": time.perf_counter() - start,
0029:             "stdout": p.stdout,
0030:             "stderr": p.stderr,
0031:             "ok": p.returncode == 0,
0032:         }
0033:     except Exception as e:
0034:         return {
0035:             "cmd": " ".join(cmd),
0036:             "returncode": -1,
0037:             "elapsed_seconds": time.perf_counter() - start,
0038:             "stdout": "",
0039:             "stderr": repr(e),
0040:             "ok": False,
0041:         }
0042: 
0043: def parse_json_loose(text):
0044:     text = text.strip()
0045:     if not text:
0046:         return {}
0047:     try:
0048:         return json.loads(text)
0049:     except Exception:
0050:         pass
0051:     start = text.find("{")
0052:     end = text.rfind("}")
0053:     if start >= 0 and end > start:
0054:         try:
0055:             return json.loads(text[start:end+1])
0056:         except Exception:
0057:             return {}
0058:     return {}
0059: 
0060: report = {
0061:     "stage": "local_cuda_gate",
0062:     "platform": platform.platform(),
0063:     "python": sys.version,
0064:     "steps": {},
0065:     "cuda_available": False,
0066:     "parity_passed": False,
0067:     "next_allowed_step": "blocked",
0068: }
0069: 
0070: # 1. CPU reference.
0071: report["steps"]["cpu_reference"] = run([sys.executable, str(ROOT / "tests" / "test_reference_top1.py")], timeout=60)
0072: 
0073: # 2. PyTorch/CUDA probe.
0074: torch_probe = """
0075: import json
0076: try:
0077:     import torch
0078:     print(json.dumps({
0079:         "torch_imported": True,
0080:         "torch_version": torch.__version__,
0081:         "cuda_available": torch.cuda.is_available(),
0082:         "torch_cuda_version": torch.version.cuda,
0083:         "device_count": torch.cuda.device_count(),
0084:         "device_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
0085:     }, indent=2))
0086: except Exception as e:
0087:     print(json.dumps({"torch_imported": False, "error": repr(e)}, indent=2))
0088:     raise
0089: """
0090: probe = run([sys.executable, "-c", torch_probe], timeout=60)
0091: report["steps"]["torch_cuda_probe"] = probe
0092: probe_json = parse_json_loose(probe["stdout"])
0093: report["torch_cuda"] = probe_json
0094: report["cuda_available"] = bool(probe_json.get("cuda_available"))
0095: 
0096: # 3. Build and parity only if CUDA is available.
0097: if report["cuda_available"] and report["steps"]["cpu_reference"]["ok"]:
0098:     report["steps"]["cuda_build"] = run(["bash", str(ROOT / "scripts" / "build_cuda.sh")], timeout=300)
0099:     if report["steps"]["cuda_build"]["ok"]:
0100:         env = os.environ.copy()
0101:         env["PYTHONPATH"] = f"{ROOT}:{ROOT / 'odyssey_v39_cuda_ext'}:" + env.get("PYTHONPATH", "")
0102:         parity = run(["bash", str(ROOT / "scripts" / "run_cuda_parity.sh")], timeout=120, env=env)
0103:         report["steps"]["cuda_parity"] = parity
0104:         out = parity["stdout"] + "\n" + parity["stderr"]
0105:         report["parity_raw_output"] = out
0106:         lower = out.lower()
0107:         report["parity_passed"] = (
0108:             parity["ok"]
0109:             and ("'passed': true" in lower or '"passed": true' in lower)
0110:             and ("active_equal" not in lower or "'active_equal': true" in lower or '"active_equal": true' in lower)
0111:         )
0112:     else:
0113:         report["steps"]["cuda_parity"] = {"skipped": True, "reason": "cuda_build_failed"}
0114: else:
0115:     report["steps"]["cuda_build"] = {"skipped": True, "reason": "cuda_unavailable_or_cpu_reference_failed"}
0116:     report["steps"]["cuda_parity"] = {"skipped": True, "reason": "cuda_unavailable_or_cpu_reference_failed"}
0117: 
0118: if report["parity_passed"]:
0119:     report["next_allowed_step"] = "cuda_top1_decode_timing_harness"
0120: else:
0121:     report["next_allowed_step"] = "patch_cuda_for_parity_only"
0122: 
0123: (RESULTS / "local_cuda_gate_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
0124: 
0125: print(json.dumps({
0126:     "cpu_reference_ok": report["steps"]["cpu_reference"].get("ok"),
0127:     "cuda_available": report["cuda_available"],
0128:     "cuda_build_ok": report["steps"].get("cuda_build", {}).get("ok", False),
0129:     "parity_passed": report["parity_passed"],
0130:     "next_allowed_step": report["next_allowed_step"],
0131:     "report": str(RESULTS / "local_cuda_gate_report.json"),
0132: }, indent=2))
```


## local_cuda_gate_attempt / `scripts/make_timing_harness_if_parity_passed.py`

```text
0001: #!/usr/bin/env python3
0002: import json
0003: from pathlib import Path
0004: 
0005: ROOT = Path(__file__).resolve().parents[1]
0006: report_path = ROOT / "results" / "local_cuda_gate_report.json"
0007: if not report_path.exists():
0008:     raise SystemExit("Missing results/local_cuda_gate_report.json. Run bash scripts/run_local_cuda_gate.sh first.")
0009: 
0010: report = json.loads(report_path.read_text(encoding="utf-8"))
0011: if not report.get("parity_passed"):
0012:     raise SystemExit("CUDA parity did not pass. Timing harness remains blocked.")
0013: 
0014: timing = ROOT / "scripts" / "run_cuda_top1_timing.py"
0015: timing.write_text("""#!/usr/bin/env python3
0016: import json
0017: import time
0018: from pathlib import Path
0019: import torch
0020: from odyssey_v39_reference import make_inputs, qlaf_top1_decode_reference
0021: import odyssey_v39_cuda
0022: 
0023: ROOT = Path(__file__).resolve().parents[1]
0024: 
0025: def bench(fn, warmup=5, trials=20):
0026:     for _ in range(warmup):
0027:         fn()
0028:     torch.cuda.synchronize()
0029:     vals = []
0030:     for _ in range(trials):
0031:         t0 = time.perf_counter()
0032:         fn()
0033:         torch.cuda.synchronize()
0034:         vals.append(time.perf_counter() - t0)
0035:     return vals
0036: 
0037: rows = []
0038: for batch in [1, 2, 4, 8]:
0039:     inp = make_inputs(batch=batch, hidden=8, states=3, rank=4, seed=123, device="cuda", dtype=torch.float32)
0040: 
0041:     def ref():
0042:         return qlaf_top1_decode_reference(**inp)
0043: 
0044:     def cuda():
0045:         return odyssey_v39_cuda.qlaf_top1_decode(
0046:             inp["x"], inp["state_summary"], inp["state_weight"],
0047:             inp["route_weight"], inp["rank_weight"], inp["out_weight"]
0048:         )
0049: 
0050:     ref_vals = bench(ref)
0051:     cuda_vals = bench(cuda)
0052:     ref_mean = sum(ref_vals) / len(ref_vals)
0053:     cuda_mean = sum(cuda_vals) / len(cuda_vals)
0054:     rows.append({
0055:         "batch": batch,
0056:         "reference_mean_seconds": ref_mean,
0057:         "cuda_mean_seconds": cuda_mean,
0058:         "speedup": ref_mean / max(cuda_mean, 1e-12),
0059:         "note": "parity-gated timing only; not optimized CUDA claim"
0060:     })
0061: 
0062: out = {"rows": rows}
0063: print(json.dumps(out, indent=2))
0064: (ROOT / "results" / "cuda_top1_timing.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
0065: """, encoding="utf-8")
0066: timing.chmod(0o755)
0067: print(json.dumps({"created": str(timing), "status": "timing_harness_created_after_parity"}))
```


## local_cuda_gate_attempt / `scripts/run_cpu_reference.sh`

```text
0001: #!/usr/bin/env bash
0002: set -euo pipefail
0003: python3 tests/test_reference_top1.py
```


## local_cuda_gate_attempt / `scripts/run_cuda_parity.sh`

```text
0001: #!/usr/bin/env bash
0002: set -euo pipefail
0003: export PYTHONPATH=".:odyssey_v39_cuda_ext:${PYTHONPATH:-}"
0004: python3 tests/test_cuda_top1_parity.py
```


## local_cuda_gate_attempt / `scripts/run_local_cuda_gate.sh`

```text
0001: #!/usr/bin/env bash
0002: set -euo pipefail
0003: python3 scripts/local_cuda_gate.py
```


## local_cuda_gate_attempt / `tests/test_cuda_top1_parity.py`

```text
0001: import sys
0002: from pathlib import Path
0003: sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
0004: sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "odyssey_v39_cuda_ext"))
0005: 
0006: import torch
0007: from odyssey_v39_reference import make_inputs, qlaf_top1_decode_reference
0008: 
0009: def main():
0010:     if not torch.cuda.is_available():
0011:         print({"passed": False, "reason": "cuda_not_available"})
0012:         return
0013: 
0014:     import odyssey_v39_cuda
0015: 
0016:     inp = make_inputs(seed=123, device="cuda", dtype=torch.float32)
0017:     y_ref, s_ref, w_ref, a_ref = qlaf_top1_decode_reference(**inp)
0018: 
0019:     y_cuda, s_cuda, w_cuda, a_cuda = odyssey_v39_cuda.qlaf_top1_decode(
0020:         inp["x"],
0021:         inp["state_summary"],
0022:         inp["state_weight"],
0023:         inp["route_weight"],
0024:         inp["rank_weight"],
0025:         inp["out_weight"],
0026:     )
0027: 
0028:     max_y = torch.max(torch.abs(y_ref - y_cuda)).item()
0029:     max_s = torch.max(torch.abs(s_ref - s_cuda)).item()
0030:     max_w = torch.max(torch.abs(w_ref - w_cuda)).item()
0031:     active_equal = torch.equal(a_ref, a_cuda)
0032: 
0033:     passed = active_equal and max_y <= 1e-4 and max_s <= 1e-4 and max_w <= 1e-4
0034:     print({
0035:         "passed": bool(passed),
0036:         "active_equal": bool(active_equal),
0037:         "max_abs_y": float(max_y),
0038:         "max_abs_state": float(max_s),
0039:         "max_abs_weight": float(max_w),
0040:     })
0041: 
0042: if __name__ == "__main__":
0043:     main()
```


## local_cuda_gate_attempt / `tests/test_reference_top1.py`

```text
0001: import sys
0002: from pathlib import Path
0003: sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
0004: 
0005: import torch
0006: from odyssey_v39_reference import make_inputs, qlaf_top1_decode_reference
0007: 
0008: def main():
0009:     inp = make_inputs(seed=123)
0010:     y1, s1, w1, a1 = qlaf_top1_decode_reference(**inp)
0011:     y2, s2, w2, a2 = qlaf_top1_decode_reference(**inp)
0012:     assert torch.equal(a1, a2)
0013:     assert torch.max(torch.abs(y1 - y2)).item() == 0.0
0014:     assert torch.max(torch.abs(s1 - s2)).item() == 0.0
0015:     assert torch.max(torch.abs(w1 - w2)).item() == 0.0
0016:     print({
0017:         "passed": True,
0018:         "active": a1.tolist(),
0019:         "max_abs_y": float(torch.max(torch.abs(y1 - y2)).item())
0020:     })
0021: 
0022: if __name__ == "__main__":
0023:     main()
```


## cpu_cuda_logic_sim / `README.md`

```text
0001: # Odyssey V39 CPU CUDA-Logic Simulation
0002: 
0003: This is the strongest CPU-side substitute for a CUDA parity check.
0004: 
0005: It fuzzes the intended CUDA top-1 decode kernel logic over many shapes and seeds:
0006: - batch sizes
0007: - hidden sizes
0008: - state counts
0009: - rank sizes
0010: - randomized pseudo-thread copy schedules
0011: - route/update/readout indexing
0012: 
0013: It does **not** prove:
0014: - CUDA build
0015: - CUDA device numerics
0016: - warp/thread synchronization behavior
0017: - GPU performance
0018: 
0019: It only proves that the intended CUDA indexing/math mirrors the reference under CPU simulation.
```


## cpu_cuda_logic_sim / `docs/LIMITS.md`

```text
0001: # Limits of CPU CUDA Simulation
0002: 
0003: A CPU can simulate the math and indexing of a CUDA kernel, but not the hardware.
0004: 
0005: CPU simulation can catch:
0006: - transposed indexing bugs
0007: - wrong flat index formula
0008: - wrong selected-state update
0009: - wrong denominator
0010: - wrong active state selection
0011: - wrong output projection layout
0012: 
0013: CPU simulation cannot catch:
0014: - nvcc compile errors
0015: - extension ABI errors
0016: - CUDA illegal memory access
0017: - race conditions from incorrect synchronization
0018: - warp-level behavior
0019: - GPU floating point differences
0020: - launch overhead
0021: - real latency
0022: 
0023: Therefore the next true gate remains real CUDA parity.
```


## cpu_cuda_logic_sim / `results/cuda_logic_sim_fuzz.csv`

```text
0001: case_id,seed,batch,hidden,states,rank,active_equal,max_abs_y,max_abs_state,max_abs_weight,passed
0002: 1,1,1,4,2,2,True,0.0,4.656612873077393e-10,0.0,True
0003: 2,1,1,4,2,4,True,0.0,2.3283064365386963e-10,0.0,True
0004: 3,1,1,4,2,8,True,0.0,4.656612873077393e-10,0.0,True
0005: 4,1,1,4,3,2,True,2.3283064365386963e-10,1.1641532182693481e-10,0.0,True
0006: 5,1,1,4,3,4,True,0.0,4.656612873077393e-10,0.0,True
0007: 6,1,1,4,3,8,True,0.0,9.313225746154785e-10,0.0,True
0008: 7,1,1,4,5,2,True,0.0,4.656612873077393e-10,0.0,True
0009: 8,1,1,4,5,4,True,2.3283064365386963e-10,1.862645149230957e-09,0.0,True
0010: 9,1,1,4,5,8,True,1.862645149230957e-09,9.313225746154785e-10,0.0,True
0011: 10,1,1,8,2,2,True,0.0,0.0,0.0,True
0012: 11,1,1,8,2,4,True,1.1641532182693481e-10,1.862645149230957e-09,0.0,True
0013: 12,1,1,8,2,8,True,0.0,9.313225746154785e-10,0.0,True
0014: 13,1,1,8,3,2,True,0.0,1.1641532182693481e-10,0.0,True
0015: 14,1,1,8,3,4,True,9.313225746154785e-10,4.656612873077393e-10,0.0,True
0016: 15,1,1,8,3,8,True,4.656612873077393e-10,9.313225746154785e-10,0.0,True
0017: 16,1,1,8,5,2,True,0.0,9.313225746154785e-10,0.0,True
0018: 17,1,1,8,5,4,True,0.0,1.862645149230957e-09,0.0,True
0019: 18,1,1,8,5,8,True,0.0,9.313225746154785e-10,0.0,True
0020: 19,1,1,16,2,2,True,0.0,1.3969838619232178e-09,0.0,True
0021: 20,1,1,16,2,4,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0022: 21,1,1,16,2,8,True,9.313225746154785e-10,1.127773430198431e-09,0.0,True
0023: 22,1,1,16,3,2,True,0.0,9.313225746154785e-10,0.0,True
0024: 23,1,1,16,3,4,True,3.725290298461914e-09,4.656612873077393e-10,0.0,True
0025: 24,1,1,16,3,8,True,0.0,1.862645149230957e-09,0.0,True
0026: 25,1,1,16,5,2,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0027: 26,1,1,16,5,4,True,2.3283064365386963e-10,1.862645149230957e-09,0.0,True
0028: 27,1,1,16,5,8,True,9.313225746154785e-10,9.313225746154785e-10,0.0,True
0029: 28,1,2,4,2,2,True,2.3283064365386963e-10,1.1641532182693481e-10,0.0,True
0030: 29,1,2,4,2,4,True,0.0,4.656612873077393e-10,0.0,True
0031: 30,1,2,4,2,8,True,7.450580596923828e-09,9.313225746154785e-10,0.0,True
0032: 31,1,2,4,3,2,True,9.313225746154785e-10,2.3283064365386963e-10,0.0,True
0033: 32,1,2,4,3,4,True,1.1641532182693481e-10,9.313225746154785e-10,0.0,True
0034: 33,1,2,4,3,8,True,4.656612873077393e-10,1.862645149230957e-09,0.0,True
0035: 34,1,2,4,5,2,True,0.0,1.862645149230957e-09,0.0,True
0036: 35,1,2,4,5,4,True,0.0,9.313225746154785e-10,0.0,True
0037: 36,1,2,4,5,8,True,2.3283064365386963e-10,3.725290298461914e-09,0.0,True
0038: 37,1,2,8,2,2,True,9.313225746154785e-10,9.313225746154785e-10,0.0,True
0039: 38,1,2,8,2,4,True,0.0,1.862645149230957e-09,0.0,True
0040: 39,1,2,8,2,8,True,9.313225746154785e-10,9.313225746154785e-10,0.0,True
0041: 40,1,2,8,3,2,True,0.0,4.656612873077393e-10,0.0,True
0042: 41,1,2,8,3,4,True,0.0,9.313225746154785e-10,0.0,True
0043: 42,1,2,8,3,8,True,7.450580596923828e-09,9.313225746154785e-10,0.0,True
0044: 43,1,2,8,5,2,True,1.862645149230957e-09,1.862645149230957e-09,0.0,True
0045: 44,1,2,8,5,4,True,2.3283064365386963e-10,4.656612873077393e-10,0.0,True
0046: 45,1,2,8,5,8,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0047: 46,1,2,16,2,2,True,0.0,9.313225746154785e-10,0.0,True
0048: 47,1,2,16,2,4,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0049: 48,1,2,16,2,8,True,9.313225746154785e-10,3.725290298461914e-09,0.0,True
0050: 49,1,2,16,3,2,True,1.862645149230957e-09,9.313225746154785e-10,0.0,True
0051: 50,1,2,16,3,4,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0052: 51,1,2,16,3,8,True,3.725290298461914e-09,9.313225746154785e-10,0.0,True
0053: 52,1,2,16,5,2,True,7.450580596923828e-09,1.862645149230957e-09,0.0,True
0054: 53,1,2,16,5,4,True,4.656612873077393e-10,1.862645149230957e-09,0.0,True
0055: 54,1,2,16,5,8,True,3.725290298461914e-09,1.862645149230957e-09,0.0,True
0056: 55,1,4,4,2,2,True,0.0,1.862645149230957e-09,0.0,True
0057: 56,1,4,4,2,4,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0058: 57,1,4,4,2,8,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0059: 58,1,4,4,3,2,True,3.725290298461914e-09,9.313225746154785e-10,0.0,True
0060: 59,1,4,4,3,4,True,0.0,9.313225746154785e-10,0.0,True
0061: 60,1,4,4,3,8,True,1.1641532182693481e-10,9.313225746154785e-10,0.0,True
0062: 61,1,4,4,5,2,True,2.3283064365386963e-10,1.862645149230957e-09,0.0,True
0063: 62,1,4,4,5,4,True,9.313225746154785e-10,9.313225746154785e-10,0.0,True
0064: 63,1,4,4,5,8,True,9.313225746154785e-10,3.725290298461914e-09,0.0,True
0065: 64,1,4,8,2,2,True,4.656612873077393e-10,0.0,0.0,True
0066: 65,1,4,8,2,4,True,0.0,4.656612873077393e-10,0.0,True
0067: 66,1,4,8,2,8,True,3.725290298461914e-09,3.725290298461914e-09,0.0,True
0068: 67,1,4,8,3,2,True,9.313225746154785e-10,3.725290298461914e-09,0.0,True
0069: 68,1,4,8,3,4,True,1.862645149230957e-09,1.862645149230957e-09,0.0,True
0070: 69,1,4,8,3,8,True,7.450580596923828e-09,3.725290298461914e-09,0.0,True
0071: 70,1,4,8,5,2,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0072: 71,1,4,8,5,4,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0073: 72,1,4,8,5,8,True,3.725290298461914e-09,3.725290298461914e-09,0.0,True
0074: 73,1,4,16,2,2,True,1.1641532182693481e-10,1.3969838619232178e-09,0.0,True
0075: 74,1,4,16,2,4,True,3.725290298461914e-09,1.862645149230957e-09,0.0,True
0076: 75,1,4,16,2,8,True,3.725290298461914e-09,1.862645149230957e-09,0.0,True
0077: 76,1,4,16,3,2,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0078: 77,1,4,16,3,4,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0079: 78,1,4,16,3,8,True,3.725290298461914e-09,3.725290298461914e-09,0.0,True
0080: 79,1,4,16,5,2,True,1.862645149230957e-09,1.862645149230957e-09,0.0,True
0081: 80,1,4,16,5,4,True,3.725290298461914e-09,1.862645149230957e-09,0.0,True
0082: 81,1,4,16,5,8,True,7.450580596923828e-09,1.862645149230957e-09,0.0,True
0083: 82,1,8,4,2,2,True,8.731149137020111e-11,3.725290298461914e-09,0.0,True
0084: 83,1,8,4,2,4,True,5.820766091346741e-11,9.313225746154785e-10,0.0,True
0085: 84,1,8,4,2,8,True,7.450580596923828e-09,1.862645149230957e-09,0.0,True
0086: 85,1,8,4,3,2,True,9.313225746154785e-10,9.313225746154785e-10,0.0,True
0087: 86,1,8,4,3,4,True,7.450580596923828e-09,1.862645149230957e-09,0.0,True
0088: 87,1,8,4,3,8,True,3.725290298461914e-09,1.862645149230957e-09,0.0,True
0089: 88,1,8,4,5,2,True,9.313225746154785e-10,9.313225746154785e-10,0.0,True
0090: 89,1,8,4,5,4,True,1.862645149230957e-09,1.862645149230957e-09,0.0,True
0091: 90,1,8,4,5,8,True,4.656612873077393e-10,3.725290298461914e-09,0.0,True
0092: 91,1,8,8,2,2,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0093: 92,1,8,8,2,4,True,9.313225746154785e-10,3.725290298461914e-09,0.0,True
0094: 93,1,8,8,2,8,True,7.450580596923828e-09,1.862645149230957e-09,0.0,True
0095: 94,1,8,8,3,2,True,1.862645149230957e-09,9.313225746154785e-10,0.0,True
0096: 95,1,8,8,3,4,True,7.450580596923828e-09,3.725290298461914e-09,0.0,True
0097: 96,1,8,8,3,8,True,3.725290298461914e-09,1.862645149230957e-09,0.0,True
0098: 97,1,8,8,5,2,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0099: 98,1,8,8,5,4,True,7.450580596923828e-09,3.725290298461914e-09,0.0,True
0100: 99,1,8,8,5,8,True,9.313225746154785e-10,3.725290298461914e-09,0.0,True
0101: 100,1,8,16,2,2,True,1.862645149230957e-09,1.862645149230957e-09,0.0,True
0102: 101,1,8,16,2,4,True,7.450580596923828e-09,1.862645149230957e-09,0.0,True
0103: 102,1,8,16,2,8,True,7.450580596923828e-09,1.862645149230957e-09,0.0,True
0104: 103,1,8,16,3,2,True,1.862645149230957e-09,3.725290298461914e-09,0.0,True
0105: 104,1,8,16,3,4,True,3.725290298461914e-09,1.862645149230957e-09,0.0,True
0106: 105,1,8,16,3,8,True,7.450580596923828e-09,3.725290298461914e-09,0.0,True
0107: 106,1,8,16,5,2,True,1.862645149230957e-09,1.862645149230957e-09,0.0,True
0108: 107,1,8,16,5,4,True,7.450580596923828e-09,1.862645149230957e-09,0.0,True
0109: 108,1,8,16,5,8,True,7.450580596923828e-09,3.725290298461914e-09,0.0,True
0110: 109,2,1,4,2,2,True,0.0,4.656612873077393e-10,0.0,True
0111: 110,2,1,4,2,4,True,0.0,9.313225746154785e-10,0.0,True
0112: 111,2,1,4,2,8,True,0.0,9.313225746154785e-10,0.0,True
0113: 112,2,1,4,3,2,True,0.0,0.0,0.0,True
0114: 113,2,1,4,3,4,True,0.0,9.313225746154785e-10,0.0,True
0115: 114,2,1,4,3,8,True,1.862645149230957e-09,1.862645149230957e-09,0.0,True
0116: 115,2,1,4,5,2,True,0.0,4.656612873077393e-10,0.0,True
0117: 116,2,1,4,5,4,True,0.0,9.313225746154785e-10,0.0,True
0118: 117,2,1,4,5,8,True,1.862645149230957e-09,9.313225746154785e-10,0.0,True
0119: 118,2,1,8,2,2,True,3.725290298461914e-09,0.0,0.0,True
0120: 119,2,1,8,2,4,True,0.0,9.313225746154785e-10,0.0,True
0121: 120,2,1,8,2,8,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0122: 121,2,1,8,3,2,True,0.0,4.656612873077393e-10,0.0,True
0123: 122,2,1,8,3,4,True,0.0,9.313225746154785e-10,0.0,True
0124: 123,2,1,8,3,8,True,9.313225746154785e-10,9.313225746154785e-10,0.0,True
0125: 124,2,1,8,5,2,True,0.0,2.582964953035116e-10,0.0,True
0126: 125,2,1,8,5,4,True,0.0,4.656612873077393e-10,0.0,True
0127: 126,2,1,8,5,8,True,9.313225746154785e-10,9.313225746154785e-10,0.0,True
0128: 127,2,1,16,2,2,True,0.0,1.862645149230957e-09,0.0,True
0129: 128,2,1,16,2,4,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0130: 129,2,1,16,2,8,True,2.3283064365386963e-10,1.862645149230957e-09,0.0,True
0131: 130,2,1,16,3,2,True,0.0,9.313225746154785e-10,0.0,True
0132: 131,2,1,16,3,4,True,4.656612873077393e-10,4.656612873077393e-10,0.0,True
0133: 132,2,1,16,3,8,True,3.725290298461914e-09,1.862645149230957e-09,0.0,True
0134: 133,2,1,16,5,2,True,9.313225746154785e-10,4.656612873077393e-10,0.0,True
0135: 134,2,1,16,5,4,True,1.862645149230957e-09,9.313225746154785e-10,0.0,True
0136: 135,2,1,16,5,8,True,3.725290298461914e-09,3.725290298461914e-09,0.0,True
0137: 136,2,2,4,2,2,True,9.313225746154785e-10,9.313225746154785e-10,0.0,True
0138: 137,2,2,4,2,4,True,0.0,9.313225746154785e-10,0.0,True
0139: 138,2,2,4,2,8,True,1.862645149230957e-09,1.862645149230957e-09,0.0,True
0140: 139,2,2,4,3,2,True,0.0,0.0,0.0,True
0141: 140,2,2,4,3,4,True,0.0,9.313225746154785e-10,0.0,True
0142: 141,2,2,4,3,8,True,0.0,9.313225746154785e-10,0.0,True
0143: 142,2,2,4,5,2,True,0.0,9.313225746154785e-10,0.0,True
0144: 143,2,2,4,5,4,True,1.862645149230957e-09,9.313225746154785e-10,0.0,True
0145: 144,2,2,4,5,8,True,9.313225746154785e-10,9.313225746154785e-10,0.0,True
0146: 145,2,2,8,2,2,True,4.656612873077393e-10,2.9103830456733704e-10,0.0,True
0147: 146,2,2,8,2,4,True,3.725290298461914e-09,9.313225746154785e-10,0.0,True
0148: 147,2,2,8,2,8,True,1.862645149230957e-09,3.725290298461914e-09,0.0,True
0149: 148,2,2,8,3,2,True,0.0,1.862645149230957e-09,0.0,True
0150: 149,2,2,8,3,4,True,4.656612873077393e-10,1.862645149230957e-09,0.0,True
... truncated after 150 of 3241 lines ...
```


## cpu_cuda_logic_sim / `results/summary.json`

```text
0001: {
0002:   "type": "CPU CUDA-logic simulation, not real CUDA",
0003:   "total_cases": 3240,
0004:   "passed_cases": 3240,
0005:   "failed_cases": 0,
0006:   "max_abs_y_global": 1.4901161193847656e-08,
0007:   "max_abs_state_global": 7.450580596923828e-09,
0008:   "max_abs_weight_global": 0.0,
0009:   "cuda_hardware_proven": false,
0010:   "cuda_build_proven": false,
0011:   "gpu_speed_proven": false,
0012:   "next_true_gate": "Run CUDA parity on real CUDA machine."
0013: }
```


## cpu_surrogate_cuda_sequence / `README.md`

```text
0001: # Odyssey V39 CPU Surrogate for CUDA Sequence
0002: 
0003: This runs the CUDA sequence locally on CPU in small passes:
0004: 
0005: 1. top-1 parity using a CPU mirror of the CUDA scalar kernel
0006: 2. CPU surrogate timing for the same top-1 boundary
0007: 3. full cached-decode CPU surrogate vs explicit Transformer KV baseline
0008: 
0009: Important:
0010: 
0011: This does **not** prove CUDA parity or CUDA speed. It only de-risks the algorithm and indexing before running on a CUDA machine.
0012: 
0013: Outputs:
0014: - `results/cpu_top1_parity.csv`
0015: - `results/cpu_top1_timing_surrogate.csv`
0016: - `results/full_cached_decode_cpu_surrogate.csv`
0017: - `results/summary.json`
```


## cpu_surrogate_cuda_sequence / `docs/INTERPRETATION.md`

```text
0001: # Interpretation
0002: 
0003: ## What this proves
0004: 
0005: If parity passes here, the CPU mirror of the intended CUDA scalar kernel matches the vectorized reference for:
0006: - top-1 active state selection
0007: - selected state update
0008: - state weight update
0009: - state-bank readout
0010: - output hidden update
0011: 
0012: ## What this does not prove
0013: 
0014: It does not prove:
0015: - CUDA builds
0016: - CUDA numerics
0017: - GPU speed
0018: - production kernel performance
0019: - prefill speed
0020: - Route B readiness
0021: 
0022: ## Next actual GPU step
0023: 
0024: Run the CUDA gate package on a CUDA machine:
0025: 
0026: ```bash
0027: bash scripts/run_local_cuda_gate.sh
0028: ```
0029: 
0030: Only if CUDA parity passes should timing be run.
```


## cpu_surrogate_cuda_sequence / `results/cpu_top1_parity.csv`

```text
0001: seed,batch,active_equal,max_abs_y,max_abs_state,max_abs_weight,passed
0002: 1,1,True,9.313225746154785e-10,4.656612873077393e-10,0.0,True
0003: 1,2,True,0.0,9.313225746154785e-10,0.0,True
0004: 1,4,True,4.656612873077393e-10,1.862645149230957e-09,0.0,True
0005: 2,1,True,0.0,9.313225746154785e-10,0.0,True
0006: 2,2,True,4.656612873077393e-10,1.862645149230957e-09,0.0,True
0007: 2,4,True,3.725290298461914e-09,1.862645149230957e-09,0.0,True
0008: 3,1,True,0.0,9.313225746154785e-10,0.0,True
0009: 3,2,True,0.0,9.313225746154785e-10,0.0,True
0010: 3,4,True,1.862645149230957e-09,3.725290298461914e-09,0.0,True
0011: 4,1,True,9.313225746154785e-10,2.3283064365386963e-10,0.0,True
0012: 4,2,True,3.725290298461914e-09,3.725290298461914e-09,0.0,True
0013: 4,4,True,9.313225746154785e-10,3.725290298461914e-09,0.0,True
0014: 5,1,True,4.656612873077393e-10,9.313225746154785e-10,0.0,True
0015: 5,2,True,0.0,7.566995918750763e-10,0.0,True
0016: 5,4,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0017: 6,1,True,0.0,9.313225746154785e-10,0.0,True
0018: 6,2,True,1.862645149230957e-09,1.862645149230957e-09,0.0,True
0019: 6,4,True,4.656612873077393e-10,1.862645149230957e-09,0.0,True
0020: 7,1,True,0.0,9.313225746154785e-10,0.0,True
0021: 7,2,True,0.0,9.313225746154785e-10,0.0,True
0022: 7,4,True,9.313225746154785e-10,1.862645149230957e-09,0.0,True
0023: 8,1,True,4.656612873077393e-10,9.313225746154785e-10,0.0,True
0024: 8,2,True,0.0,9.313225746154785e-10,0.0,True
0025: 8,4,True,3.725290298461914e-09,1.862645149230957e-09,0.0,True
0026: 9,1,True,8.731149137020111e-11,4.656612873077393e-10,0.0,True
0027: 9,2,True,9.313225746154785e-10,9.313225746154785e-10,0.0,True
0028: 9,4,True,2.3283064365386963e-10,1.862645149230957e-09,0.0,True
0029: 10,1,True,0.0,5.820766091346741e-11,0.0,True
0030: 10,2,True,9.313225746154785e-10,4.656612873077393e-10,0.0,True
0031: 10,4,True,1.862645149230957e-09,1.862645149230957e-09,0.0,True
```


## cpu_surrogate_cuda_sequence / `results/cpu_top1_timing_surrogate.csv`

```text
0001: batch,reference_mean_ms,cpu_kernel_mirror_mean_ms,mirror_vs_reference_speed,note
0002: 1,0.25880362497900933,2.12143127496347,0.12199481926816876,CPU surrogate timing only; not CUDA speed
0003: 2,0.25881289998324064,4.298860824906114,0.060204996282682166,CPU surrogate timing only; not CUDA speed
0004: 4,0.25728445000368083,8.667828550142076,0.029682687943736914,CPU surrogate timing only; not CUDA speed
0005: 8,0.25617304984280054,17.31321584993566,0.014796387457027662,CPU surrogate timing only; not CUDA speed
0006: 16,0.2632122000250092,33.59468972503237,0.007834934692933993,CPU surrogate timing only; not CUDA speed
```


## cpu_surrogate_cuda_sequence / `results/full_cached_decode_cpu_surrogate.csv`

```text
0001: seed,context,batch,v39_seconds,transformer_kv_seconds,v39_tokens_per_sec,transformer_tokens_per_sec,v39_speedup_vs_transformer_kv,v39_cache_elements,transformer_kv_elements,cache_reduction_percent,logit_l1_gap_proxy
0002: 1,8,2,0.0034707099994193413,0.0026325210001232335,4610.007751346797,6077.824260186721,0.758496388509458,30,256,88.28125,0.0001028089682222344
0003: 1,16,2,0.005027177000556549,0.004967490999661095,6365.40149600011,6441.883840792703,0.9881273325190567,30,512,94.140625,6.57759010209702e-05
0004: 1,32,2,0.01075544200011791,0.01000791400019807,5950.476047316176,6394.939045113033,0.9304976959652942,30,1024,97.0703125,5.579085336648859e-05
0005: 1,64,2,0.021418982999421132,0.01921058500010986,5976.007357747066,6662.993344516474,0.8968952914631401,30,2048,98.53515625,4.3631865992210805e-05
0006: 1,128,2,0.043329280999387265,0.038656448000438104,5908.244819562554,6622.439806086133,0.8921553071924909,30,4096,99.267578125,4.070403520017862e-05
0007: 2,8,2,0.002410459000202536,0.002135202000317804,6637.739948555697,7493.4362170972845,0.8858072259840952,30,256,88.28125,0.0001261759753106162
0008: 2,16,2,0.010269579999658163,0.004071702000146615,3115.9989017141074,7859.1213204816395,0.39648184251762464,30,512,94.140625,0.00011088138853665441
0009: 2,32,2,0.010788665999825753,0.009792838000066695,5932.151389340783,6535.388413406218,0.9076968366825758,30,1024,97.0703125,8.273788262158632e-05
0010: 2,64,2,0.020284746000470477,0.020481651999944006,6310.160353845753,6249.495890289999,1.009707097119627,30,2048,98.53515625,7.09134474163875e-05
0011: 2,128,2,0.04403694099983113,0.03887041500001942,5813.301155522626,6585.985768350353,0.8826774548252222,30,4096,99.267578125,4.6134082367643714e-05
0012: 3,8,2,0.0025066600001082406,0.002194239999880665,6382.995699181022,7291.818579950311,0.8753640301380782,30,256,88.28125,9.790161857381463e-05
0013: 3,16,2,0.005057991000285256,0.004823840999961249,6326.622565796439,6633.717819525367,0.9537069163802779,30,512,94.140625,0.00010192287300014868
0014: 3,32,2,0.010133687000234204,0.009662513999501243,6315.569051868374,6623.535034806007,0.9535042871639837,30,1024,97.0703125,5.2567065722541884e-05
0015: 3,64,2,0.026982192999639665,0.022446889999628183,4743.869410529729,5702.348966922376,0.8319149596153267,30,2048,98.53515625,6.0422757087508217e-05
0016: 3,128,2,0.035603301000264764,0.04719355999986874,7190.3445132263505,5424.468931793067,1.3255388875182608,30,4096,99.267578125,3.494138582027517e-05
```


## cpu_surrogate_cuda_sequence / `results/summary.json`

```text
0001: {
0002:   "type": "CPU surrogate for CUDA sequence",
0003:   "cuda_proof": false,
0004:   "top1_parity_all_passed": true,
0005:   "parity_rows": 30,
0006:   "timing_rows": [
0007:     {
0008:       "batch": 1,
0009:       "reference_mean_ms": 0.25880362497900933,
0010:       "cpu_kernel_mirror_mean_ms": 2.12143127496347,
0011:       "mirror_vs_reference_speed": 0.12199481926816876,
0012:       "note": "CPU surrogate timing only; not CUDA speed"
0013:     },
0014:     {
0015:       "batch": 2,
0016:       "reference_mean_ms": 0.25881289998324064,
0017:       "cpu_kernel_mirror_mean_ms": 4.298860824906114,
0018:       "mirror_vs_reference_speed": 0.060204996282682166,
0019:       "note": "CPU surrogate timing only; not CUDA speed"
0020:     },
0021:     {
0022:       "batch": 4,
0023:       "reference_mean_ms": 0.25728445000368083,
0024:       "cpu_kernel_mirror_mean_ms": 8.667828550142076,
0025:       "mirror_vs_reference_speed": 0.029682687943736914,
0026:       "note": "CPU surrogate timing only; not CUDA speed"
0027:     },
0028:     {
0029:       "batch": 8,
0030:       "reference_mean_ms": 0.25617304984280054,
0031:       "cpu_kernel_mirror_mean_ms": 17.31321584993566,
0032:       "mirror_vs_reference_speed": 0.014796387457027662,
0033:       "note": "CPU surrogate timing only; not CUDA speed"
0034:     },
0035:     {
0036:       "batch": 16,
0037:       "reference_mean_ms": 0.2632122000250092,
0038:       "cpu_kernel_mirror_mean_ms": 33.59468972503237,
0039:       "mirror_vs_reference_speed": 0.007834934692933993,
0040:       "note": "CPU surrogate timing only; not CUDA speed"
0041:     }
0042:   ],
0043:   "decode_context_summary": {
0044:     "8": {
0045:       "n": 3,
0046:       "speedup_mean": 0.8398892148772105,
0047:       "speedup_min": 0.758496388509458,
0048:       "speedup_max": 0.8858072259840952,
0049:       "cache_reduction_mean_percent": 88.28125
0050:     },
0051:     "16": {
0052:       "n": 3,
0053:       "speedup_mean": 0.7794386971389864,
0054:       "speedup_min": 0.39648184251762464,
0055:       "speedup_max": 0.9881273325190567,
0056:       "cache_reduction_mean_percent": 94.140625
0057:     },
0058:     "32": {
0059:       "n": 3,
0060:       "speedup_mean": 0.9305662732706179,
0061:       "speedup_min": 0.9076968366825758,
0062:       "speedup_max": 0.9535042871639837,
0063:       "cache_reduction_mean_percent": 97.0703125
0064:     },
0065:     "64": {
0066:       "n": 3,
0067:       "speedup_mean": 0.9128391160660312,
0068:       "speedup_min": 0.8319149596153267,
0069:       "speedup_max": 1.009707097119627,
0070:       "cache_reduction_mean_percent": 98.53515625
0071:     },
0072:     "128": {
0073:       "n": 3,
0074:       "speedup_mean": 1.0334572165119913,
0075:       "speedup_min": 0.8826774548252222,
0076:       "speedup_max": 1.3255388875182608,
0077:       "cache_reduction_mean_percent": 99.267578125
0078:     }
0079:   },
0080:   "next_gate": "Run actual CUDA parity on CUDA machine; CPU surrogate cannot prove CUDA correctness."
0081: }
```
