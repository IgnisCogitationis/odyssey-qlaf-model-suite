
# Odyssey V39 Full Engine Audit Pass 7

Date: 2026-04-28

## Scope

This pass audits every currently available engine artifact against the entire project goal:

> **QLAF causal state cache + AION adaptive hierarchy + TSC residual correction + decode-branch specialization + Route B CUDA/HF deployment**, with the objective of replacing the Transformer architecture where QLAF/State-cache serving can outperform attention/KV-cache serving.

This pass adds the newest result:

- CPU CUDA-logic simulation ran **3,240 fuzz cases** and passed all of them.
- This strongly de-risks indexing/math of the intended CUDA top-1 kernel.
- It still does **not** prove CUDA build, CUDA device numerics, or GPU speed.

## Executive verdict

The current engine is no longer just a sketch. It is now a staged, evidence-gated replacement program.

But it is still not a finished Transformer replacement because the decisive hardware gate remains open:

```text
Real CUDA top-1 decode parity has not yet run on a CUDA machine.
```

Current strongest facts:

| Area | Status |
|---|---|
| independent full-forward parity | passed in reference pipeline |
| cached decode vs explicit KV proxy | scaled CPU/proxy table exists |
| 3-seed stabilized training | passed |
| CPU CUDA-logic simulation | 3,240/3,240 cases passed |
| CUDA top-1 extension | written as parity harness |
| CPU reference for CUDA harness | passed |
| real CUDA build/parity | not run here, CUDA unavailable |
| CUDA timing | blocked |
| prefill CUDA | blocked |
| Route B server | blocked until CUDA path stabilizes |

## Most important interpretation

The algorithmic replacement path is coherent:

1. **QLAF cache** replaces Transformer KV cache as the dominant decode memory.
2. **AION** decides when a cheap top-1 path is safe and when widening/refresh is needed.
3. **TSC** repairs local/content errors as a residual, not as a second full mixer.
4. **Decode-branch specialization** makes inference the first win condition.
5. **Route B** packages the result only after CUDA parity and timing.

The weak point is no longer the high-level architecture. The weak point is proving that the CUDA path implements the already-tested reference path and then measuring it.

---

# Latest result summaries

## 3-seed training gate

```json
{
  "seeds_found": 3,
  "all_seeds_complete": true,
  "all_v39_train_reduced": true,
  "all_v39_val_not_blowup": true,
  "all_transformer_train_reduced": true,
  "all_transformer_val_not_blowup": true,
  "v39_train_delta_mean": 0.17383305231730142,
  "v39_val_delta_mean": 0.01929783821105957,
  "transformer_train_delta_mean": 0.20308883984883627,
  "transformer_val_delta_mean": 0.027557373046875,
  "v39_final_train_loss_mean": 3.551933447519938,
  "transformer_final_train_loss_mean": 3.7313548723856607,
  "cuda_unlocked": true,
  "cuda_gate": "unlocked_for_top1_decode_parity_harness_only"
}
```

## CPU CUDA-logic simulation

```json
{
  "type": "CPU CUDA-logic simulation, not real CUDA",
  "total_cases": 3240,
  "passed_cases": 3240,
  "failed_cases": 0,
  "max_abs_y_global": 1.4901161193847656e-08,
  "max_abs_state_global": 7.450580596923828e-09,
  "max_abs_weight_global": 0.0,
  "cuda_hardware_proven": false,
  "cuda_build_proven": false,
  "gpu_speed_proven": false,
  "next_true_gate": "Run CUDA parity on real CUDA machine."
}
```

## CPU surrogate CUDA sequence

```json
{
  "type": "CPU surrogate for CUDA sequence",
  "cuda_proof": false,
  "top1_parity_all_passed": true,
  "parity_rows": 30,
  "timing_rows": [
    {
      "batch": 1,
      "reference_mean_ms": 0.25880362497900933,
      "cpu_kernel_mirror_mean_ms": 2.12143127496347,
      "mirror_vs_reference_speed": 0.12199481926816876,
      "note": "CPU surrogate timing only; not CUDA speed"
    },
    {
      "batch": 2,
      "reference_mean_ms": 0.25881289998324064,
      "cpu_kernel_mirror_mean_ms": 4.298860824906114,
      "mirror_vs_reference_speed": 0.060204996282682166,
      "note": "CPU surrogate timing only; not CUDA speed"
    },
    {
      "batch": 4,
      "reference_mean_ms": 0.25728445000368083,
      "cpu_kernel_mirror_mean_ms": 8.667828550142076,
      "mirror_vs_reference_speed": 0.029682687943736914,
      "note": "CPU surrogate timing only; not CUDA speed"
    },
    {
      "batch": 8,
      "reference_mean_ms": 0.25617304984280054,
      "cpu_kernel_mirror_mean_ms": 17.31321584993566,
      "mirror_vs_reference_speed": 0.014796387457027662,
      "note": "CPU surrogate timing only; not CUDA speed"
    },
    {
      "batch": 16,
      "reference_mean_ms": 0.2632122000250092,
      "cpu_kernel_mirror_mean_ms": 33.59468972503237,
      "mirror_vs_reference_speed": 0.007834934692933993,
      "note": "CPU surrogate timing only; not CUDA speed"
    }
  ],
  "decode_context_summary": {
    "8": {
      "n": 3,
      "speedup_mean": 0.8398892148772105,
      "speedup_min": 0.758496388509458,
      "speedup_max": 0.8858072259840952,
      "cache_reduction_mean_percent": 88.28125
    },
    "16": {
      "n": 3,
      "speedup_mean": 0.7794386971389864,
      "speedup_min": 0.39648184251762464,
      "speedup_max": 0.9881273325190567,
      "cache_reduction_mean_percent": 94.140625
    },
    "32": {
      "n": 3,
      "speedup_mean": 0.9305662732706179,
      "speedup_min": 0.9076968366825758,
      "speedup_max": 0.9535042871639837,
      "cache_reduction_mean_percent": 97.0703125
    },
    "64": {
      "n": 3,
      "speedup_mean": 0.9128391160660312,
      "speedup_min": 0.8319149596153267,
      "speedup_max": 1.009707097119627,
      "cache_reduction_mean_percent": 98.53515625
    },
    "128": {
      "n": 3,
      "speedup_mean": 1.0334572165119913,
      "speedup_min": 0.8826774548252222,
      "speedup_max": 1.3255388875182608,
      "cache_reduction_mean_percent": 99.267578125
    }
  },
  "next_gate": "Run actual CUDA parity on CUDA machine; CPU surrogate cannot prove CUDA correctness."
}
```

## Local CUDA gate attempt

```json
{
  "stage": "local_cuda_gate",
  "platform": "Linux-4.4.0-x86_64-with-glibc2.41",
  "python": "3.13.5 (main, Jun 25 2025, 18:55:22) [GCC 14.2.0]",
  "cuda_available": false,
  "parity_passed": false,
  "next_allowed_step": "patch_cuda_for_parity_only",
  "torch_cuda": {
    "torch_imported": true,
    "torch_version": "2.10.0+cpu",
    "cuda_available": false,
    "torch_cuda_version": null,
    "device_count": 0,
    "device_name": null
  }
}
```

---

# Full engine review from start to finish

## 1. Engine contract layer

The initial engine stack correctly separated the engine into:

- configuration;
- cache;
- AION policy;
- TSC policy;
- dispatcher;
- engine interface;
- Route B deployment specifications.

This is the right shape because it prevents the architecture from collapsing into one monolithic script.

### What is right

- The engine is being treated as a runtime with state, not just a model class.
- Prefill and decode are separated.
- CUDA is gated through a dispatcher.
- AION and TSC are first-class policies instead of being buried inside the forward pass.

### What is insufficient

The original stack is still interface-level. It does not yet enforce production tensor shapes or lifecycle invariants.

Required hardening:

```text
EngineConfig:
  hidden_size
  num_layers
  num_states
  state_rank
  top_k_default
  aion_policy
  tsc_policy
  dtype
  device
  cache_layout_version
  kernel_abi_version
  decode_branch_mode
  prefill_mode
  hierarchy_levels
```

The engine must refuse to run if the cache layout, dtype, or kernel ABI mismatches.

## 2. QLAF causal state cache

The cache is the core Transformer replacement mechanism.

Transformer decode stores:

```text
K,V for every token, every layer
O(batch * layers * context * hidden)
```

QLAF decode stores:

```text
state summaries and weights
O(batch * layers * states * rank)
```

This is the structural advantage.

### Current evidence

The cached-decode proxy and CPU surrogate show cache reduction rising with context:

```text
ctx 8:   ~88.28% reduction
ctx 16:  ~94.14% reduction
ctx 32:  ~97.07% reduction
ctx 64:  ~98.54% reduction
ctx 128: ~99.27% reduction
```

### Required production cache

```text
state_summary      [B, L, S, R]
state_weight       [B, L, S]
active_state_ids   [B, L, K]
route_confidence   [B, L]
route_margin       [B, L]
hierarchy_level    [B, L, S]
refresh_counter    [B, L]
position           [B]
valid              [B]
```

### Missing runtime operations

The cache must support:

- `allocate(batch, config)`;
- `reset_rows(indices)`;
- `repack_batch(old_to_new)`;
- `invalidate(request_id)`;
- `partial_refresh(scope)`;
- `validate_layout(config, kernel_abi)`;
- `elements()` and `bytes()`;
- mixed precision state storage;
- state offload/failover.

Until these exist, V39 is not a production server engine.

## 3. Full-forward vs cached-decode parity

This gate matters because a replacement engine must not use one algorithm for training and another incompatible algorithm for serving.

### Current status

Independent full-forward parity exists in the sharded pipeline.

This is stronger than the earlier PyTorch bridge where `forward_full()` called `forward_cached()`.

### Required next hardening

Move independent parity into the PyTorch reference model as a first-class test:

```text
forward_full_independent()
forward_cached_decode()
assert max_abs_diff <= tolerance
```

Then repeat at:

- top-1;
- top-2;
- AION mixed top-k;
- TSC off/on;
- batch sizes 1, 2, 4, 8;
- contexts 8, 16, 32, 64, 128.

## 4. AION adaptive hierarchy

AION is the architectural piece that prevents QLAF from becoming a lossy fixed-state bottleneck.

### Current status

AION currently exists as:

- confidence threshold;
- top-1/top-2 switch;
- periodic refresh concept.

### What it needs to become

AION should be a hierarchy controller:

```text
Inputs:
  route_confidence
  route_margin
  entropy
  cache_age
  position
  repeated_low_confidence
  retrieval_failure_flag
  refresh_counter

Outputs:
  top_k
  refresh_scope
  promote_state
  split_state
  merge_state
  tsc_scale
  fallback_flag
```

### Required tests

- confident token stays top-1;
- ambiguous token widens to top-2;
- repeated uncertainty widens or refreshes;
- periodic refresh fires;
- cache repair does not break parity;
- AION does not over-widen and destroy speed.

Without these tests, AION remains a policy idea rather than a replacement-grade hierarchy.

## 5. TSC residual correction

TSC should stay small.

The correct role:

```text
QLAF = memory/retrieval substrate
AION = adaptive controller
TSC = residual correction
```

The incorrect role:

```text
TSC = second full mixer that duplicates attention cost
```

### Current status

TSC has been included in training and parity gates as a residual effect. It has not yet been proven by ablation.

### Required ablation table

| Variant | Expected purpose |
|---|---|
| QLAF only | base state-cache engine |
| QLAF + AION | anti-collapse adaptive routing |
| QLAF + TSC | residual correction value |
| QLAF + AION + TSC | full V39 |

Measure:

- train loss;
- val loss;
- decode time;
- cache memory;
- top-k frequency;
- TSC scale;
- p50/p95 decode.

## 6. Training evidence

### Current status

3-seed stabilized training passed.

This proves:

- V39 can reduce loss under the tiny stabilized recipe;
- validation did not blow up;
- CUDA top-1 parity harness is allowed.

It does not prove:

- real language quality;
- large-scale convergence;
- Transformer replacement quality;
- robustness to real corpora.

### Next training ladder

1. Tiny synthetic, already passed.
2. Larger synthetic delayed-disambiguation tasks.
3. Small real text corpus.
4. Matched tokenizer.
5. 3 seeds.
6. 5 seeds.
7. Scaling contexts.
8. Long-context retrieval/disambiguation benchmark.

The replacement claim cannot be strong until V39 matches or beats Transformer on at least small real text and synthetic long-context tasks.

## 7. Cached decode benchmark

### Current status

CPU/proxy cached decode shows strong cache memory advantage and mixed speed results depending implementation.

Earlier sharded proxy showed V39 speedup improving with context. The later PyTorch CPU surrogate was more conservative and sometimes slower, which is expected because Python/PyTorch implementation details dominate.

### Interpretation

The real speed question cannot be answered on CPU proxy.

The structural reason V39 can win remains:

```text
Transformer cached decode reads O(context * hidden) per step.
QLAF top-1 decode reads/updates O(states * rank + hidden) per step.
```

But the actual win depends on:

- CUDA kernel fusion;
- avoiding Python overhead;
- memory coalescing;
- launch overhead;
- readout layout;
- state/rank sizes;
- batching.

## 8. CUDA top-1 decode

This is now the decisive next artifact.

### Current status

The CUDA harness includes:

- `bindings.cpp`;
- `top1_decode.cu`;
- PyTorch reference;
- CPU reference test;
- CUDA parity test;
- local CUDA gate runner;
- parity-fail patch guide;
- CPU CUDA-logic simulation.

CPU CUDA-logic simulation passed:

```text
3,240 / 3,240 fuzz cases
max_abs_y <= 1.49e-08
max_abs_state <= 7.45e-09
max_abs_weight = 0
```

### What this proves

It de-risks:

- route argmax indexing;
- rank projection layout;
- selected-state update;
- state-weight update;
- state-bank readout;
- output projection layout.

### What this does not prove

It does not prove:

- nvcc build;
- PyTorch extension ABI;
- CUDA device memory correctness;
- synchronization correctness;
- illegal memory access absence;
- GPU floating point behavior;
- speed.

### Required real gate

On CUDA machine:

```bash
bash scripts/run_local_cuda_gate.sh
cat results/local_cuda_gate_report.json
```

If pass:

```bash
python3 scripts/make_timing_harness_if_parity_passed.py
PYTHONPATH=.:odyssey_v39_cuda_ext python3 scripts/run_cuda_top1_timing.py
```

If fail:

- patch only parity;
- no timing.

## 9. Prefill

Prefill is not yet a win condition.

The correct sequencing is:

1. top-1 decode parity;
2. top-1 decode timing;
3. top-1 decode optimization;
4. explicit KV Transformer comparison;
5. only then prefill CUDA.

Prefill is harder because it is a scan over prompt tokens. It needs:

- fused route/rank scan;
- blockwise state accumulation;
- top-k prefill;
- no future leakage;
- parity against independent full forward.

## 10. Route B deployment

Route B is the right deployment strategy but should remain blocked.

Route B requires:

- HF custom config;
- custom model code;
- safetensors;
- CUDA wheel;
- server with cache manager;
- request batching;
- streaming;
- metrics.

It should not be implemented as a final deployment until CUDA top-1 decode is stable.

---

# What can be done to thoroughly replace Transformer

## Stage A: Prove the state engine

Must pass:

- independent full-forward parity;
- cached decode parity;
- no-future leakage;
- batch equivalence;
- cache reset/repack;
- top-1/top-2 routing;
- 3-seed training stability.

Status: mostly passed at tiny/reference scale.

## Stage B: Prove CUDA decode

Must pass:

- CUDA builds;
- CUDA top-1 parity;
- CUDA top-1 timing;
- CUDA top-1 vs PyTorch reference speedup;
- CUDA top-1 vs explicit Transformer KV baseline.

Status: blocked by no CUDA machine here.

## Stage C: Prove quality

Must pass:

- small real text training;
- synthetic delayed disambiguation;
- long-context retrieval;
- 3 seeds then 5 seeds;
- ablations.

Status: not yet done beyond tiny stabilized training.

## Stage D: Prove production viability

Must pass:

- Route B HF load;
- custom CUDA wheel load;
- custom server;
- p50/p95 latency;
- memory;
- batching;
- fallback.

Status: planned, not unlocked.

---

# Final replacement strategy

The final engine should be:

```text
Input tokens
  -> embeddings
  -> per-layer QLAF route
  -> top-1 state update by default
  -> AION widening/refresh only when needed
  -> QLAF state readout
  -> TSC residual correction if enabled
  -> MLP
  -> logits
```

The final server should be:

```text
prefill builds QLAF cache
decode uses top-1 CUDA fast path
AION controls rare refresh/widening
TSC correction remains residual/optional
Route B serves through custom HF/CUDA/server stack
```

The final claim should be:

> V39 is a Transformer replacement for decode-dominant, long-context serving if it matches quality while reducing KV-cache memory and decode latency.

Do not claim full universal replacement until real text, CUDA, and server evidence exists.

---

# Immediate next action

Run the CUDA gate on a CUDA machine.

The CPU has now done nearly everything it can:

- parity reference;
- training gate;
- cached-decode proxy;
- CUDA indexing simulation.

The next bottleneck is real hardware.
