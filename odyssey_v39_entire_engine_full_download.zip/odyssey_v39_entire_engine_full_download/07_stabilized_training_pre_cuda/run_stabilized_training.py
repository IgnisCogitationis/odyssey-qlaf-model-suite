
#!/usr/bin/env python3
import argparse, csv, json, time, statistics
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--seeds", default="1,2,3")
parser.add_argument("--steps", type=int, default=12)
parser.add_argument("--lr", type=float, default=8e-4)
parser.add_argument("--batch", type=int, default=2)
parser.add_argument("--seq", type=int, default=8)
parser.add_argument("--hidden", type=int, default=8)
parser.add_argument("--states", type=int, default=3)
parser.add_argument("--rank", type=int, default=4)
parser.add_argument("--intermediate", type=int, default=32)
parser.add_argument("--outdir", default="results_stabilized")
parser.add_argument("--smoke", action="store_true")
args = parser.parse_args()

if args.smoke:
    args.seeds = "1"
    args.steps = 3
    args.batch = 1
    args.seq = 6
    args.lr = 5e-4

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except Exception as e:
    print(json.dumps({"passed": False, "error": "torch_import_failed", "detail": repr(e)}, indent=2))
    raise SystemExit(0)

class TinyV39(nn.Module):
    def __init__(self, vocab=32, hidden=8, states=3, rank=4, inter=32, max_pos=64):
        super().__init__()
        self.vocab = vocab
        self.hidden = hidden
        self.states = states
        self.rank = rank
        self.emb = nn.Embedding(vocab, hidden)
        self.pos = nn.Embedding(max_pos, hidden)
        self.norm = nn.LayerNorm(hidden)
        self.route = nn.Linear(hidden, states, bias=False)
        self.to_rank = nn.Linear(hidden, rank, bias=False)
        self.from_state = nn.Linear(states * rank, hidden, bias=False)
        self.tsc_norm = nn.LayerNorm(hidden)
        self.tsc = nn.Linear(hidden, hidden, bias=False)
        self.mlp_norm = nn.LayerNorm(hidden)
        self.mlp = nn.Sequential(nn.Linear(hidden, inter), nn.SiLU(), nn.Linear(inter, hidden))
        self.head = nn.Linear(hidden, vocab, bias=False)

    def forward(self, x, top_k=2, use_tsc=True):
        B, T = x.shape
        state = torch.zeros(B, self.states, self.rank, device=x.device, dtype=self.emb.weight.dtype)
        weight = torch.zeros(B, self.states, device=x.device, dtype=self.emb.weight.dtype)
        outs = []
        bi = torch.arange(B, device=x.device)
        for t in range(T):
            h = self.emb(x[:, t]) + self.pos(torch.full((B,), t, device=x.device, dtype=torch.long))
            hn = self.norm(h)
            probs = torch.softmax(self.route(hn), dim=-1)
            vals, ids = torch.topk(probs, k=top_k, dim=-1)
            vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
            z = self.to_rank(hn)

            # Out-of-place state update for autograd stability.
            new_state = state.clone()
            new_weight = weight.clone()
            for j in range(top_k):
                sid = ids[:, j]
                w = vals[:, j]
                old_w = new_weight[bi, sid]
                new_w = old_w + w
                old = new_state[bi, sid]
                updated = (old * old_w[:, None] + z * w[:, None]) / new_w[:, None].clamp_min(1e-8)
                new_state[bi, sid] = updated
                new_weight[bi, sid] = new_w
            state, weight = new_state, new_weight

            flat = (state * weight[:, :, None] / weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)[:, :, None]).reshape(B, self.states * self.rank)
            h = h + self.from_state(flat)
            if use_tsc:
                h = h + 0.10 * self.tsc(self.tsc_norm(h))
            h = h + self.mlp(self.mlp_norm(h))
            outs.append(self.head(h)[:, None, :])
        return torch.cat(outs, dim=1)

class TinyTransformer(nn.Module):
    def __init__(self, vocab=32, hidden=8, inter=32, max_pos=64):
        super().__init__()
        self.emb = nn.Embedding(vocab, hidden)
        self.pos = nn.Embedding(max_pos, hidden)
        self.norm1 = nn.LayerNorm(hidden)
        self.attn = nn.MultiheadAttention(hidden, num_heads=1, batch_first=True)
        self.norm2 = nn.LayerNorm(hidden)
        self.mlp = nn.Sequential(nn.Linear(hidden, inter), nn.SiLU(), nn.Linear(inter, hidden))
        self.head = nn.Linear(hidden, vocab, bias=False)

    def forward(self, x):
        B, T = x.shape
        pos = torch.arange(T, device=x.device).unsqueeze(0).expand(B, T)
        h = self.emb(x) + self.pos(pos)
        mask = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
        q = self.norm1(h)
        y, _ = self.attn(q, q, q, attn_mask=mask, need_weights=False)
        h = h + y
        h = h + self.mlp(self.norm2(h))
        return self.head(h)

def make_fixed_batch(seed, batch, seq, vocab=32, device="cpu"):
    g = torch.Generator(device="cpu")
    g.manual_seed(seed)
    x = torch.randint(0, vocab, (batch, seq), generator=g).to(device)
    for t in range(2, seq):
        x[:, t] = (x[:, t-1] + x[:, t-2] + (t % 5)) % vocab
    return x

def lm_loss(logits, x):
    return F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), x[:, 1:].reshape(-1))

def run_model(model, train_x, val_x, steps, lr):
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    train_losses = []
    val_losses = []
    start = time.perf_counter()
    for step in range(steps):
        model.train()
        opt.zero_grad(set_to_none=True)
        logits = model(train_x)
        loss = lm_loss(logits, train_x)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)
        opt.step()
        train_losses.append(float(loss.item()))

        model.eval()
        with torch.no_grad():
            val_losses.append(float(lm_loss(model(val_x), val_x).item()))
    return {
        "train_losses": train_losses,
        "val_losses": val_losses,
        "elapsed": time.perf_counter() - start,
    }

def count_params(model):
    return sum(p.numel() for p in model.parameters())

device = "cuda" if torch.cuda.is_available() else "cpu"
outdir = Path(args.outdir)
outdir.mkdir(parents=True, exist_ok=True)

rows = []
seeds = [int(s) for s in args.seeds.split(",") if s.strip()]
for seed in seeds:
    torch.manual_seed(seed)
    train_x = make_fixed_batch(10_000 + seed, args.batch, args.seq, device=device)
    val_x = make_fixed_batch(20_000 + seed, args.batch, args.seq, device=device)

    torch.manual_seed(seed)
    v39 = TinyV39(hidden=args.hidden, states=args.states, rank=args.rank, inter=args.intermediate, max_pos=max(64, args.seq + 4)).to(device)
    torch.manual_seed(seed)
    tr = TinyTransformer(hidden=args.hidden, inter=args.intermediate, max_pos=max(64, args.seq + 4)).to(device)

    v = run_model(v39, train_x, val_x, args.steps, args.lr)
    t = run_model(tr, train_x, val_x, args.steps, args.lr)

    row = {
        "seed": seed,
        "device": device,
        "steps": args.steps,
        "lr": args.lr,
        "batch": args.batch,
        "seq": args.seq,
        "hidden": args.hidden,
        "states": args.states,
        "rank": args.rank,
        "intermediate": args.intermediate,
        "v39_params": count_params(v39),
        "transformer_params": count_params(tr),
        "param_ratio": count_params(v39) / max(count_params(tr), 1),
        "v39_train_initial": v["train_losses"][0],
        "v39_train_final": v["train_losses"][-1],
        "v39_train_delta": v["train_losses"][0] - v["train_losses"][-1],
        "v39_val_initial": v["val_losses"][0],
        "v39_val_final": v["val_losses"][-1],
        "v39_val_delta": v["val_losses"][0] - v["val_losses"][-1],
        "transformer_train_initial": t["train_losses"][0],
        "transformer_train_final": t["train_losses"][-1],
        "transformer_train_delta": t["train_losses"][0] - t["train_losses"][-1],
        "transformer_val_initial": t["val_losses"][0],
        "transformer_val_final": t["val_losses"][-1],
        "transformer_val_delta": t["val_losses"][0] - t["val_losses"][-1],
        "v39_seconds": v["elapsed"],
        "transformer_seconds": t["elapsed"],
        "v39_train_curve": json.dumps(v["train_losses"]),
        "v39_val_curve": json.dumps(v["val_losses"]),
        "transformer_train_curve": json.dumps(t["train_losses"]),
        "transformer_val_curve": json.dumps(t["val_losses"]),
        "v39_train_reduced": v["train_losses"][-1] <= v["train_losses"][0],
        "transformer_train_reduced": t["train_losses"][-1] <= t["train_losses"][0],
    }
    rows.append(row)

csv_path = outdir / "stabilized_training.csv"
with csv_path.open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)

summary = {
    "device": device,
    "rows": len(rows),
    "all_v39_train_reduced": all(r["v39_train_reduced"] for r in rows),
    "all_transformer_train_reduced": all(r["transformer_train_reduced"] for r in rows),
    "v39_train_delta_mean": statistics.mean(r["v39_train_delta"] for r in rows),
    "transformer_train_delta_mean": statistics.mean(r["transformer_train_delta"] for r in rows),
    "v39_val_final_mean": statistics.mean(r["v39_val_final"] for r in rows),
    "transformer_val_final_mean": statistics.mean(r["transformer_val_final"] for r in rows),
    "rows_detail": rows,
    "cuda_allowed_next": False,
    "cuda_gate": "Require stable train reduction and acceptable validation behavior before CUDA top-1 decode."
}
(outdir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
