# Odyssey V39 Stabilized Training Before CUDA

This package stabilizes the PyTorch gradient-training shard before CUDA work.

Changes:
- lower LR default: 8e-4
- fixed train batch per seed
- fixed validation batch per seed
- smaller gradient clipping: 0.5
- deterministic seeds
- CSV logging
- validation loss curve
- explicit CUDA gate flag

Run smoke:

```bash
python3 run_stabilized_training.py --smoke
```

Run 3-seed stabilized shard:

```bash
python3 run_stabilized_training.py --seeds 1,2,3 --steps 12 --lr 8e-4 --batch 2 --seq 8
```

CUDA should remain blocked until this training gate is stable.
