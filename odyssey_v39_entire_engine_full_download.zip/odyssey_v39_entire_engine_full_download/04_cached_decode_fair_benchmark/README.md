# Odyssey V39 vs Transformer Cached-Decode Fair Benchmark + CSV Reporting

This package adds the next benchmark gate:

- V39 cached decode;
- Transformer cached decode with explicit per-layer KV cache;
- identical tiny config/data;
- parameter counts;
- cache-memory accounting;
- decode timing;
- prefill timing;
- CSV outputs;
- JSON summary.

This is still a tiny reference benchmark. It is not a CUDA result and not a final superiority claim.
