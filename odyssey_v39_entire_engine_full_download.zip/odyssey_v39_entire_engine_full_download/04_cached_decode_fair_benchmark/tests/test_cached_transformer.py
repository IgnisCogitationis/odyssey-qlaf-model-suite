import torch
from odyssey_v39_cached_bench.config import TinyConfig
from odyssey_v39_cached_bench.data import make_synthetic_batch
from odyssey_v39_cached_bench.model_transformer_cached import TinyTransformerCachedLM

def test_transformer_cached_matches_full_cpu():
    cfg = TinyConfig(max_positions=20)
    model = TinyTransformerCachedLM(cfg).eval()
    x = make_synthetic_batch(2, 8, cfg.vocab_size, seed=123)
    with torch.no_grad():
        full = model.forward_full(x)
        cached, _ = model.prefill_cached(x)
    assert (full - cached).abs().max().item() < 1e-5
