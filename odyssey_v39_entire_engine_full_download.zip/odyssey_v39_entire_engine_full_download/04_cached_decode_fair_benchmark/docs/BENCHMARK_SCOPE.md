# Benchmark Scope

This artifact replaces the earlier naive Transformer prefix-recompute decode comparison with an explicit cached Transformer baseline.

## What is fairer now

The Transformer baseline stores per-layer K/V tensors and decodes one token at a time using the cache.

The V39 baseline stores QLAF state summaries and decodes one token at a time using the QLAF cache.

Both are tiny PyTorch reference implementations.

## What is still not final

- Not CUDA-optimized.
- Not using FlashAttention.
- Not using production scheduling.
- Parameter counts are reported but not tightly tuned.
- Tiny synthetic sizes do not prove quality or production superiority.

## CSV outputs

`benchmark_outputs/cached_decode_results.csv` contains:
- context;
- seed;
- parameter counts;
- prefill timing;
- cached decode timing;
- tokens/sec;
- speedup ratios;
- cache element counts;
- cache memory reduction percent.

`benchmark_outputs/summary.json` contains full rows plus trial timings.
