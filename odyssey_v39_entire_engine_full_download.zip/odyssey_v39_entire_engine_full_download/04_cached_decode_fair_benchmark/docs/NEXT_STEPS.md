# Recommended Next Steps

1. Run this benchmark locally on CPU and GPU.
2. Inspect `cached_decode_results.csv`.
3. Tighten V39/Transformer parameter counts.
4. Add training before benchmark so weights are not random.
5. Increase contexts to 128/256/512.
6. Add 3 then 5 seeds.
7. Implement CUDA top-1 V39 decode and compare again.
8. Add optimized Transformer baseline if available.
