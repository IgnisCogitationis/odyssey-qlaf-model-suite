from odyssey_v39_cached_bench.benchmark import run_benchmark
import json

if __name__ == "__main__":
    print(json.dumps(run_benchmark(output_dir="benchmark_outputs"), indent=2))
