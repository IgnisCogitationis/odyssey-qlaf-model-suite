import math
import torch
import torch.nn as nn
import torch.nn.functional as F

class KVCache:
    def __init__(self, num_layers, batch_size, num_heads, max_len, head_dim, device=None, dtype=None):
        self.k = torch.zeros(num_layers, batch_size, num_heads, max_len, head_dim, device=device, dtype=dtype)
        self.v = torch.zeros(num_layers, batch_size, num_heads, max_len, head_dim, device=device, dtype=dtype)
        self.position = 0
        self.max_len = max_len

    def elements(self):
        return self.k.numel() + self.v.numel()

class CachedTransformerBlock(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        h = cfg.hidden_size
        heads = cfg.num_heads if h % cfg.num_heads == 0 else 1
        self.num_heads = heads
        self.head_dim = h // heads
        self.norm1 = nn.LayerNorm(h)
        self.q = nn.Linear(h, h, bias=False)
        self.k = nn.Linear(h, h, bias=False)
        self.v = nn.Linear(h, h, bias=False)
        self.o = nn.Linear(h, h, bias=False)
        self.norm2 = nn.LayerNorm(h)
        self.mlp = nn.Sequential(nn.Linear(h, cfg.intermediate_size), nn.SiLU(), nn.Linear(cfg.intermediate_size, h))

    def split_heads(self, x):
        B, H = x.shape
        return x.view(B, self.num_heads, self.head_dim)

    def merge_heads(self, x):
        B, heads, dim = x.shape
        return x.reshape(B, heads * dim)

    def decode_step(self, x, cache, layer_idx):
        # x [B,H], cache stores previous plus current K/V.
        B = x.size(0)
        xn = self.norm1(x)
        q = self.split_heads(self.q(xn))
        k = self.split_heads(self.k(xn))
        v = self.split_heads(self.v(xn))

        pos = cache.position
        cache.k[layer_idx, :, :, pos, :] = k
        cache.v[layer_idx, :, :, pos, :] = v

        keys = cache.k[layer_idx, :, :, :pos+1, :]
        vals = cache.v[layer_idx, :, :, :pos+1, :]
        scores = torch.einsum("bhd,bhtd->bht", q, keys) / math.sqrt(self.head_dim)
        probs = torch.softmax(scores, dim=-1)
        ctx = torch.einsum("bht,bhtd->bhd", probs, vals)
        y = x + self.o(self.merge_heads(ctx))
        y = y + self.mlp(self.norm2(y))
        return y

    def forward_full(self, x):
        B, T, H = x.shape
        xn = self.norm1(x)
        q = self.q(xn).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k(xn).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v(xn).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
        scores = torch.einsum("bhtd,bhsd->bhts", q, k) / math.sqrt(self.head_dim)
        mask = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
        scores = scores.masked_fill(mask[None, None, :, :], float("-inf"))
        probs = torch.softmax(scores, dim=-1)
        ctx = torch.einsum("bhts,bhsd->bhtd", probs, v).transpose(1, 2).reshape(B, T, H)
        y = x + self.o(ctx)
        y = y + self.mlp(self.norm2(y))
        return y

class TinyTransformerCachedLM(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
        self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
        self.layers = nn.ModuleList([CachedTransformerBlock(cfg) for _ in range(cfg.num_layers)])
        self.norm = nn.LayerNorm(cfg.hidden_size)
        self.head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)

    def new_cache(self, batch_size, max_len, device=None, dtype=None):
        heads = self.layers[0].num_heads
        head_dim = self.layers[0].head_dim
        return KVCache(self.cfg.num_layers, batch_size, heads, max_len, head_dim, device=device, dtype=dtype)

    def decode_step(self, token_ids, cache):
        B = token_ids.size(0)
        pos = torch.full((B, 1), cache.position, device=token_ids.device, dtype=torch.long)
        x = self.embed(token_ids)[:, 0] + self.pos(pos)[:, 0]
        for li, layer in enumerate(self.layers):
            x = layer.decode_step(x, cache, li)
        cache.position += 1
        return self.head(self.norm(x)), cache

    def prefill_cached(self, input_ids):
        B, T = input_ids.shape
        cache = self.new_cache(B, self.cfg.max_positions, device=input_ids.device, dtype=self.embed.weight.dtype)
        logits = []
        for t in range(T):
            y, cache = self.decode_step(input_ids[:, t:t+1], cache)
            logits.append(y[:, None, :])
        return torch.cat(logits, dim=1), cache

    def forward_full(self, input_ids):
        B, T = input_ids.shape
        pos = torch.arange(T, device=input_ids.device).unsqueeze(0).expand(B, T)
        x = self.embed(input_ids) + self.pos(pos)
        for layer in self.layers:
            x = layer.forward_full(x)
        return self.head(self.norm(x))

    def forward(self, input_ids, labels=None):
        logits = self.forward_full(input_ids)
        loss = None
        if labels is not None:
            loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
        return {"logits": logits, "loss": loss}

    def cache_elements(self, batch_size, seq_len):
        heads = self.layers[0].num_heads
        head_dim = self.layers[0].head_dim
        return 2 * self.cfg.num_layers * batch_size * heads * seq_len * head_dim
