from dataclasses import dataclass
import torch

@dataclass
class QLAFCache:
    state_summary: torch.Tensor
    state_weight: torch.Tensor
    position: int = 0
    valid: bool = True

    @classmethod
    def empty(cls, batch_size, cfg, device=None, dtype=None):
        return cls(
            state_summary=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, cfg.state_rank, device=device, dtype=dtype),
            state_weight=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, device=device, dtype=dtype),
            position=0,
            valid=True,
        )

    def elements(self):
        return self.state_summary.numel() + self.state_weight.numel()

    def require_valid(self):
        if not self.valid:
            raise RuntimeError("QLAF cache invalid")
