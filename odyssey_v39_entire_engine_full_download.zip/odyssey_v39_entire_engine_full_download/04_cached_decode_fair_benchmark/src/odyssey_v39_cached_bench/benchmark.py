import csv
import json
import time
from pathlib import Path
import torch
from .config import TinyConfig
from .data import make_synthetic_batch
from .model_v39 import TinyOdysseyV39
from .model_transformer_cached import TinyTransformerCachedLM

def count_params(model):
    return sum(p.numel() for p in model.parameters())

def sync_if_needed(device):
    if device.startswith("cuda") and torch.cuda.is_available():
        torch.cuda.synchronize()

def time_call(fn, device, warmup=2, trials=5):
    for _ in range(warmup):
        fn()
    sync_if_needed(device)
    vals = []
    for _ in range(trials):
        start = time.perf_counter()
        fn()
        sync_if_needed(device)
        vals.append(time.perf_counter() - start)
    return sum(vals) / len(vals), vals

def run_one_context(cfg, context, batch_size, device, seed):
    torch.manual_seed(seed)
    v39 = TinyOdysseyV39(cfg).to(device).eval()
    torch.manual_seed(seed)
    tr = TinyTransformerCachedLM(cfg).to(device).eval()
    x = make_synthetic_batch(batch_size, context, cfg.vocab_size, device=device, seed=seed + 100)

    with torch.no_grad():
        # parity for Transformer full vs cached decode
        tf_full = tr.forward_full(x)
        tf_cached, tf_cache = tr.prefill_cached(x)
        tf_parity = float((tf_full - tf_cached).abs().max().item())

        def v39_prefill():
            v39.prefill(x, top_k=2, use_tsc=True)

        def tr_prefill_cached():
            tr.prefill_cached(x)

        def v39_decode_only():
            cache = v39.new_cache(batch_size, device=device, dtype=v39.embed.weight.dtype)
            for t in range(context):
                v39.decode_step(x[:, t:t+1], cache, top_k=1, use_tsc=False)

        def tr_decode_only():
            cache = tr.new_cache(batch_size, cfg.max_positions, device=device, dtype=tr.embed.weight.dtype)
            for t in range(context):
                tr.decode_step(x[:, t:t+1], cache)

        v39_prefill_mean, v39_prefill_trials = time_call(v39_prefill, device)
        tr_prefill_mean, tr_prefill_trials = time_call(tr_prefill_cached, device)
        v39_decode_mean, v39_decode_trials = time_call(v39_decode_only, device)
        tr_decode_mean, tr_decode_trials = time_call(tr_decode_only, device)

    v39_cache = v39.cache_elements(batch_size)
    tr_cache = tr.cache_elements(batch_size, context)
    return {
        "seed": seed,
        "context": context,
        "batch_size": batch_size,
        "device": device,
        "v39_params": count_params(v39),
        "transformer_params": count_params(tr),
        "param_ratio_v39_over_transformer": count_params(v39) / max(count_params(tr), 1),
        "transformer_full_vs_cached_max_abs": tf_parity,
        "v39_prefill_seconds": v39_prefill_mean,
        "transformer_cached_prefill_seconds": tr_prefill_mean,
        "v39_decode_seconds": v39_decode_mean,
        "transformer_cached_decode_seconds": tr_decode_mean,
        "v39_prefill_tokens_per_sec": batch_size * context / max(v39_prefill_mean, 1e-9),
        "transformer_prefill_tokens_per_sec": batch_size * context / max(tr_prefill_mean, 1e-9),
        "v39_decode_tokens_per_sec": batch_size * context / max(v39_decode_mean, 1e-9),
        "transformer_decode_tokens_per_sec": batch_size * context / max(tr_decode_mean, 1e-9),
        "v39_decode_speedup_vs_transformer_cached": tr_decode_mean / max(v39_decode_mean, 1e-9),
        "v39_prefill_speedup_vs_transformer_cached": tr_prefill_mean / max(v39_prefill_mean, 1e-9),
        "v39_cache_elements": v39_cache,
        "transformer_kv_cache_elements": tr_cache,
        "v39_cache_reduction_percent": 100.0 * (1.0 - v39_cache / max(tr_cache, 1)),
        "v39_prefill_trials": v39_prefill_trials,
        "transformer_prefill_trials": tr_prefill_trials,
        "v39_decode_trials": v39_decode_trials,
        "transformer_decode_trials": tr_decode_trials,
    }

def write_csv(rows, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [k for k in rows[0].keys() if not k.endswith("_trials")]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow({k: row[k] for k in fieldnames})

def run_benchmark(output_dir="benchmark_outputs", contexts=(8, 16, 32), seeds=(1, 2), batch_size=2, device=None):
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = TinyConfig(max_positions=max(contexts) + 4)
    rows = []
    for seed in seeds:
        for ctx in contexts:
            rows.append(run_one_context(cfg, ctx, batch_size, device, seed))
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_csv(rows, out / "cached_decode_results.csv")
    summary = {
        "device": device,
        "contexts": list(contexts),
        "seeds": list(seeds),
        "batch_size": batch_size,
        "rows": rows,
        "notes": [
            "Transformer uses explicit KV cache decode, not naive prefix recompute.",
            "Tiny benchmark is reference-level, not CUDA-optimized.",
            "Parameter counts are reported and may not be perfectly matched."
        ],
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary

if __name__ == "__main__":
    print(json.dumps(run_benchmark(), indent=2))
