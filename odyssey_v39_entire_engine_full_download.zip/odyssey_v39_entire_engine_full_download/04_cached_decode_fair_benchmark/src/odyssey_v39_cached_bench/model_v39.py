import torch
import torch.nn as nn
import torch.nn.functional as F
from .cache_v39 import QLAFCache

class QLAFLayer(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        h, s, r = cfg.hidden_size, cfg.num_states, cfg.state_rank
        self.norm = nn.LayerNorm(h)
        self.route = nn.Linear(h, s, bias=False)
        self.to_rank = nn.Linear(h, r, bias=False)
        self.from_state = nn.Linear(s * r, h, bias=False)
        self.tsc_norm = nn.LayerNorm(h)
        self.tsc = nn.Linear(h, h, bias=False)
        self.mlp_norm = nn.LayerNorm(h)
        self.mlp = nn.Sequential(nn.Linear(h, cfg.intermediate_size), nn.SiLU(), nn.Linear(cfg.intermediate_size, h))

    def update_one(self, x, state_summary, state_weight, top_k=1, use_tsc=True):
        B, S, R = state_summary.shape
        xn = self.norm(x)
        route_probs = torch.softmax(self.route(xn), dim=-1)
        vals, ids = torch.topk(route_probs, k=top_k, dim=-1)
        vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        z = self.to_rank(xn)
        new_state = state_summary.clone()
        new_weight = state_weight.clone()
        batch_idx = torch.arange(B, device=x.device)

        for j in range(top_k):
            sid = ids[:, j]
            w = vals[:, j]
            old_w = new_weight[batch_idx, sid]
            new_w = old_w + w
            old = new_state[batch_idx, sid]
            new_state[batch_idx, sid] = (old * old_w[:, None] + z * w[:, None]) / new_w[:, None].clamp_min(1e-8)
            new_weight[batch_idx, sid] = new_w

        weighted = new_state * new_weight[:, :, None]
        denom = new_weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        flat = (weighted / denom[:, :, None]).reshape(B, S * R)
        y = x + self.from_state(flat)
        if use_tsc:
            y = y + self.cfg.tsc_scale * self.tsc(self.tsc_norm(y))
        y = y + self.mlp(self.mlp_norm(y))
        return y, new_state, new_weight

class TinyOdysseyV39(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
        self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
        self.layers = nn.ModuleList([QLAFLayer(cfg) for _ in range(cfg.num_layers)])
        self.norm = nn.LayerNorm(cfg.hidden_size)
        self.head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)

    def new_cache(self, batch_size, device=None, dtype=None):
        return QLAFCache.empty(batch_size, self.cfg, device=device, dtype=dtype)

    def decode_step(self, token_ids, cache, top_k=1, use_tsc=True):
        cache.require_valid()
        B = token_ids.size(0)
        pos = torch.full((B, 1), cache.position, device=token_ids.device, dtype=torch.long)
        x = self.embed(token_ids)[:, 0] + self.pos(pos)[:, 0]
        for li, layer in enumerate(self.layers):
            x, ns, nw = layer.update_one(x, cache.state_summary[:, li], cache.state_weight[:, li], top_k=top_k, use_tsc=use_tsc)
            cache.state_summary[:, li] = ns
            cache.state_weight[:, li] = nw
        cache.position += 1
        return self.head(self.norm(x)), cache

    def prefill(self, input_ids, top_k=2, use_tsc=True):
        B, T = input_ids.shape
        cache = self.new_cache(B, device=input_ids.device, dtype=self.embed.weight.dtype)
        logits = []
        for t in range(T):
            y, cache = self.decode_step(input_ids[:, t:t+1], cache, top_k=top_k, use_tsc=use_tsc)
            logits.append(y[:, None, :])
        return torch.cat(logits, dim=1), cache

    def forward(self, input_ids, labels=None):
        logits, _ = self.prefill(input_ids, top_k=2, use_tsc=True)
        loss = None
        if labels is not None:
            loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
        return {"logits": logits, "loss": loss}

    def cache_elements(self, batch_size):
        return batch_size * self.cfg.num_layers * self.cfg.num_states * self.cfg.state_rank + batch_size * self.cfg.num_layers * self.cfg.num_states
