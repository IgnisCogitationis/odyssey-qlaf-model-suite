# Interpretation

## What this proves

If parity passes here, the CPU mirror of the intended CUDA scalar kernel matches the vectorized reference for:
- top-1 active state selection
- selected state update
- state weight update
- state-bank readout
- output hidden update

## What this does not prove

It does not prove:
- CUDA builds
- CUDA numerics
- GPU speed
- production kernel performance
- prefill speed
- Route B readiness

## Next actual GPU step

Run the CUDA gate package on a CUDA machine:

```bash
bash scripts/run_local_cuda_gate.sh
```

Only if CUDA parity passes should timing be run.
