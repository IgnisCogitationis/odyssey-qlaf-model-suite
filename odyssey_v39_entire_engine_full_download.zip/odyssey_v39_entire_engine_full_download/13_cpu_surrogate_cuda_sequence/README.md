# Odyssey V39 CPU Surrogate for CUDA Sequence

This runs the CUDA sequence locally on CPU in small passes:

1. top-1 parity using a CPU mirror of the CUDA scalar kernel
2. CPU surrogate timing for the same top-1 boundary
3. full cached-decode CPU surrogate vs explicit Transformer KV baseline

Important:

This does **not** prove CUDA parity or CUDA speed. It only de-risks the algorithm and indexing before running on a CUDA machine.

Outputs:
- `results/cpu_top1_parity.csv`
- `results/cpu_top1_timing_surrogate.csv`
- `results/full_cached_decode_cpu_surrogate.csv`
- `results/summary.json`
