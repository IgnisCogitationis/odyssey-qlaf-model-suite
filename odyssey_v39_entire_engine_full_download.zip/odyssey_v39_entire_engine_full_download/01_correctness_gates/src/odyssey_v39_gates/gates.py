import json
import torch
from .tiny_model import TinyV39Config, TinyV39Model
from .cache import TinyQLAFCache

def set_seed(seed=1234):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def max_abs(a, b):
    return float((a - b).abs().max().item())

def gate_full_forward_vs_cached_decode(device="cpu"):
    set_seed(1)
    cfg = TinyV39Config()
    model = TinyV39Model(cfg).to(device).eval()
    input_ids = torch.randint(0, cfg.vocab_size, (3, 9), device=device)
    with torch.no_grad():
        full = model.forward_full(input_ids, top_k=2)
        cached, _ = model.prefill(input_ids, top_k=2)
    diff = max_abs(full, cached)
    return {"gate": "full_forward_vs_cached_decode", "passed": diff < 1e-6, "max_abs_diff": diff}

def gate_no_future_leakage(device="cpu"):
    set_seed(2)
    cfg = TinyV39Config()
    model = TinyV39Model(cfg).to(device).eval()
    prefix = torch.randint(0, cfg.vocab_size, (2, 6), device=device)
    suffix_a = torch.randint(0, cfg.vocab_size, (2, 4), device=device)
    suffix_b = torch.randint(0, cfg.vocab_size, (2, 4), device=device)
    seq_a = torch.cat([prefix, suffix_a], dim=1)
    seq_b = torch.cat([prefix, suffix_b], dim=1)
    with torch.no_grad():
        logits_a = model.forward_full(seq_a, top_k=2)[:, :prefix.shape[1]]
        logits_b = model.forward_full(seq_b, top_k=2)[:, :prefix.shape[1]]
    diff = max_abs(logits_a, logits_b)
    return {"gate": "no_future_leakage", "passed": diff < 1e-6, "max_abs_diff": diff}

def gate_cache_reset(device="cpu"):
    set_seed(3)
    cfg = TinyV39Config()
    cache = TinyQLAFCache.empty(2, cfg.layers, cfg.states, cfg.rank, device=device)
    cache.state_summary.normal_()
    cache.state_weight.uniform_()
    cache.position = 7
    cache.reset()
    summary_zero = float(cache.state_summary.abs().max().item())
    weight_zero = float(cache.state_weight.abs().max().item())
    passed = summary_zero == 0.0 and weight_zero == 0.0 and cache.position == 0 and cache.valid
    return {"gate": "cache_reset", "passed": passed, "summary_max": summary_zero, "weight_max": weight_zero, "position": cache.position}

def gate_batch_equivalence(device="cpu"):
    set_seed(4)
    cfg = TinyV39Config()
    model = TinyV39Model(cfg).to(device).eval()
    input_ids = torch.randint(0, cfg.vocab_size, (4, 8), device=device)
    with torch.no_grad():
        batch_logits = model.forward_full(input_ids, top_k=2)
        singles = []
        for i in range(input_ids.shape[0]):
            singles.append(model.forward_full(input_ids[i:i+1], top_k=2))
        single_logits = torch.cat(singles, dim=0)
    diff = max_abs(batch_logits, single_logits)
    return {"gate": "batch_equivalence", "passed": diff < 1e-6, "max_abs_diff": diff}

def gate_top1_top2_routing_behavior(device="cpu"):
    set_seed(5)
    cfg = TinyV39Config()
    model = TinyV39Model(cfg).to(device).eval()
    input_ids = torch.randint(0, cfg.vocab_size, (2, 7), device=device)
    cache1 = TinyQLAFCache.empty(2, cfg.layers, cfg.states, cfg.rank, device=device)
    cache2 = TinyQLAFCache.empty(2, cfg.layers, cfg.states, cfg.rank, device=device)
    route_shapes_ok = True
    top2_has_two = True
    with torch.no_grad():
        for t in range(input_ids.shape[1]):
            _, cache1, info1 = model.decode_step(input_ids[:, t:t+1], cache1, top_k=1)
            _, cache2, info2 = model.decode_step(input_ids[:, t:t+1], cache2, top_k=2)
            route_shapes_ok &= info1["route_ids"].shape[-1] == 1
            route_shapes_ok &= info2["route_ids"].shape[-1] == 2
            top2_has_two &= bool((info2["route_ids"][:, :, 0] != info2["route_ids"][:, :, 1]).all().item())
    cache_difference = float((cache1.state_summary - cache2.state_summary).abs().sum().item())
    passed = bool(route_shapes_ok and top2_has_two and cache_difference > 0.0)
    return {
        "gate": "top1_top2_routing_behavior",
        "passed": passed,
        "route_shapes_ok": bool(route_shapes_ok),
        "top2_distinct_ids": bool(top2_has_two),
        "cache_l1_difference": cache_difference
    }

def run_all_gates(device=None):
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    results = [
        gate_full_forward_vs_cached_decode(device),
        gate_no_future_leakage(device),
        gate_cache_reset(device),
        gate_batch_equivalence(device),
        gate_top1_top2_routing_behavior(device),
    ]
    return {
        "device": device,
        "all_passed": all(r["passed"] for r in results),
        "results": results,
    }

if __name__ == "__main__":
    print(json.dumps(run_all_gates(), indent=2))
