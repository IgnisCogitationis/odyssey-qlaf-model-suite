from dataclasses import dataclass
from typing import Tuple, Optional
import torch
import torch.nn as nn
import torch.nn.functional as F
from .cache import TinyQLAFCache

@dataclass
class TinyV39Config:
    vocab_size: int = 31
    hidden_size: int = 24
    layers: int = 2
    states: int = 4
    rank: int = 8
    max_positions: int = 64
    top1_threshold: float = 0.0

class TinyQLAFLayer(nn.Module):
    def __init__(self, cfg: TinyV39Config):
        super().__init__()
        self.cfg = cfg
        h, s, r = cfg.hidden_size, cfg.states, cfg.rank
        self.norm = nn.LayerNorm(h)
        self.route = nn.Linear(h, s, bias=False)
        self.to_rank = nn.Linear(h, r, bias=False)
        self.from_state = nn.Linear(s * r, h, bias=False)
        self.mlp = nn.Sequential(nn.LayerNorm(h), nn.Linear(h, 4*h), nn.SiLU(), nn.Linear(4*h, h))

    def route_topk(self, x, top_k):
        logits = self.route(self.norm(x))
        probs = torch.softmax(logits, dim=-1)
        vals, ids = torch.topk(probs, k=top_k, dim=-1)
        vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        return ids, vals, probs

    def update_one(self, x_t, layer_state, layer_weight, top_k):
        # x_t: [B,H], layer_state: [B,S,R], layer_weight: [B,S]
        ids, vals, probs = self.route_topk(x_t, top_k)
        z = self.to_rank(self.norm(x_t))
        B, S, R = layer_state.shape
        new_state = layer_state.clone()
        new_weight = layer_weight.clone()

        for j in range(top_k):
            sid = ids[:, j]
            w = vals[:, j]
            for b in range(B):
                sidx = int(sid[b].item())
                old_w = new_weight[b, sidx]
                add_w = w[b]
                denom = old_w + add_w
                new_state[b, sidx] = (new_state[b, sidx] * old_w + z[b] * add_w) / denom.clamp_min(1e-8)
                new_weight[b, sidx] = denom

        read = (new_state * new_weight.unsqueeze(-1).clamp_min(0.0)).reshape(B, S * R)
        denom = new_weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        read = read / denom
        y = x_t + self.from_state(read)
        y = y + self.mlp(y)
        confidence = probs.max(dim=-1).values
        return y, new_state, new_weight, ids, confidence

class TinyV39Model(nn.Module):
    def __init__(self, cfg: TinyV39Config):
        super().__init__()
        self.cfg = cfg
        self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
        self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
        self.layers = nn.ModuleList([TinyQLAFLayer(cfg) for _ in range(cfg.layers)])
        self.final_norm = nn.LayerNorm(cfg.hidden_size)
        self.lm_head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)

    def _token_hidden(self, input_ids, pos_offset=0):
        B, T = input_ids.shape
        positions = torch.arange(pos_offset, pos_offset + T, device=input_ids.device).unsqueeze(0).expand(B, T)
        return self.embed(input_ids) + self.pos(positions)

    def forward_full(self, input_ids, top_k=2):
        B, T = input_ids.shape
        cache = TinyQLAFCache.empty(
            B, self.cfg.layers, self.cfg.states, self.cfg.rank,
            device=input_ids.device, dtype=self.embed.weight.dtype
        )
        logits_list = []
        hidden = self._token_hidden(input_ids, 0)
        for t in range(T):
            x = hidden[:, t]
            for li, layer in enumerate(self.layers):
                x, ns, nw, _, _ = layer.update_one(
                    x, cache.state_summary[:, li], cache.state_weight[:, li], top_k=top_k
                )
                cache.state_summary[:, li] = ns
                cache.state_weight[:, li] = nw
            logits_list.append(self.lm_head(self.final_norm(x)).unsqueeze(1))
            cache.position += 1
        return torch.cat(logits_list, dim=1)

    def prefill(self, input_ids, top_k=2):
        B, T = input_ids.shape
        cache = TinyQLAFCache.empty(
            B, self.cfg.layers, self.cfg.states, self.cfg.rank,
            device=input_ids.device, dtype=self.embed.weight.dtype
        )
        logits = []
        for t in range(T):
            step_logits, cache, _ = self.decode_step(input_ids[:, t:t+1], cache, top_k=top_k)
            logits.append(step_logits.unsqueeze(1))
        return torch.cat(logits, dim=1), cache

    def decode_step(self, token_ids, cache: TinyQLAFCache, top_k=1):
        cache.require_valid()
        assert token_ids.shape[1] == 1
        x = self._token_hidden(token_ids, cache.position)[:, 0]
        route_ids = []
        confidences = []
        for li, layer in enumerate(self.layers):
            x, ns, nw, ids, conf = layer.update_one(
                x, cache.state_summary[:, li], cache.state_weight[:, li], top_k=top_k
            )
            cache.state_summary[:, li] = ns
            cache.state_weight[:, li] = nw
            route_ids.append(ids)
            confidences.append(conf)
        cache.position += 1
        logits = self.lm_head(self.final_norm(x))
        route_info = {
            "route_ids": torch.stack(route_ids, dim=1),
            "confidence": torch.stack(confidences, dim=1),
            "top_k": top_k,
        }
        return logits, cache, route_info
