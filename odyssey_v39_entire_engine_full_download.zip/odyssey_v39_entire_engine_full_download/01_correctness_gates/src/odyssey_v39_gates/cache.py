from dataclasses import dataclass
import torch

@dataclass
class TinyQLAFCache:
    state_summary: torch.Tensor
    state_weight: torch.Tensor
    position: int
    valid: bool = True

    @classmethod
    def empty(cls, batch_size, layers, states, rank, device=None, dtype=torch.float32):
        return cls(
            state_summary=torch.zeros(batch_size, layers, states, rank, device=device, dtype=dtype),
            state_weight=torch.zeros(batch_size, layers, states, device=device, dtype=dtype),
            position=0,
            valid=True,
        )

    def clone(self):
        return TinyQLAFCache(
            state_summary=self.state_summary.clone(),
            state_weight=self.state_weight.clone(),
            position=int(self.position),
            valid=bool(self.valid),
        )

    def reset(self):
        self.state_summary.zero_()
        self.state_weight.zero_()
        self.position = 0
        self.valid = True

    def invalidate(self):
        self.valid = False

    def require_valid(self):
        if not self.valid:
            raise RuntimeError("TinyQLAFCache is invalid")
