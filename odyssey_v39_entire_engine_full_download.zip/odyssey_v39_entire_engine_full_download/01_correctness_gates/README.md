# Odyssey V39 Correctness Gates

This artifact targets the five correctness gates required before speed claims:

1. full-forward vs cached-decode parity;
2. no-future-leakage;
3. cache reset;
4. batch equivalence;
5. top-1/top-2 routing behavior.

This is a reference correctness harness, not the production engine and not a CUDA implementation.

The harness intentionally uses a tiny deterministic QLAF-style causal state model so the engine contract can be tested before optimizing kernels.
