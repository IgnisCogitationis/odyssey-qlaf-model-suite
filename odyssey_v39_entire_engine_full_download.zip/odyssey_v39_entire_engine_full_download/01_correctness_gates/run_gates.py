import json
from odyssey_v39_gates.gates import run_all_gates

if __name__ == "__main__":
    report = run_all_gates()
    print(json.dumps(report, indent=2))
