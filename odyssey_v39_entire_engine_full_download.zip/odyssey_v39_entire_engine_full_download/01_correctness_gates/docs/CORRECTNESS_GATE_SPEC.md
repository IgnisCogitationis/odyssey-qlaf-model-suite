# Correctness Gate Specification

## Gate 1 — Full-forward vs cached-decode parity

Purpose:
The model's causal full forward must match prefill/decode execution when both use the same routing policy.

Pass:
- max absolute logit difference within tolerance.

Fail means:
- cache update does not match full causal scan;
- position handling is wrong;
- routing differs;
- future leakage or stale state exists.

## Gate 2 — No future leakage

Purpose:
Changing suffix tokens must not alter logits for prefix positions.

Pass:
- prefix logits are identical when suffix changes.

Fail means:
- full forward is non-causal;
- scan accidentally reads future;
- batch operation mixes future tokens.

## Gate 3 — Cache reset

Purpose:
Reset must clear state summaries, weights, position, and validity.

Pass:
- state tensors zero;
- position zero;
- cache valid.

Fail means:
- stale generation state can leak across requests.

## Gate 4 — Batch equivalence

Purpose:
Batch execution must match independent single-sequence execution.

Pass:
- batched logits equal concatenated single logits.

Fail means:
- batch dimension mixing;
- cache rows corrupted;
- routing uses cross-batch data.

## Gate 5 — Top-1/top-2 routing behavior

Purpose:
Top-1 and top-2 modes must be structurally different and observable.

Pass:
- top-1 route has one state;
- top-2 route has two distinct states;
- resulting cache differs between top-1 and top-2.

Fail means:
- adaptive routing is fake;
- top-k selection broken;
- AION widening cannot work.
