from odyssey_v39_gates.gates import run_all_gates

def test_all_correctness_gates_cpu():
    report = run_all_gates(device="cpu")
    assert report["all_passed"], report
