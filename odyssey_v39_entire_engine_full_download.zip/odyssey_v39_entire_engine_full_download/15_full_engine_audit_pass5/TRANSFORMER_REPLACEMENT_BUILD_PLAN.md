
# Odyssey V39 Transformer Replacement Build Plan

## Build target

A single-GPU engine where the dominant inference path contains no attention matrix and no KV cache.

## Engine layers

Each layer:

1. RMSNorm.
2. QLAF route.
3. QLAF causal state update.
4. QLAF state read.
5. residual add.
6. optional TSC residual correction.
7. MLP.
8. residual add.

## Cache layout

Required production tensor layout:

- `state_summary`: `[batch, layers, states, rank]`
- `state_weight`: `[batch, layers, states]`
- `active_state_ids`: `[batch, layers, top_k]`
- `route_confidence`: `[batch, layers]`
- `hierarchy_level`: `[batch, layers, states]`
- `refresh_counter`: `[batch, layers]`
- `position`: `[batch]`

## AION policy

Inputs:
- route confidence;
- route margin;
- entropy;
- position;
- refresh counter;
- stale flag;
- task flag if available.

Outputs:
- top-k;
- refresh scope;
- hierarchy action;
- TSC scale;
- fallback flag.

## Benchmark gates

1. Independent full-reference vs cached-decode parity.
2. No-future-leakage.
3. Cache reset/repack.
4. Batch equivalence.
5. Mixed top-1/top-2 routing.
6. TSC on/off parity.
7. Transformer full vs KV cached parity.
8. V39 vs Transformer cached decode timing.
9. Cache memory table.
10. Matched training quality.

## CUDA order

1. top-1 decode state update;
2. route select;
3. rank projection;
4. state read;
5. output projection;
6. prefill scan;
7. graph capture/server scheduler.

## Public claim order

Do not claim full replacement until the following evidence exists:

- matched loss/perplexity;
- decode speed table;
- memory table;
- long-context table;
- ablations;
- reproducible server run.
