
# Odyssey V39 / QLAF-AION-TSC Engine Full Audit Pass 5

Date: 2026-04-28

## Scope

This audit reviews the current engine artifacts against the entire project goal:

> **QLAF causal state cache + AION adaptive hierarchy + TSC residual correction + decode-branch specialization + Route B CUDA/HF deployment**, with the long-term goal of replacing the Transformer architecture on a single GPU.

Audited artifacts:

- `odyssey_v39_engine_stack_pass1`
- `odyssey_v39_pytorch_correctness_training_lite`
- `odyssey_v39_cached_decode_fair_benchmark`
- `odyssey_v39_cached_decode_envsafe`
- `odyssey_v39_parameter_matched_benchmark`
- relevant V38/Route B audit context from previous passes

## Executive verdict

The project is now in the **reference-contract and benchmark-harness stage**.

It is stronger than a concept sketch because it now has:

1. a named final stack;
2. cache schema;
3. AION adaptive routing policy;
4. TSC residual policy;
5. PyTorch tiny correctness gates;
6. explicit cached Transformer baseline scaffold;
7. CSV reporting plans;
8. parameter-matching proxy harness;
9. Route B HF/CUDA/server deployment plan.

But it is **not yet a complete Transformer replacement engine** because the production-critical pieces are still not locked:

1. the engine stack is still mostly interface-level;
2. the PyTorch V39 model is a tiny reference, not the actual engine;
3. the fair cached-decode benchmark exists, but the container did not complete it;
4. the V39 PyTorch cache update is reference-style and clone-heavy, not a final efficient memory layout;
5. no CUDA top-1 decode kernel has been compiled or parity-tested;
6. no trained V39 model has been shown to match Transformer quality;
7. no KV-cache-equivalent Transformer baseline has been beaten under an optimized implementation;
8. no Route B HF/server package has been linked to the trained weights and CUDA path.

## Most important conclusion

The right replacement path is still correct:

**Odyssey V39 should be a state-engine, not an attention variant.**

The central replacement mechanism must be:

- QLAF causal state cache as the memory substrate;
- AION as adaptive anti-collapse / refresh / hierarchy controller;
- TSC as a small residual correction, not a full alternative path;
- decode-branch specialization as the production serving mode;
- Route B as the deployment wrapper, not the architecture itself.

## Replacement bar

To say V39 thoroughly replaces the Transformer, it must replace the following Transformer functions:

| Transformer function | Current V39 state | Required next state |
|---|---|---|
| causal sequence memory | QLAF cache exists in tiny/reference form | production tensor cache with stable API and CUDA layout |
| content retrieval | route-to-state exists | trainable route with quality validation |
| KV cache | QLAF state cache exists | measured cache-memory advantage vs explicit KV |
| attention heads | multi-state bank exists | ablation showing state count/rank replaces heads |
| dynamic routing | AION policy exists | mixed top-1/top-2 behavior, not forced top-2 only |
| local correction | TSC exists | residual-only ablation proving value without dominating cost |
| training stability | tiny benchmark exists | matched multi-seed training |
| serving speed | proxy/smoke exists | real cached decode speed vs Transformer KV cache |
| production deployment | Route B plan exists | HF repo + wheel + server integration |
| superiority claim | not proven | quality + speed + memory table |

---

# 1. Artifact inventory and line-level status


### engine_stack / `README.md`

- Lines: 40
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `benchmarks/BENCHMARK_PROTOCOL.md`

- Lines: 46
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `cuda_extension/odyssey_v39_cuda/CUDA_ABI.md`

- Lines: 34
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `docs/00_EXECUTIVE_SPEC.md`

- Lines: 69
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `docs/01_ENGINE_ARCHITECTURE.md`

- Lines: 127
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `docs/02_CACHE_SCHEMA.md`

- Lines: 119
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `docs/03_AION_POLICY.md`

- Lines: 70
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `docs/04_TSC_RESIDUAL_CORRECTION.md`

- Lines: 45
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `docs/05_DECODE_BRANCH_SPECIALIZATION.md`

- Lines: 40
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `docs/06_ROUTE_B_DEPLOYMENT.md`

- Lines: 53
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `docs/07_BENCHMARK_GATES.md`

- Lines: 63
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `hf_repo_template/HF_REPO_SPEC.md`

- Lines: 32
- Status: spec/documentation
- Findings: self-identifies as non-final benchmark/proof


### engine_stack / `pyproject.toml`

- Lines: 9
- Status: useful scaffold
- Findings: no automatic red flags found


### engine_stack / `server/SERVER_SPEC.md`

- Lines: 33
- Status: spec/documentation
- Findings: no automatic red flags found


### engine_stack / `src/odyssey_v39/__init__.py`

- Lines: 5
- Status: useful scaffold
- Findings: no automatic red flags found


### engine_stack / `src/odyssey_v39/aion.py`

- Lines: 23
- Status: useful scaffold
- Findings: no automatic red flags found


### engine_stack / `src/odyssey_v39/cache.py`

- Lines: 45
- Status: useful scaffold
- Findings: no automatic red flags found


### engine_stack / `src/odyssey_v39/config.py`

- Lines: 26
- Status: useful scaffold
- Findings: no automatic red flags found


### engine_stack / `src/odyssey_v39/dispatcher.py`

- Lines: 33
- Status: useful scaffold
- Findings: contains explicit unimplemented runtime path


### engine_stack / `src/odyssey_v39/engine.py`

- Lines: 53
- Status: useful scaffold
- Findings: contains explicit unimplemented runtime path


### engine_stack / `src/odyssey_v39/tsc.py`

- Lines: 17
- Status: useful scaffold
- Findings: no automatic red flags found


### engine_stack / `tests/test_aion_policy.py`

- Lines: 13
- Status: useful scaffold
- Findings: no automatic red flags found


### engine_stack / `tests/test_cache_contract.py`

- Lines: 20
- Status: useful scaffold
- Findings: no automatic red flags found


### pytorch_lite / `README.md`

- Lines: 13
- Status: spec/documentation
- Findings: self-identifies as non-final benchmark/proof


### pytorch_lite / `docs/NEXT_STEPS.md`

- Lines: 9
- Status: spec/documentation
- Findings: no automatic red flags found


### pytorch_lite / `docs/STATUS.md`

- Lines: 14
- Status: spec/documentation
- Findings: contains naive/proxy benchmark language


### pytorch_lite / `pyproject.toml`

- Lines: 9
- Status: useful scaffold
- Findings: no automatic red flags found


### pytorch_lite / `run_all.py`

- Lines: 5
- Status: useful scaffold
- Findings: no automatic red flags found


### pytorch_lite / `run_gates_only.py`

- Lines: 5
- Status: useful scaffold
- Findings: no automatic red flags found


### pytorch_lite / `src/odyssey_v39_pt/__init__.py`

- Lines: 7
- Status: useful scaffold
- Findings: no automatic red flags found


### pytorch_lite / `src/odyssey_v39_pt/cache.py`

- Lines: 34
- Status: useful scaffold
- Findings: uses clone/update cache semantics; good for reference but not final CUDA memory behavior


### pytorch_lite / `src/odyssey_v39_pt/config.py`

- Lines: 13
- Status: useful scaffold
- Findings: no automatic red flags found


### pytorch_lite / `src/odyssey_v39_pt/data.py`

- Lines: 13
- Status: useful scaffold
- Findings: no automatic red flags found


### pytorch_lite / `src/odyssey_v39_pt/decode_bench.py`

- Lines: 36
- Status: useful scaffold
- Findings: contains naive/proxy benchmark language


### pytorch_lite / `src/odyssey_v39_pt/gates.py`

- Lines: 86
- Status: useful scaffold
- Findings: no automatic red flags found


### pytorch_lite / `src/odyssey_v39_pt/memory.py`

- Lines: 13
- Status: useful scaffold
- Findings: cache memory accounting exists


### pytorch_lite / `src/odyssey_v39_pt/model_transformer.py`

- Lines: 44
- Status: useful scaffold
- Findings: Transformer baseline uses PyTorch MultiheadAttention; good smoke baseline but not production KV optimized


### pytorch_lite / `src/odyssey_v39_pt/model_v39.py`

- Lines: 106
- Status: useful scaffold
- Findings: uses clone/update cache semantics; good for reference but not final CUDA memory behavior


### pytorch_lite / `src/odyssey_v39_pt/run_all.py`

- Lines: 23
- Status: useful scaffold
- Findings: no automatic red flags found


### pytorch_lite / `src/odyssey_v39_pt/train_bench.py`

- Lines: 59
- Status: useful scaffold
- Findings: self-identifies as non-final benchmark/proof


### pytorch_lite / `tests/test_gates.py`

- Lines: 13
- Status: useful scaffold
- Findings: no automatic red flags found


### cached_decode / `README.md`

- Lines: 15
- Status: spec/documentation
- Findings: self-identifies as non-final benchmark/proof


### cached_decode / `docs/BENCHMARK_SCOPE.md`

- Lines: 34
- Status: spec/documentation
- Findings: contains naive/proxy benchmark language, self-identifies as non-final benchmark/proof


### cached_decode / `docs/NEXT_STEPS.md`

- Lines: 10
- Status: spec/documentation
- Findings: no automatic red flags found


### cached_decode / `pyproject.toml`

- Lines: 9
- Status: useful scaffold
- Findings: no automatic red flags found


### cached_decode / `run_benchmark.py`

- Lines: 5
- Status: useful scaffold
- Findings: no automatic red flags found


### cached_decode / `src/odyssey_v39_cached_bench/__init__.py`

- Lines: 4
- Status: useful scaffold
- Findings: no automatic red flags found


### cached_decode / `src/odyssey_v39_cached_bench/benchmark.py`

- Lines: 131
- Status: useful scaffold
- Findings: contains naive/proxy benchmark language, cache memory accounting exists


### cached_decode / `src/odyssey_v39_cached_bench/cache_v39.py`

- Lines: 25
- Status: useful scaffold
- Findings: no automatic red flags found


### cached_decode / `src/odyssey_v39_cached_bench/config.py`

- Lines: 13
- Status: useful scaffold
- Findings: no automatic red flags found


### cached_decode / `src/odyssey_v39_cached_bench/data.py`

- Lines: 12
- Status: useful scaffold
- Findings: no automatic red flags found


### cached_decode / `src/odyssey_v39_cached_bench/model_transformer_cached.py`

- Lines: 127
- Status: useful scaffold
- Findings: explicit KV cache baseline exists, cache memory accounting exists


### cached_decode / `src/odyssey_v39_cached_bench/model_v39.py`

- Lines: 91
- Status: useful scaffold
- Findings: uses clone/update cache semantics; good for reference but not final CUDA memory behavior, cache memory accounting exists


### cached_decode / `tests/test_cached_transformer.py`

- Lines: 13
- Status: useful scaffold
- Findings: no automatic red flags found


### param_matched / `README.md`

- Lines: 20
- Status: spec/documentation
- Findings: self-identifies as non-final benchmark/proof


### param_matched / `docs/BENCHMARK_CONTRACT.md`

- Lines: 40
- Status: spec/documentation
- Findings: contains naive/proxy benchmark language


### param_matched / `docs/CUDA_GATE_AFTER_THIS.md`

- Lines: 26
- Status: spec/documentation
- Findings: no automatic red flags found


### param_matched / `docs/NEXT_STEPS.md`

- Lines: 36
- Status: spec/documentation
- Findings: no automatic red flags found


### param_matched / `scripts/RUN_LOCAL.sh`

- Lines: 5
- Status: useful scaffold
- Findings: no automatic red flags found


### param_matched / `scripts/param_match_sweep.py`

- Lines: 146
- Status: useful scaffold
- Findings: self-identifies as non-final benchmark/proof, cache memory accounting exists, proxy harness only; not a real model benchmark


### envsafe / `README.md`

- Lines: 17
- Status: spec/documentation
- Findings: no automatic red flags found


### envsafe / `docs/ENVIRONMENT_LIMIT_WORKAROUNDS.md`

- Lines: 20
- Status: spec/documentation
- Findings: no automatic red flags found


### envsafe / `run_envsafe_benchmark.pl`

- Lines: 21
- Status: useful scaffold
- Findings: self-identifies as non-final benchmark/proof, cache memory accounting exists


### envsafe / `scripts/run_smoke.sh`

- Lines: 3
- Status: useful scaffold
- Findings: no automatic red flags found


---

# 2. File-by-file engineering audit

## 2.1 `odyssey_v39_engine_stack_pass1`

This is the cleanest architecture contract. It correctly separates:

- config;
- cache;
- AION policy;
- TSC policy;
- dispatcher;
- engine.

### `config.py`

Good:
- exposes state count, state rank, top-k, TSC/AION toggles;
- separates runtime config from architecture config.

Weak:
- lacks training/decode branch config;
- lacks refresh policy details beyond interval/confidence;
- lacks dtype enum validation;
- lacks kernel ABI version;
- lacks cache layout mode;
- lacks state hierarchy levels;
- lacks explicit positional mode.

Required patch:
- add `decode_branch_mode`, `prefill_state_policy`, `hierarchy_levels`, `refresh_policy`, `cache_layout`, `position_mode`, `kernel_abi_version`.

### `cache.py`

Good:
- has metadata;
- has per-layer state fields;
- has invalidation.

Weak:
- `LayerState` stores `Any`; no tensor shape contract enforced;
- newly-created cache is invalid by default because layers have `valid=False`;
- engine `new_cache()` returns a cache that cannot pass `require_valid()` unless each layer is manually marked;
- no allocation method;
- no device/dtype check;
- no position consistency check;
- no batch row management;
- no partial refresh state;
- no hierarchy tensor allocation.

Required patch:
- cache must allocate actual tensors:
  - `state_summary [B,L,S,R]`;
  - `state_weight [B,L,S]`;
  - `active_state_ids [B,L,K]`;
  - `route_confidence [B,L]`;
  - `hierarchy_level [B,L,S]`;
  - `position [B]`;
  - `refresh_counter [B,L]`;
- add `validate_against_config`;
- add `reset_rows`;
- add `repack_batch`;
- add `partial_refresh`;
- add `cache_elements`.

### `aion.py`

Good:
- top-1 fast path;
- top-2 widening on low confidence;
- periodic refresh trigger.

Weak:
- entropy argument is unused;
- no hierarchy promotion except periodic;
- no stale-cache or long-context triggers;
- no state split/collapse;
- no route diversity measurement;
- no top-4/full refresh mode.

Required patch:
- incorporate entropy, context position, stale flags, repeated low confidence, and route margin;
- output `refresh_scope`, `target_states`, `tsc_scale`, `hierarchy_action`;
- support top-1, top-2, top-4, rebuild.

### `tsc.py`

Good:
- keeps TSC residual policy small;
- supports disabled/default/adaptive decode.

Weak:
- not linked to actual tensor branch in engine stack;
- only outputs scalar scale;
- no latency budget or correction shape;
- no ablation hooks.

Required patch:
- make TSC explicitly residual-only;
- add `max_flop_fraction`;
- add `decode_disable_by_default`;
- add AION-controlled scale schedule.

### `dispatcher.py`

Good:
- clean CUDA/reference selection concept.

Weak:
- reference path raises `NotImplementedError`;
- no kernel ABI version check;
- swallows CUDA import exception;
- no diagnostics;
- no per-op fallback;
- no parity mode.

Required patch:
- record import error;
- expose `backend_report`;
- add ABI check;
- add `prefill_reference` and `decode_reference` route;
- add parity mode comparing CUDA/reference on tiny inputs.

### `engine.py`

Good:
- has high-level engine object;
- owns model, runtime, AION, TSC, dispatcher;
- separates prefill/decode.

Weak:
- `new_cache()` has no batch size and allocates no tensors;
- `prefill()` assumes model signature `prefill(input_ids, cache)`, while later tiny models use `prefill(input_ids, top_k, use_tsc)`;
- `decode_step()` passes `decision` and `tsc_scale`, but tiny models do not accept that signature;
- no scheduler;
- no request lifecycle;
- no streaming;
- no metrics;
- no fallback isolation;
- no cache ownership by request id.

Required patch:
- standardize model API:
  - `prefill(input_ids, cache, policy) -> logits, cache, info`;
  - `decode_step(token_ids, cache, policy) -> logits, cache, info`;
- engine must create cache with batch shape;
- add request id and cache manager;
- add scheduler;
- add metrics;
- add route of AION decision into model top-k/TSC.

## 2.2 `odyssey_v39_pytorch_correctness_training_lite`

This artifact is useful because it moves from pure numeric to PyTorch.

### Strengths

- TinyConfig is small enough for local CPU;
- QLAFCache contains real tensors;
- TinyOdysseyV39 supports decode step and cached forward;
- correctness gates exist;
- TSC parity exists;
- AION adaptive parity exists;
- tiny training benchmark exists;
- memory accounting exists.

### Critical weaknesses

1. **Forward full equals cached by construction.**
   `forward_full()` calls `forward_cached()`. This is okay for API smoke, but not a strong independent parity proof.
   Required patch: implement a separate full causal scan or vectorized reference, then compare cached decode to it.

2. **Cache updates use clone-heavy per-step assignments.**
   This is fine for correctness, but not a production implementation.
   Required patch: separate reference path from efficient path.

3. **AION test forces top-2 with high threshold.**
   It proves top-2 is reachable but not that mixed adaptive behavior works.
   Required patch: create deterministic examples where some steps top-1 and some top-2.

4. **Tiny training benchmark is synthetic and underpowered.**
   It only shows both models reduce loss.
   Required patch: add a real text option and multi-seed CSV.

5. **Transformer baseline is not parameter matched tightly.**
   Required patch: auto-sweep V39 state/rank/intermediate sizes to match Transformer parameters within 1–2%.

## 2.3 `odyssey_v39_cached_decode_fair_benchmark`

This is the right direction because it introduces explicit Transformer KV-cache decode.

### Strengths

- Transformer has `KVCache`;
- Transformer cached decode stores K/V per layer;
- Transformer full-vs-cached parity test exists;
- V39 cache memory and Transformer KV memory are reported;
- CSV output exists;
- prefill/decode timings are separated.

### Critical weaknesses

1. **The local run did not complete in the environment.**
   The package is runnable, but no measured table has been produced here.

2. **V39 and Transformer are still tiny and random.**
   Speed tables before training are engineering smoke only.

3. **V39 `prefill` uses sequential `decode_step`.**
   That is correct but not optimized. A final QLAF prefill should use a fused scan.

4. **Transformer cached decode is reference PyTorch, not optimized production decode.**
   It is fairer than naive prefix recompute but still not a FlashAttention/TGI-grade baseline.

5. **Parameter matching is reported but not enforced.**
   Required patch: use candidate sweep to select matched configs, then benchmark only matched rows.

## 2.4 `odyssey_v39_parameter_matched_benchmark`

This is useful as an environment-safe proxy.

### Strengths

- requires no PyTorch;
- emits parameter candidates;
- supports CSV append/resume;
- compares QLAF cache elements vs KV cache elements;
- provides CPU work proxy.

### Limitations

- analytical/proxy only;
- no model training;
- no real logits;
- no autograd;
- speedups are not publishable;
- still useful for deciding configurations before PyTorch/GPU runs.

## 2.5 `odyssey_v39_cached_decode_envsafe`

Useful for avoiding environment limits. It should remain a local smoke/triage tool, not evidence of superiority.

---

# 3. Main architectural blockers

## Blocker 1: independent full-forward parity is not strong enough

Current tiny PyTorch model uses cached scan as full forward. That proves consistency of one implementation path, not equivalence between two independent paths.

Patch:
- implement `forward_full_reference` that performs a separate causal state scan without using `decode_step`;
- compare `forward_full_reference` vs cached decode;
- keep the current `forward_cached` as serving path.

## Blocker 2: AION is policy-only, not true hierarchy yet

Current AION widens top-k. It does not yet split/collapse/promote states.

Patch:
- add `hierarchy_level`;
- add local/global state bands;
- add periodic promotion from local to global;
- add forced refresh scope;
- add route-margin trigger.

## Blocker 3: TSC is present but not proven useful

TSC has nonzero effect, but no quality ablation.

Patch:
- train QLAF-only, QLAF+AION, QLAF+TSC, full V39;
- report loss/speed/memory;
- keep TSC residual under a latency budget.

## Blocker 4: CUDA path is not implemented

The strongest claim requires a top-1 decode CUDA kernel.

Patch order:
1. PyTorch top-1 cached decode fixed;
2. C++/CUDA top-1 state update;
3. CUDA/reference parity;
4. timed decode vs cached Transformer;
5. only then prefill kernel.

## Blocker 5: no quality evidence yet

The project has architecture and benchmark harnesses, but no trained model quality table.

Patch:
- add small real text dataset;
- matched tokenizer;
- 3 seeds first;
- then 5 seeds;
- report validation loss/perplexity.

---

# 4. What must be done to thoroughly replace Transformer

## 4.1 Minimum scientific replacement

A minimal honest replacement claim requires:

1. V39 has no attention in the main path.
2. V39 cached decode does not use KV cache.
3. V39 full reference and cached decode match.
4. V39 trains to comparable loss on matched data.
5. V39 decode beats Transformer cached decode.
6. V39 cache memory is materially smaller.
7. AION/TSC ablations show they are useful.
8. Route B deploys the exact architecture.

## 4.2 Strong replacement

A strong claim requires:

1. equal or better validation loss;
2. decode speed +50% or more;
3. cache memory -40% or more;
4. p95 latency improvement;
5. long-context advantage grows with context;
6. reproducible GPU server run;
7. 5-seed results;
8. real dataset.

## 4.3 “Utter superiority” bar

Do not use that phrase publicly unless:

- V39 beats matched Transformer in quality or matches within statistical noise;
- V39 beats decode latency and memory by large margins;
- V39 does not lose important retrieval/disambiguation tasks;
- V39 has a real CUDA path;
- third-party reproduction is possible.

---

# 5. Recommended exact next patches

## Patch A — true independent parity

Add to PyTorch V39:

- `forward_full_reference`;
- `forward_cached`;
- gate comparing both.

Exit:
- max absolute diff < 1e-6 on CPU.

## Patch B — mixed AION behavior

Add deterministic route cases:

- confident token -> top-1;
- ambiguous token -> top-2;
- periodic refresh -> top-2/top-4.

Exit:
- top-k sequence contains both 1 and 2 naturally.

## Patch C — parameter-matched PyTorch benchmark

Use `parameter_candidates.csv` to select:

- hidden;
- layers;
- states;
- rank;
- intermediate.

Exit:
- parameter ratio within 1–2%.

## Patch D — fair cached decode run

Run:

- V39 cached decode;
- Transformer explicit KV cached decode;
- contexts 8, 16, 32, 64 first;
- CSV output.

Exit:
- table exists and is stable across 3 seeds.

## Patch E — tiny training benchmark

Train both models:

- same synthetic task first;
- then small real text;
- 3 seeds.

Exit:
- both reduce loss;
- V39 loss within a reasonable range.

## Patch F — CUDA top-1 decode

Only after A–E.

Kernel:
- route select;
- rank projection;
- state update;
- state read;
- output projection if possible.

Exit:
- CUDA/reference parity;
- speedup vs PyTorch V39 decode.

## Patch G — Route B server

Only after CUDA parity.

Package:
- HF repo;
- CUDA wheel;
- custom server;
- benchmark scripts;
- Dockerfile.

---

# 6. Final answer

The engine should not become a Transformer-like hybrid. It should become a **single-GPU state engine**:

> QLAF supplies causal memory and retrieval; AION prevents collapse and manages hierarchy; TSC repairs local/content errors as a small residual; decode-branch specialization makes serving fast; Route B packages the result for HF/CUDA/server deployment.

The current project artifacts are pointed in the right direction, but the decisive next step is **not more deployment packaging**. The decisive next step is:

1. independent parity;
2. parameter-matched fair cached decode;
3. tiny training quality table;
4. CUDA top-1 decode.

That is the shortest path from scaffold to credible Transformer replacement.
