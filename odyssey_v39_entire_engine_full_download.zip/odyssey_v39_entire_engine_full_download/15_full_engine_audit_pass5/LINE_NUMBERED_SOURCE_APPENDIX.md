# Line-Numbered Source Appendix



## engine_stack / `README.md`

```text
0001: # Odyssey V39 Engine Stack Pass 1
0002: 
0003: Architecture stack:
0004: 
0005: QLAF causal state cache + AION adaptive hierarchy + TSC residual correction + decode-branch specialization + Route B CUDA/HF deployment.
0006: 
0007: This package is an implementation-grade scaffold and engineering contract. It is not a measured benchmark claim.
0008: 
0009: The purpose is to define the single-GPU Transformer-replacement engine in a way that can be implemented, tested, benchmarked, and deployed.
0010: 
0011: ## Core goal
0012: 
0013: Remove attention and KV cache from the dominant inference path.
0014: 
0015: Replace them with:
0016: - a causal QLAF state cache,
0017: - AION adaptive state hierarchy,
0018: - TSC residual correction,
0019: - top-1 decode branch,
0020: - CUDA fused single-GPU kernels,
0021: - Hugging Face custom model packaging,
0022: - custom inference server.
0023: 
0024: ## Status
0025: 
0026: This pass includes:
0027: - engine architecture contract,
0028: - cache schema,
0029: - AION policy spec,
0030: - TSC residual spec,
0031: - decode branch specialization spec,
0032: - Route B deployment spec,
0033: - benchmark gates,
0034: - risk register,
0035: - minimal Python module skeletons,
0036: - test stubs,
0037: - CUDA ABI skeleton,
0038: - HF repo template.
0039: 
0040: It intentionally does not claim performance superiority yet.
```


## engine_stack / `benchmarks/BENCHMARK_PROTOCOL.md`

```text
0001: # Odyssey V39 Benchmark Protocol
0002: 
0003: ## Models
0004: 
0005: - matched Transformer baseline;
0006: - Odyssey V39 QLAF only;
0007: - Odyssey V39 QLAF + AION;
0008: - Odyssey V39 QLAF + TSC;
0009: - Odyssey V39 full stack.
0010: 
0011: ## Required context lengths
0012: 
0013: - 512;
0014: - 1024;
0015: - 2048;
0016: - 4096;
0017: - 8192.
0018: 
0019: ## Required metrics
0020: 
0021: - train loss;
0022: - validation loss;
0023: - perplexity;
0024: - training tokens/sec;
0025: - prefill tokens/sec;
0026: - decode tokens/sec;
0027: - p50 latency;
0028: - p95 latency;
0029: - peak memory;
0030: - cache memory;
0031: - model parameter count.
0032: 
0033: ## Seeds
0034: 
0035: Minimum:
0036: - 5 seeds for final claim.
0037: 
0038: ## Output tables
0039: 
0040: Produce:
0041: - aggregate_results.csv;
0042: - speedup_table.csv;
0043: - memory_table.csv;
0044: - latency_table.csv;
0045: - ablation_table.csv;
0046: - README_summary.md.
```


## engine_stack / `cuda_extension/odyssey_v39_cuda/CUDA_ABI.md`

```text
0001: # Odyssey V39 CUDA ABI
0002: 
0003: ## Required exported functions
0004: 
0005: - qlaf_prefill
0006: - qlaf_decode_top1
0007: - qlaf_decode_topk
0008: - qlaf_cache_update
0009: - qlaf_route_select
0010: - tsc_residual_optional
0011: 
0012: ## Phase 1
0013: 
0014: Correctness kernels:
0015: - simple prefill;
0016: - simple decode;
0017: - reference parity.
0018: 
0019: ## Phase 2
0020: 
0021: Performance kernels:
0022: - BF16/FP16;
0023: - FP32 accumulation;
0024: - tiled state projection;
0025: - fused state update/readout;
0026: - top-1 decode specialization.
0027: 
0028: ## Phase 3
0029: 
0030: Production kernels:
0031: - persistent cache layout;
0032: - batch decode scheduler support;
0033: - graph-capture-friendly call boundaries;
0034: - metrics hooks.
```


## engine_stack / `docs/00_EXECUTIVE_SPEC.md`

```text
0001: # Odyssey V39 Executive Specification
0002: 
0003: ## Final stack
0004: 
0005: **QLAF causal state cache + AION adaptive hierarchy + TSC residual correction + decode-branch specialization + Route B CUDA/HF deployment.**
0006: 
0007: This is the strongest single-GPU Transformer-replacement direction from the project.
0008: 
0009: ## Why this replaces Transformer
0010: 
0011: A Transformer uses:
0012: - attention scores;
0013: - softmax retrieval;
0014: - KV cache;
0015: - many heads;
0016: - full-context prefill;
0017: - token-by-token KV reuse during decode.
0018: 
0019: Odyssey V39 replaces those with:
0020: - QLAF route scores;
0021: - state-summary readout;
0022: - causal QLAF state cache;
0023: - multi-state bank;
0024: - AION hierarchy/refresh;
0025: - top-1 decode state update.
0026: 
0027: ## Primary claim target
0028: 
0029: Not:
0030: > "It is another efficient attention."
0031: 
0032: But:
0033: > "The dominant inference path removes attention and the KV cache, replacing them with a causal QLAF state engine that preserves language quality while improving single-GPU decode speed, cache memory, and long-context serving."
0034: 
0035: ## Single-GPU proof target
0036: 
0037: Required hardware class:
0038: - A100 40GB/80GB, H100, L40S, RTX 4090/5090-class GPU.
0039: 
0040: Required comparison:
0041: - matched Transformer baseline;
0042: - matched parameter count;
0043: - matched data;
0044: - matched tokenizer;
0045: - matched optimizer;
0046: - matched tokens;
0047: - matched context lengths;
0048: - 5 seeds.
0049: 
0050: Required metrics:
0051: - validation loss/perplexity;
0052: - training tokens/sec;
0053: - prefill tokens/sec;
0054: - decode tokens/sec;
0055: - p50/p95 latency;
0056: - peak memory;
0057: - cache memory;
0058: - long-context scaling.
0059: 
0060: ## Hard gate before superiority claim
0061: 
0062: Odyssey V39 must pass:
0063: 1. no-future-leakage test;
0064: 2. full-forward vs cached-decode parity test;
0065: 3. batch vs single equivalence;
0066: 4. cache reset/invalidation test;
0067: 5. CUDA vs PyTorch reference parity;
0068: 6. matched quality table;
0069: 7. matched speed/memory table.
```


## engine_stack / `docs/01_ENGINE_ARCHITECTURE.md`

```text
0001: # Engine Architecture
0002: 
0003: ## Major components
0004: 
0005: ### OdysseyV39Engine
0006: 
0007: Owns:
0008: - model;
0009: - tokenizer;
0010: - runtime config;
0011: - cache manager;
0012: - AION policy;
0013: - kernel dispatcher;
0014: - scheduler;
0015: - metrics collector.
0016: 
0017: Responsibilities:
0018: - prefill prompts;
0019: - decode tokens;
0020: - manage caches;
0021: - route requests;
0022: - select CUDA or fallback kernels;
0023: - expose generation API.
0024: 
0025: ### QLAFCausalStateCache
0026: 
0027: Replaces Transformer KV cache.
0028: 
0029: Per layer, per batch:
0030: - state summaries;
0031: - active-state ids;
0032: - state weights/counts;
0033: - route confidence;
0034: - hierarchy levels;
0035: - refresh counters;
0036: - sequence position;
0037: - validity metadata.
0038: 
0039: ### AIONAdaptiveHierarchy
0040: 
0041: Controls:
0042: - top-1 vs top-2/top-4 state use;
0043: - refresh timing;
0044: - state split/collapse;
0045: - long-context promotion;
0046: - stale-state recovery.
0047: 
0048: ### TSCResidualCorrector
0049: 
0050: Small residual branch after QLAF:
0051: - improves local/content correction;
0052: - must not become the main mixer;
0053: - can be disabled or thinned during decode.
0054: 
0055: ### DecodeBranchSpecializer
0056: 
0057: Enforces serving path:
0058: - default top-1 state;
0059: - correction minimal;
0060: - optional adaptive widening;
0061: - cache-resident updates only.
0062: 
0063: ### RouteBDeployment
0064: 
0065: Includes:
0066: - HF custom model;
0067: - safetensors;
0068: - trust_remote_code=True;
0069: - PyTorch fallback;
0070: - CUDA wheel;
0071: - Docker/custom server.
0072: 
0073: ## Layer contract
0074: 
0075: Each layer:
0076: 
0077: 1. RMSNorm.
0078: 2. QLAF causal state mixer.
0079: 3. Residual add.
0080: 4. TSC residual correction.
0081: 5. Residual add.
0082: 6. SwiGLU MLP.
0083: 7. Residual add.
0084: 
0085: The attention module is not present in the dominant path.
0086: 
0087: ## Prefill contract
0088: 
0089: Input:
0090: - prompt tokens [B, T].
0091: 
0092: Output:
0093: - logits or final hidden states;
0094: - active causal QLAF cache.
0095: 
0096: Required behavior:
0097: - causal scan;
0098: - no future leakage;
0099: - cache populated for decode;
0100: - top-k prefill routing.
0101: 
0102: ## Decode contract
0103: 
0104: Input:
0105: - current token [B, 1];
0106: - existing QLAF cache.
0107: 
0108: Output:
0109: - logits [B, vocab];
0110: - updated QLAF cache.
0111: 
0112: Required behavior:
0113: - top-1 default route;
0114: - no full-sequence recomputation;
0115: - cache update;
0116: - optional AION widening/refresh.
0117: 
0118: ## Refresh contract
0119: 
0120: Refresh may:
0121: - recompute selected states;
0122: - widen top-k temporarily;
0123: - rebuild from compressed prefix;
0124: - mark cache valid/invalid;
0125: - preserve causal consistency.
0126: 
0127: It must not silently change logits in a way that breaks parity tests.
```


## engine_stack / `docs/02_CACHE_SCHEMA.md`

```text
0001: # QLAF Causal State Cache Schema
0002: 
0003: ## Purpose
0004: 
0005: The QLAF cache is the center of the Transformer replacement. It is not metadata and it is not a KV cache.
0006: 
0007: It stores causal state summaries that decode can read and update.
0008: 
0009: ## Per-layer tensors
0010: 
0011: ### state_summary
0012: 
0013: Shape:
0014: `[batch, num_states, state_rank]`
0015: 
0016: Meaning:
0017: The compressed causal memory bank.
0018: 
0019: ### state_weight
0020: 
0021: Shape:
0022: `[batch, num_states]`
0023: 
0024: Meaning:
0025: How much causal evidence has entered each state. Can represent count, decay mass, confidence weight, or normalized accumulator.
0026: 
0027: ### active_state_ids
0028: 
0029: Shape:
0030: `[batch, decode_top_k]`
0031: 
0032: Meaning:
0033: Which state(s) are active for the next decode update.
0034: 
0035: ### route_confidence
0036: 
0037: Shape:
0038: `[batch]`
0039: 
0040: Meaning:
0041: Confidence in top-1 state. AION uses this to decide whether to widen or refresh.
0042: 
0043: ### hierarchy_level
0044: 
0045: Shape:
0046: `[batch, num_states]`
0047: 
0048: Meaning:
0049: AION state hierarchy marker. Lower levels track local detail; higher levels track long-context summaries.
0050: 
0051: ### refresh_counter
0052: 
0053: Shape:
0054: `[batch]`
0055: 
0056: Meaning:
0057: Number of decode steps since last refresh.
0058: 
0059: ### position
0060: 
0061: Shape:
0062: `[batch]`
0063: 
0064: Meaning:
0065: Current causal position.
0066: 
0067: ### valid
0068: 
0069: Shape:
0070: `[batch]`
0071: 
0072: Meaning:
0073: Whether the cache row can be used.
0074: 
0075: ## Metadata
0076: 
0077: Required:
0078: - dtype;
0079: - device;
0080: - model revision;
0081: - kernel version;
0082: - max context;
0083: - state count;
0084: - state rank;
0085: - routing policy;
0086: - cache creation mode.
0087: 
0088: ## Invalidation triggers
0089: 
0090: Invalidate cache if:
0091: - model weights change;
0092: - dtype changes;
0093: - device changes;
0094: - kernel version changes;
0095: - routing policy changes incompatibly;
0096: - state rank changes;
0097: - num states changes;
0098: - sequence exceeds max context;
0099: - request batch packing corrupts order.
0100: 
0101: ## Partial refresh triggers
0102: 
0103: Refresh selected states if:
0104: - route confidence below threshold;
0105: - logit entropy spike;
0106: - periodic refresh interval reached;
0107: - long-context boundary crossed;
0108: - fallback kernel used after CUDA failure;
0109: - AION detects collapse risk.
0110: 
0111: ## Cache correctness tests
0112: 
0113: Required:
0114: 1. full forward equals prefill+decode within tolerance;
0115: 2. one-token decode equals equivalent causal scan;
0116: 3. batch decode equals independent decode;
0117: 4. cache reset clears all state;
0118: 5. invalid cache refuses decode;
0119: 6. device/dtype mismatch detected.
```


## engine_stack / `docs/03_AION_POLICY.md`

```text
0001: # AION Adaptive Hierarchy Policy
0002: 
0003: ## Purpose
0004: 
0005: AION prevents QLAF from becoming an irreversible lossy single-state collapse.
0006: 
0007: The default decode path is top-1 for speed, but AION decides when the model must temporarily widen or refresh.
0008: 
0009: ## Policy levels
0010: 
0011: ### Level 0: fixed_top1
0012: 
0013: Use top-1 state only.
0014: 
0015: Fastest. Used during normal decode.
0016: 
0017: ### Level 1: adaptive_top2
0018: 
0019: Use top-2 states if:
0020: - route confidence is low;
0021: - entropy is high;
0022: - state weight is unstable;
0023: - generated sequence crosses a boundary.
0024: 
0025: ### Level 2: refresh_top4
0026: 
0027: Use top-4 or full local refresh if:
0028: - repeated uncertainty;
0029: - long-context transition;
0030: - cache stale flag;
0031: - mismatch detected by parity monitor.
0032: 
0033: ### Level 3: forced_rebuild
0034: 
0035: Rebuild selected cache rows if:
0036: - invalid metadata;
0037: - fallback recovery;
0038: - kernel mismatch;
0039: - severe numerical instability.
0040: 
0041: ## AION inputs
0042: 
0043: - route logits;
0044: - route confidence;
0045: - decode entropy;
0046: - state weights;
0047: - sequence position;
0048: - refresh counter;
0049: - optional task signal.
0050: 
0051: ## AION outputs
0052: 
0053: - active top-k;
0054: - refresh flag;
0055: - hierarchy promotion flag;
0056: - TSC correction strength;
0057: - cache validity update.
0058: 
0059: ## Design constraint
0060: 
0061: AION must not turn every decode step into full compute. It exists to keep top-1 decode safe, not to erase the speed advantage.
0062: 
0063: ## Training regularization
0064: 
0065: Recommended:
0066: - route entropy regularizer;
0067: - top-1 consistency loss;
0068: - refresh penalty;
0069: - decode branch KL;
0070: - state diversity penalty.
```


## engine_stack / `docs/04_TSC_RESIDUAL_CORRECTION.md`

```text
0001: # TSC Residual Correction
0002: 
0003: ## Purpose
0004: 
0005: TSC repairs local/content mistakes that pure QLAF state aggregation may miss.
0006: 
0007: It should be a correction branch, not the dominant mixer.
0008: 
0009: ## Placement
0010: 
0011: After QLAF residual and before MLP:
0012: 
0013: 1. normalized hidden state;
0014: 2. small local/content correction;
0015: 3. gated residual add.
0016: 
0017: ## Constraints
0018: 
0019: - small parameter share;
0020: - low latency;
0021: - optional in decode;
0022: - no full attention;
0023: - no all-token quadratic mixing;
0024: - can be stronger during training/prefill.
0025: 
0026: ## Decode behavior
0027: 
0028: Default:
0029: - TSC minimal or disabled.
0030: 
0031: Adaptive:
0032: - enabled if AION uncertainty trigger fires.
0033: 
0034: Training:
0035: - enabled more often;
0036: - consistency loss encourages decode path to survive without full correction.
0037: 
0038: ## Ablation requirements
0039: 
0040: Benchmarks must report:
0041: - QLAF only;
0042: - QLAF + AION;
0043: - QLAF + TSC;
0044: - QLAF + AION + TSC;
0045: - decode branch enabled/disabled.
```


## engine_stack / `docs/05_DECODE_BRANCH_SPECIALIZATION.md`

```text
0001: # Decode Branch Specialization
0002: 
0003: ## Goal
0004: 
0005: Make the serving path fast enough to defeat Transformer KV-cache decode on one GPU.
0006: 
0007: ## Training path
0008: 
0009: Training uses:
0010: - richer top-k state access;
0011: - TSC correction;
0012: - optional teacher KL;
0013: - route regularization.
0014: 
0015: ## Decode path
0016: 
0017: Serving uses:
0018: - top-1 state default;
0019: - cache-resident updates;
0020: - minimal TSC;
0021: - no full attention;
0022: - no full sequence recomputation.
0023: 
0024: ## Consistency losses
0025: 
0026: Recommended:
0027: 
0028: 1. full branch CE loss;
0029: 2. decode branch CE loss;
0030: 3. full-to-decode KL;
0031: 4. top-1 route stability loss;
0032: 5. refresh penalty.
0033: 
0034: ## Exit criteria
0035: 
0036: Decode branch is acceptable only if:
0037: - quality loss vs rich path is small;
0038: - decode latency improves materially;
0039: - p95 remains stable;
0040: - adaptive widening recovers hard cases.
```


## engine_stack / `docs/06_ROUTE_B_DEPLOYMENT.md`

```text
0001: # Route B CUDA/HF Deployment
0002: 
0003: ## Components
0004: 
0005: ### HF repository
0006: 
0007: Contains:
0008: - config;
0009: - custom model files;
0010: - generation utilities;
0011: - tokenizer;
0012: - safetensors;
0013: - README/model card.
0014: 
0015: Requires:
0016: - `trust_remote_code=True`.
0017: 
0018: ### CUDA wheel
0019: 
0020: Contains:
0021: - QLAF prefill kernels;
0022: - QLAF decode kernels;
0023: - cache update kernels;
0024: - route selection kernels;
0025: - optional TSC kernels.
0026: 
0027: ### Custom server
0028: 
0029: Contains:
0030: - prefill/decode scheduler;
0031: - streaming output;
0032: - cache ownership;
0033: - metrics;
0034: - memory accounting;
0035: - batching.
0036: 
0037: ## Correct deployment modes
0038: 
0039: ### Mode 1: HF fallback
0040: 
0041: Works anywhere. Not performance claim.
0042: 
0043: ### Mode 2: HF + CUDA wheel
0044: 
0045: Local accelerated inference.
0046: 
0047: ### Mode 3: Docker/custom server
0048: 
0049: Production performance path.
0050: 
0051: ## Warning
0052: 
0053: Hosted generic inference may not preserve the custom-kernel advantages. The official performance claim should be based on the custom server and wheel.
```


## engine_stack / `docs/07_BENCHMARK_GATES.md`

```text
0001: # Benchmark Gates
0002: 
0003: ## Gate 1: Correctness
0004: 
0005: - no future leakage;
0006: - full-forward/cached-decode parity;
0007: - CUDA/reference parity;
0008: - batch/single equivalence;
0009: - cache invalidation.
0010: 
0011: ## Gate 2: Matched training
0012: 
0013: - matched Transformer;
0014: - matched V39;
0015: - same tokenizer;
0016: - same dataset;
0017: - same train/val split;
0018: - same optimizer;
0019: - same tokens;
0020: - same context;
0021: - 5 seeds.
0022: 
0023: ## Gate 3: Serving
0024: 
0025: Report:
0026: - prefill tokens/sec;
0027: - decode tokens/sec;
0028: - end-to-end tokens/sec;
0029: - p50 latency;
0030: - p95 latency;
0031: - peak GPU memory;
0032: - cache memory.
0033: 
0034: ## Gate 4: Long context
0035: 
0036: Test:
0037: - 512;
0038: - 1024;
0039: - 2048;
0040: - 4096;
0041: - 8192.
0042: 
0043: ## Gate 5: Ablation
0044: 
0045: Report:
0046: - Transformer;
0047: - QLAF only;
0048: - QLAF + AION;
0049: - QLAF + TSC;
0050: - QLAF + AION + TSC;
0051: - decode branch top-1;
0052: - adaptive top-k.
0053: 
0054: ## Superiority threshold
0055: 
0056: A defensible "utter superiority" single-GPU claim needs:
0057: 
0058: - quality within 0–5% of Transformer, preferably equal/better;
0059: - decode speed +50% or more;
0060: - cache memory -40% or more;
0061: - p95 latency -25% or more;
0062: - long-context serving advantage increasing with context;
0063: - reproducible scripts/logs.
```


## engine_stack / `hf_repo_template/HF_REPO_SPEC.md`

```text
0001: # Hugging Face Repo Template Spec
0002: 
0003: ## Required files
0004: 
0005: - config.json
0006: - configuration_odyssey_v39.py
0007: - modeling_odyssey_v39.py
0008: - generation_odyssey_v39.py
0009: - tokenizer files
0010: - model.safetensors
0011: - README.md
0012: - requirements.txt
0013: 
0014: ## Loading
0015: 
0016: Use:
0017: 
0018: AutoModelForCausalLM.from_pretrained(
0019:     repo,
0020:     trust_remote_code=True,
0021:     torch_dtype="auto",
0022:     device_map="auto",
0023: )
0024: 
0025: ## Model card warning
0026: 
0027: Best performance requires:
0028: - odyssey-v39-cuda wheel;
0029: - compatible CUDA/PyTorch version;
0030: - custom Odyssey server.
0031: 
0032: PyTorch fallback is for portability/correctness, not final performance claims.
```


## engine_stack / `pyproject.toml`

```text
0001: [project]
0002: name = "odyssey-v39-engine-stack"
0003: version = "0.1.0"
0004: description = "Odyssey V39 single-GPU QLAF/AION/TSC Transformer-replacement engine scaffold"
0005: requires-python = ">=3.10"
0006: 
0007: [tool.pytest.ini_options]
0008: pythonpath = ["src"]
0009: testpaths = ["tests"]
```


## engine_stack / `server/SERVER_SPEC.md`

```text
0001: # Odyssey V39 Server Spec
0002: 
0003: ## Responsibilities
0004: 
0005: - load HF model with trust_remote_code;
0006: - load CUDA wheel if available;
0007: - own QLAF caches;
0008: - separate prefill and decode;
0009: - stream tokens;
0010: - batch compatible decode requests;
0011: - avoid mixing fallback requests into fast CUDA batch;
0012: - report metrics.
0013: 
0014: ## Endpoints
0015: 
0016: - /health
0017: - /generate
0018: - /generate_stream
0019: - /metrics
0020: - /cache/debug
0021: 
0022: ## Required metrics
0023: 
0024: - active requests;
0025: - prefill queue length;
0026: - decode batch size;
0027: - tokens/sec;
0028: - p50 latency;
0029: - p95 latency;
0030: - peak GPU memory;
0031: - cache memory;
0032: - fallback count;
0033: - refresh count;
```


## engine_stack / `src/odyssey_v39/__init__.py`

```text
0001: from .config import OdysseyV39Config, RuntimeConfig
0002: from .cache import QLAFCausalStateCache
0003: from .aion import AIONPolicy
0004: from .tsc import TSCResidualPolicy
0005: from .engine import OdysseyV39Engine
```


## engine_stack / `src/odyssey_v39/aion.py`

```text
0001: from dataclasses import dataclass
0002: 
0003: @dataclass
0004: class AIONDecision:
0005:     top_k: int
0006:     refresh: bool
0007:     promote_hierarchy: bool
0008:     enable_tsc: bool
0009:     reason: str
0010: 
0011: class AIONPolicy:
0012:     def __init__(self, decode_top_k=1, prefill_top_k=2, confidence_threshold=0.65, refresh_interval=128):
0013:         self.decode_top_k = decode_top_k
0014:         self.prefill_top_k = prefill_top_k
0015:         self.confidence_threshold = confidence_threshold
0016:         self.refresh_interval = refresh_interval
0017: 
0018:     def decide_decode(self, route_confidence: float, entropy: float, steps_since_refresh: int) -> AIONDecision:
0019:         if steps_since_refresh >= self.refresh_interval:
0020:             return AIONDecision(top_k=max(2, self.decode_top_k), refresh=True, promote_hierarchy=True, enable_tsc=True, reason="periodic_refresh")
0021:         if route_confidence < self.confidence_threshold:
0022:             return AIONDecision(top_k=max(2, self.decode_top_k), refresh=False, promote_hierarchy=False, enable_tsc=True, reason="low_confidence")
0023:         return AIONDecision(top_k=self.decode_top_k, refresh=False, promote_hierarchy=False, enable_tsc=False, reason="fast_top1")
```


## engine_stack / `src/odyssey_v39/cache.py`

```text
0001: from dataclasses import dataclass, field
0002: from typing import Dict, Any, Optional
0003: 
0004: @dataclass
0005: class CacheMetadata:
0006:     dtype: str
0007:     device: str
0008:     model_revision: str
0009:     kernel_version: str
0010:     routing_policy: str
0011:     valid: bool = True
0012: 
0013: @dataclass
0014: class LayerState:
0015:     state_summary: Any = None
0016:     state_weight: Any = None
0017:     active_state_ids: Any = None
0018:     route_confidence: Any = None
0019:     hierarchy_level: Any = None
0020:     refresh_counter: Any = None
0021:     position: Any = None
0022:     valid: bool = False
0023: 
0024: class QLAFCausalStateCache:
0025:     def __init__(self, num_layers: int, metadata: CacheMetadata):
0026:         self.num_layers = num_layers
0027:         self.metadata = metadata
0028:         self.layers = [LayerState() for _ in range(num_layers)]
0029: 
0030:     def invalidate(self, reason: str):
0031:         self.metadata.valid = False
0032:         for layer in self.layers:
0033:             layer.valid = False
0034:         self.invalid_reason = reason
0035: 
0036:     def is_valid(self) -> bool:
0037:         return bool(self.metadata.valid and all(layer.valid for layer in self.layers))
0038: 
0039:     def mark_layer_valid(self, layer_idx: int):
0040:         self.layers[layer_idx].valid = True
0041: 
0042:     def require_valid(self):
0043:         if not self.is_valid():
0044:             reason = getattr(self, "invalid_reason", "unknown")
0045:             raise RuntimeError(f"QLAF cache invalid: {reason}")
```


## engine_stack / `src/odyssey_v39/config.py`

```text
0001: from dataclasses import dataclass
0002: 
0003: @dataclass
0004: class OdysseyV39Config:
0005:     vocab_size: int = 32000
0006:     hidden_size: int = 1024
0007:     intermediate_size: int = 4096
0008:     num_layers: int = 16
0009:     num_states: int = 8
0010:     state_rank: int = 64
0011:     prefill_top_k: int = 2
0012:     decode_top_k: int = 1
0013:     max_position_embeddings: int = 8192
0014:     use_tsc: bool = True
0015:     use_aion: bool = True
0016: 
0017: @dataclass
0018: class RuntimeConfig:
0019:     device: str = "cuda"
0020:     dtype: str = "bfloat16"
0021:     use_cuda_kernels: bool = True
0022:     allow_fallback: bool = True
0023:     force_reference: bool = False
0024:     cache_refresh_interval: int = 128
0025:     route_confidence_threshold: float = 0.65
0026:     entropy_refresh_threshold: float = 7.5
```


## engine_stack / `src/odyssey_v39/dispatcher.py`

```text
0001: class KernelDispatcher:
0002:     def __init__(self, use_cuda_kernels=True, allow_fallback=True, force_reference=False):
0003:         self.use_cuda_kernels = use_cuda_kernels
0004:         self.allow_fallback = allow_fallback
0005:         self.force_reference = force_reference
0006:         self.cuda_available = False
0007:         self.cuda_module = None
0008:         if use_cuda_kernels and not force_reference:
0009:             try:
0010:                 import odyssey_v39_cuda
0011:                 self.cuda_module = odyssey_v39_cuda
0012:                 self.cuda_available = True
0013:             except Exception:
0014:                 self.cuda_available = False
0015: 
0016:     def backend(self) -> str:
0017:         if self.force_reference:
0018:             return "reference"
0019:         if self.use_cuda_kernels and self.cuda_available:
0020:             return "cuda"
0021:         if self.allow_fallback:
0022:             return "reference"
0023:         raise RuntimeError("CUDA kernels unavailable and fallback disabled")
0024: 
0025:     def prefill(self, *args, **kwargs):
0026:         if self.backend() == "cuda":
0027:             return self.cuda_module.prefill(*args, **kwargs)
0028:         raise NotImplementedError("Reference prefill must be provided by model implementation")
0029: 
0030:     def decode(self, *args, **kwargs):
0031:         if self.backend() == "cuda":
0032:             return self.cuda_module.decode(*args, **kwargs)
0033:         raise NotImplementedError("Reference decode must be provided by model implementation")
```


## engine_stack / `src/odyssey_v39/engine.py`

```text
0001: from .config import OdysseyV39Config, RuntimeConfig
0002: from .cache import QLAFCausalStateCache, CacheMetadata
0003: from .aion import AIONPolicy
0004: from .tsc import TSCResidualPolicy
0005: from .dispatcher import KernelDispatcher
0006: 
0007: class OdysseyV39Engine:
0008:     def __init__(self, model=None, tokenizer=None, config=None, runtime=None, model_revision="dev"):
0009:         self.model = model
0010:         self.tokenizer = tokenizer
0011:         self.config = config or OdysseyV39Config()
0012:         self.runtime = runtime or RuntimeConfig()
0013:         self.model_revision = model_revision
0014:         self.aion = AIONPolicy(
0015:             decode_top_k=self.config.decode_top_k,
0016:             prefill_top_k=self.config.prefill_top_k,
0017:             confidence_threshold=self.runtime.route_confidence_threshold,
0018:             refresh_interval=self.runtime.cache_refresh_interval,
0019:         )
0020:         self.tsc_policy = TSCResidualPolicy(enabled=self.config.use_tsc)
0021:         self.dispatcher = KernelDispatcher(
0022:             use_cuda_kernels=self.runtime.use_cuda_kernels,
0023:             allow_fallback=self.runtime.allow_fallback,
0024:             force_reference=self.runtime.force_reference,
0025:         )
0026: 
0027:     def new_cache(self):
0028:         metadata = CacheMetadata(
0029:             dtype=self.runtime.dtype,
0030:             device=self.runtime.device,
0031:             model_revision=self.model_revision,
0032:             kernel_version="v39-dev",
0033:             routing_policy="aion_adaptive" if self.config.use_aion else "fixed_top1",
0034:         )
0035:         return QLAFCausalStateCache(self.config.num_layers, metadata)
0036: 
0037:     def prefill(self, input_ids):
0038:         cache = self.new_cache()
0039:         if self.model is None:
0040:             raise RuntimeError("No model attached")
0041:         if hasattr(self.model, "prefill"):
0042:             return self.model.prefill(input_ids, cache)
0043:         raise NotImplementedError("Attached model must implement prefill(input_ids, cache)")
0044: 
0045:     def decode_step(self, token_ids, cache, route_confidence=1.0, entropy=0.0, steps_since_refresh=0):
0046:         cache.require_valid()
0047:         decision = self.aion.decide_decode(route_confidence, entropy, steps_since_refresh)
0048:         tsc_scale = self.tsc_policy.scale_for_decode(decision.enable_tsc)
0049:         if self.model is None:
0050:             raise RuntimeError("No model attached")
0051:         if hasattr(self.model, "decode_step"):
0052:             return self.model.decode_step(token_ids, cache, decision=decision, tsc_scale=tsc_scale)
0053:         raise NotImplementedError("Attached model must implement decode_step(token_ids, cache, decision, tsc_scale)")
```


## engine_stack / `src/odyssey_v39/tsc.py`

```text
0001: from dataclasses import dataclass
0002: 
0003: @dataclass
0004: class TSCResidualPolicy:
0005:     enabled: bool = True
0006:     decode_default_enabled: bool = False
0007:     correction_scale: float = 0.10
0008:     max_decode_scale: float = 0.20
0009: 
0010:     def scale_for_decode(self, enable_tsc: bool) -> float:
0011:         if not self.enabled:
0012:             return 0.0
0013:         if enable_tsc:
0014:             return self.max_decode_scale
0015:         if self.decode_default_enabled:
0016:             return self.correction_scale
0017:         return 0.0
```


## engine_stack / `tests/test_aion_policy.py`

```text
0001: def test_aion_fast_top1():
0002:     from odyssey_v39.aion import AIONPolicy
0003:     p = AIONPolicy(decode_top_k=1, confidence_threshold=0.5, refresh_interval=100)
0004:     d = p.decide_decode(route_confidence=0.9, entropy=1.0, steps_since_refresh=1)
0005:     assert d.top_k == 1
0006:     assert not d.refresh
0007: 
0008: def test_aion_low_confidence_widens():
0009:     from odyssey_v39.aion import AIONPolicy
0010:     p = AIONPolicy(decode_top_k=1, confidence_threshold=0.8, refresh_interval=100)
0011:     d = p.decide_decode(route_confidence=0.2, entropy=1.0, steps_since_refresh=1)
0012:     assert d.top_k >= 2
0013:     assert d.enable_tsc
```


## engine_stack / `tests/test_cache_contract.py`

```text
0001: # Contract tests for Odyssey V39 cache.
0002: # These are stubs for the real implementation.
0003: 
0004: def test_cache_invalidates_all_layers():
0005:     from odyssey_v39.cache import QLAFCausalStateCache, CacheMetadata
0006:     cache = QLAFCausalStateCache(3, CacheMetadata("bf16", "cuda", "dev", "dev", "top1"))
0007:     for i in range(3):
0008:         cache.mark_layer_valid(i)
0009:     cache.invalidate("unit_test")
0010:     assert not cache.is_valid()
0011: 
0012: def test_cache_requires_valid():
0013:     from odyssey_v39.cache import QLAFCausalStateCache, CacheMetadata
0014:     cache = QLAFCausalStateCache(1, CacheMetadata("bf16", "cuda", "dev", "dev", "top1"))
0015:     try:
0016:         cache.require_valid()
0017:     except RuntimeError:
0018:         assert True
0019:     else:
0020:         assert False
```


## pytorch_lite / `README.md`

```text
0001: # Odyssey V39 PyTorch Correctness + Tiny Training Benchmark Lite
0002: 
0003: This is the PyTorch bridge artifact for:
0004: 
0005: - correctness gates;
0006: - TSC parity;
0007: - AION adaptive parity;
0008: - tiny matched Transformer training benchmark;
0009: - decode speed smoke;
0010: - memory accounting.
0011: 
0012: The default benchmark settings are intentionally tiny so they can run locally first.
0013: This is not a CUDA engine and not a final superiority claim.
```


## pytorch_lite / `docs/NEXT_STEPS.md`

```text
0001: # Next Steps
0002: 
0003: 1. Run `python run_gates_only.py`.
0004: 2. Run `python run_all.py`.
0005: 3. Add Transformer KV-cache decode baseline.
0006: 4. Tighten parameter matching.
0007: 5. Run 3 seeds and output CSV.
0008: 6. Add CUDA top-1 decode only after PyTorch gates pass.
0009: 7. Add HF custom model wrapper and Route B server.
```


## pytorch_lite / `docs/STATUS.md`

```text
0001: # Status
0002: 
0003: This package provides the PyTorch bridge for Odyssey V39.
0004: 
0005: Included:
0006: - QLAF causal cache correctness gates.
0007: - TSC parity.
0008: - AION adaptive routing parity.
0009: - Tiny synthetic training benchmark.
0010: - Decode speed smoke.
0011: - Cache memory accounting.
0012: 
0013: Caution:
0014: The decode benchmark compares against naive Transformer prefix recompute, not optimized KV-cache decode. The next fair step is a Transformer cached decode baseline.
```


## pytorch_lite / `pyproject.toml`

```text
0001: [project]
0002: name = "odyssey-v39-pytorch-correctness-training-lite"
0003: version = "0.1.0"
0004: requires-python = ">=3.10"
0005: dependencies = ["torch"]
0006: 
0007: [tool.pytest.ini_options]
0008: pythonpath = ["src"]
0009: testpaths = ["tests"]
```


## pytorch_lite / `run_all.py`

```text
0001: import json
0002: from odyssey_v39_pt.run_all import run_all
0003: 
0004: if __name__ == "__main__":
0005:     print(json.dumps(run_all(), indent=2))
```


## pytorch_lite / `run_gates_only.py`

```text
0001: import json
0002: from odyssey_v39_pt.run_all import run_all
0003: 
0004: if __name__ == "__main__":
0005:     print(json.dumps(run_all(include_training=False), indent=2))
```


## pytorch_lite / `src/odyssey_v39_pt/__init__.py`

```text
0001: from .config import TinyConfig
0002: from .model_v39 import TinyOdysseyV39
0003: from .model_transformer import TinyTransformerLM
0004: from .gates import run_correctness_gates, run_tsc_parity, run_aion_adaptive_parity
0005: from .train_bench import run_tiny_training_benchmark
0006: from .decode_bench import run_decode_speed_benchmark
0007: from .run_all import run_all
```


## pytorch_lite / `src/odyssey_v39_pt/cache.py`

```text
0001: from dataclasses import dataclass
0002: import torch
0003: 
0004: @dataclass
0005: class QLAFCache:
0006:     state_summary: torch.Tensor
0007:     state_weight: torch.Tensor
0008:     position: int = 0
0009:     valid: bool = True
0010: 
0011:     @classmethod
0012:     def empty(cls, batch_size, cfg, device=None, dtype=None):
0013:         return cls(
0014:             state_summary=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, cfg.state_rank, device=device, dtype=dtype),
0015:             state_weight=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, device=device, dtype=dtype),
0016:             position=0,
0017:             valid=True,
0018:         )
0019: 
0020:     def clone(self):
0021:         return QLAFCache(self.state_summary.clone(), self.state_weight.clone(), int(self.position), bool(self.valid))
0022: 
0023:     def reset(self):
0024:         self.state_summary.zero_()
0025:         self.state_weight.zero_()
0026:         self.position = 0
0027:         self.valid = True
0028: 
0029:     def invalidate(self):
0030:         self.valid = False
0031: 
0032:     def require_valid(self):
0033:         if not self.valid:
0034:             raise RuntimeError("QLAF cache is invalid")
```


## pytorch_lite / `src/odyssey_v39_pt/config.py`

```text
0001: from dataclasses import dataclass
0002: 
0003: @dataclass
0004: class TinyConfig:
0005:     vocab_size: int = 32
0006:     hidden_size: int = 16
0007:     num_layers: int = 1
0008:     num_states: int = 3
0009:     state_rank: int = 4
0010:     max_positions: int = 64
0011:     intermediate_size: int = 32
0012:     tsc_scale: float = 0.10
0013:     aion_confidence_threshold: float = 0.55
```


## pytorch_lite / `src/odyssey_v39_pt/data.py`

```text
0001: import torch
0002: 
0003: def make_synthetic_batch(batch_size, seq_len, vocab_size, device="cpu", seed=None):
0004:     if seed is not None:
0005:         gen = torch.Generator(device="cpu")
0006:         gen.manual_seed(seed)
0007:         x = torch.randint(0, vocab_size, (batch_size, seq_len), generator=gen)
0008:         x = x.to(device)
0009:     else:
0010:         x = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)
0011:     for t in range(2, seq_len):
0012:         x[:, t] = (x[:, t - 1] + x[:, t - 2] + (t % 5)) % vocab_size
0013:     return x
```


## pytorch_lite / `src/odyssey_v39_pt/decode_bench.py`

```text
0001: import time
0002: import torch
0003: from .config import TinyConfig
0004: from .cache import QLAFCache
0005: from .model_v39 import TinyOdysseyV39
0006: from .model_transformer import TinyTransformerLM
0007: from .data import make_synthetic_batch
0008: 
0009: def run_decode_speed_benchmark(device="cpu", steps=24, batch_size=2):
0010:     torch.manual_seed(321)
0011:     cfg = TinyConfig(max_positions=max(64, steps + 4))
0012:     v39 = TinyOdysseyV39(cfg).to(device).eval()
0013:     tr = TinyTransformerLM(cfg).to(device).eval()
0014:     x = make_synthetic_batch(batch_size, steps, cfg.vocab_size, device=device, seed=322)
0015: 
0016:     with torch.no_grad():
0017:         cache = QLAFCache.empty(batch_size, cfg, device=device, dtype=v39.embed.weight.dtype)
0018:         start = time.perf_counter()
0019:         for t in range(steps):
0020:             v39.decode_step(x[:, t:t+1], cache, top_k=1, use_tsc=False)
0021:         v39_top1 = time.perf_counter() - start
0022: 
0023:         start = time.perf_counter()
0024:         for t in range(1, steps + 1):
0025:             tr(x[:, :t])
0026:         transformer_naive = time.perf_counter() - start
0027: 
0028:     return {
0029:         "section": "decode_speed_benchmark",
0030:         "passed": bool(v39_top1 < transformer_naive),
0031:         "steps": steps,
0032:         "v39_top1_seconds": v39_top1,
0033:         "transformer_naive_prefix_seconds": transformer_naive,
0034:         "v39_top1_vs_transformer_naive_speedup": transformer_naive / max(v39_top1, 1e-9),
0035:         "note": "Transformer baseline is naive prefix recompute, not optimized KV-cache decode.",
0036:     }
```


## pytorch_lite / `src/odyssey_v39_pt/gates.py`

```text
0001: import torch
0002: from .config import TinyConfig
0003: from .cache import QLAFCache
0004: from .model_v39 import TinyOdysseyV39
0005: from .data import make_synthetic_batch
0006: 
0007: def max_abs(a, b):
0008:     return float((a - b).abs().max().item())
0009: 
0010: def run_correctness_gates(device="cpu"):
0011:     torch.manual_seed(1)
0012:     cfg = TinyConfig()
0013:     model = TinyOdysseyV39(cfg).to(device).eval()
0014:     x = make_synthetic_batch(2, 8, cfg.vocab_size, device=device, seed=2)
0015: 
0016:     with torch.no_grad():
0017:         full = model.forward_full(x, top_k=2, use_tsc=False)
0018:         cached, _, _ = model.forward_cached(x, top_k=2, use_tsc=False)
0019:     parity_diff = max_abs(full, cached)
0020: 
0021:     prefix = make_synthetic_batch(2, 4, cfg.vocab_size, device=device, seed=3)
0022:     suffix_a = make_synthetic_batch(2, 4, cfg.vocab_size, device=device, seed=4)
0023:     suffix_b = make_synthetic_batch(2, 4, cfg.vocab_size, device=device, seed=5)
0024:     with torch.no_grad():
0025:         la = model.forward_full(torch.cat([prefix, suffix_a], dim=1), top_k=2, use_tsc=False)[:, :4]
0026:         lb = model.forward_full(torch.cat([prefix, suffix_b], dim=1), top_k=2, use_tsc=False)[:, :4]
0027:     future_diff = max_abs(la, lb)
0028: 
0029:     cache = QLAFCache.empty(2, cfg, device=device, dtype=torch.float32)
0030:     cache.state_summary.normal_()
0031:     cache.state_weight.uniform_()
0032:     cache.position = 7
0033:     cache.reset()
0034:     reset_ok = cache.state_summary.abs().max().item() == 0.0 and cache.state_weight.abs().max().item() == 0.0 and cache.position == 0 and cache.valid
0035: 
0036:     with torch.no_grad():
0037:         batch_logits = model.forward_full(x, top_k=2, use_tsc=False)
0038:         single_logits = torch.cat([model.forward_full(x[i:i+1], top_k=2, use_tsc=False) for i in range(x.size(0))], dim=0)
0039:     batch_diff = max_abs(batch_logits, single_logits)
0040: 
0041:     c1 = QLAFCache.empty(2, cfg, device=device, dtype=model.embed.weight.dtype)
0042:     c2 = QLAFCache.empty(2, cfg, device=device, dtype=model.embed.weight.dtype)
0043:     route_shape_ok, top2_distinct = True, True
0044:     with torch.no_grad():
0045:         for t in range(4):
0046:             _, c1, info1 = model.decode_step(x[:, t:t+1], c1, top_k=1, use_tsc=False)
0047:             _, c2, info2 = model.decode_step(x[:, t:t+1], c2, top_k=2, use_tsc=False)
0048:             route_shape_ok = route_shape_ok and info1["route_ids"].shape[-1] == 1 and info2["route_ids"].shape[-1] == 2
0049:             top2_distinct = top2_distinct and bool((info2["route_ids"][..., 0] != info2["route_ids"][..., 1]).all().item())
0050:     cache_diff = float((c1.state_summary - c2.state_summary).abs().sum().item())
0051: 
0052:     results = [
0053:         {"gate": "full_forward_vs_cached_decode", "passed": parity_diff < 1e-7, "max_abs_diff": parity_diff},
0054:         {"gate": "no_future_leakage", "passed": future_diff < 1e-7, "max_abs_diff": future_diff},
0055:         {"gate": "cache_reset", "passed": bool(reset_ok)},
0056:         {"gate": "batch_equivalence", "passed": batch_diff < 1e-7, "max_abs_diff": batch_diff},
0057:         {"gate": "top1_top2_routing_behavior", "passed": bool(route_shape_ok and top2_distinct and cache_diff > 0.0), "cache_diff": cache_diff},
0058:     ]
0059:     return {"section": "correctness_gates", "all_passed": all(r["passed"] for r in results), "results": results}
0060: 
0061: def run_tsc_parity(device="cpu"):
0062:     torch.manual_seed(6)
0063:     cfg = TinyConfig()
0064:     model = TinyOdysseyV39(cfg).to(device).eval()
0065:     x = make_synthetic_batch(2, 8, cfg.vocab_size, device=device, seed=7)
0066:     with torch.no_grad():
0067:         full = model.forward_full(x, top_k=2, use_tsc=True)
0068:         cached, _, _ = model.forward_cached(x, top_k=2, use_tsc=True)
0069:         off = model.forward_full(x, top_k=2, use_tsc=False)
0070:     diff = max_abs(full, cached)
0071:     effect = max_abs(full, off)
0072:     return {"section": "tsc_parity", "passed": bool(diff < 1e-7 and effect > 0.0), "max_abs_diff": diff, "tsc_effect": effect}
0073: 
0074: def run_aion_adaptive_parity(device="cpu"):
0075:     torch.manual_seed(8)
0076:     cfg = TinyConfig(aion_confidence_threshold=0.99)
0077:     model = TinyOdysseyV39(cfg).to(device).eval()
0078:     x = make_synthetic_batch(2, 8, cfg.vocab_size, device=device, seed=9)
0079:     cache = QLAFCache.empty(2, cfg, device=device, dtype=model.embed.weight.dtype)
0080:     topks = []
0081:     with torch.no_grad():
0082:         for t in range(x.size(1)):
0083:             _, cache, info = model.aion_decode_step(x[:, t:t+1], cache, use_tsc=True)
0084:             topks.append(info["top_k"])
0085:     used_top2 = any(k == 2 for k in topks)
0086:     return {"section": "aion_adaptive_parity", "passed": bool(used_top2), "topk_sequence": topks}
```


## pytorch_lite / `src/odyssey_v39_pt/memory.py`

```text
0001: def qlaf_cache_elements(batch, layers, states, rank):
0002:     return batch * layers * states * rank + batch * layers * states
0003: 
0004: def transformer_kv_cache_elements(batch, layers, seq_len, hidden):
0005:     return 2 * batch * layers * seq_len * hidden
0006: 
0007: def memory_table(batch=1, layers=1, states=3, rank=4, hidden=16, contexts=(128, 512, 1024, 2048, 4096, 8192)):
0008:     q = qlaf_cache_elements(batch, layers, states, rank)
0009:     rows = []
0010:     for ctx in contexts:
0011:         kv = transformer_kv_cache_elements(batch, layers, ctx, hidden)
0012:         rows.append({"context": ctx, "qlaf_elements": q, "transformer_kv_elements": kv, "qlaf_reduction_percent": 100.0 * (1.0 - q / max(kv, 1))})
0013:     return rows
```


## pytorch_lite / `src/odyssey_v39_pt/model_transformer.py`

```text
0001: import torch
0002: import torch.nn as nn
0003: import torch.nn.functional as F
0004: 
0005: class TinyTransformerBlock(nn.Module):
0006:     def __init__(self, cfg):
0007:         super().__init__()
0008:         h = cfg.hidden_size
0009:         heads = 4 if h % 4 == 0 else 1
0010:         self.norm1 = nn.LayerNorm(h)
0011:         self.attn = nn.MultiheadAttention(h, num_heads=heads, batch_first=True)
0012:         self.norm2 = nn.LayerNorm(h)
0013:         self.mlp = nn.Sequential(nn.Linear(h, cfg.intermediate_size), nn.SiLU(), nn.Linear(cfg.intermediate_size, h))
0014: 
0015:     def forward(self, x):
0016:         T = x.size(1)
0017:         mask = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
0018:         q = self.norm1(x)
0019:         y, _ = self.attn(q, q, q, attn_mask=mask, need_weights=False)
0020:         x = x + y
0021:         x = x + self.mlp(self.norm2(x))
0022:         return x
0023: 
0024: class TinyTransformerLM(nn.Module):
0025:     def __init__(self, cfg):
0026:         super().__init__()
0027:         self.cfg = cfg
0028:         self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
0029:         self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
0030:         self.layers = nn.ModuleList([TinyTransformerBlock(cfg) for _ in range(cfg.num_layers)])
0031:         self.norm = nn.LayerNorm(cfg.hidden_size)
0032:         self.lm_head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)
0033: 
0034:     def forward(self, input_ids, labels=None):
0035:         B, T = input_ids.shape
0036:         pos = torch.arange(T, device=input_ids.device).unsqueeze(0).expand(B, T)
0037:         x = self.embed(input_ids) + self.pos(pos)
0038:         for layer in self.layers:
0039:             x = layer(x)
0040:         logits = self.lm_head(self.norm(x))
0041:         loss = None
0042:         if labels is not None:
0043:             loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
0044:         return {"logits": logits, "loss": loss}
```


## pytorch_lite / `src/odyssey_v39_pt/model_v39.py`

```text
0001: import torch
0002: import torch.nn as nn
0003: import torch.nn.functional as F
0004: from .cache import QLAFCache
0005: 
0006: class QLAFLayer(nn.Module):
0007:     def __init__(self, cfg):
0008:         super().__init__()
0009:         self.cfg = cfg
0010:         h, s, r = cfg.hidden_size, cfg.num_states, cfg.state_rank
0011:         self.norm = nn.LayerNorm(h)
0012:         self.route = nn.Linear(h, s, bias=False)
0013:         self.to_rank = nn.Linear(h, r, bias=False)
0014:         self.from_state = nn.Linear(s * r, h, bias=False)
0015:         self.tsc_norm = nn.LayerNorm(h)
0016:         self.tsc = nn.Linear(h, h, bias=False)
0017:         self.mlp_norm = nn.LayerNorm(h)
0018:         self.mlp = nn.Sequential(nn.Linear(h, cfg.intermediate_size), nn.SiLU(), nn.Linear(cfg.intermediate_size, h))
0019: 
0020:     def update_one(self, x, state_summary, state_weight, top_k=1, use_tsc=True):
0021:         B, S, R = state_summary.shape
0022:         xn = self.norm(x)
0023:         route_probs = torch.softmax(self.route(xn), dim=-1)
0024:         vals, ids = torch.topk(route_probs, k=top_k, dim=-1)
0025:         vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0026:         z = self.to_rank(xn)
0027:         new_state = state_summary.clone()
0028:         new_weight = state_weight.clone()
0029:         batch_idx = torch.arange(B, device=x.device)
0030: 
0031:         for j in range(top_k):
0032:             sid = ids[:, j]
0033:             w = vals[:, j]
0034:             old_w = new_weight[batch_idx, sid]
0035:             new_w = old_w + w
0036:             old = new_state[batch_idx, sid]
0037:             new_state[batch_idx, sid] = (old * old_w[:, None] + z * w[:, None]) / new_w[:, None].clamp_min(1e-8)
0038:             new_weight[batch_idx, sid] = new_w
0039: 
0040:         weighted = new_state * new_weight[:, :, None]
0041:         denom = new_weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0042:         flat = (weighted / denom[:, :, None]).reshape(B, S * R)
0043:         y = x + self.from_state(flat)
0044: 
0045:         if use_tsc:
0046:             y = y + self.cfg.tsc_scale * self.tsc(self.tsc_norm(y))
0047:         y = y + self.mlp(self.mlp_norm(y))
0048:         confidence = route_probs.max(dim=-1).values
0049:         return y, new_state, new_weight, ids, confidence
0050: 
0051: class TinyOdysseyV39(nn.Module):
0052:     def __init__(self, cfg):
0053:         super().__init__()
0054:         self.cfg = cfg
0055:         self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
0056:         self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
0057:         self.layers = nn.ModuleList([QLAFLayer(cfg) for _ in range(cfg.num_layers)])
0058:         self.final_norm = nn.LayerNorm(cfg.hidden_size)
0059:         self.lm_head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)
0060: 
0061:     def token_hidden(self, input_ids, pos_offset=0):
0062:         B, T = input_ids.shape
0063:         pos = torch.arange(pos_offset, pos_offset + T, device=input_ids.device).unsqueeze(0).expand(B, T)
0064:         return self.embed(input_ids) + self.pos(pos)
0065: 
0066:     def decode_step(self, token_ids, cache, top_k=1, use_tsc=True):
0067:         cache.require_valid()
0068:         x = self.token_hidden(token_ids, cache.position)[:, 0]
0069:         route_ids, confidences = [], []
0070:         for li, layer in enumerate(self.layers):
0071:             x, ns, nw, ids, conf = layer.update_one(x, cache.state_summary[:, li], cache.state_weight[:, li], top_k=top_k, use_tsc=use_tsc)
0072:             cache.state_summary[:, li] = ns
0073:             cache.state_weight[:, li] = nw
0074:             route_ids.append(ids)
0075:             confidences.append(conf)
0076:         cache.position += 1
0077:         logits = self.lm_head(self.final_norm(x))
0078:         info = {"route_ids": torch.stack(route_ids, dim=1), "confidence": torch.stack(confidences, dim=1), "top_k": top_k}
0079:         return logits, cache, info
0080: 
0081:     def aion_decode_step(self, token_ids, cache, use_tsc=True):
0082:         probe = cache.clone()
0083:         _, _, info = self.decode_step(token_ids, probe, top_k=1, use_tsc=use_tsc)
0084:         top_k = 2 if info["confidence"].min().item() < self.cfg.aion_confidence_threshold else 1
0085:         return self.decode_step(token_ids, cache, top_k=top_k, use_tsc=use_tsc)
0086: 
0087:     def forward_cached(self, input_ids, top_k=1, use_tsc=True):
0088:         B, T = input_ids.shape
0089:         cache = QLAFCache.empty(B, self.cfg, device=input_ids.device, dtype=self.embed.weight.dtype)
0090:         logits, infos = [], []
0091:         for t in range(T):
0092:             y, cache, info = self.decode_step(input_ids[:, t:t+1], cache, top_k=top_k, use_tsc=use_tsc)
0093:             logits.append(y[:, None, :])
0094:             infos.append(info)
0095:         return torch.cat(logits, dim=1), cache, infos
0096: 
0097:     def forward_full(self, input_ids, top_k=1, use_tsc=True):
0098:         logits, _, _ = self.forward_cached(input_ids, top_k=top_k, use_tsc=use_tsc)
0099:         return logits
0100: 
0101:     def forward(self, input_ids, labels=None, top_k=1, use_tsc=True):
0102:         logits = self.forward_full(input_ids, top_k=top_k, use_tsc=use_tsc)
0103:         loss = None
0104:         if labels is not None:
0105:             loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
0106:         return {"logits": logits, "loss": loss}
```


## pytorch_lite / `src/odyssey_v39_pt/run_all.py`

```text
0001: import torch
0002: from .gates import run_correctness_gates, run_tsc_parity, run_aion_adaptive_parity
0003: from .train_bench import run_tiny_training_benchmark
0004: from .decode_bench import run_decode_speed_benchmark
0005: from .memory import memory_table
0006: 
0007: def run_all(device=None, include_training=True):
0008:     if device is None:
0009:         device = "cuda" if torch.cuda.is_available() else "cpu"
0010:     results = [
0011:         run_correctness_gates(device=device),
0012:         run_tsc_parity(device=device),
0013:         run_aion_adaptive_parity(device=device),
0014:     ]
0015:     if include_training:
0016:         results.append(run_tiny_training_benchmark(device=device))
0017:         results.append(run_decode_speed_benchmark(device=device))
0018:     return {
0019:         "device": device,
0020:         "all_passed": all(r.get("all_passed", r.get("passed", False)) for r in results),
0021:         "results": results,
0022:         "memory_table": memory_table(),
0023:     }
```


## pytorch_lite / `src/odyssey_v39_pt/train_bench.py`

```text
0001: import time
0002: import torch
0003: from .config import TinyConfig
0004: from .model_v39 import TinyOdysseyV39
0005: from .model_transformer import TinyTransformerLM
0006: from .data import make_synthetic_batch
0007: 
0008: def count_params(model):
0009:     return sum(p.numel() for p in model.parameters())
0010: 
0011: def train_one(model, cfg, steps=8, batch_size=4, seq_len=12, lr=3e-3, device="cpu", is_v39=False):
0012:     model.train()
0013:     opt = torch.optim.AdamW(model.parameters(), lr=lr)
0014:     losses = []
0015:     start = time.perf_counter()
0016:     for _ in range(steps):
0017:         x = make_synthetic_batch(batch_size, seq_len, cfg.vocab_size, device=device)
0018:         opt.zero_grad(set_to_none=True)
0019:         out = model(x, labels=x, top_k=2, use_tsc=True) if is_v39 else model(x, labels=x)
0020:         loss = out["loss"]
0021:         loss.backward()
0022:         torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
0023:         opt.step()
0024:         losses.append(float(loss.item()))
0025:     elapsed = time.perf_counter() - start
0026:     return {"initial_loss": losses[0], "final_loss": losses[-1], "loss_delta": losses[0] - losses[-1], "elapsed_seconds": elapsed, "losses": losses}
0027: 
0028: def eval_loss(model, cfg, device="cpu", is_v39=False):
0029:     model.eval()
0030:     vals = []
0031:     with torch.no_grad():
0032:         for i in range(2):
0033:             x = make_synthetic_batch(4, 12, cfg.vocab_size, device=device, seed=100 + i)
0034:             out = model(x, labels=x, top_k=2, use_tsc=True) if is_v39 else model(x, labels=x)
0035:             vals.append(float(out["loss"].item()))
0036:     return sum(vals) / len(vals)
0037: 
0038: def run_tiny_training_benchmark(device="cpu"):
0039:     torch.manual_seed(123)
0040:     cfg = TinyConfig()
0041:     v39 = TinyOdysseyV39(cfg).to(device)
0042:     torch.manual_seed(123)
0043:     tr = TinyTransformerLM(cfg).to(device)
0044:     v39_train = train_one(v39, cfg, device=device, is_v39=True)
0045:     tr_train = train_one(tr, cfg, device=device, is_v39=False)
0046:     v39_eval = eval_loss(v39, cfg, device=device, is_v39=True)
0047:     tr_eval = eval_loss(tr, cfg, device=device, is_v39=False)
0048:     return {
0049:         "section": "tiny_matched_training_benchmark",
0050:         "passed": bool(v39_train["final_loss"] < v39_train["initial_loss"] and tr_train["final_loss"] < tr_train["initial_loss"]),
0051:         "v39_params": count_params(v39),
0052:         "transformer_params": count_params(tr),
0053:         "v39_train": v39_train,
0054:         "transformer_train": tr_train,
0055:         "v39_eval_loss": v39_eval,
0056:         "transformer_eval_loss": tr_eval,
0057:         "eval_loss_ratio_v39_over_transformer": v39_eval / max(tr_eval, 1e-9),
0058:         "note": "tiny synthetic benchmark; not final quality evidence",
0059:     }
```


## pytorch_lite / `tests/test_gates.py`

```text
0001: from odyssey_v39_pt.gates import run_correctness_gates, run_tsc_parity, run_aion_adaptive_parity
0002: 
0003: def test_correctness_gates_cpu():
0004:     r = run_correctness_gates("cpu")
0005:     assert r["all_passed"], r
0006: 
0007: def test_tsc_parity_cpu():
0008:     r = run_tsc_parity("cpu")
0009:     assert r["passed"], r
0010: 
0011: def test_aion_adaptive_cpu():
0012:     r = run_aion_adaptive_parity("cpu")
0013:     assert r["passed"], r
```


## cached_decode / `README.md`

```text
0001: # Odyssey V39 vs Transformer Cached-Decode Fair Benchmark + CSV Reporting
0002: 
0003: This package adds the next benchmark gate:
0004: 
0005: - V39 cached decode;
0006: - Transformer cached decode with explicit per-layer KV cache;
0007: - identical tiny config/data;
0008: - parameter counts;
0009: - cache-memory accounting;
0010: - decode timing;
0011: - prefill timing;
0012: - CSV outputs;
0013: - JSON summary.
0014: 
0015: This is still a tiny reference benchmark. It is not a CUDA result and not a final superiority claim.
```


## cached_decode / `docs/BENCHMARK_SCOPE.md`

```text
0001: # Benchmark Scope
0002: 
0003: This artifact replaces the earlier naive Transformer prefix-recompute decode comparison with an explicit cached Transformer baseline.
0004: 
0005: ## What is fairer now
0006: 
0007: The Transformer baseline stores per-layer K/V tensors and decodes one token at a time using the cache.
0008: 
0009: The V39 baseline stores QLAF state summaries and decodes one token at a time using the QLAF cache.
0010: 
0011: Both are tiny PyTorch reference implementations.
0012: 
0013: ## What is still not final
0014: 
0015: - Not CUDA-optimized.
0016: - Not using FlashAttention.
0017: - Not using production scheduling.
0018: - Parameter counts are reported but not tightly tuned.
0019: - Tiny synthetic sizes do not prove quality or production superiority.
0020: 
0021: ## CSV outputs
0022: 
0023: `benchmark_outputs/cached_decode_results.csv` contains:
0024: - context;
0025: - seed;
0026: - parameter counts;
0027: - prefill timing;
0028: - cached decode timing;
0029: - tokens/sec;
0030: - speedup ratios;
0031: - cache element counts;
0032: - cache memory reduction percent.
0033: 
0034: `benchmark_outputs/summary.json` contains full rows plus trial timings.
```


## cached_decode / `docs/NEXT_STEPS.md`

```text
0001: # Recommended Next Steps
0002: 
0003: 1. Run this benchmark locally on CPU and GPU.
0004: 2. Inspect `cached_decode_results.csv`.
0005: 3. Tighten V39/Transformer parameter counts.
0006: 4. Add training before benchmark so weights are not random.
0007: 5. Increase contexts to 128/256/512.
0008: 6. Add 3 then 5 seeds.
0009: 7. Implement CUDA top-1 V39 decode and compare again.
0010: 8. Add optimized Transformer baseline if available.
```


## cached_decode / `pyproject.toml`

```text
0001: [project]
0002: name = "odyssey-v39-cached-decode-fair-benchmark"
0003: version = "0.1.0"
0004: requires-python = ">=3.10"
0005: dependencies = ["torch"]
0006: 
0007: [tool.pytest.ini_options]
0008: pythonpath = ["src"]
0009: testpaths = ["tests"]
```


## cached_decode / `run_benchmark.py`

```text
0001: from odyssey_v39_cached_bench.benchmark import run_benchmark
0002: import json
0003: 
0004: if __name__ == "__main__":
0005:     print(json.dumps(run_benchmark(output_dir="benchmark_outputs"), indent=2))
```


## cached_decode / `src/odyssey_v39_cached_bench/__init__.py`

```text
0001: from .config import TinyConfig
0002: from .model_v39 import TinyOdysseyV39
0003: from .model_transformer_cached import TinyTransformerCachedLM
0004: from .benchmark import run_benchmark
```


## cached_decode / `src/odyssey_v39_cached_bench/benchmark.py`

```text
0001: import csv
0002: import json
0003: import time
0004: from pathlib import Path
0005: import torch
0006: from .config import TinyConfig
0007: from .data import make_synthetic_batch
0008: from .model_v39 import TinyOdysseyV39
0009: from .model_transformer_cached import TinyTransformerCachedLM
0010: 
0011: def count_params(model):
0012:     return sum(p.numel() for p in model.parameters())
0013: 
0014: def sync_if_needed(device):
0015:     if device.startswith("cuda") and torch.cuda.is_available():
0016:         torch.cuda.synchronize()
0017: 
0018: def time_call(fn, device, warmup=2, trials=5):
0019:     for _ in range(warmup):
0020:         fn()
0021:     sync_if_needed(device)
0022:     vals = []
0023:     for _ in range(trials):
0024:         start = time.perf_counter()
0025:         fn()
0026:         sync_if_needed(device)
0027:         vals.append(time.perf_counter() - start)
0028:     return sum(vals) / len(vals), vals
0029: 
0030: def run_one_context(cfg, context, batch_size, device, seed):
0031:     torch.manual_seed(seed)
0032:     v39 = TinyOdysseyV39(cfg).to(device).eval()
0033:     torch.manual_seed(seed)
0034:     tr = TinyTransformerCachedLM(cfg).to(device).eval()
0035:     x = make_synthetic_batch(batch_size, context, cfg.vocab_size, device=device, seed=seed + 100)
0036: 
0037:     with torch.no_grad():
0038:         # parity for Transformer full vs cached decode
0039:         tf_full = tr.forward_full(x)
0040:         tf_cached, tf_cache = tr.prefill_cached(x)
0041:         tf_parity = float((tf_full - tf_cached).abs().max().item())
0042: 
0043:         def v39_prefill():
0044:             v39.prefill(x, top_k=2, use_tsc=True)
0045: 
0046:         def tr_prefill_cached():
0047:             tr.prefill_cached(x)
0048: 
0049:         def v39_decode_only():
0050:             cache = v39.new_cache(batch_size, device=device, dtype=v39.embed.weight.dtype)
0051:             for t in range(context):
0052:                 v39.decode_step(x[:, t:t+1], cache, top_k=1, use_tsc=False)
0053: 
0054:         def tr_decode_only():
0055:             cache = tr.new_cache(batch_size, cfg.max_positions, device=device, dtype=tr.embed.weight.dtype)
0056:             for t in range(context):
0057:                 tr.decode_step(x[:, t:t+1], cache)
0058: 
0059:         v39_prefill_mean, v39_prefill_trials = time_call(v39_prefill, device)
0060:         tr_prefill_mean, tr_prefill_trials = time_call(tr_prefill_cached, device)
0061:         v39_decode_mean, v39_decode_trials = time_call(v39_decode_only, device)
0062:         tr_decode_mean, tr_decode_trials = time_call(tr_decode_only, device)
0063: 
0064:     v39_cache = v39.cache_elements(batch_size)
0065:     tr_cache = tr.cache_elements(batch_size, context)
0066:     return {
0067:         "seed": seed,
0068:         "context": context,
0069:         "batch_size": batch_size,
0070:         "device": device,
0071:         "v39_params": count_params(v39),
0072:         "transformer_params": count_params(tr),
0073:         "param_ratio_v39_over_transformer": count_params(v39) / max(count_params(tr), 1),
0074:         "transformer_full_vs_cached_max_abs": tf_parity,
0075:         "v39_prefill_seconds": v39_prefill_mean,
0076:         "transformer_cached_prefill_seconds": tr_prefill_mean,
0077:         "v39_decode_seconds": v39_decode_mean,
0078:         "transformer_cached_decode_seconds": tr_decode_mean,
0079:         "v39_prefill_tokens_per_sec": batch_size * context / max(v39_prefill_mean, 1e-9),
0080:         "transformer_prefill_tokens_per_sec": batch_size * context / max(tr_prefill_mean, 1e-9),
0081:         "v39_decode_tokens_per_sec": batch_size * context / max(v39_decode_mean, 1e-9),
0082:         "transformer_decode_tokens_per_sec": batch_size * context / max(tr_decode_mean, 1e-9),
0083:         "v39_decode_speedup_vs_transformer_cached": tr_decode_mean / max(v39_decode_mean, 1e-9),
0084:         "v39_prefill_speedup_vs_transformer_cached": tr_prefill_mean / max(v39_prefill_mean, 1e-9),
0085:         "v39_cache_elements": v39_cache,
0086:         "transformer_kv_cache_elements": tr_cache,
0087:         "v39_cache_reduction_percent": 100.0 * (1.0 - v39_cache / max(tr_cache, 1)),
0088:         "v39_prefill_trials": v39_prefill_trials,
0089:         "transformer_prefill_trials": tr_prefill_trials,
0090:         "v39_decode_trials": v39_decode_trials,
0091:         "transformer_decode_trials": tr_decode_trials,
0092:     }
0093: 
0094: def write_csv(rows, path):
0095:     path = Path(path)
0096:     path.parent.mkdir(parents=True, exist_ok=True)
0097:     fieldnames = [k for k in rows[0].keys() if not k.endswith("_trials")]
0098:     with path.open("w", newline="", encoding="utf-8") as f:
0099:         w = csv.DictWriter(f, fieldnames=fieldnames)
0100:         w.writeheader()
0101:         for row in rows:
0102:             w.writerow({k: row[k] for k in fieldnames})
0103: 
0104: def run_benchmark(output_dir="benchmark_outputs", contexts=(8, 16, 32), seeds=(1, 2), batch_size=2, device=None):
0105:     if device is None:
0106:         device = "cuda" if torch.cuda.is_available() else "cpu"
0107:     cfg = TinyConfig(max_positions=max(contexts) + 4)
0108:     rows = []
0109:     for seed in seeds:
0110:         for ctx in contexts:
0111:             rows.append(run_one_context(cfg, ctx, batch_size, device, seed))
0112:     out = Path(output_dir)
0113:     out.mkdir(parents=True, exist_ok=True)
0114:     write_csv(rows, out / "cached_decode_results.csv")
0115:     summary = {
0116:         "device": device,
0117:         "contexts": list(contexts),
0118:         "seeds": list(seeds),
0119:         "batch_size": batch_size,
0120:         "rows": rows,
0121:         "notes": [
0122:             "Transformer uses explicit KV cache decode, not naive prefix recompute.",
0123:             "Tiny benchmark is reference-level, not CUDA-optimized.",
0124:             "Parameter counts are reported and may not be perfectly matched."
0125:         ],
0126:     }
0127:     (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
0128:     return summary
0129: 
0130: if __name__ == "__main__":
0131:     print(json.dumps(run_benchmark(), indent=2))
```


## cached_decode / `src/odyssey_v39_cached_bench/cache_v39.py`

```text
0001: from dataclasses import dataclass
0002: import torch
0003: 
0004: @dataclass
0005: class QLAFCache:
0006:     state_summary: torch.Tensor
0007:     state_weight: torch.Tensor
0008:     position: int = 0
0009:     valid: bool = True
0010: 
0011:     @classmethod
0012:     def empty(cls, batch_size, cfg, device=None, dtype=None):
0013:         return cls(
0014:             state_summary=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, cfg.state_rank, device=device, dtype=dtype),
0015:             state_weight=torch.zeros(batch_size, cfg.num_layers, cfg.num_states, device=device, dtype=dtype),
0016:             position=0,
0017:             valid=True,
0018:         )
0019: 
0020:     def elements(self):
0021:         return self.state_summary.numel() + self.state_weight.numel()
0022: 
0023:     def require_valid(self):
0024:         if not self.valid:
0025:             raise RuntimeError("QLAF cache invalid")
```


## cached_decode / `src/odyssey_v39_cached_bench/config.py`

```text
0001: from dataclasses import dataclass
0002: 
0003: @dataclass
0004: class TinyConfig:
0005:     vocab_size: int = 32
0006:     hidden_size: int = 16
0007:     num_layers: int = 1
0008:     num_states: int = 3
0009:     state_rank: int = 4
0010:     max_positions: int = 128
0011:     intermediate_size: int = 32
0012:     num_heads: int = 4
0013:     tsc_scale: float = 0.10
```


## cached_decode / `src/odyssey_v39_cached_bench/data.py`

```text
0001: import torch
0002: 
0003: def make_synthetic_batch(batch_size, seq_len, vocab_size, device="cpu", seed=None):
0004:     if seed is not None:
0005:         gen = torch.Generator(device="cpu")
0006:         gen.manual_seed(seed)
0007:         x = torch.randint(0, vocab_size, (batch_size, seq_len), generator=gen).to(device)
0008:     else:
0009:         x = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)
0010:     for t in range(2, seq_len):
0011:         x[:, t] = (x[:, t - 1] + x[:, t - 2] + (t % 5)) % vocab_size
0012:     return x
```


## cached_decode / `src/odyssey_v39_cached_bench/model_transformer_cached.py`

```text
0001: import math
0002: import torch
0003: import torch.nn as nn
0004: import torch.nn.functional as F
0005: 
0006: class KVCache:
0007:     def __init__(self, num_layers, batch_size, num_heads, max_len, head_dim, device=None, dtype=None):
0008:         self.k = torch.zeros(num_layers, batch_size, num_heads, max_len, head_dim, device=device, dtype=dtype)
0009:         self.v = torch.zeros(num_layers, batch_size, num_heads, max_len, head_dim, device=device, dtype=dtype)
0010:         self.position = 0
0011:         self.max_len = max_len
0012: 
0013:     def elements(self):
0014:         return self.k.numel() + self.v.numel()
0015: 
0016: class CachedTransformerBlock(nn.Module):
0017:     def __init__(self, cfg):
0018:         super().__init__()
0019:         self.cfg = cfg
0020:         h = cfg.hidden_size
0021:         heads = cfg.num_heads if h % cfg.num_heads == 0 else 1
0022:         self.num_heads = heads
0023:         self.head_dim = h // heads
0024:         self.norm1 = nn.LayerNorm(h)
0025:         self.q = nn.Linear(h, h, bias=False)
0026:         self.k = nn.Linear(h, h, bias=False)
0027:         self.v = nn.Linear(h, h, bias=False)
0028:         self.o = nn.Linear(h, h, bias=False)
0029:         self.norm2 = nn.LayerNorm(h)
0030:         self.mlp = nn.Sequential(nn.Linear(h, cfg.intermediate_size), nn.SiLU(), nn.Linear(cfg.intermediate_size, h))
0031: 
0032:     def split_heads(self, x):
0033:         B, H = x.shape
0034:         return x.view(B, self.num_heads, self.head_dim)
0035: 
0036:     def merge_heads(self, x):
0037:         B, heads, dim = x.shape
0038:         return x.reshape(B, heads * dim)
0039: 
0040:     def decode_step(self, x, cache, layer_idx):
0041:         # x [B,H], cache stores previous plus current K/V.
0042:         B = x.size(0)
0043:         xn = self.norm1(x)
0044:         q = self.split_heads(self.q(xn))
0045:         k = self.split_heads(self.k(xn))
0046:         v = self.split_heads(self.v(xn))
0047: 
0048:         pos = cache.position
0049:         cache.k[layer_idx, :, :, pos, :] = k
0050:         cache.v[layer_idx, :, :, pos, :] = v
0051: 
0052:         keys = cache.k[layer_idx, :, :, :pos+1, :]
0053:         vals = cache.v[layer_idx, :, :, :pos+1, :]
0054:         scores = torch.einsum("bhd,bhtd->bht", q, keys) / math.sqrt(self.head_dim)
0055:         probs = torch.softmax(scores, dim=-1)
0056:         ctx = torch.einsum("bht,bhtd->bhd", probs, vals)
0057:         y = x + self.o(self.merge_heads(ctx))
0058:         y = y + self.mlp(self.norm2(y))
0059:         return y
0060: 
0061:     def forward_full(self, x):
0062:         B, T, H = x.shape
0063:         xn = self.norm1(x)
0064:         q = self.q(xn).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
0065:         k = self.k(xn).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
0066:         v = self.v(xn).view(B, T, self.num_heads, self.head_dim).transpose(1, 2)
0067:         scores = torch.einsum("bhtd,bhsd->bhts", q, k) / math.sqrt(self.head_dim)
0068:         mask = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), diagonal=1)
0069:         scores = scores.masked_fill(mask[None, None, :, :], float("-inf"))
0070:         probs = torch.softmax(scores, dim=-1)
0071:         ctx = torch.einsum("bhts,bhsd->bhtd", probs, v).transpose(1, 2).reshape(B, T, H)
0072:         y = x + self.o(ctx)
0073:         y = y + self.mlp(self.norm2(y))
0074:         return y
0075: 
0076: class TinyTransformerCachedLM(nn.Module):
0077:     def __init__(self, cfg):
0078:         super().__init__()
0079:         self.cfg = cfg
0080:         self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
0081:         self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
0082:         self.layers = nn.ModuleList([CachedTransformerBlock(cfg) for _ in range(cfg.num_layers)])
0083:         self.norm = nn.LayerNorm(cfg.hidden_size)
0084:         self.head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)
0085: 
0086:     def new_cache(self, batch_size, max_len, device=None, dtype=None):
0087:         heads = self.layers[0].num_heads
0088:         head_dim = self.layers[0].head_dim
0089:         return KVCache(self.cfg.num_layers, batch_size, heads, max_len, head_dim, device=device, dtype=dtype)
0090: 
0091:     def decode_step(self, token_ids, cache):
0092:         B = token_ids.size(0)
0093:         pos = torch.full((B, 1), cache.position, device=token_ids.device, dtype=torch.long)
0094:         x = self.embed(token_ids)[:, 0] + self.pos(pos)[:, 0]
0095:         for li, layer in enumerate(self.layers):
0096:             x = layer.decode_step(x, cache, li)
0097:         cache.position += 1
0098:         return self.head(self.norm(x)), cache
0099: 
0100:     def prefill_cached(self, input_ids):
0101:         B, T = input_ids.shape
0102:         cache = self.new_cache(B, self.cfg.max_positions, device=input_ids.device, dtype=self.embed.weight.dtype)
0103:         logits = []
0104:         for t in range(T):
0105:             y, cache = self.decode_step(input_ids[:, t:t+1], cache)
0106:             logits.append(y[:, None, :])
0107:         return torch.cat(logits, dim=1), cache
0108: 
0109:     def forward_full(self, input_ids):
0110:         B, T = input_ids.shape
0111:         pos = torch.arange(T, device=input_ids.device).unsqueeze(0).expand(B, T)
0112:         x = self.embed(input_ids) + self.pos(pos)
0113:         for layer in self.layers:
0114:             x = layer.forward_full(x)
0115:         return self.head(self.norm(x))
0116: 
0117:     def forward(self, input_ids, labels=None):
0118:         logits = self.forward_full(input_ids)
0119:         loss = None
0120:         if labels is not None:
0121:             loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
0122:         return {"logits": logits, "loss": loss}
0123: 
0124:     def cache_elements(self, batch_size, seq_len):
0125:         heads = self.layers[0].num_heads
0126:         head_dim = self.layers[0].head_dim
0127:         return 2 * self.cfg.num_layers * batch_size * heads * seq_len * head_dim
```


## cached_decode / `src/odyssey_v39_cached_bench/model_v39.py`

```text
0001: import torch
0002: import torch.nn as nn
0003: import torch.nn.functional as F
0004: from .cache_v39 import QLAFCache
0005: 
0006: class QLAFLayer(nn.Module):
0007:     def __init__(self, cfg):
0008:         super().__init__()
0009:         self.cfg = cfg
0010:         h, s, r = cfg.hidden_size, cfg.num_states, cfg.state_rank
0011:         self.norm = nn.LayerNorm(h)
0012:         self.route = nn.Linear(h, s, bias=False)
0013:         self.to_rank = nn.Linear(h, r, bias=False)
0014:         self.from_state = nn.Linear(s * r, h, bias=False)
0015:         self.tsc_norm = nn.LayerNorm(h)
0016:         self.tsc = nn.Linear(h, h, bias=False)
0017:         self.mlp_norm = nn.LayerNorm(h)
0018:         self.mlp = nn.Sequential(nn.Linear(h, cfg.intermediate_size), nn.SiLU(), nn.Linear(cfg.intermediate_size, h))
0019: 
0020:     def update_one(self, x, state_summary, state_weight, top_k=1, use_tsc=True):
0021:         B, S, R = state_summary.shape
0022:         xn = self.norm(x)
0023:         route_probs = torch.softmax(self.route(xn), dim=-1)
0024:         vals, ids = torch.topk(route_probs, k=top_k, dim=-1)
0025:         vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0026:         z = self.to_rank(xn)
0027:         new_state = state_summary.clone()
0028:         new_weight = state_weight.clone()
0029:         batch_idx = torch.arange(B, device=x.device)
0030: 
0031:         for j in range(top_k):
0032:             sid = ids[:, j]
0033:             w = vals[:, j]
0034:             old_w = new_weight[batch_idx, sid]
0035:             new_w = old_w + w
0036:             old = new_state[batch_idx, sid]
0037:             new_state[batch_idx, sid] = (old * old_w[:, None] + z * w[:, None]) / new_w[:, None].clamp_min(1e-8)
0038:             new_weight[batch_idx, sid] = new_w
0039: 
0040:         weighted = new_state * new_weight[:, :, None]
0041:         denom = new_weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)
0042:         flat = (weighted / denom[:, :, None]).reshape(B, S * R)
0043:         y = x + self.from_state(flat)
0044:         if use_tsc:
0045:             y = y + self.cfg.tsc_scale * self.tsc(self.tsc_norm(y))
0046:         y = y + self.mlp(self.mlp_norm(y))
0047:         return y, new_state, new_weight
0048: 
0049: class TinyOdysseyV39(nn.Module):
0050:     def __init__(self, cfg):
0051:         super().__init__()
0052:         self.cfg = cfg
0053:         self.embed = nn.Embedding(cfg.vocab_size, cfg.hidden_size)
0054:         self.pos = nn.Embedding(cfg.max_positions, cfg.hidden_size)
0055:         self.layers = nn.ModuleList([QLAFLayer(cfg) for _ in range(cfg.num_layers)])
0056:         self.norm = nn.LayerNorm(cfg.hidden_size)
0057:         self.head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)
0058: 
0059:     def new_cache(self, batch_size, device=None, dtype=None):
0060:         return QLAFCache.empty(batch_size, self.cfg, device=device, dtype=dtype)
0061: 
0062:     def decode_step(self, token_ids, cache, top_k=1, use_tsc=True):
0063:         cache.require_valid()
0064:         B = token_ids.size(0)
0065:         pos = torch.full((B, 1), cache.position, device=token_ids.device, dtype=torch.long)
0066:         x = self.embed(token_ids)[:, 0] + self.pos(pos)[:, 0]
0067:         for li, layer in enumerate(self.layers):
0068:             x, ns, nw = layer.update_one(x, cache.state_summary[:, li], cache.state_weight[:, li], top_k=top_k, use_tsc=use_tsc)
0069:             cache.state_summary[:, li] = ns
0070:             cache.state_weight[:, li] = nw
0071:         cache.position += 1
0072:         return self.head(self.norm(x)), cache
0073: 
0074:     def prefill(self, input_ids, top_k=2, use_tsc=True):
0075:         B, T = input_ids.shape
0076:         cache = self.new_cache(B, device=input_ids.device, dtype=self.embed.weight.dtype)
0077:         logits = []
0078:         for t in range(T):
0079:             y, cache = self.decode_step(input_ids[:, t:t+1], cache, top_k=top_k, use_tsc=use_tsc)
0080:             logits.append(y[:, None, :])
0081:         return torch.cat(logits, dim=1), cache
0082: 
0083:     def forward(self, input_ids, labels=None):
0084:         logits, _ = self.prefill(input_ids, top_k=2, use_tsc=True)
0085:         loss = None
0086:         if labels is not None:
0087:             loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
0088:         return {"logits": logits, "loss": loss}
0089: 
0090:     def cache_elements(self, batch_size):
0091:         return batch_size * self.cfg.num_layers * self.cfg.num_states * self.cfg.state_rank + batch_size * self.cfg.num_layers * self.cfg.num_states
```


## cached_decode / `tests/test_cached_transformer.py`

```text
0001: import torch
0002: from odyssey_v39_cached_bench.config import TinyConfig
0003: from odyssey_v39_cached_bench.data import make_synthetic_batch
0004: from odyssey_v39_cached_bench.model_transformer_cached import TinyTransformerCachedLM
0005: 
0006: def test_transformer_cached_matches_full_cpu():
0007:     cfg = TinyConfig(max_positions=20)
0008:     model = TinyTransformerCachedLM(cfg).eval()
0009:     x = make_synthetic_batch(2, 8, cfg.vocab_size, seed=123)
0010:     with torch.no_grad():
0011:         full = model.forward_full(x)
0012:         cached, _ = model.prefill_cached(x)
0013:     assert (full - cached).abs().max().item() < 1e-5
```


## param_matched / `README.md`

```text
0001: # Odyssey V39 Parameter-Matched Benchmark Package
0002: 
0003: Purpose: continue from the env-safe cached-decode benchmark into a parameter-matched benchmark plan and runnable harness.
0004: 
0005: This package is designed around environment limits:
0006: - sharded contexts;
0007: - sharded seeds;
0008: - append-only CSV;
0009: - quick smoke mode;
0010: - optional PyTorch mode;
0011: - no single long run required.
0012: 
0013: It compares:
0014: - Odyssey V39 QLAF causal-state cached decode;
0015: - Transformer explicit KV-cache cached decode;
0016: - parameter-count matched configurations;
0017: - cache-memory scaling;
0018: - prefill/decode timing.
0019: 
0020: This is not a final superiority claim. It is the next reproducible gate before CUDA top-1 decode.
```


## param_matched / `docs/BENCHMARK_CONTRACT.md`

```text
0001: # Benchmark Contract
0002: 
0003: ## Required fairness rules
0004: 
0005: - Same vocabulary size.
0006: - Same hidden size unless intentionally swept.
0007: - Same number of layers or reported difference.
0008: - Parameter count within 1-2% for matched claim.
0009: - Same batch size.
0010: - Same sequence/context length.
0011: - Same seeds.
0012: - Same hardware.
0013: - Same dtype where applicable.
0014: - Transformer uses explicit KV cached decode, not naive prefix recompute.
0015: - V39 uses QLAF causal state cache.
0016: 
0017: ## Metrics
0018: 
0019: - parameter count;
0020: - parameter ratio;
0021: - QLAF cache elements;
0022: - Transformer KV cache elements;
0023: - cache reduction percent;
0024: - prefill seconds;
0025: - cached decode seconds;
0026: - tokens/sec;
0027: - V39 speedup ratio;
0028: - context length;
0029: - seed;
0030: - batch size.
0031: 
0032: ## Claim gate
0033: 
0034: Do not claim superiority unless:
0035: 
0036: - parameter ratio is within 1-2%;
0037: - at least 3 seeds pass smoke, 5 seeds for final;
0038: - V39 decode beats Transformer cached decode;
0039: - QLAF cache memory is materially lower;
0040: - training/quality loss is not degraded beyond accepted threshold.
```


## param_matched / `docs/CUDA_GATE_AFTER_THIS.md`

```text
0001: # CUDA Gate After Parameter-Matched Benchmark
0002: 
0003: Once the parameter-matched PyTorch/CPU benchmark produces stable CSVs, build only the top-1 decode kernel first.
0004: 
0005: Do not start with prefill.
0006: 
0007: ## CUDA top-1 decode gate
0008: 
0009: Required:
0010: 
0011: 1. PyTorch top-1 decode reference frozen.
0012: 2. CUDA top-1 output matches PyTorch within tolerance.
0013: 3. CUDA cache update matches PyTorch cache update.
0014: 4. CUDA handles batch dimension.
0015: 5. CUDA reports speedup over PyTorch V39 top-1.
0016: 6. CUDA V39 top-1 is compared against Transformer cached decode.
0017: 
0018: ## Kernel order
0019: 
0020: 1. route select top-1;
0021: 2. rank projection;
0022: 3. selected-state update;
0023: 4. state readout;
0024: 5. output projection;
0025: 6. optional fused norm;
0026: 7. optional TSC branch.
```


## param_matched / `docs/NEXT_STEPS.md`

```text
0001: # Recommended Execution Order
0002: 
0003: 1. Run smoke shard:
0004: 
0005: ```bash
0006: python3 scripts/param_match_sweep.py --smoke
0007: ```
0008: 
0009: 2. Generate candidate parameter matches:
0010: 
0011: ```bash
0012: python3 scripts/param_match_sweep.py --emit-candidates
0013: ```
0014: 
0015: 3. Run one matched configuration:
0016: 
0017: ```bash
0018: python3 scripts/param_match_sweep.py --contexts 8,16,32 --seeds 1,2,3 --append
0019: ```
0020: 
0021: 4. Inspect:
0022: 
0023: ```text
0024: results/parameter_candidates.csv
0025: results/cached_decode_matched.csv
0026: results/summary.md
0027: ```
0028: 
0029: 5. Only after stable CSV:
0030: 
0031: ```text
0032: CUDA top-1 decode kernel
0033: CUDA parity test
0034: CUDA vs PyTorch benchmark
0035: Route B HF/server package
0036: ```
```


## param_matched / `scripts/RUN_LOCAL.sh`

```text
0001: #!/usr/bin/env bash
0002: set -euo pipefail
0003: python3 scripts/param_match_sweep.py --smoke
0004: python3 scripts/param_match_sweep.py --emit-candidates
0005: python3 scripts/param_match_sweep.py --contexts 8,16,32,64 --seeds 1,2,3 --trials 3 --append
```


## param_matched / `scripts/param_match_sweep.py`

```text
0001: #!/usr/bin/env python3
0002: import argparse, csv, math, os, random, time
0003: from pathlib import Path
0004: 
0005: # Environment-safe analytical + lightweight timing harness.
0006: # It does not require PyTorch. It estimates parameter and cache parity and runs tiny CPU loop timings.
0007: 
0008: VOCAB = 32
0009: 
0010: def v39_params(hidden, layers, states, rank, intermediate):
0011:     # Embedding + pos omitted from matching core because both share vocab/pos roughly.
0012:     per_layer = 0
0013:     per_layer += hidden * states          # route
0014:     per_layer += hidden * rank            # to_rank
0015:     per_layer += (states * rank) * hidden # from_state
0016:     per_layer += hidden * hidden          # TSC
0017:     per_layer += hidden * intermediate + intermediate * hidden # MLP
0018:     per_layer += 6 * hidden               # norms rough
0019:     head = VOCAB * hidden
0020:     emb = VOCAB * hidden + 128 * hidden
0021:     return layers * per_layer + head + emb
0022: 
0023: def transformer_params(hidden, layers, heads, intermediate):
0024:     per_layer = 0
0025:     per_layer += 4 * hidden * hidden      # q,k,v,o
0026:     per_layer += hidden * intermediate + intermediate * hidden
0027:     per_layer += 4 * hidden               # norms rough
0028:     head = VOCAB * hidden
0029:     emb = VOCAB * hidden + 128 * hidden
0030:     return layers * per_layer + head + emb
0031: 
0032: def qlaf_cache_elements(batch, layers, states, rank):
0033:     return batch * layers * states * rank + batch * layers * states
0034: 
0035: def kv_cache_elements(batch, layers, context, hidden):
0036:     return 2 * batch * layers * context * hidden
0037: 
0038: def emit_candidates(outdir):
0039:     outdir.mkdir(parents=True, exist_ok=True)
0040:     path = outdir / "parameter_candidates.csv"
0041:     rows = []
0042:     for hidden in [16, 24, 32, 48, 64]:
0043:         for layers in [1, 2, 3, 4]:
0044:             for states in [2, 3, 4, 6, 8]:
0045:                 for rank in [4, 8, 12, 16, 24]:
0046:                     for intermediate in [2*hidden, 3*hidden, 4*hidden]:
0047:                         vp = v39_params(hidden, layers, states, rank, intermediate)
0048:                         tp = transformer_params(hidden, layers, 4 if hidden % 4 == 0 else 1, intermediate)
0049:                         ratio = vp / tp if tp else 0
0050:                         if 0.98 <= ratio <= 1.02:
0051:                             rows.append(dict(hidden=hidden,layers=layers,states=states,rank=rank,intermediate=intermediate,v39_params=vp,transformer_params=tp,ratio=ratio))
0052:     rows.sort(key=lambda r: abs(r['ratio']-1.0))
0053:     with path.open('w', newline='') as f:
0054:         w = csv.DictWriter(f, fieldnames=['hidden','layers','states','rank','intermediate','v39_params','transformer_params','ratio'])
0055:         w.writeheader(); w.writerows(rows)
0056:     return rows
0057: 
0058: def tiny_v39_decode_work(hidden, states, rank, steps, batch):
0059:     # CPU work proxy: top-1 state update is O(batch*steps*(hidden*states + hidden*rank + states*rank))
0060:     acc = 0.0
0061:     rng = random.Random(123)
0062:     route = [[rng.random() for _ in range(hidden)] for _ in range(states)]
0063:     proj = [[rng.random() for _ in range(hidden)] for _ in range(rank)]
0064:     x = [[rng.random() for _ in range(hidden)] for _ in range(batch)]
0065:     state = [[[0.0 for _ in range(rank)] for _ in range(states)] for _ in range(batch)]
0066:     for _ in range(steps):
0067:         for b in range(batch):
0068:             scores = [sum(route[s][h]*x[b][h] for h in range(hidden)) for s in range(states)]
0069:             sid = max(range(states), key=lambda s: scores[s])
0070:             z = [sum(proj[r][h]*x[b][h] for h in range(hidden)) for r in range(rank)]
0071:             for r in range(rank):
0072:                 state[b][sid][r] = 0.9*state[b][sid][r] + 0.1*z[r]
0073:                 acc += state[b][sid][r]
0074:     return acc
0075: 
0076: def tiny_transformer_cached_work(hidden, context, steps, batch):
0077:     # CPU work proxy: cached attention reads all previous keys O(batch*steps*context*hidden)
0078:     acc = 0.0
0079:     rng = random.Random(456)
0080:     q = [[rng.random() for _ in range(hidden)] for _ in range(batch)]
0081:     kcache = [[[rng.random() for _ in range(hidden)] for _ in range(context)] for _ in range(batch)]
0082:     for t in range(steps):
0083:         upto = min(t+1, context)
0084:         for b in range(batch):
0085:             for j in range(upto):
0086:                 acc += sum(q[b][h]*kcache[b][j][h] for h in range(hidden))
0087:     return acc
0088: 
0089: def run_rows(contexts, seeds, trials, append, outdir, hidden=32, layers=2, states=4, rank=8, intermediate=64, batch=2):
0090:     outdir.mkdir(parents=True, exist_ok=True)
0091:     path = outdir / "cached_decode_matched.csv"
0092:     exists = path.exists()
0093:     mode = 'a' if append else 'w'
0094:     fields = ['seed','context','batch','hidden','layers','states','rank','intermediate','v39_params','transformer_params','param_ratio','v39_decode_seconds','transformer_cached_decode_seconds','v39_speedup','qlaf_cache_elements','kv_cache_elements','cache_reduction_percent']
0095:     with path.open(mode, newline='') as f:
0096:         w = csv.DictWriter(f, fieldnames=fields)
0097:         if (not append) or (not exists): w.writeheader()
0098:         for seed in seeds:
0099:             random.seed(seed)
0100:             for ctx in contexts:
0101:                 vtimes=[]; ttimes=[]
0102:                 for _ in range(trials):
0103:                     st=time.perf_counter(); tiny_v39_decode_work(hidden, states, rank, ctx, batch); vtimes.append(time.perf_counter()-st)
0104:                     st=time.perf_counter(); tiny_transformer_cached_work(hidden, ctx, ctx, batch); ttimes.append(time.perf_counter()-st)
0105:                 vt=sum(vtimes)/len(vtimes); tt=sum(ttimes)/len(ttimes)
0106:                 vp=v39_params(hidden,layers,states,rank,intermediate); tp=transformer_params(hidden,layers,4 if hidden%4==0 else 1,intermediate)
0107:                 qc=qlaf_cache_elements(batch,layers,states,rank); kc=kv_cache_elements(batch,layers,ctx,hidden)
0108:                 w.writerow(dict(seed=seed,context=ctx,batch=batch,hidden=hidden,layers=layers,states=states,rank=rank,intermediate=intermediate,v39_params=vp,transformer_params=tp,param_ratio=vp/tp,v39_decode_seconds=vt,transformer_cached_decode_seconds=tt,v39_speedup=tt/max(vt,1e-12),qlaf_cache_elements=qc,kv_cache_elements=kc,cache_reduction_percent=100*(1-qc/max(kc,1))))
0109:     make_summary(path, outdir / "summary.md")
0110: 
0111: def make_summary(csv_path, summary_path):
0112:     rows=[]
0113:     if csv_path.exists():
0114:         with csv_path.open() as f: rows=list(csv.DictReader(f))
0115:     if not rows:
0116:         summary_path.write_text("# Summary\n\nNo rows yet.\n"); return
0117:     avg_speed=sum(float(r['v39_speedup']) for r in rows)/len(rows)
0118:     avg_cache=sum(float(r['cache_reduction_percent']) for r in rows)/len(rows)
0119:     summary_path.write_text(f"# Summary\n\nRows: {len(rows)}\n\nAverage V39 decode speedup proxy: {avg_speed:.3f}x\n\nAverage QLAF cache reduction: {avg_cache:.2f}%\n\nNote: CPU proxy harness, not final PyTorch/CUDA result.\n")
0120: 
0121: def parse_csv_ints(s): return [int(x) for x in s.split(',') if x.strip()]
0122: 
0123: def main():
0124:     ap=argparse.ArgumentParser()
0125:     ap.add_argument('--smoke', action='store_true')
0126:     ap.add_argument('--emit-candidates', action='store_true')
0127:     ap.add_argument('--contexts', default='8,16,32')
0128:     ap.add_argument('--seeds', default='1,2')
0129:     ap.add_argument('--trials', type=int, default=2)
0130:     ap.add_argument('--append', action='store_true')
0131:     ap.add_argument('--outdir', default='results')
0132:     args=ap.parse_args()
0133:     outdir=Path(args.outdir)
0134:     if args.emit_candidates or args.smoke:
0135:         rows=emit_candidates(outdir)
0136:         print(f"parameter candidates: {len(rows)}")
0137:         if rows[:1]: print(rows[0])
0138:     if args.smoke:
0139:         run_rows([4,8], [1], 1, False, outdir, hidden=16, layers=1, states=3, rank=4, intermediate=32, batch=1)
0140:         print(f"wrote {outdir}/cached_decode_matched.csv")
0141:         return
0142:     if not args.emit_candidates:
0143:         run_rows(parse_csv_ints(args.contexts), parse_csv_ints(args.seeds), args.trials, args.append, outdir)
0144:         print(f"wrote {outdir}/cached_decode_matched.csv")
0145: 
0146: if __name__=='__main__': main()
```


## envsafe / `README.md`

```text
0001: # Odyssey V39 Cached Decode Environment-Safe Benchmark
0002: 
0003: This package fixes the sandbox-limit problem by adding a no-PyTorch smoke benchmark path.
0004: 
0005: Use first:
0006: 
0007: ```bash
0008: PYTHONPATH=src perl run_envsafe_benchmark.pl --contexts 4,8 --seeds 1 --trials 1
0009: ```
0010: 
0011: Then scale locally:
0012: 
0013: ```bash
0014: PYTHONPATH=src perl run_envsafe_benchmark.pl --contexts 8,16,32,64 --seeds 1,2,3 --trials 3 --append
0015: ```
0016: 
0017: It writes CSV/JSON-compatible output without importing torch or using long subprocesses. This is a systems smoke, not CUDA evidence.
```


## envsafe / `docs/ENVIRONMENT_LIMIT_WORKAROUNDS.md`

```text
0001: # Environment Limit Workarounds
0002: 
0003: Observed problem: Python/Torch startup in this sandbox can exceed the tool limit. Even plain Python became unreliable after prior runs.
0004: 
0005: Implemented workaround:
0006: 
0007: 1. provide a no-PyTorch/no-Python smoke path in Perl;
0008: 2. split runs by context and seed;
0009: 3. append each row immediately to CSV;
0010: 4. use tiny defaults;
0011: 5. keep full PyTorch/GPU runs for local machine;
0012: 6. run CUDA only after local PyTorch cached-decode benchmark passes.
0013: 
0014: Recommended order:
0015: 
0016: 1. `perl run_envsafe_benchmark.pl --contexts 4,8 --seeds 1 --trials 1`
0017: 2. `perl run_envsafe_benchmark.pl --contexts 8,16,32 --seeds 1,2,3 --trials 3 --append`
0018: 3. run PyTorch local CPU benchmark;
0019: 4. run PyTorch GPU benchmark;
0020: 5. build CUDA top-1 decode.
```


## envsafe / `run_envsafe_benchmark.pl`

```text
0001: #!/usr/bin/env perl
0002: use strict; use warnings; use Time::HiRes qw(time); use Getopt::Long; use JSON::PP;
0003: my $contexts='4,8'; my $seeds='1'; my $batch=1; my $trials=1; my $out='benchmark_outputs'; my $append=0;
0004: GetOptions('contexts=s'=>\$contexts,'seeds=s'=>\$seeds,'batch=i'=>\$batch,'trials=i'=>\$trials,'output-dir=s'=>\$out,'append'=>\$append);
0005: sub nums { return map { int($_) } grep { length($_) } split /,/, shift; }
0006: sub dot { my($a,$b)=@_; my $s=0; $s+=$a->[$_]*$b->[$_] for 0..$#$a; return $s; }
0007: sub add { my($a,$b)=@_; return [map {$a->[$_]+$b->[$_]} 0..$#$a]; }
0008: sub mul { my($a,$s)=@_; return [map {$_*$s} @$a]; }
0009: sub norm { my($x)=@_; my $n=@$x; my $m=0; $m+=$_ for @$x; $m/=$n; my $v=0; $v+=($_-$m)**2 for @$x; $v/=$n; my $inv=1/sqrt($v+1e-5); return [map {($_-$m)*$inv} @$x]; }
0010: sub softmax { my($x)=@_; my $m=$x->[0]; for my $z (@$x){ $m=$z if $z>$m; } my @e=map {exp($_-$m)} @$x; my $s=0; $s+=$_ for @e; return [map {$_/$s} @e]; }
0011: sub matvec { my($W,$x)=@_; return [map {dot($_,$x)} @$W]; }
0012: sub randv { my($n,$scale)=@_; return [map {(rand()*2-1)*$scale} 1..$n]; }
0013: sub randm { my($r,$c,$scale)=@_; return [map {randv($c,$scale)} 1..$r]; }
0014: sub tokens { my($batch,$T,$V,$seed)=@_; srand($seed); my @xs; for my $b (0..$batch-1){ my @r=map {int(rand($V))} 1..$T; for my $t (2..$T-1){$r[$t]=($r[$t-1]+$r[$t-2]+($t%5))%$V;} push @xs, \@r;} return \@xs; }
0015: sub v39_new { my($seed)=@_; srand($seed); return {H=>8,V=>16,S=>2,R=>2, emb=>randm(16,8,.2), pos=>randm(2048,8,.05), route=>randm(2,8,.08), tor=>randm(2,8,.08), from=>randm(8,4,.08), head=>randm(16,8,.08)}; }
0016: sub tr_new { my($seed)=@_; srand($seed); return {H=>8,V=>16, emb=>randm(16,8,.2), pos=>randm(2048,8,.05), q=>randm(8,8,.08), k=>randm(8,8,.08), v=>randm(8,8,.08), o=>randm(8,8,.08), head=>randm(16,8,.08)}; }
0017: sub v39_decode { my($m,$seqs)=@_; my $B=@$seqs; my $T=@{$seqs->[0]}; my @sum=map { [map {[(0)x$m->{R}]} 1..$m->{S}] } 1..$B; my @w=map {[(0)x$m->{S}]} 1..$B; for my $t (0..$T-1){ for my $b (0..$B-1){ my $x=add($m->{emb}->[$seqs->[$b][$t]],$m->{pos}->[$t]); my $xn=norm($x); my $p=softmax([map {dot($m->{route}->[$_],$xn)} 0..$m->{S}-1]); my $sid=0; for my $ii (0..$m->{S}-1){ $sid=$ii if $p->[$ii]>$p->[$sid]; } my $z=matvec($m->{tor},$xn); my $ow=$w[$b][$sid]; my $nw=$ow+1; for my $j (0..$m->{R}-1){$sum[$b][$sid][$j]=($sum[$b][$sid][$j]*$ow+$z->[$j])/$nw;} $w[$b][$sid]=$nw; my $tot=0; $tot+=$_ for @{$w[$b]}; $tot=1e-8 if $tot<1e-8; my @flat; for my $s (0..$m->{S}-1){push @flat, map {$_*$w[$b][$s]/$tot} @{$sum[$b][$s]};} $x=add($x,matvec($m->{from},\@flat)); my $log=matvec($m->{head},norm($x)); } } }
0018: sub tr_decode { my($m,$seqs)=@_; my $B=@$seqs; my $T=@{$seqs->[0]}; my @ks=map {[]} 1..$B; my @vs=map {[]} 1..$B; for my $t (0..$T-1){ for my $b (0..$B-1){ my $x=add($m->{emb}->[$seqs->[$b][$t]],$m->{pos}->[$t]); my $xn=norm($x); my $q=matvec($m->{q},$xn); my $k=matvec($m->{k},$xn); my $v=matvec($m->{v},$xn); push @{$ks[$b]},$k; push @{$vs[$b]},$v; my $p=softmax([map {dot($q,$_)/sqrt($m->{H})} @{$ks[$b]}]); my @ctx=(0)x$m->{H}; for my $i (0..$#$p){ my $vv=$vs[$b][$i]; $ctx[$_]+=$p->[$i]*$vv->[$_] for 0..$#ctx; } $x=add($x,matvec($m->{o},\@ctx)); my $log=matvec($m->{head},norm($x)); } } }
0019: sub timeit { my($code,$trials)=@_; my $s=0; for(1..$trials){my $t=time(); $code->(); $s+=time()-$t;} return $s/$trials; }
0020: mkdir $out unless -d $out; my $csv="$out/envsafe_cached_decode_results.csv"; my $new=!(-e $csv && $append); open my $fh, ($append?'>>':'>'), $csv or die $!; print $fh "seed,context,batch,v39_seconds,transformer_kv_seconds,speedup,v39_cache_elements,transformer_kv_elements,cache_reduction_percent\n" if $new; my @rows;
0021: for my $seed (nums($seeds)){ for my $T (nums($contexts)){ my $seq=tokens($batch,$T,16,$seed+$T); my $v=v39_new($seed); my $tr=tr_new($seed); my $vt=timeit(sub{v39_decode($v,$seq)},$trials); my $tt=timeit(sub{tr_decode($tr,$seq)},$trials); my $ve=$batch*2*2+$batch*2; my $te=2*$batch*$T*8; my $red=100*(1-$ve/$te); my $sp=$tt/($vt||1e-12); print $fh join(',', $seed,$T,$batch,$vt,$tt,$sp,$ve,$te,$red)."\n"; push @rows,{seed=>$seed,context=>$T,batch=>$batch,v39_seconds=>$vt,transformer_kv_seconds=>$tt,speedup=>$sp,v39_cache_elements=>$ve,transformer_kv_elements=>$te,cache_reduction_percent=>$red}; }} close $fh; open my $js,'>',"$out/envsafe_summary.json"; print $js JSON::PP->new->pretty->encode({rows=>\@rows,note=>'Perl no-Python/no-Torch environment-safe smoke benchmark; not final CUDA evidence.'}); close $js; print JSON::PP->new->pretty->encode({rows=>\@rows});
```


## envsafe / `scripts/run_smoke.sh`

```text
0001: #!/usr/bin/env bash
0002: set -euo pipefail
0003: perl run_envsafe_benchmark.pl --contexts 4,8 --seeds 1 --trials 1
```
