import torch
from odyssey_v39 import OdysseyConfig, OdysseyEngine

cfg = OdysseyConfig(vocab_size=64, hidden_size=16, num_layers=1, num_states=3, state_rank=4, intermediate_size=32)
engine = OdysseyEngine(cfg).to("cpu")
x = torch.randint(0, 64, (1, 8))
print(engine.generate(x, max_new_tokens=4))
