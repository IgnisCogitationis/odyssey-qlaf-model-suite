import torch
from odyssey_v39.kernels.top1_reference import make_inputs, qlaf_top1_decode_reference

def main():
    if not torch.cuda.is_available():
        print({"passed": False, "reason": "cuda_not_available"})
        return
    import odyssey_v39_cuda
    inp = make_inputs(seed=123, device="cuda")
    y_ref, s_ref, w_ref, a_ref = qlaf_top1_decode_reference(**inp)
    y, s, w, a = odyssey_v39_cuda.qlaf_top1_decode(inp["x"], inp["state_summary"], inp["state_weight"], inp["route_weight"], inp["rank_weight"], inp["out_weight"])
    result = {
        "passed": bool(torch.equal(a_ref, a) and (y_ref-y).abs().max().item() <= 1e-4 and (s_ref-s).abs().max().item() <= 1e-4 and (w_ref-w).abs().max().item() <= 1e-4),
        "active_equal": bool(torch.equal(a_ref, a)),
        "max_abs_y": float((y_ref-y).abs().max().item()),
        "max_abs_state": float((s_ref-s).abs().max().item()),
        "max_abs_weight": float((w_ref-w).abs().max().item()),
    }
    print(result)

if __name__ == "__main__":
    main()
