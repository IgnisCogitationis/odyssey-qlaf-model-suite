import torch
from odyssey_v39 import OdysseyConfig
from odyssey_v39.cache.state_cache import QLAFCache

def test_cache_reset_repack():
    cfg = OdysseyConfig(hidden_size=16, num_layers=1, num_states=3, state_rank=4)
    c = QLAFCache.allocate(3, cfg, device="cpu")
    c.state_summary.normal_()
    c.reset_rows(torch.tensor([1]))
    assert torch.all(c.state_summary[1] == 0)
    r = c.repack(torch.tensor([2,0]))
    assert r.batch_size == 2
