import torch
from odyssey_v39 import OdysseyConfig, RuntimeConfig, OdysseyEngine

def test_cpu_engine_prefill_decode():
    cfg = OdysseyConfig(vocab_size=64, hidden_size=16, num_layers=1, num_states=3, state_rank=4, intermediate_size=32, max_positions=64)
    engine = OdysseyEngine(cfg, RuntimeConfig(device="cpu")).to("cpu")
    x = torch.randint(0, cfg.vocab_size, (2, 8))
    logits, cache = engine.prefill(x)
    assert logits.shape == (2, 8, cfg.vocab_size)
    step, cache, info = engine.decode_step(x[:, :1], cache)
    assert step.shape == (2, cfg.vocab_size)
    assert cache.elements() > 0
