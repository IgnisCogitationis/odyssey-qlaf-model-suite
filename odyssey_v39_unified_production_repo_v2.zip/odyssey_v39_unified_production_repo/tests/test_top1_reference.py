from odyssey_v39.kernels.top1_reference import make_inputs, qlaf_top1_decode_reference
import torch

def test_top1_reference_deterministic():
    inp = make_inputs(seed=1)
    y1, s1, w1, a1 = qlaf_top1_decode_reference(**inp)
    y2, s2, w2, a2 = qlaf_top1_decode_reference(**inp)
    assert torch.equal(a1, a2)
    assert torch.max(torch.abs(y1-y2)).item() == 0
