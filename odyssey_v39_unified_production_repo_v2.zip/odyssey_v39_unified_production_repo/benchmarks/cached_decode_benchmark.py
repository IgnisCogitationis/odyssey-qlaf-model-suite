import time, csv
import torch
from odyssey_v39 import OdysseyConfig, RuntimeConfig, OdysseyEngine

def bench():
    rows = []
    for ctx in [8,16,32,64,128]:
        cfg = OdysseyConfig(vocab_size=64, hidden_size=16, num_layers=1, num_states=3, state_rank=4, intermediate_size=32, max_positions=ctx+8)
        engine = OdysseyEngine(cfg, RuntimeConfig(device="cpu", decode_branch_mode="top1")).to("cpu")
        x = torch.randint(0, cfg.vocab_size, (2, ctx))
        t0 = time.perf_counter()
        logits, cache = engine.prefill(x)
        elapsed = time.perf_counter() - t0
        rows.append({"context": ctx, "seconds": elapsed, "tokens_per_sec": 2*ctx/max(elapsed,1e-9), "cache_elements": cache.elements()})
    with open("results/cached_decode_benchmark.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(rows)

if __name__ == "__main__":
    bench()
