# Odyssey V39 Unified Production Repository

This is the unified Odyssey V39 production-style repository.

It integrates:

- QLAF causal state cache
- AION adaptive hierarchy policy
- TSC residual correction
- decode-branch specialization
- PyTorch reference model
- CUDA top-1 decode parity extension scaffold
- prefill path
- Route B Hugging Face custom model
- custom inference server
- tests, benchmarks, runbooks, and Docker scaffolds

## Current truth

This repo is production-structured, but the CUDA path is still parity-gated.

CPU/PyTorch reference paths are runnable. CUDA top-1 decode must be built and parity-tested on a CUDA machine before timing or deployment claims.

## Quick CPU smoke

```bash
pip install -e .
python scripts/run_cpu_smoke.py
pytest -q tests
```

## CUDA parity

```bash
cd odyssey_v39/kernels/cuda_ext
python setup.py build_ext --inplace
cd ../../..
PYTHONPATH=. python tests/test_cuda_top1_parity.py
```

## Route B server

```bash
python server/app.py --host 0.0.0.0 --port 8000
```

## Status

- Reference QLAF/AION/TSC engine: included
- Prefill/decode split: included
- HF `trust_remote_code=True` scaffold: included
- CUDA top-1 parity kernel: included
- Optimized CUDA: not yet
- Production-grade training: scaffold only
- Full Transformer replacement proof: not yet
