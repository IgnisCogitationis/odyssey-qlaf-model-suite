import torch
import torch.nn as nn
from odyssey_v39.config.schema import OdysseyConfig

class TSCResidual(nn.Module):
    def __init__(self, config: OdysseyConfig):
        super().__init__()
        self.config = config
        self.norm = nn.LayerNorm(config.hidden_size)
        self.proj = nn.Linear(config.hidden_size, config.hidden_size, bias=False)

    def forward(self, x: torch.Tensor, scale_multiplier: float = 1.0) -> torch.Tensor:
        return x + (self.config.tsc_scale * scale_multiplier) * self.proj(self.norm(x))
