from dataclasses import dataclass
from typing import Literal
import torch
from odyssey_v39.config.schema import OdysseyConfig

@dataclass
class AIONDecision:
    top_k: int
    refresh_scope: Literal["none", "layer", "row", "full"] = "none"
    hierarchy_action: Literal["none", "promote", "split", "merge"] = "none"
    tsc_scale_multiplier: float = 1.0
    fallback: bool = False

class AIONPolicy:
    def __init__(self, config: OdysseyConfig):
        self.config = config

    def decide(
        self,
        route_probs: torch.Tensor,
        position: torch.Tensor,
        refresh_counter: torch.Tensor,
    ) -> AIONDecision:
        sorted_probs = torch.sort(route_probs, dim=-1, descending=True).values
        confidence = sorted_probs[..., 0].min().item()
        margin = (sorted_probs[..., 0] - sorted_probs[..., 1]).min().item() if route_probs.shape[-1] > 1 else 1.0
        periodic = bool((refresh_counter >= self.config.aion_refresh_interval).any().item())

        if periodic:
            return AIONDecision(top_k=min(2, self.config.num_states), refresh_scope="layer", hierarchy_action="promote")

        if confidence < self.config.aion_confidence_threshold or margin < self.config.aion_margin_threshold:
            return AIONDecision(top_k=min(2, self.config.num_states), refresh_scope="none", hierarchy_action="none", tsc_scale_multiplier=1.25)

        return AIONDecision(top_k=1)
