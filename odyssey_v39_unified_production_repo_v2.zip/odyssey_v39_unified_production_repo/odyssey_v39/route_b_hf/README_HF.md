# Odyssey V39 Route B HF Scaffold

Use with:

```python
AutoModelForCausalLM.from_pretrained(repo, trust_remote_code=True)
```

This is the portable fallback path. Performance requires the CUDA wheel and custom server.
