from transformers import PretrainedConfig

class OdysseyV39Config(PretrainedConfig):
    model_type = "odyssey_v39"

    def __init__(
        self,
        vocab_size=32000,
        hidden_size=512,
        num_layers=8,
        num_states=8,
        state_rank=64,
        intermediate_size=2048,
        max_positions=8192,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.num_states = num_states
        self.state_rank = state_rank
        self.intermediate_size = intermediate_size
        self.max_positions = max_positions
