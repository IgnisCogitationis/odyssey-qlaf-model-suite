import torch
from torch import nn
from transformers import PreTrainedModel
from transformers.modeling_outputs import CausalLMOutput
from odyssey_v39.config.schema import OdysseyConfig, RuntimeConfig
from odyssey_v39.model.modeling_odyssey import OdysseyForCausalLM
from .configuration_odyssey_v39 import OdysseyV39Config

class OdysseyV39ForCausalLM(PreTrainedModel):
    config_class = OdysseyV39Config
    main_input_name = "input_ids"

    def __init__(self, config: OdysseyV39Config):
        super().__init__(config)
        core_config = OdysseyConfig(
            vocab_size=config.vocab_size,
            hidden_size=config.hidden_size,
            num_layers=config.num_layers,
            num_states=config.num_states,
            state_rank=config.state_rank,
            intermediate_size=config.intermediate_size,
            max_positions=config.max_positions,
        )
        self.model = OdysseyForCausalLM(core_config)

    def forward(self, input_ids=None, labels=None, **kwargs):
        out = self.model(input_ids, labels=labels, runtime=RuntimeConfig())
        return CausalLMOutput(loss=out["loss"], logits=out["logits"])

    def prepare_inputs_for_generation(self, input_ids, **kwargs):
        return {"input_ids": input_ids}
