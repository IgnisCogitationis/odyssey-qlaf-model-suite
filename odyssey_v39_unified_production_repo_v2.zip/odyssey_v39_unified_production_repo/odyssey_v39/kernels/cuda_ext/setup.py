from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

setup(
    name="odyssey_v39_cuda",
    version="0.1.0",
    packages=["odyssey_v39_cuda"],
    ext_modules=[
        CUDAExtension(
            name="odyssey_v39_cuda._C",
            sources=["odyssey_v39_cuda/bindings.cpp", "odyssey_v39_cuda/top1_decode.cu"],
            extra_compile_args={"cxx": ["-O2"], "nvcc": ["-O2", "-lineinfo"]},
        )
    ],
    cmdclass={"build_ext": BuildExtension},
)
