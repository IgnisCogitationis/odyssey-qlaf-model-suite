#include <torch/extension.h>
#include <cuda.h>
#include <cuda_runtime.h>
#include <vector>

__global__ void qlaf_top1_decode_kernel(
    const float* __restrict__ x,
    const float* __restrict__ state_summary,
    const float* __restrict__ state_weight,
    const float* __restrict__ route_weight,
    const float* __restrict__ rank_weight,
    const float* __restrict__ out_weight,
    float* __restrict__ y,
    float* __restrict__ new_state,
    float* __restrict__ new_weight,
    int64_t* __restrict__ active_out,
    int B, int H, int S, int R
) {
    int b = blockIdx.x;
    if (b >= B) return;

    for (int s = threadIdx.x; s < S; s += blockDim.x) {
        new_weight[b*S + s] = state_weight[b*S + s];
        for (int r = 0; r < R; ++r) {
            new_state[(b*S + s)*R + r] = state_summary[(b*S + s)*R + r];
        }
    }
    __syncthreads();

    if (threadIdx.x == 0) {
        int best_s = 0;
        float best_val = -3.402823466e+38F;
        for (int s = 0; s < S; ++s) {
            float acc = 0.0f;
            for (int h = 0; h < H; ++h) acc += x[b*H + h] * route_weight[s*H + h];
            if (acc > best_val) { best_val = acc; best_s = s; }
        }
        active_out[b] = (int64_t)best_s;

        float old_w = new_weight[b*S + best_s];
        float new_w = old_w + 1.0f;
        for (int r = 0; r < R; ++r) {
            float z = 0.0f;
            for (int h = 0; h < H; ++h) z += x[b*H + h] * rank_weight[r*H + h];
            float old_val = new_state[(b*S + best_s)*R + r];
            new_state[(b*S + best_s)*R + r] = (old_val * old_w + z) / fmaxf(new_w, 1.0e-8f);
        }
        new_weight[b*S + best_s] = new_w;

        float denom = 0.0f;
        for (int s = 0; s < S; ++s) denom += new_weight[b*S + s];
        denom = fmaxf(denom, 1.0e-8f);

        for (int h = 0; h < H; ++h) {
            float acc = 0.0f;
            for (int s = 0; s < S; ++s) {
                float sw = new_weight[b*S + s] / denom;
                for (int r = 0; r < R; ++r) {
                    int flat_idx = s*R + r;
                    float flat_val = new_state[(b*S + s)*R + r] * sw;
                    acc += flat_val * out_weight[h*(S*R) + flat_idx];
                }
            }
            y[b*H + h] = x[b*H + h] + acc;
        }
    }
}

std::vector<torch::Tensor> qlaf_top1_decode_cuda(
    torch::Tensor x, torch::Tensor state_summary, torch::Tensor state_weight,
    torch::Tensor route_weight, torch::Tensor rank_weight, torch::Tensor out_weight
) {
    int B = x.size(0), H = x.size(1), S = state_summary.size(1), R = state_summary.size(2);
    auto y = torch::empty_like(x);
    auto ns = torch::empty_like(state_summary);
    auto nw = torch::empty_like(state_weight);
    auto active = torch::empty({B}, torch::TensorOptions().device(x.device()).dtype(torch::kInt64));
    qlaf_top1_decode_kernel<<<B, 128>>>(
        x.data_ptr<float>(), state_summary.data_ptr<float>(), state_weight.data_ptr<float>(),
        route_weight.data_ptr<float>(), rank_weight.data_ptr<float>(), out_weight.data_ptr<float>(),
        y.data_ptr<float>(), ns.data_ptr<float>(), nw.data_ptr<float>(), active.data_ptr<int64_t>(),
        B, H, S, R
    );
    return {y, ns, nw, active};
}
