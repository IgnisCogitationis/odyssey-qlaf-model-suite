#include <torch/extension.h>
#include <vector>

std::vector<torch::Tensor> qlaf_top1_decode_cuda(
    torch::Tensor x,
    torch::Tensor state_summary,
    torch::Tensor state_weight,
    torch::Tensor route_weight,
    torch::Tensor rank_weight,
    torch::Tensor out_weight
);

std::vector<torch::Tensor> qlaf_top1_decode(
    torch::Tensor x,
    torch::Tensor state_summary,
    torch::Tensor state_weight,
    torch::Tensor route_weight,
    torch::Tensor rank_weight,
    torch::Tensor out_weight
) {
    TORCH_CHECK(x.is_cuda(), "x must be CUDA");
    TORCH_CHECK(x.dtype() == torch::kFloat32, "float32 only for parity kernel");
    return qlaf_top1_decode_cuda(x, state_summary, state_weight, route_weight, rank_weight, out_weight);
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("qlaf_top1_decode", &qlaf_top1_decode, "Odyssey V39 QLAF top-1 decode parity kernel");
}
