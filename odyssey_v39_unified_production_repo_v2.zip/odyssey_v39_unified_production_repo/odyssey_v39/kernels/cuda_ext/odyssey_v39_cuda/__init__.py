try:
    from ._C import qlaf_top1_decode
except Exception as e:
    _IMPORT_ERROR = e
    def qlaf_top1_decode(*args, **kwargs):
        raise RuntimeError(f"odyssey_v39_cuda is not built or failed to import: {_IMPORT_ERROR}")
