import torch

def qlaf_top1_decode_reference(x, state_summary, state_weight, route_weight, rank_weight, out_weight):
    B, H = x.shape
    S, R = state_summary.shape[1], state_summary.shape[2]
    active = torch.argmax(x @ route_weight.t(), dim=-1)
    z = x @ rank_weight.t()
    ns = state_summary.clone()
    nw = state_weight.clone()
    bi = torch.arange(B, device=x.device)
    old_w = nw[bi, active]
    new_w = old_w + 1.0
    old = ns[bi, active]
    ns[bi, active] = (old * old_w[:, None] + z) / new_w[:, None].clamp_min(1e-8)
    nw[bi, active] = new_w
    flat = (ns * nw[:, :, None] / nw.sum(dim=-1, keepdim=True).clamp_min(1e-8)[:, :, None]).reshape(B, S * R)
    y = x + flat @ out_weight.t()
    return y, ns, nw, active

def make_inputs(batch=2, hidden=8, states=3, rank=4, seed=1, device="cpu"):
    g = torch.Generator(device="cpu")
    g.manual_seed(seed)
    def randn(*shape):
        return (torch.randn(*shape, generator=g) * 0.05).to(device)
    return {
        "x": randn(batch, hidden),
        "state_summary": randn(batch, states, rank),
        "state_weight": (torch.rand(batch, states, generator=g) * 0.5).to(device),
        "route_weight": randn(states, hidden),
        "rank_weight": randn(rank, hidden),
        "out_weight": randn(hidden, states * rank),
    }
