import torch
import torch.nn as nn
from odyssey_v39.config.schema import OdysseyConfig
from odyssey_v39.policies.tsc import TSCResidual

class QLAFLayer(nn.Module):
    def __init__(self, config: OdysseyConfig, layer_idx: int):
        super().__init__()
        self.config = config
        self.layer_idx = layer_idx
        H, S, R = config.hidden_size, config.num_states, config.state_rank
        self.norm = nn.LayerNorm(H)
        self.route = nn.Linear(H, S, bias=False)
        self.to_rank = nn.Linear(H, R, bias=False)
        self.from_state = nn.Linear(S * R, H, bias=False)
        self.tsc = TSCResidual(config)
        self.mlp_norm = nn.LayerNorm(H)
        self.mlp = nn.Sequential(
            nn.Linear(H, config.intermediate_size),
            nn.SiLU(),
            nn.Linear(config.intermediate_size, H),
        )

    def route_probs(self, x: torch.Tensor) -> torch.Tensor:
        return torch.softmax(self.route(self.norm(x)), dim=-1)

    def update_state(
        self,
        x: torch.Tensor,
        state_summary: torch.Tensor,
        state_weight: torch.Tensor,
        top_k: int,
    ):
        B, S, R = state_summary.shape
        xn = self.norm(x)
        probs = torch.softmax(self.route(xn), dim=-1)
        vals, ids = torch.topk(probs, k=top_k, dim=-1)
        vals = vals / vals.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        z = self.to_rank(xn)

        new_state = state_summary.clone()
        new_weight = state_weight.clone()
        batch_idx = torch.arange(B, device=x.device)

        for j in range(top_k):
            sid = ids[:, j]
            w = vals[:, j]
            old_w = new_weight[batch_idx, sid]
            new_w = old_w + w
            old = new_state[batch_idx, sid]
            new_state[batch_idx, sid] = (old * old_w[:, None] + z * w[:, None]) / new_w[:, None].clamp_min(1e-8)
            new_weight[batch_idx, sid] = new_w

        return new_state, new_weight, ids, probs

    def read_state(self, x: torch.Tensor, state_summary: torch.Tensor, state_weight: torch.Tensor) -> torch.Tensor:
        B, S, R = state_summary.shape
        weighted = state_summary * state_weight[:, :, None]
        denom = state_weight.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        flat = (weighted / denom[:, :, None]).reshape(B, S * R)
        return x + self.from_state(flat)

    def forward_decode(
        self,
        x: torch.Tensor,
        cache,
        top_k: int,
        enable_tsc: bool = True,
        tsc_scale_multiplier: float = 1.0,
    ):
        li = self.layer_idx
        ns, nw, ids, probs = self.update_state(x, cache.state_summary[:, li], cache.state_weight[:, li], top_k)
        cache.state_summary[:, li] = ns
        cache.state_weight[:, li] = nw
        cache.active_state_ids[:, li, :ids.shape[-1]] = ids
        sorted_probs = torch.sort(probs, dim=-1, descending=True).values
        cache.route_confidence[:, li] = sorted_probs[:, 0]
        cache.route_margin[:, li] = sorted_probs[:, 0] - sorted_probs[:, 1] if probs.shape[-1] > 1 else 1.0
        cache.refresh_counter[:, li] += 1

        y = self.read_state(x, ns, nw)
        if enable_tsc:
            y = self.tsc(y, scale_multiplier=tsc_scale_multiplier)
        y = y + self.mlp(self.mlp_norm(y))
        return y, probs
