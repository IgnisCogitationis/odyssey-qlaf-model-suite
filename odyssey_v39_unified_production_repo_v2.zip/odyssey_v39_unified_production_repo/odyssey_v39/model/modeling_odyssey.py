import torch
import torch.nn as nn
import torch.nn.functional as F
from odyssey_v39.config.schema import OdysseyConfig, RuntimeConfig
from odyssey_v39.cache.state_cache import QLAFCache
from odyssey_v39.model.layers import QLAFLayer
from odyssey_v39.policies.aion import AIONPolicy

class OdysseyForCausalLM(nn.Module):
    def __init__(self, config: OdysseyConfig):
        super().__init__()
        self.config = config
        self.embed_tokens = nn.Embedding(config.vocab_size, config.hidden_size)
        self.position_embeddings = nn.Embedding(config.max_positions, config.hidden_size)
        self.layers = nn.ModuleList([QLAFLayer(config, i) for i in range(config.num_layers)])
        self.norm = nn.LayerNorm(config.hidden_size)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        self.aion = AIONPolicy(config)

    def new_cache(self, batch_size: int, device=None, dtype=None) -> QLAFCache:
        if dtype is None:
            dtype = self.embed_tokens.weight.dtype
        return QLAFCache.allocate(batch_size, self.config, device=device, dtype=dtype)

    def token_hidden(self, input_ids: torch.Tensor, position: torch.Tensor) -> torch.Tensor:
        return self.embed_tokens(input_ids[:, 0]) + self.position_embeddings(position)

    def decode_step(
        self,
        input_ids: torch.Tensor,
        cache: QLAFCache,
        runtime: RuntimeConfig | None = None,
    ):
        if runtime is None:
            runtime = RuntimeConfig()
        cache.require_valid()
        cache.validate(self.config)

        x = self.token_hidden(input_ids, cache.position)
        info = {"top_k": [], "route_confidence": [], "route_margin": []}

        for li, layer in enumerate(self.layers):
            # Probe route probabilities before choosing adaptive top-k.
            probs = layer.route_probs(x)
            if runtime.enable_aion and runtime.decode_branch_mode == "adaptive":
                decision = self.aion.decide(probs, cache.position, cache.refresh_counter[:, li])
                top_k = decision.top_k
                tsc_mult = decision.tsc_scale_multiplier
            elif runtime.decode_branch_mode == "top2":
                top_k = min(2, self.config.num_states)
                tsc_mult = 1.0
            else:
                top_k = 1
                tsc_mult = 1.0

            x, probs = layer.forward_decode(
                x,
                cache,
                top_k=top_k,
                enable_tsc=runtime.enable_tsc,
                tsc_scale_multiplier=tsc_mult,
            )
            sorted_probs = torch.sort(probs, dim=-1, descending=True).values
            info["top_k"].append(top_k)
            info["route_confidence"].append(sorted_probs[:, 0].detach())
            info["route_margin"].append((sorted_probs[:, 0] - sorted_probs[:, 1]).detach() if probs.shape[-1] > 1 else torch.ones_like(sorted_probs[:, 0]))

        cache.position += 1
        logits = self.lm_head(self.norm(x))
        return logits, cache, info

    def prefill(self, input_ids: torch.Tensor, runtime: RuntimeConfig | None = None):
        B, T = input_ids.shape
        cache = self.new_cache(B, device=input_ids.device, dtype=self.embed_tokens.weight.dtype)
        logits = []
        for t in range(T):
            step_logits, cache, _ = self.decode_step(input_ids[:, t:t+1], cache, runtime=runtime)
            logits.append(step_logits[:, None, :])
        return torch.cat(logits, dim=1), cache

    def forward(self, input_ids: torch.Tensor, labels: torch.Tensor | None = None, runtime: RuntimeConfig | None = None):
        logits, cache = self.prefill(input_ids, runtime=runtime)
        loss = None
        if labels is not None:
            loss = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.size(-1)), labels[:, 1:].reshape(-1))
        return {"logits": logits, "loss": loss, "cache": cache}

    def generate_greedy(self, input_ids: torch.Tensor, max_new_tokens: int = 16, runtime: RuntimeConfig | None = None):
        logits, cache = self.prefill(input_ids, runtime=runtime)
        next_token = torch.argmax(logits[:, -1, :], dim=-1, keepdim=True)
        generated = [next_token]
        for _ in range(max_new_tokens - 1):
            step_logits, cache, _ = self.decode_step(next_token, cache, runtime=runtime)
            next_token = torch.argmax(step_logits, dim=-1, keepdim=True)
            generated.append(next_token)
        return torch.cat([input_ids] + generated, dim=1)
