import torch
from odyssey_v39.config.schema import OdysseyConfig, RuntimeConfig
from odyssey_v39.model.modeling_odyssey import OdysseyForCausalLM
from odyssey_v39.cache.state_cache import QLAFCache

class OdysseyEngine:
    def __init__(self, config: OdysseyConfig | None = None, runtime: RuntimeConfig | None = None):
        self.config = config or OdysseyConfig()
        self.runtime = runtime or RuntimeConfig()
        self.model = OdysseyForCausalLM(self.config)
        self.model.eval()

    def to(self, device: str):
        self.runtime.device = device
        self.model.to(device)
        return self

    def new_cache(self, batch_size: int) -> QLAFCache:
        dtype = next(self.model.parameters()).dtype
        return self.model.new_cache(batch_size, device=self.runtime.device, dtype=dtype)

    @torch.no_grad()
    def prefill(self, input_ids: torch.Tensor):
        input_ids = input_ids.to(self.runtime.device)
        return self.model.prefill(input_ids, runtime=self.runtime)

    @torch.no_grad()
    def decode_step(self, input_ids: torch.Tensor, cache: QLAFCache):
        input_ids = input_ids.to(self.runtime.device)
        return self.model.decode_step(input_ids, cache, runtime=self.runtime)

    @torch.no_grad()
    def generate(self, input_ids: torch.Tensor, max_new_tokens: int = 16):
        input_ids = input_ids.to(self.runtime.device)
        return self.model.generate_greedy(input_ids, max_new_tokens=max_new_tokens, runtime=self.runtime)
