from dataclasses import dataclass, asdict
from typing import Literal, Optional, Dict, Any

@dataclass
class OdysseyConfig:
    vocab_size: int = 32000
    hidden_size: int = 512
    num_layers: int = 8
    num_states: int = 8
    state_rank: int = 64
    intermediate_size: int = 2048
    max_positions: int = 8192
    top_k_default: int = 1
    tsc_scale: float = 0.10
    aion_confidence_threshold: float = 0.55
    aion_margin_threshold: float = 0.05
    aion_refresh_interval: int = 128
    hierarchy_levels: int = 2
    cache_layout_version: str = "qlaf_cache_v1"
    kernel_abi_version: str = "odyssey_v39_top1_abi_v1"
    dtype: str = "float32"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "OdysseyConfig":
        return cls(**data)

@dataclass
class RuntimeConfig:
    backend: Literal["torch", "cuda", "auto"] = "auto"
    device: str = "cpu"
    decode_branch_mode: Literal["top1", "adaptive", "top2"] = "adaptive"
    prefill_mode: Literal["scan", "reference"] = "scan"
    enable_tsc: bool = True
    enable_aion: bool = True
    parity_mode: bool = False
    allow_cuda_fallback: bool = True
    server_streaming: bool = True
    max_batch_size: int = 16
