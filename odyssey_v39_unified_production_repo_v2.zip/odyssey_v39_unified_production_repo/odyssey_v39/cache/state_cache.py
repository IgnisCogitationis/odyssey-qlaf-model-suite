from dataclasses import dataclass
from typing import Optional
import torch
from odyssey_v39.config.schema import OdysseyConfig

@dataclass
class QLAFCache:
    state_summary: torch.Tensor
    state_weight: torch.Tensor
    active_state_ids: torch.Tensor
    route_confidence: torch.Tensor
    route_margin: torch.Tensor
    hierarchy_level: torch.Tensor
    refresh_counter: torch.Tensor
    position: torch.Tensor
    valid: torch.Tensor
    layout_version: str
    kernel_abi_version: str

    @classmethod
    def allocate(cls, batch_size: int, config: OdysseyConfig, device=None, dtype=torch.float32) -> "QLAFCache":
        L, S, R = config.num_layers, config.num_states, config.state_rank
        return cls(
            state_summary=torch.zeros(batch_size, L, S, R, device=device, dtype=dtype),
            state_weight=torch.zeros(batch_size, L, S, device=device, dtype=dtype),
            active_state_ids=torch.zeros(batch_size, L, max(1, config.top_k_default), device=device, dtype=torch.long),
            route_confidence=torch.zeros(batch_size, L, device=device, dtype=dtype),
            route_margin=torch.zeros(batch_size, L, device=device, dtype=dtype),
            hierarchy_level=torch.zeros(batch_size, L, S, device=device, dtype=torch.long),
            refresh_counter=torch.zeros(batch_size, L, device=device, dtype=torch.long),
            position=torch.zeros(batch_size, device=device, dtype=torch.long),
            valid=torch.ones(batch_size, device=device, dtype=torch.bool),
            layout_version=config.cache_layout_version,
            kernel_abi_version=config.kernel_abi_version,
        )

    @property
    def batch_size(self) -> int:
        return int(self.state_summary.shape[0])

    def validate(self, config: OdysseyConfig) -> None:
        if self.layout_version != config.cache_layout_version:
            raise RuntimeError(f"cache layout mismatch: {self.layout_version} != {config.cache_layout_version}")
        if self.kernel_abi_version != config.kernel_abi_version:
            raise RuntimeError(f"kernel ABI mismatch: {self.kernel_abi_version} != {config.kernel_abi_version}")
        expected = (self.batch_size, config.num_layers, config.num_states, config.state_rank)
        if tuple(self.state_summary.shape) != expected:
            raise RuntimeError(f"state_summary shape mismatch: {tuple(self.state_summary.shape)} != {expected}")

    def reset_rows(self, rows: Optional[torch.Tensor] = None) -> None:
        if rows is None:
            self.state_summary.zero_()
            self.state_weight.zero_()
            self.active_state_ids.zero_()
            self.route_confidence.zero_()
            self.route_margin.zero_()
            self.hierarchy_level.zero_()
            self.refresh_counter.zero_()
            self.position.zero_()
            self.valid.fill_(True)
            return
        self.state_summary[rows].zero_()
        self.state_weight[rows].zero_()
        self.active_state_ids[rows].zero_()
        self.route_confidence[rows].zero_()
        self.route_margin[rows].zero_()
        self.hierarchy_level[rows].zero_()
        self.refresh_counter[rows].zero_()
        self.position[rows].zero_()
        self.valid[rows] = True

    def invalidate_rows(self, rows: torch.Tensor) -> None:
        self.valid[rows] = False

    def require_valid(self) -> None:
        if not bool(self.valid.all().item()):
            raise RuntimeError("QLAFCache contains invalid rows")

    def repack(self, indices: torch.Tensor) -> "QLAFCache":
        return QLAFCache(
            state_summary=self.state_summary[indices].contiguous(),
            state_weight=self.state_weight[indices].contiguous(),
            active_state_ids=self.active_state_ids[indices].contiguous(),
            route_confidence=self.route_confidence[indices].contiguous(),
            route_margin=self.route_margin[indices].contiguous(),
            hierarchy_level=self.hierarchy_level[indices].contiguous(),
            refresh_counter=self.refresh_counter[indices].contiguous(),
            position=self.position[indices].contiguous(),
            valid=self.valid[indices].contiguous(),
            layout_version=self.layout_version,
            kernel_abi_version=self.kernel_abi_version,
        )

    def elements(self) -> int:
        return (
            self.state_summary.numel()
            + self.state_weight.numel()
            + self.active_state_ids.numel()
            + self.route_confidence.numel()
            + self.route_margin.numel()
            + self.hierarchy_level.numel()
            + self.refresh_counter.numel()
            + self.position.numel()
            + self.valid.numel()
        )

    def bytes(self) -> int:
        total = 0
        for t in [
            self.state_summary, self.state_weight, self.active_state_ids,
            self.route_confidence, self.route_margin, self.hierarchy_level,
            self.refresh_counter, self.position, self.valid
        ]:
            total += t.numel() * t.element_size()
        return int(total)
