# Odyssey V39 Unified Production Repo Status

This repository contains the full unified production-style codebase:

- QLAF cache
- AION adaptive policy
- TSC residual
- decode branch
- reference prefill
- PyTorch model
- CUDA top-1 parity extension
- Hugging Face Route B scaffold
- FastAPI server
- tests and benchmarks

## Verified in this container

Structure validation passed.

## Not verified in this container

PyTorch runtime smoke did not complete here because PyTorch import hung in this environment during packaging. Earlier tiny PyTorch shards and seed-by-seed training gates passed in separate artifacts, but this unified repo should still be run locally with:

```bash
pip install -e .
python scripts/run_cpu_smoke.py
pytest -q tests
```

## CUDA

CUDA top-1 parity must be run on a CUDA machine:

```bash
bash scripts/build_cuda.sh
bash scripts/run_cuda_parity.sh
```

No CUDA optimization or production claims until that passes.
