import argparse
import torch
from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn
from odyssey_v39 import OdysseyConfig, RuntimeConfig, OdysseyEngine

class GenerateRequest(BaseModel):
    input_ids: list[list[int]]
    max_new_tokens: int = 16

def create_app():
    app = FastAPI(title="Odyssey V39 Server")
    config = OdysseyConfig(vocab_size=32000, hidden_size=128, num_layers=2, num_states=4, state_rank=16, intermediate_size=256)
    runtime = RuntimeConfig(device="cuda" if torch.cuda.is_available() else "cpu", backend="auto")
    engine = OdysseyEngine(config, runtime).to(runtime.device)

    @app.get("/health")
    def health():
        return {"ok": True, "device": runtime.device, "backend": runtime.backend}

    @app.post("/generate")
    def generate(req: GenerateRequest):
        x = torch.tensor(req.input_ids, dtype=torch.long)
        y = engine.generate(x, max_new_tokens=req.max_new_tokens)
        return {"output_ids": y.cpu().tolist()}

    @app.get("/metrics")
    def metrics():
        return {"status": "reference_server", "cuda_available": torch.cuda.is_available()}

    return app

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    uvicorn.run(create_app(), host=args.host, port=args.port)
