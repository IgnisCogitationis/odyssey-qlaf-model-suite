#!/usr/bin/env bash
set -euo pipefail
python server/app.py --host 0.0.0.0 --port 8000
