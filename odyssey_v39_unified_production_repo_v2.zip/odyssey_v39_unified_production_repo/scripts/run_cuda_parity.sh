#!/usr/bin/env bash
set -euo pipefail
PYTHONPATH=.:odyssey_v39/kernels/cuda_ext python tests/test_cuda_top1_parity.py
