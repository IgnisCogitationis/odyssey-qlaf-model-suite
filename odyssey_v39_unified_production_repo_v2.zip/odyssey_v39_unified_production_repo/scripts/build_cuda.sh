#!/usr/bin/env bash
set -euo pipefail
cd odyssey_v39/kernels/cuda_ext
python setup.py build_ext --inplace
