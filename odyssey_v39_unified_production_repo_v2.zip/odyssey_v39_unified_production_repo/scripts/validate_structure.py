#!/usr/bin/env python3
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
required = [
    "odyssey_v39/config/schema.py",
    "odyssey_v39/cache/state_cache.py",
    "odyssey_v39/policies/aion.py",
    "odyssey_v39/policies/tsc.py",
    "odyssey_v39/model/layers.py",
    "odyssey_v39/model/modeling_odyssey.py",
    "odyssey_v39/engine/engine.py",
    "odyssey_v39/kernels/top1_reference.py",
    "odyssey_v39/kernels/cuda_ext/setup.py",
    "odyssey_v39/kernels/cuda_ext/odyssey_v39_cuda/top1_decode.cu",
    "odyssey_v39/kernels/cuda_ext/odyssey_v39_cuda/bindings.cpp",
    "odyssey_v39/route_b_hf/configuration_odyssey_v39.py",
    "odyssey_v39/route_b_hf/modeling_odyssey_v39.py",
    "server/app.py",
    "tests/test_cpu_engine.py",
    "tests/test_cache.py",
    "tests/test_cuda_top1_parity.py",
]
missing = [p for p in required if not (ROOT / p).exists()]
result = {
    "passed": len(missing) == 0,
    "required_count": len(required),
    "missing": missing,
    "note": "structure-only validation; does not import torch or prove runtime execution",
}
print(json.dumps(result, indent=2))
(ROOT / "results" / "structure_validation.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
raise SystemExit(0 if result["passed"] else 1)
