import torch
from odyssey_v39 import OdysseyConfig, RuntimeConfig, OdysseyEngine

cfg = OdysseyConfig(vocab_size=64, hidden_size=16, num_layers=1, num_states=3, state_rank=4, intermediate_size=32, max_positions=64)
rt = RuntimeConfig(device="cpu", decode_branch_mode="adaptive")
engine = OdysseyEngine(cfg, rt).to("cpu")
x = torch.randint(0, cfg.vocab_size, (2, 8))
logits, cache = engine.prefill(x)
y = engine.generate(x[:, :4], max_new_tokens=4)
print({"passed": True, "logits_shape": tuple(logits.shape), "cache_elements": cache.elements(), "generated_shape": tuple(y.shape)})
