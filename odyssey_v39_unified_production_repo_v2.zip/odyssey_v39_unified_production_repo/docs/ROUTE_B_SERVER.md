# Route B Server

The server is a reference FastAPI service.

Production Route B still requires:
- real tokenizer
- safetensors checkpoint
- CUDA wheel install
- batch scheduler
- streaming
- request-id cache manager
- metrics
