# Odyssey V39 Architecture

Dominant decode path:

```text
token -> embedding -> QLAF route -> top-1/top-2 state update -> state readout -> TSC residual -> MLP -> logits
```

QLAF replaces the Transformer KV cache with a bounded state cache.

AION controls top-k widening and refresh.

TSC is residual-only.

Route B deploys through HF custom model + CUDA wheel + custom server.
