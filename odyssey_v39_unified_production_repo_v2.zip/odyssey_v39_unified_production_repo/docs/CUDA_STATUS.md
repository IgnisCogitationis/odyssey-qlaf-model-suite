# CUDA Status

Included:
- top-1 decode parity extension
- PyTorch reference
- CUDA parity test

Not included:
- optimized CUDA
- prefill CUDA optimization
- production fused kernels

Gate:

```bash
bash scripts/build_cuda.sh
bash scripts/run_cuda_parity.sh
```

No CUDA timing or optimization claims until parity passes.
