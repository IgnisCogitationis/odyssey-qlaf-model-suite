import argparse,torch
from odyssey_gpu_engine_v12 import OdysseyGPUV12LM,MatchedTransformerLM,make_cfg,count_params
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu'); ap.add_argument('--dtype',default='bf16',choices=['fp32','fp16','bf16']); args=ap.parse_args(); device=torch.device(args.device); dtype={'fp32':torch.float32,'fp16':torch.float16,'bf16':torch.bfloat16}[args.dtype]; amp=device.type=='cuda' and dtype!=torch.float32
 cfg=make_cfg('tiny',vocab_size=1024,max_seq_len=128)
 for cls,name in [(OdysseyGPUV12LM,'odyssey_v12'),(MatchedTransformerLM,'transformer')]:
  m=cls(cfg).to(device); x=torch.randint(0,cfg.vocab_size,(2,32),device=device); y=torch.randint(0,cfg.vocab_size,(2,32),device=device); opt=torch.optim.AdamW(m.parameters(),lr=1e-4); opt.zero_grad(set_to_none=True)
  with torch.autocast(device_type=device.type,dtype=dtype,enabled=amp): logits,loss=m(x,y,phase='train',mode='balanced')
  assert logits.shape==(2,32,cfg.vocab_size); assert loss is not None and torch.isfinite(loss); loss.backward(); opt.step()
  with torch.no_grad(): m(x,None,phase='decode',mode='lean')
  print(name,'PASS','params',count_params(m),'loss',float(loss.detach().cpu()))
 if device.type=='cuda': print('GPU',torch.cuda.get_device_name(),'peak_mb',torch.cuda.max_memory_allocated()/1024/1024)
if __name__=='__main__': main()
