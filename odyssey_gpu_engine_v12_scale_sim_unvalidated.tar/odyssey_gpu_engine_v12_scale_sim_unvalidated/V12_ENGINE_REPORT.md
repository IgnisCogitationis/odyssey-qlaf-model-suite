# Odyssey GPU Engine v12 Report

## What was simulated

The simulator estimates transformer and Odyssey-v12 latency/memory trends under A100/H100-like profiles. It is a planning tool only.

## Main conclusion

Odyssey v12 is expected to beat transformer furthest in long-context prefill/decode when it uses `lean` or `survival` decode and `balanced` prefill. The main risk is GPU op fragmentation, not the high-level architecture.

## Best deployment policy

| Phase | Recommended mode | Reason |
|---|---|---|
| training | balanced | keeps TSC signal without full backward cost |
| prefill | balanced or lean | preserves quality with bounded correction |
| decode | lean | latency improvement, rare correction |
| memory emergency | survival | QLAF-only plus minimal local branch |

## Failure-driven engine changes made in v12

1. Budgeted adaptive TSC caps.
2. Packed QLAF state layout.
3. Separate phase policies.
4. Survival fallback.
5. Checkpointing flag.
6. A100/H100 scripts and simulator.

## Remaining unvalidated assumptions

- Real Triton fused path is not production-validated.
- Transformer baseline should use FlashAttention on real GPU.
- Real speed can drop if op fragmentation dominates.
- Quality impact of TSC suppression must be trained and measured.
