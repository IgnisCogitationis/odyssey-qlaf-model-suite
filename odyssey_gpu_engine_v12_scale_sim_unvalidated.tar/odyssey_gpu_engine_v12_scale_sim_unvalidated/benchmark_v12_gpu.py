import argparse,csv,time,json,platform
from pathlib import Path
import torch
from odyssey_gpu_engine_v12 import OdysseyGPUV12LM,MatchedTransformerLM,make_cfg,count_params
def sync(d):
 if d.type=='cuda': torch.cuda.synchronize()
def timed(fn,d,warm,trials):
 for _ in range(warm): fn()
 sync(d); ts=[]
 for _ in range(trials):
  t=time.perf_counter(); fn(); sync(d); ts.append(time.perf_counter()-t)
 return sum(ts)/len(ts), min(ts)
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu'); ap.add_argument('--dtype',default='bf16',choices=['fp32','fp16','bf16']); ap.add_argument('--size',default='small'); ap.add_argument('--seqs',nargs='+',type=int,default=[256,512,1024]); ap.add_argument('--batch-sizes',nargs='+',type=int,default=[1,2]); ap.add_argument('--trials',type=int,default=10); ap.add_argument('--warmup',type=int,default=5); ap.add_argument('--out',default='results/v12_gpu_benchmark_raw.csv'); args=ap.parse_args(); device=torch.device(args.device); dtype={'fp32':torch.float32,'fp16':torch.float16,'bf16':torch.bfloat16}[args.dtype]; amp=device.type=='cuda' and dtype!=torch.float32
 cfg=make_cfg(args.size,vocab_size=8192,max_seq_len=max(args.seqs)); Path(args.out).parent.mkdir(parents=True,exist_ok=True); rows=[]
 for b in args.batch_sizes:
  for s in args.seqs:
   x=torch.randint(0,cfg.vocab_size,(b,s),device=device); y=torch.randint(0,cfg.vocab_size,(b,s),device=device)
   for name,model in [('transformer',MatchedTransformerLM(cfg).to(device)),('odyssey_v12',OdysseyGPUV12LM(cfg).to(device))]:
    for phase,mode in [('prefill','balanced'),('decode','lean'),('train','balanced')]:
     if device.type=='cuda': torch.cuda.reset_peak_memory_stats()
     opt=torch.optim.AdamW(model.parameters(),lr=1e-4) if phase=='train' else None
     def fn():
      if phase=='train':
       model.train(); opt.zero_grad(set_to_none=True)
       with torch.autocast(device_type=device.type,dtype=dtype,enabled=amp): logits,loss=model(x,y,phase='train',mode=mode)
       loss.backward(); opt.step(); return loss
      model.eval()
      with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp): logits,_=model(x,None,phase=phase,mode=mode)
      return logits
     avg,mn=timed(fn,device,args.warmup,args.trials); rows.append(dict(model=name,phase=phase,mode=mode,batch=b,seq=s,avg_s=avg,min_s=mn,tokens_per_s=b*s/avg,peak_mem_mb=(torch.cuda.max_memory_allocated()/1024/1024 if device.type=='cuda' else 0),params=count_params(model)))
    del model
    if device.type=='cuda': torch.cuda.empty_cache()
 with open(args.out,'w',newline='') as f: w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
 pct=[]
 for r in rows:
  if r['model']=='odyssey_v12':
   base=next(z for z in rows if z['model']=='transformer' and z['phase']==r['phase'] and z['batch']==r['batch'] and z['seq']==r['seq']); pct.append({**r,'transformer_avg_s':base['avg_s'],'speedup_vs_transformer_pct':(base['avg_s']/r['avg_s']-1)*100})
 pp=str(Path(args.out).with_name('v12_percent_vs_transformer.csv'))
 with open(pp,'w',newline='') as f: w=csv.DictWriter(f,fieldnames=list(pct[0].keys()) if pct else []); w.writeheader(); w.writerows(pct)
 Path(args.out).with_name('environment_report.json').write_text(json.dumps({'torch':torch.__version__,'platform':platform.platform(),'device':str(device),'cuda':torch.cuda.is_available(),'gpu':torch.cuda.get_device_name() if torch.cuda.is_available() and device.type=='cuda' else None},indent=2))
 print('WROTE',args.out); print('WROTE',pp)
if __name__=='__main__': main()
