import argparse,csv,json
from pathlib import Path
GPU_PROFILES={'cpu_reference':dict(vram_gb=16,bandwidth_tb_s=0.1,tflops=1,launch_us=20),'a100':dict(vram_gb=40,bandwidth_tb_s=1.55,tflops=312,launch_us=5),'a100_80gb':dict(vram_gb=80,bandwidth_tb_s=2.0,tflops=312,launch_us=5),'h100':dict(vram_gb=80,bandwidth_tb_s=3.35,tflops=989,launch_us=3)}
def est_t(seq,batch,d,layers,heads,gpu):
 p=GPU_PROFILES[gpu]; attn=layers*batch*heads*seq*seq*(d//heads)*2; mlp=layers*batch*seq*d*4*d*2; mem=layers*batch*seq*d*2*10+layers*batch*heads*seq*seq*2*0.25
 return max((attn+mlp)/(p['tflops']*1e12),mem/(p['bandwidth_tb_s']*1e12))+layers*18*p['launch_us']/1e6, mem/1e9
def est_o(seq,batch,d,layers,states,gpu,mode):
 p=GPU_PROFILES[gpu]; frac={'full':1,'balanced':0.5,'lean':0.1,'survival':0}[mode]; ops=layers*batch*seq*d*d*(states*.45+states*.20*frac)+layers*batch*seq*d*7+layers*batch*seq*d*4*d*2; mem=layers*batch*seq*d*2*(7+2*states+4*frac)
 return max(ops/(p['tflops']*1e12),mem/(p['bandwidth_tb_s']*1e12))+layers*10*p['launch_us']/1e6, mem/1e9
def flags(mem,vram,seq,batch,mode):
 f=[]
 if mem>.85*vram:f.append('OOM_risk_high')
 elif mem>.65*vram:f.append('memory_pressure')
 if seq<=128 and mode!='survival':f.append('small_seq_overhead')
 if batch>=8 and seq>=4096:f.append('activation_pressure')
 return ';'.join(f) or 'ok'
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--gpu',default='a100',choices=list(GPU_PROFILES)); ap.add_argument('--seqs',nargs='+',type=int,default=[512,1024,2048,4096,8192]); ap.add_argument('--batch-sizes',nargs='+',type=int,default=[1,2,4,8]); ap.add_argument('--d-model',type=int,default=512); ap.add_argument('--layers',type=int,default=8); ap.add_argument('--heads',type=int,default=8); ap.add_argument('--states',type=int,default=4); ap.add_argument('--out',default='results/v12_scale_simulation.csv'); args=ap.parse_args()
 Path(args.out).parent.mkdir(parents=True,exist_ok=True); rows=[]; vram=GPU_PROFILES[args.gpu]['vram_gb']
 for b in args.batch_sizes:
  for s in args.seqs:
   tlat,tmem=est_t(s,b,args.d_model,args.layers,args.heads,args.gpu); rows.append(dict(gpu=args.gpu,model='transformer',mode='baseline',batch=b,seq=s,estimated_latency_ms=tlat*1000,estimated_mem_gb=tmem,speedup_vs_transformer_pct=0,flags=flags(tmem,vram,s,b,'full')))
   for m in ['full','balanced','lean','survival']:
    olat,omem=est_o(s,b,args.d_model,args.layers,args.states,args.gpu,m); rows.append(dict(gpu=args.gpu,model='odyssey_v12',mode=m,batch=b,seq=s,estimated_latency_ms=olat*1000,estimated_mem_gb=omem,speedup_vs_transformer_pct=(tlat/olat-1)*100,flags=flags(omem,vram,s,b,m)))
 with open(args.out,'w',newline='') as f: w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
 print('WROTE',args.out); print(json.dumps({'gpu_profile':GPU_PROFILES[args.gpu]},indent=2))
if __name__=='__main__': main()
