Run scale_simulator.py and benchmark_v12_gpu.py to generate CSVs in this directory.
