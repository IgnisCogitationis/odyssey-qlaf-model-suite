# Scaled GPU Estimate and Failure Model

This document separates CPU-reference evidence from unvalidated GPU projections.

## Expected strengths

- Long-context prefill: QLAF-style state aggregation should avoid full quadratic attention scaling.
- Decode: strongest when TSC is adaptive/rare and state routing is hard top-1/top-2.
- Memory: structured state cache should be smaller than transformer KV cache at long context if state count stays bounded.

## Expected failures

| Failure mode | Cause | v12 mitigation |
|---|---|---|
| Small-sequence overhead | routing/gating overhead dominates | lean/survival modes |
| TSC backward explosion | correction branch creates extra graph/memory | train budget cap + detach-compatible design |
| GPU op fragmentation | many small PyTorch ops | packed QLAF path + Triton-ready signature |
| Memory OOM | activations/caches exceed VRAM | checkpointing + fallback policy |
| Triton mismatch | shape/dtype unsupported | PyTorch fallback |
| Quality loss | TSC suppressed too often | richer prefill, confidence-triggered correction |
| Multi-GPU inefficiency | state/gate sync overhead | shardable state-cache interface planned |

## Validation requirements

1. A100 matched forward/decode/train.
2. A100 memory saturation sweep.
3. H100 optional repeat.
4. 5-seed training quality test.
5. Real tokenizer generation latency.
6. FlashAttention transformer baseline.
