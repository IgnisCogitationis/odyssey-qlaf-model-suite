# Odyssey GPU Engine v12 — Scale Simulation + Failure-Hardened Engine

Status: **written and packaged; not CUDA/Triton validated in this environment**.

This package extends the v11 GPU engine with scaled-GPU failure modeling and concrete v12 engine changes:

- prefill/decode/train phase separation
- budgeted adaptive TSC correction
- packed QLAF state path
- pressure-aware modes: `full`, `balanced`, `lean`, `survival`
- checkpointing flag for training memory pressure
- A100/H100 scale simulator
- A100/H100 benchmark scripts
- CPU fallback support

## Quick start

```bash
pip install -r requirements.txt
python scale_simulator.py --gpu a100 --seqs 512 1024 2048 4096 8192 --batch-sizes 1 2 4 8
python smoke_test_v12.py --device cuda --dtype bf16
python benchmark_v12_gpu.py --device cuda --dtype bf16 --seqs 512 1024 2048 4096 --batch-sizes 1 2 4
```

CPU fallback:

```bash
python smoke_test_v12.py --device cpu --dtype fp32
python scale_simulator.py --gpu cpu_reference
```

## Important

The scale simulator is an engineering projection tool, not measured GPU truth. Final claims require A100/H100 validation against a FlashAttention transformer baseline.
