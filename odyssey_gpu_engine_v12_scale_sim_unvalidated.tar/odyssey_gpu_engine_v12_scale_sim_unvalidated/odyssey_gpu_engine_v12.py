from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Literal
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

ModeName = Literal['full','balanced','lean','survival']
PhaseName = Literal['prefill','decode','train']

@dataclass
class V12Config:
    vocab_size:int=8192; d_model:int=512; n_layers:int=8; n_heads:int=8; d_ff:int=2048; max_seq_len:int=8192
    n_states:int=4; dropout:float=0.0; qlaf_ratio:float=0.70; local_ratio:float=0.20; tsc_ratio:float=0.10
    tsc_threshold:float=0.62; max_tsc_fraction_prefill:float=1.0; max_tsc_fraction_decode:float=0.10; max_tsc_fraction_train:float=0.50
    use_checkpointing:bool=False; use_triton_if_available:bool=False; mode:ModeName='balanced'

class RMSNorm(nn.Module):
    def __init__(self,d:int,eps:float=1e-6): super().__init__(); self.weight=nn.Parameter(torch.ones(d)); self.eps=eps
    def forward(self,x): return x*torch.rsqrt(x.pow(2).mean(-1,keepdim=True)+self.eps)*self.weight

class SwiGLU(nn.Module):
    def __init__(self,d:int,ff:int): super().__init__(); self.a=nn.Linear(d,ff,bias=False); self.b=nn.Linear(d,ff,bias=False); self.o=nn.Linear(ff,d,bias=False)
    def forward(self,x): return self.o(F.silu(self.a(x))*self.b(x))

class PackedQLAFPath(nn.Module):
    def __init__(self,cfg:V12Config):
        super().__init__(); self.cfg=cfg; d=cfg.d_model; s=cfg.n_states
        self.state_proj=nn.Linear(d,d*s,bias=False); self.router=nn.Linear(d,s,bias=False); self.out=nn.Linear(d,d,bias=False)
        self.state_scale=nn.Parameter(torch.ones(s,d)/math.sqrt(d))
    def forward(self,x, phase:PhaseName='prefill', mode:ModeName='balanced'):
        B,T,D=x.shape; S=self.cfg.n_states
        logits=self.router(x); hard=(phase=='decode' or mode in ('lean','survival'))
        if hard:
            idx=logits.argmax(-1,keepdim=True); weights=torch.zeros_like(logits).scatter_(-1,idx,1.0)
        else: weights=torch.softmax(logits,dim=-1)
        states=torch.tanh(self.state_proj(x).view(B,T,S,D).contiguous())*self.state_scale.view(1,1,S,D)
        return self.out(torch.einsum('bts,btsd->btd',weights,states)), logits

class LocalMixer(nn.Module):
    def __init__(self,d:int,k:int=5): super().__init__(); self.dw=nn.Conv1d(d,d,k,groups=d,padding=k-1,bias=False); self.pw=nn.Linear(d,d,bias=False); self.g=nn.Linear(d,d,bias=False)
    def forward(self,x):
        y=self.dw(x.transpose(1,2))[:,:,:x.size(1)].transpose(1,2); return self.pw(y)*torch.sigmoid(self.g(x))

class AIONGate(nn.Module):
    def __init__(self,d:int): super().__init__(); self.op=nn.Linear(d,d,bias=False); self.g=nn.Linear(d,3,bias=True)
    def forward(self,x): return torch.softmax(self.g(torch.tanh(self.op(x))),dim=-1)

class BudgetedTSC(nn.Module):
    def __init__(self,d:int,rank:int=4): super().__init__(); self.rank=rank; self.l=nn.Linear(d,d*rank,bias=False); self.r=nn.Linear(d,rank,bias=False); self.o=nn.Linear(d,d,bias=False)
    def forward(self,x):
        B,T,D=x.shape; R=self.rank; l=self.l(x).view(B,T,R,D); r=torch.softmax(self.r(x),dim=-1).view(B,T,R,1)
        return self.o(torch.tanh((l*r).sum(2)))

class V12Policy:
    def __init__(self,cfg:V12Config): self.cfg=cfg
    def branch_weights(self,phase:PhaseName,mode:ModeName):
        if mode=='full': return 0.70,0.20,0.10
        if mode=='balanced': return (0.74,0.20,0.06) if phase=='decode' else (0.70,0.20,0.10)
        if mode=='lean': return 0.84,0.14,0.02
        if mode=='survival': return 0.94,0.06,0.0
        return 0.70,0.20,0.10
    def tsc_cap(self,phase:PhaseName,mode:ModeName):
        if mode=='survival': return 0.0
        if phase=='decode': return 0.02 if mode=='lean' else self.cfg.max_tsc_fraction_decode
        if phase=='train': return 0.20 if mode=='lean' else self.cfg.max_tsc_fraction_train
        return 0.50 if mode!='full' else self.cfg.max_tsc_fraction_prefill

class V12Block(nn.Module):
    def __init__(self,cfg:V12Config):
        super().__init__(); self.cfg=cfg; d=cfg.d_model; self.policy=V12Policy(cfg)
        self.n1=RMSNorm(d); self.n2=RMSNorm(d); self.qlaf=PackedQLAFPath(cfg); self.local=LocalMixer(d); self.tsc=BudgetedTSC(d,max(2,cfg.n_states)); self.aion=AIONGate(d); self.ff=SwiGLU(d,cfg.d_ff); self.drop=nn.Dropout(cfg.dropout)
    def forward(self,x,phase:PhaseName='prefill',mode:Optional[ModeName]=None):
        mode=mode or self.cfg.mode; h=self.n1(x); q,_=self.qlaf(h,phase,mode); l=self.local(h) if mode!='survival' else torch.zeros_like(q)
        aion=self.aion(h); conf=aion.max(-1).values.mean(); cap=self.policy.tsc_cap(phase,mode)
        run_t = cap>0 and not (phase=='decode' and bool((conf>=self.cfg.tsc_threshold).item()))
        t=self.tsc(h)*cap if run_t else torch.zeros_like(q)
        qw,lw,tw=self.policy.branch_weights(phase,mode); y=qw*q+lw*l+tw*t
        adaptive=aion[...,0:1]*q+aion[...,1:2]*l+aion[...,2:3]*t; y=0.90*y+0.10*adaptive
        x=x+self.drop(y); x=x+self.drop(self.ff(self.n2(x))); return x

class OdysseyGPUV12LM(nn.Module):
    def __init__(self,cfg:V12Config):
        super().__init__(); self.cfg=cfg; self.tok=nn.Embedding(cfg.vocab_size,cfg.d_model); self.pos=nn.Embedding(cfg.max_seq_len,cfg.d_model)
        self.blocks=nn.ModuleList([V12Block(cfg) for _ in range(cfg.n_layers)]); self.norm=RMSNorm(cfg.d_model); self.lm_head=nn.Linear(cfg.d_model,cfg.vocab_size,bias=False); self.lm_head.weight=self.tok.weight
    def forward(self,idx,targets=None,phase:PhaseName='prefill',mode:Optional[ModeName]=None):
        B,T=idx.shape
        if T>self.cfg.max_seq_len: raise ValueError('sequence exceeds max_seq_len')
        p=torch.arange(T,device=idx.device).unsqueeze(0); x=self.tok(idx)+self.pos(p)
        for block in self.blocks:
            if self.cfg.use_checkpointing and self.training:
                from torch.utils.checkpoint import checkpoint
                x=checkpoint(lambda z: block(z,phase,mode),x,use_reentrant=False)
            else: x=block(x,phase,mode)
        logits=self.lm_head(self.norm(x)); loss=None
        if targets is not None: loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1))
        return logits,loss

class MatchedTransformerLM(nn.Module):
    def __init__(self,cfg:V12Config):
        super().__init__(); self.cfg=cfg; self.tok=nn.Embedding(cfg.vocab_size,cfg.d_model); self.pos=nn.Embedding(cfg.max_seq_len,cfg.d_model)
        self.layers=nn.ModuleList([nn.TransformerEncoderLayer(d_model=cfg.d_model,nhead=cfg.n_heads,dim_feedforward=cfg.d_ff,dropout=cfg.dropout,batch_first=True,activation='gelu',norm_first=True) for _ in range(cfg.n_layers)])
        self.norm=RMSNorm(cfg.d_model); self.lm_head=nn.Linear(cfg.d_model,cfg.vocab_size,bias=False); self.lm_head.weight=self.tok.weight
    def forward(self,idx,targets=None,phase='prefill',mode=None):
        T=idx.shape[1]; p=torch.arange(T,device=idx.device).unsqueeze(0); x=self.tok(idx)+self.pos(p); mask=torch.ones(T,T,device=idx.device,dtype=torch.bool).triu(1)
        for layer in self.layers: x=layer(x,src_mask=mask)
        logits=self.lm_head(self.norm(x)); loss=None
        if targets is not None: loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1))
        return logits,loss

def make_cfg(size='small',**kw):
    sizes={'tiny':dict(d_model=128,n_layers=2,n_heads=4,d_ff=512,max_seq_len=2048),'small':dict(d_model=256,n_layers=4,n_heads=4,d_ff=1024,max_seq_len=4096),'base':dict(d_model=512,n_layers=8,n_heads=8,d_ff=2048,max_seq_len=8192),'large':dict(d_model=768,n_layers=12,n_heads=12,d_ff=3072,max_seq_len=8192)}
    d=sizes.get(size,sizes['small']).copy(); d.update(kw); return V12Config(**d)
def count_params(m): return sum(p.numel() for p in m.parameters())
