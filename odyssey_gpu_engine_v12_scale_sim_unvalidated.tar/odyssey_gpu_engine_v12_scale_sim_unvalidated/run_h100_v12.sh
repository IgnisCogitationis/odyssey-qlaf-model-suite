#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python scale_simulator.py --gpu h100 --seqs 512 1024 2048 4096 8192 16384 --batch-sizes 1 2 4 8 --out results/h100_scale_simulation.csv
python smoke_test_v12.py --device cuda --dtype bf16
python benchmark_v12_gpu.py --device cuda --dtype bf16 --size base --seqs 512 1024 2048 4096 8192 --batch-sizes 1 2 4 --trials 20 --warmup 10 --out results/h100_v12_gpu_benchmark_raw.csv
