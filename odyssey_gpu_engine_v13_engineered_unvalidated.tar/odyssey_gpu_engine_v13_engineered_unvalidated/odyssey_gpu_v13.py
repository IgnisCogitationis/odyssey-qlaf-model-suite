from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Dict, Tuple, Literal
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


Phase = Literal["train", "prefill", "decode", "decode_chunk"]
PressureMode = Literal["full", "balanced", "lean", "survival"]


@dataclass
class V13Config:
    vocab_size: int = 8192
    d_model: int = 512
    n_layers: int = 8
    n_heads: int = 8
    d_ff: int = 2048
    max_seq_len: int = 4096
    dropout: float = 0.0

    n_states: int = 4
    tsc_rank: int = 4

    qlaf_weight: float = 0.80
    local_weight: float = 0.15
    tsc_weight: float = 0.05

    controller_mix: float = 0.10
    decode_top1: bool = True
    prefill_top2: bool = True

    tsc_confidence_threshold: float = 0.62
    tsc_token_budget_ratio: float = 0.125
    train_tsc_scale: float = 0.35

    local_kernel: int = 5
    use_torch_compile_safe: bool = False
    use_triton_if_available: bool = False


def preset_config(size: str = "small", **overrides) -> V13Config:
    presets = {
        "tiny": dict(d_model=128, n_layers=2, n_heads=4, d_ff=512, max_seq_len=2048, n_states=4, tsc_rank=4),
        "small": dict(d_model=256, n_layers=4, n_heads=4, d_ff=1024, max_seq_len=4096, n_states=4, tsc_rank=4),
        "base": dict(d_model=512, n_layers=8, n_heads=8, d_ff=2048, max_seq_len=4096, n_states=4, tsc_rank=4),
        "large": dict(d_model=768, n_layers=12, n_heads=12, d_ff=3072, max_seq_len=8192, n_states=6, tsc_rank=6),
    }
    kw = presets.get(size, presets["small"]).copy()
    kw.update(overrides)
    return V13Config(**kw)


class RMSNorm(nn.Module):
    def __init__(self, d: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(d))
        self.eps = eps

    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(dim=-1, keepdim=True) + self.eps) * self.weight


class SwiGLU(nn.Module):
    def __init__(self, d: int, ff: int):
        super().__init__()
        self.a = nn.Linear(d, ff, bias=False)
        self.b = nn.Linear(d, ff, bias=False)
        self.o = nn.Linear(ff, d, bias=False)

    def forward(self, x):
        return self.o(F.silu(self.a(x)) * self.b(x))


class PackedQLAFPath(nn.Module):
    """
    GPU-first QLAF path.

    One packed projection produces:
    - state candidate tensor
    - router logits
    - controller features

    This avoids separate tiny projections and improves GEMM shape.
    """
    def __init__(self, cfg: V13Config):
        super().__init__()
        self.cfg = cfg
        d, s = cfg.d_model, cfg.n_states
        packed_dim = s * d + s + d
        self.packed = nn.Linear(d, packed_dim, bias=False)
        self.out = nn.Linear(d, d, bias=False)
        self.state_scale = nn.Parameter(torch.ones(s, d) / math.sqrt(d))

    def _route_weights(self, logits: torch.Tensor, phase: Phase) -> torch.Tensor:
        cfg = self.cfg
        if phase in ("decode", "decode_chunk") and cfg.decode_top1:
            idx = logits.argmax(dim=-1, keepdim=True)
            return torch.zeros_like(logits).scatter_(-1, idx, 1.0)

        if phase == "prefill" and cfg.prefill_top2 and logits.size(-1) > 2:
            vals, idx = torch.topk(logits, k=2, dim=-1)
            sparse = torch.full_like(logits, float("-inf"))
            sparse.scatter_(-1, idx, vals)
            return torch.softmax(sparse, dim=-1)

        return torch.softmax(logits, dim=-1)

    def forward(self, x: torch.Tensor, phase: Phase) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        B, T, D = x.shape
        S = self.cfg.n_states
        packed = self.packed(x)
        state_raw = packed[..., :S * D].view(B, T, S, D)
        router_logits = packed[..., S * D:S * D + S]
        control_feat = packed[..., S * D + S:]

        states = torch.tanh(state_raw) * self.state_scale.view(1, 1, S, D)
        weights = self._route_weights(router_logits, phase)

        # PyTorch packed fallback. Target future fusion:
        # fused_states_weight_project(x, packed_weight, out_weight, routing_mode)
        combined = torch.einsum("bts,btsd->btd", weights, states)
        return self.out(combined), router_logits, control_feat


class AIONController(nn.Module):
    """
    Lightweight controller. It outputs:
    - branch weights
    - confidence
    - pressure scalar

    It should never become a heavy compute path.
    """
    def __init__(self, d: int):
        super().__init__()
        self.gate = nn.Linear(d, 3, bias=True)
        self.pressure = nn.Linear(d, 1, bias=True)

    def forward(self, control_feat: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        gate = torch.softmax(self.gate(torch.tanh(control_feat)), dim=-1)
        confidence = gate.max(dim=-1).values
        pressure = torch.sigmoid(self.pressure(control_feat)).squeeze(-1)
        return gate, confidence, pressure


class LocalMixerGPU(nn.Module):
    """
    Local branch. Kept small and disabled/reduced under lean pressure.
    Depthwise conv is not always optimal on GPU, but provides useful local mixing.
    """
    def __init__(self, cfg: V13Config):
        super().__init__()
        d = cfg.d_model
        k = cfg.local_kernel
        self.dw = nn.Conv1d(d, d, kernel_size=k, padding=k-1, groups=d, bias=False)
        self.pw = nn.Linear(d, d, bias=False)
        self.gate = nn.Linear(d, d, bias=False)

    def forward(self, x):
        y = self.dw(x.transpose(1, 2))[:, :, :x.size(1)].transpose(1, 2)
        return self.pw(y) * torch.sigmoid(self.gate(x))


class BudgetedTSC(nn.Module):
    """
    Low-rank tensor-state correction.

    GPU policy: run on all tokens only in full mode. In balanced/lean decode,
    use confidence budget or disable.
    """
    def __init__(self, cfg: V13Config):
        super().__init__()
        d, r = cfg.d_model, cfg.tsc_rank
        self.r = r
        self.d = d
        self.left = nn.Linear(d, r * d, bias=False)
        self.right = nn.Linear(d, r, bias=False)
        self.out = nn.Linear(d, d, bias=False)

    def forward_all(self, x):
        B, T, D = x.shape
        l = self.left(x).view(B, T, self.r, D)
        r = torch.softmax(self.right(x), dim=-1).view(B, T, self.r, 1)
        return self.out(torch.tanh((l * r).sum(dim=2)))

    def forward_budgeted(self, x, confidence: torch.Tensor, budget_ratio: float):
        # Pure PyTorch fallback for validation. A production kernel should compact selected tokens.
        B, T, D = x.shape
        if budget_ratio <= 0:
            return torch.zeros_like(x)
        k = max(1, int(T * budget_ratio))
        # Lower confidence = more likely to need correction.
        _, idx = torch.topk(-confidence, k=k, dim=1)
        mask = torch.zeros(B, T, device=x.device, dtype=x.dtype)
        mask.scatter_(1, idx, 1.0)
        y = self.forward_all(x)
        return y * mask.unsqueeze(-1)


class V13Block(nn.Module):
    def __init__(self, cfg: V13Config):
        super().__init__()
        self.cfg = cfg
        d = cfg.d_model
        self.norm1 = RMSNorm(d)
        self.qlaf = PackedQLAFPath(cfg)
        self.ctrl = AIONController(d)
        self.local = LocalMixerGPU(cfg)
        self.tsc = BudgetedTSC(cfg)
        self.norm2 = RMSNorm(d)
        self.ff = SwiGLU(d, cfg.d_ff)
        self.drop = nn.Dropout(cfg.dropout)

    def _policy(self, phase: Phase, pressure_mode: PressureMode):
        if pressure_mode == "survival":
            return dict(local_scale=0.0, tsc_mode="off", tsc_scale=0.0)
        if pressure_mode == "lean":
            if phase in ("decode", "decode_chunk"):
                return dict(local_scale=0.25, tsc_mode="off", tsc_scale=0.0)
            return dict(local_scale=0.50, tsc_mode="budget", tsc_scale=0.15)
        if pressure_mode == "balanced":
            if phase in ("decode", "decode_chunk"):
                return dict(local_scale=0.75, tsc_mode="budget", tsc_scale=0.50)
            if phase == "train":
                return dict(local_scale=1.0, tsc_mode="budget", tsc_scale=self.cfg.train_tsc_scale)
            return dict(local_scale=1.0, tsc_mode="budget", tsc_scale=0.75)
        return dict(local_scale=1.0, tsc_mode="all", tsc_scale=1.0)

    def forward(self, x, phase: Phase = "train", pressure_mode: PressureMode = "balanced"):
        cfg = self.cfg
        h = self.norm1(x)
        q, router_logits, control_feat = self.qlaf(h, phase=phase)
        gate, confidence, pressure = self.ctrl(control_feat)
        policy = self._policy(phase, pressure_mode)

        if policy["local_scale"] > 0:
            l = self.local(h) * policy["local_scale"]
        else:
            l = torch.zeros_like(q)

        if policy["tsc_mode"] == "off":
            t = torch.zeros_like(q)
        elif policy["tsc_mode"] == "budget":
            budget = cfg.tsc_token_budget_ratio
            if phase in ("decode", "decode_chunk"):
                # Decode should be extra conservative.
                budget = min(budget, 0.0625)
            t = self.tsc.forward_budgeted(h, confidence, budget) * policy["tsc_scale"]
        else:
            t = self.tsc.forward_all(h) * policy["tsc_scale"]

        fixed = cfg.qlaf_weight * q + cfg.local_weight * l + cfg.tsc_weight * t
        adaptive = gate[..., 0:1] * q + gate[..., 1:2] * l + gate[..., 2:3] * t
        y = (1.0 - cfg.controller_mix) * fixed + cfg.controller_mix * adaptive

        x = x + self.drop(y)
        x = x + self.drop(self.ff(self.norm2(x)))
        return x


class OdysseyGPUV13LM(nn.Module):
    def __init__(self, cfg: V13Config):
        super().__init__()
        self.cfg = cfg
        self.tok = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.pos = nn.Embedding(cfg.max_seq_len, cfg.d_model)
        self.blocks = nn.ModuleList([V13Block(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.head.weight = self.tok.weight

    def forward(self, idx, targets=None, phase: Phase = "train", pressure_mode: PressureMode = "balanced"):
        B, T = idx.shape
        if T > self.cfg.max_seq_len:
            raise ValueError(f"T={T} exceeds max_seq_len={self.cfg.max_seq_len}")
        pos = torch.arange(T, device=idx.device).unsqueeze(0)
        x = self.tok(idx) + self.pos(pos)
        for block in self.blocks:
            x = block(x, phase=phase, pressure_mode=pressure_mode)
        x = self.norm(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss

    @torch.no_grad()
    def prefill(self, idx, pressure_mode: PressureMode = "balanced"):
        logits, _ = self.forward(idx, phase="prefill", pressure_mode=pressure_mode)
        return logits

    @torch.no_grad()
    def decode_step(self, idx, pressure_mode: PressureMode = "lean"):
        logits, _ = self.forward(idx, phase="decode", pressure_mode=pressure_mode)
        return logits[:, -1, :]

    @torch.no_grad()
    def generate(self, idx, max_new_tokens: int, temperature: float = 1.0, pressure_mode: PressureMode = "lean"):
        self.eval()
        for _ in range(max_new_tokens):
            ctx = idx[:, -self.cfg.max_seq_len:]
            logits = self.decode_step(ctx, pressure_mode=pressure_mode) / max(temperature, 1e-6)
            nxt = torch.multinomial(torch.softmax(logits, dim=-1), 1)
            idx = torch.cat([idx, nxt], dim=1)
        return idx


class TransformerAttention(nn.Module):
    def __init__(self, cfg: V13Config):
        super().__init__()
        assert cfg.d_model % cfg.n_heads == 0
        self.cfg = cfg
        self.qkv = nn.Linear(cfg.d_model, 3 * cfg.d_model, bias=False)
        self.out = nn.Linear(cfg.d_model, cfg.d_model, bias=False)

    def forward(self, x):
        B, T, D = x.shape
        H = self.cfg.n_heads
        hd = D // H
        qkv = self.qkv(x).view(B, T, 3, H, hd).transpose(1, 3)
        q, k, v = qkv[:, :, 0], qkv[:, :, 1], qkv[:, :, 2]
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        y = y.transpose(1, 2).contiguous().view(B, T, D)
        return self.out(y)


class TransformerBlock(nn.Module):
    def __init__(self, cfg: V13Config):
        super().__init__()
        self.n1 = RMSNorm(cfg.d_model)
        self.attn = TransformerAttention(cfg)
        self.n2 = RMSNorm(cfg.d_model)
        self.ff = SwiGLU(cfg.d_model, cfg.d_ff)

    def forward(self, x):
        x = x + self.attn(self.n1(x))
        x = x + self.ff(self.n2(x))
        return x


class MatchedTransformerV13LM(nn.Module):
    def __init__(self, cfg: V13Config):
        super().__init__()
        self.cfg = cfg
        self.tok = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.pos = nn.Embedding(cfg.max_seq_len, cfg.d_model)
        self.blocks = nn.ModuleList([TransformerBlock(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.head.weight = self.tok.weight

    def forward(self, idx, targets=None, phase: Phase = "train", pressure_mode: PressureMode = "balanced"):
        B, T = idx.shape
        pos = torch.arange(T, device=idx.device).unsqueeze(0)
        x = self.tok(idx) + self.pos(pos)
        for block in self.blocks:
            x = block(x)
        x = self.norm(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss


def count_params(model):
    return sum(p.numel() for p in model.parameters())


def maybe_compile(model, enabled: bool):
    if not enabled:
        return model
    try:
        return torch.compile(model)
    except Exception as e:
        print("torch.compile failed; using eager:", repr(e))
        return model
