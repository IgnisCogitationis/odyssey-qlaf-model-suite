# Odyssey GPU Engine v13 Engineering Notes

## What changed from v12

1. **Packed QLAF projection as primary path**
   - Uses a single packed projection for state candidates and controller features.
   - Avoids multiple small projections where possible.

2. **AION controller only**
   - AION determines policy, correction budget, and pressure mode behavior.
   - It is not a heavy independent compute branch.

3. **Budgeted adaptive TSC**
   - TSC correction is activated by phase and pressure policy.
   - Decode defaults to top-confidence suppression.
   - Training defaults to partial-strength TSC to avoid backward domination.

4. **Explicit phase policies**
   - `train`
   - `prefill`
   - `decode`
   - `decode_chunk`

5. **Pressure modes**
   - `full`: QLAF + local + TSC
   - `balanced`: QLAF + local + budgeted TSC
   - `lean`: QLAF + minimal local, TSC mostly off
   - `survival`: QLAF only

6. **Kernel-fusion direction**
   - PyTorch packed fallback is implemented.
   - Triton hook contract exists for fused weighted-state projection.
   - True fused backward remains future work.

## Expected strengths on GPU

- Long sequence forward/prefill
- Decode with QLAF-only or budgeted correction
- Lower memory growth than attention
- Better pressure survival than dense attention

## Expected weaknesses

- Short sequence overhead
- Dynamic routing may disrupt torch.compile
- TSC can slow training if always active
- Naive depthwise local mixer may underutilize tensor cores
- True win against FlashAttention requires fused kernels

## Recommended validation order

1. Smoke test tiny model.
2. Parameter count sanity.
3. Forward-only timings at 128/256/512/1024.
4. Decode-only timings at 1-token and chunk decode.
5. Training step timings.
6. Peak memory measurements.
7. Compare with FlashAttention-enabled transformer if available.
8. Enable `torch.compile`.
9. Only then test Triton dispatch.
