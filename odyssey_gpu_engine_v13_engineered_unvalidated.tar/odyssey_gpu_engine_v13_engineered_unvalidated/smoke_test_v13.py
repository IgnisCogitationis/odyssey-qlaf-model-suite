import argparse
import torch
from odyssey_gpu_v13 import OdysseyGPUV13LM, MatchedTransformerV13LM, preset_config, count_params

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--dtype", default="bf16", choices=["fp32","fp16","bf16"])
    p.add_argument("--size", default="tiny")
    args = p.parse_args()

    device = torch.device(args.device)
    dtype = {"fp32": torch.float32, "fp16": torch.float16, "bf16": torch.bfloat16}[args.dtype]
    amp = device.type == "cuda" and dtype != torch.float32

    cfg = preset_config(args.size, vocab_size=2048, max_seq_len=256)
    for name, cls in [("odyssey_v13", OdysseyGPUV13LM), ("transformer", MatchedTransformerV13LM)]:
        model = cls(cfg).to(device)
        x = torch.randint(0, cfg.vocab_size, (2, 64), device=device)
        y = torch.randint(0, cfg.vocab_size, (2, 64), device=device)

        opt = torch.optim.AdamW(model.parameters(), lr=1e-4)
        model.train()
        opt.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=dtype, enabled=amp):
            logits, loss = model(x, y, phase="train", pressure_mode="balanced")
        assert logits.shape == (2, 64, cfg.vocab_size)
        assert torch.isfinite(loss)
        loss.backward()
        opt.step()

        model.eval()
        with torch.no_grad(), torch.autocast(device_type=device.type, dtype=dtype, enabled=amp):
            pf = model(x, phase="prefill", pressure_mode="balanced")[0]
            dec = model(x[:, :16], phase="decode", pressure_mode="lean")[0]
        print(f"{name}: PASS params={count_params(model):,} loss={float(loss.detach().cpu()):.4f}")

    if device.type == "cuda":
        print("GPU:", torch.cuda.get_device_name())
        print("Peak memory MB:", torch.cuda.max_memory_allocated() / 1024 / 1024)

if __name__ == "__main__":
    main()
