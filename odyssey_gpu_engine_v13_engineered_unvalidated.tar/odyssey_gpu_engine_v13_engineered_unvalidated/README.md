# Odyssey GPU Engine v13 — Engineered GPU Scale Pass

Status: **written and packaged, not CUDA/Triton validated in this environment**.

This version is based on the GPU scale-up failure analysis:

- QLAF must be packed into large contiguous GEMMs.
- AION must remain a low-cost controller, not a heavy branch.
- TSC must be budgeted/adaptive, not always active.
- Prefill, decode, and training must use different execution policies.
- GPU pressure modes must progressively disable expensive correction paths.
- Small sequences may still lose to FlashAttention unless kernel launch count is minimized.
- Long context and decode are the highest-probability win regimes.

## Main files

- `odyssey_gpu_v13.py` — full engine/model implementation
- `benchmark_v13_gpu.py` — CUDA-aware benchmark runner
- `simulate_gpu_scaling.py` — analytical GPU scaling/failure simulator
- `run_a100_v13.sh` — recommended A100 validation script
- `run_h100_v13.sh` — recommended H100 validation script
- `smoke_test_v13.py` — smoke test
- `ENGINEERING_NOTES_v13.md` — design/failure notes
- `requirements.txt`

## Quick start

```bash
pip install -r requirements.txt
python smoke_test_v13.py --device cuda --dtype bf16
python benchmark_v13_gpu.py --device cuda --dtype bf16 --size small
python simulate_gpu_scaling.py
```

## Recommended A100 validation

```bash
bash run_a100_v13.sh
```

## Recommended H100 validation

```bash
bash run_h100_v13.sh
```

## Important

This package contains optional Triton dispatch hooks but defaults to safe PyTorch implementation.
The Triton kernel is intentionally guarded; validate numerics before enabling in production.
