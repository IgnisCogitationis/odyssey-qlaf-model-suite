"""
Analytical scaling simulator for Odyssey v13 vs transformer.

This is not a benchmark. It estimates likely failure/win regimes using rough
complexity and memory traffic proxies.
"""
import csv
from pathlib import Path

def estimate(seq, batch, d, layers, states=4, pressure="balanced"):
    # Arbitrary normalized units.
    transformer_attn = layers * batch * (seq * seq * d * 0.35 + seq * d * d * 3.0)
    transformer_mem = layers * batch * seq * seq * 0.25 + layers * batch * seq * d * 4

    qlaf = layers * batch * (seq * d * d * 2.2 + seq * states * d * 0.45)
    local = layers * batch * seq * d * 0.35
    if pressure == "survival":
        tsc = 0
        local *= 0
    elif pressure == "lean":
        tsc = layers * batch * seq * d * 0.05
        local *= 0.25
    elif pressure == "balanced":
        tsc = layers * batch * seq * d * 0.15
    else:
        tsc = layers * batch * seq * d * 0.45
    odyssey = qlaf + local + tsc
    odyssey_mem = layers * batch * seq * d * (4 + states * 0.25)
    ratio = transformer_attn / odyssey
    mem_ratio = transformer_mem / odyssey_mem
    return ratio, mem_ratio

def main():
    out = Path("results/v13_scaling_simulation.csv")
    out.parent.mkdir(exist_ok=True)
    rows = []
    for d, layers in [(256,4),(512,8),(768,12)]:
        for seq in [128,256,512,1024,2048,4096,8192]:
            for batch in [1,2,4,8]:
                for pressure in ["full","balanced","lean","survival"]:
                    speed_ratio, mem_ratio = estimate(seq,batch,d,layers,pressure=pressure)
                    rows.append({
                        "d_model": d, "layers": layers, "seq": seq, "batch": batch,
                        "pressure": pressure,
                        "estimated_speed_ratio_transformer_over_odyssey": speed_ratio,
                        "estimated_memory_ratio_transformer_over_odyssey": mem_ratio,
                        "estimated_percent_speedup": (speed_ratio - 1)*100,
                    })
    with out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print("WROTE", out)

if __name__ == "__main__":
    main()
