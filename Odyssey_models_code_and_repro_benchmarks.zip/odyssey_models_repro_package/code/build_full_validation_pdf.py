import json, statistics, math, os
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import landscape, letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
    KeepTogether
)
from reportlab.pdfbase.pdfmetrics import stringWidth
from pypdf import PdfReader, PdfWriter

BASE = Path('/mnt/data')
orig_pdf = BASE / '54.pdf'
supp_pdf = BASE / 'validation_volume_appendix.pdf'
full_pdf = BASE / 'Odyssey_Archival_Monograph_Full_With_Validation.pdf'

# ---------- data loading ----------
def mean_metrics(per_seed):
    keys = sorted({k for row in per_seed for k in row.keys()})
    out = {}
    for k in keys:
        vals = [row[k] for row in per_seed if isinstance(row.get(k), (int, float))]
        if vals:
            out[k] = statistics.mean(vals)
    return out


def load_models(path):
    data = json.load(open(path))
    out = {}
    for seq, seqd in data.items():
        models = seqd.get('models', seqd)
        out[seq] = {}
        for name, md in models.items():
            per_seed = md.get('per_seed', [])
            if per_seed:
                out[seq][name] = mean_metrics(per_seed)
    return out

v3 = load_models(BASE / 'qlaf_ablation/v3_quick/results_partial.json')
v5 = load_models(BASE / 'qlaf_ablation/v5_secondrank/results.json')
v6 = load_models(BASE / 'qlaf_ablation/v6_sparse/results_partial.json')
v8 = load_models(BASE / 'qlaf_ablation/v8_longhead/results.json')
v9 = load_models(BASE / 'qlaf_ablation/v9_confirm/results_seedexpansion.json')

# ---------- formatting ----------
def fmt_num(x, kind='float'):
    if x is None:
        return '-'
    if kind == 'int':
        return f"{x:,.0f}"
    if kind == 'acc':
        return f"{x:.4f}"
    if kind == 'lat':
        return f"{x:.2f}"
    if kind == 'mem':
        return f"{x:.2f}"
    return f"{x:.4f}"


def percent_vs(val, base, lower_better=False):
    if base == 0:
        return 'n/a'
    pct = (val - base) / base * 100.0
    if lower_better:
        pct = -pct
    sign = '+' if pct >= 0 else ''
    return f"{sign}{pct:.2f}%"


def prettify_model(name):
    mapping = {
        'qlaf_global_order': 'QLAF global+order',
        'qlaf_global_order_pyramid': 'QLAF global+order+pyramid',
        'qlaf_global_order_second': 'QLAF global+order+2nd',
        'qlaf_global_order_pyramid_second': 'QLAF global+order+pyramid+2nd',
        'transformer_matched': 'Transformer matched',
        'qlaf_go_second_r24': 'QLAF GO 2nd r24',
        'qlaf_go_second_r48': 'QLAF GO 2nd r48',
        'qlaf_go_second_r96': 'QLAF GO 2nd r96',
        'qlaf_go_second_r48_dense': 'QLAF GO r48 dense',
        'qlaf_go_second_r48_top1': 'QLAF GO r48 top-1',
        'qlaf_go_second_r48_top2': 'QLAF GO r48 top-2',
        'qlaf_go_second_r48_top4': 'QLAF GO r48 top-4',
        'qlaf_adaptive_margin_base': 'QLAF adaptive-margin base',
        'qlaf_adaptive_margin_longhead': 'QLAF adaptive-margin longhead',
        'qlaf_dense_longhead': 'QLAF dense longhead',
        'qlaf_entropy_longhead': 'QLAF entropy longhead',
    }
    return mapping.get(name, name.replace('_',' '))

# ---------- document styles ----------
styles = getSampleStyleSheet()
styles.add(ParagraphStyle('TitleBig', parent=styles['Title'], fontName='Helvetica-Bold', fontSize=24, leading=28,
                          textColor=colors.HexColor('#17365D'), alignment=TA_CENTER, spaceAfter=12))
styles.add(ParagraphStyle('SubTitle', parent=styles['Normal'], fontName='Helvetica', fontSize=11, leading=14,
                          textColor=colors.HexColor('#506070'), alignment=TA_CENTER, spaceAfter=12))
styles.add(ParagraphStyle('H1', parent=styles['Heading1'], fontName='Helvetica-Bold', fontSize=18, leading=22,
                          textColor=colors.HexColor('#17365D'), spaceBefore=6, spaceAfter=8))
styles.add(ParagraphStyle('H2', parent=styles['Heading2'], fontName='Helvetica-Bold', fontSize=12.5, leading=15,
                          textColor=colors.HexColor('#214E7A'), spaceBefore=8, spaceAfter=5))
styles.add(ParagraphStyle('Body', parent=styles['BodyText'], fontName='Helvetica', fontSize=9.3, leading=12,
                          textColor=colors.black, spaceAfter=4))
styles.add(ParagraphStyle('Small', parent=styles['BodyText'], fontName='Helvetica', fontSize=8.2, leading=10.5,
                          textColor=colors.HexColor('#444444'), spaceAfter=3))
styles.add(ParagraphStyle('Note', parent=styles['BodyText'], fontName='Helvetica-Oblique', fontSize=8.2, leading=10.5,
                          textColor=colors.HexColor('#555555'), spaceAfter=4))

PAGE_SIZE = landscape(letter)
PAGE_W, PAGE_H = PAGE_SIZE
LEFT = RIGHT = 0.45*inch
TOP = 0.45*inch
BOTTOM = 0.45*inch
DOC_W = PAGE_W - LEFT - RIGHT


def build_table(headers, rows, col_widths=None, font_size=8.1, header_bg='#DCE6F1'):
    if col_widths is None:
        col_widths = [DOC_W/len(headers)]*len(headers)
    data = [headers] + rows
    t = Table(data, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor(header_bg)),
        ('TEXTCOLOR', (0,0), (-1,0), colors.HexColor('#17365D')),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,-1), font_size),
        ('LEADING', (0,0), (-1,-1), font_size+2.2),
        ('BACKGROUND', (0,1), (-1,-1), colors.white),
        ('GRID', (0,0), (-1,-1), 0.35, colors.HexColor('#B7C4D3')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#F7FAFC')]),
        ('ALIGN', (1,1), (-1,-1), 'CENTER'),
        ('ALIGN', (0,0), (0,-1), 'LEFT'),
    ]))
    return t


def section_header(text):
    return Paragraph(text, styles['H1'])


def subsection(text):
    return Paragraph(text, styles['H2'])


def para(text, style='Body'):
    return Paragraph(text, styles[style])


def metric_rows(models, include_mem=True):
    rows = []
    for name, m in models.items():
        row = [prettify_model(name), fmt_num(m.get('val_loss')), fmt_num(m.get('accuracy'),'acc'), fmt_num(m.get('train_tok_s'),'int'), fmt_num(m.get('infer_tok_s'),'int'), fmt_num(m.get('latency_ms'),'lat')]
        if include_mem:
            row.append(fmt_num(m.get('rss_delta_mb'),'mem'))
        rows.append(row)
    return rows


def pct_rows(models, baseline_name, include_mem=True):
    base = models[baseline_name]
    rows = []
    for name, m in models.items():
        if name == baseline_name:
            continue
        row = [prettify_model(name),
               percent_vs(m['val_loss'], base['val_loss'], lower_better=True),
               percent_vs(m['accuracy'], base['accuracy'], lower_better=False),
               percent_vs(m['train_tok_s'], base['train_tok_s'], lower_better=False),
               percent_vs(m['infer_tok_s'], base['infer_tok_s'], lower_better=False),
               percent_vs(m['latency_ms'], base['latency_ms'], lower_better=True)]
        if include_mem and 'rss_delta_mb' in m and 'rss_delta_mb' in base:
            row.append(percent_vs(m['rss_delta_mb'], base['rss_delta_mb'], lower_better=True))
        rows.append(row)
    return rows


def add_stage(story, stage_name, source_note, dataset, stage_data, commentary_lines, include_pct=True):
    story.append(section_header(stage_name))
    story.append(para(source_note, 'Small'))
    story.append(para(commentary_lines, 'Body'))
    for seq in ['seq128','seq512','seq1024']:
        if seq not in stage_data:
            continue
        story.append(subsection(f"{seq.replace('seq','Sequence length ')}"))
        models = stage_data[seq]
        include_mem = any('rss_delta_mb' in m for m in models.values())
        headers = ['Model','Val loss','Accuracy','Train tok/s','Infer tok/s','Latency ms'] + (['RSS delta MB'] if include_mem else [])
        col_widths = [2.4*inch, 0.9*inch, 0.82*inch, 1.1*inch, 1.1*inch, 0.95*inch] + ([0.95*inch] if include_mem else [])
        story.append(build_table(headers, metric_rows(models, include_mem), col_widths, font_size=7.9))
        story.append(Spacer(1,8))
        if include_pct and 'transformer_matched' in models:
            pct_headers = ['Model','Loss vs tx','Acc vs tx','Train vs tx','Infer vs tx','Latency vs tx'] + (['RSS vs tx'] if include_mem else [])
            story.append(build_table(pct_headers, pct_rows(models, 'transformer_matched', include_mem), col_widths, font_size=7.7, header_bg='#E9EFF5'))
            story.append(Spacer(1,10))
        story.append(para(f"Table notes: lower is better for loss, latency, and RSS delta; higher is better for accuracy and throughput. Source family: {dataset}.", 'Note'))
        story.append(Spacer(1,6))
    story.append(PageBreak())

# ---------- build supplement ----------
story = []
story.append(Spacer(1, 0.4*inch))
story.append(Paragraph('Odyssey / QLAF Archival Monograph', styles['TitleBig']))
story.append(Paragraph('Supplementary Validation Volume', styles['TitleBig']))
story.append(Paragraph('Integrated CPU benchmark progression, routing studies, long-head validation, and frontier confirmation appended to the archival monograph PDF.', styles['SubTitle']))
story.append(Spacer(1, 0.12*inch))
intro_box = build_table(
    ['Scope'],
    [[Paragraph(
        'This appended volume consolidates the preserved post-monograph CPU benchmark program from the workspace. '
        'It packages the completed ablation ladder in order: (i) early global/order/second-order diagnosis, '
        '(ii) second-order rank sweep, (iii) sparse-routing sweep, (iv) long-head interaction sweep, and '
        '(v) longer matched-budget confirmation with seed expansion. The original 434-page archival monograph is '
        'left intact and this volume is appended after it as an explicit validation layer rather than silently rewriting the recovered book.', styles['Body'])]],
    [DOC_W], font_size=9.2)
story.append(intro_box)
story.append(Spacer(1, 0.15*inch))
story.append(para('Method discipline. All tables below are derived from preserved JSON outputs in /mnt/data/qlaf_ablation. Comparisons were matched within each sweep: identical dataset family, optimizer family, sequence ladder, and matched-transformer search logic for the relevant target parameter count. Where a stage used a reduced budget or partial preservation, that is stated explicitly in the stage heading.', 'Body'))
story.append(Spacer(1,0.1*inch))
summary_headers=['Stage','What changed','Main finding']
summary_rows=[
    ['v3 quick','global/order base, pyramid local bank, second-order add-ons','Second-order helped more than pyramid locality; transformer still led on loss in early quick passes.'],
    ['v5 rank sweep','second-order rank r24/r48/r96','More interaction capacity helped up to a point; r96 dominated at 128, r48 became the medium/long-context balance point.'],
    ['v6 sparse routing','dense vs top-1/top-2/top-4 on fixed r48 base','Routing optimum was regime-dependent: top-2 best at 128, dense best at 512, objective split at 1024.'],
    ['v8 long-head','modest long-context interaction branch','Long-head became the strongest quality lever after routing; 512 quality improved materially and 1024 moved out of pure collapse.'],
    ['v9 confirmation','longer matched budget + seed expansion on narrowed frontier','512 adaptive-margin-longhead was confirmed as a clean win; 1024 dense-longhead preserved large operational and accuracy gains while transformer kept the loss edge.'],
]
story.append(build_table(summary_headers, summary_rows, [1.0*inch,2.1*inch, DOC_W-3.1*inch], font_size=8.3))
story.append(PageBreak())

story.append(section_header('Validation methodology and reading guide'))
story.append(para('This volume is intentionally transparent. It does not claim a universal architecture theorem from the experiments. It records what the preserved CPU runs establish under the matched comparison protocols used in the workspace. The interpretation should therefore be read as a regime map: which QLAF variant wins under which objective (loss, accuracy, training throughput, inference throughput, latency, and memory delta) at each sequence length.', 'Body'))
story.append(para('The progression is important. Early experiments changed the state family before touching routing. Only after the richer dictionary, order-aware summaries, and second-order correction head were explored was sparse routing revisited. The long-head branch was added only after the earlier local-bank redesigns, fixed sparse sweeps, and adaptive routing sweeps had already exposed the remaining long-context quality gap.', 'Body'))
story.append(para('Page structure. Each stage below includes raw mean tables for sequence lengths 128, 512, and 1024 wherever preserved, plus percent comparisons against the matched transformer when that comparator was part of the saved stage. Raw values are authoritative; percent rows are included only as a convenience for reading the direction and magnitude of the deltas.', 'Body'))
story.append(PageBreak())

add_stage(
    story,
    'Stage v3 - early global/order diagnosis',
    'Source: /mnt/data/qlaf_ablation/v3_quick/results_partial.json. These were reduced-budget early passes used to diagnose whether the local pyramid or the second-order correction was the more promising next direction.',
    'byte-level local language-model setup used in the CPU ablation harness',
    v3,
    'The v3 stage established that the first useful lift was coming from richer interaction structure rather than from the local pyramid alone. In these quick passes the matched transformer still had the stronger loss profile, but the QLAF variants already showed a much stronger operational scaling profile at 512 and 1024. This stage narrowed the next architectural lever to the interaction head.'
)

add_stage(
    story,
    'Stage v5 - second-order rank sweep',
    'Source: /mnt/data/qlaf_ablation/v5_secondrank/results.json. Fixed base: global + order with second-order correction, sweeping correction rank r24 / r48 / r96.',
    'same matched CPU protocol family',
    v5,
    'The v5 sweep isolated the interaction-capacity question cleanly. More second-order capacity helped monotonically at short context, with r96 crossing the matched transformer at 128. At 512 and 1024, however, the best loss/quality balance came from r48 rather than r96, indicating that the useful interaction enrichment was real but not monotone with rank. This established r48 as the medium/long-context operating point used for later routing studies.'
)

add_stage(
    story,
    'Stage v6 - sparse-routing sweep on the fixed r48 base',
    'Source: /mnt/data/qlaf_ablation/v6_sparse/results_partial.json. Fixed base: global + order + second-order (r48). Routing variants: dense, top-1, top-2, top-4.',
    'same matched CPU protocol family',
    v6,
    'The v6 stage resolved the routing question: there was no universal top-k winner. Top-2 was strongest at 128, dense was the best overall point at 512, and 1024 split by objective - top-1 for loss, dense for training/accuracy, and top-2/top-4 for serving speed and latency. This is what motivated the later adaptive-routing experiments and, after that, the move to a long-head interaction branch.'
)

add_stage(
    story,
    'Stage v8 - long-head interaction branch',
    'Source: /mnt/data/qlaf_ablation/v8_longhead/results.json. Compared adaptive-margin base and long-head variants against the matched transformer across the full ladder.',
    'same matched CPU protocol family',
    v8,
    'The long-head branch became the strongest remaining quality lever after the routing studies. At 128 it improved the frontier cleanly. At 512 it improved the quality frontier materially but paid a noticeable serving-speed tax. At 1024 the dense-longhead variant became the strongest QLAF point by a wide margin relative to earlier stages, moving the regime from a crude quality-collapse reading toward a mixed regime with real long-context operational and accuracy strength.'
)

add_stage(
    story,
    'Stage v9 - longer matched-budget confirmation with seed expansion',
    'Source: /mnt/data/qlaf_ablation/v9_confirm/results_seedexpansion.json. This is the narrowed confirmation layer only: qlaf_adaptive_margin_longhead vs transformer at 512, and qlaf_dense_longhead vs transformer at 1024, aggregated over three saved seeds each.',
    'same matched CPU protocol family, deeper confirmation budget',
    v9,
    'This confirmation layer is the most important evidentiary table set in the appendix. At 512, adaptive-margin-longhead was no longer merely competitive; under the longer matched budget it beat the matched transformer on all recorded metrics, including loss, accuracy, throughput, latency, and memory delta. At 1024, dense-longhead did not close the transformer loss gap, but it preserved a substantial edge in accuracy, train throughput, inference throughput, and latency. The three-seed aggregate also clarified that memory at 1024 was mixed rather than a clean QLAF win.'
)

# final synthesis page
story.append(section_header('Final confirmed regime map'))
story.append(para('The completed preserved evidence supports a narrower and more precise claim than a blanket architecture victory statement. The best validated QLAF point at sequence length 512 is the adaptive-margin long-head model. The best validated QLAF point at sequence length 1024 is the dense long-head model. The matched transformer retains the 1024 loss edge, but not the 512 loss edge under the longer matched budget, and not the 1024 accuracy or operational edge.', 'Body'))

final_rows = [
    ['128', 'QLAF dense longhead (loss) / QLAF adaptive-margin longhead (accuracy)', 'long-head branch clearly improves the frontier; transformer no longer leads this regime'],
    ['512', 'QLAF adaptive-margin longhead', 'confirmed win on loss, accuracy, training throughput, inference throughput, latency, and RSS delta under longer matched budget'],
    ['1024', 'QLAF dense longhead (accuracy and operations), transformer matched (loss)', 'mixed regime: transformer keeps loss; QLAF keeps accuracy plus large operational edge'],
]
story.append(build_table(['Seq length','Best validated point','Reading'], final_rows,
                         [0.9*inch, 3.5*inch, DOC_W-4.4*inch], font_size=8.5))
story.append(Spacer(1,10))
story.append(para('Architectural reading. The preserved run ladder supports the ordering implied by the project theory: richer state family first, then order-aware summaries, then second-order interaction enrichment, then routing. Local-bank enrichment was not the main unlock. Medium-rank second-order interaction was. Routing optimum was context- and objective-dependent rather than universal. The long-head branch became the strongest remaining quality lever after those earlier stages had saturated.', 'Body'))
story.append(para('Packaging note. This PDF appends the validation volume after the recovered archival monograph rather than rewriting the original pages. The archival theorem body therefore remains intact and separately readable, while the validation layer is attached in explicit chronological order as a post-monograph supplement.', 'Body'))

# build supplement pdf
SimpleDocTemplate(str(supp_pdf), pagesize=PAGE_SIZE, leftMargin=LEFT, rightMargin=RIGHT, topMargin=TOP, bottomMargin=BOTTOM,
                  title='Odyssey Supplementary Validation Volume', author='OpenAI').build(story)

# merge
writer = PdfWriter()
for path in [orig_pdf, supp_pdf]:
    reader = PdfReader(str(path))
    for p in reader.pages:
        writer.add_page(p)
with open(full_pdf, 'wb') as f:
    writer.write(f)
print('wrote', supp_pdf, full_pdf)
print('pages original', len(PdfReader(str(orig_pdf)).pages), 'supp', len(PdfReader(str(supp_pdf)).pages), 'full', len(PdfReader(str(full_pdf)).pages))
