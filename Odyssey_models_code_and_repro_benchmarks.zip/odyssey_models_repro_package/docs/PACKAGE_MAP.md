# Package Map

## Code lineage
- models_v3.py: multibank / pyramid baseline + shared helper classes + matched transformer baseline.
- models_v6.py: fixed sparse-routing variants.
- models_v7.py: adaptive-routing variants.
- models_v8.py: long-head interaction variants.

## Result lineage
- qlaf_ablation_self: first reduced-budget CPU ablation summary.
- v3_quick: pyramid/local follow-up.
- v5_secondrank: second-order rank sweep that identified the medium-rank sweet spot.
- v6_sparse: fixed top-k routing sweep.
- v7_adaptive: adaptive-routing sweep.
- v8_longhead: long-head interaction sweep.
- v9_confirm: longer matched-budget frontier confirmation and seed-expansion.
