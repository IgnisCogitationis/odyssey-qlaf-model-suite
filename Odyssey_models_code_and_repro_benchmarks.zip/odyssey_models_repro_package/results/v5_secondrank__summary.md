# v5 second-order rank sweep

## seq128

| Model | Val loss | Acc | Train tok/s | Infer tok/s | Latency ms | Params |
|---|---:|---:|---:|---:|---:|---:|
| qlaf_go_second_r24 | 3.5908 | 0.2245 | 10548 | 20841 | 6.14 | 1551088 |
| qlaf_go_second_r48 | 3.4088 | 0.2311 | 10844 | 20720 | 6.19 | 1578736 |
| qlaf_go_second_r96 | 2.9938 | 0.2459 | 10433 | 20647 | 6.20 | 1634032 |
| transformer_matched | 3.0707 | 0.1938 | 7573 | 14603 | 8.80 | 1614080 |

| Model | Loss vs transformer | Acc vs transformer | Train tok/s vs transformer | Infer tok/s vs transformer | Latency vs transformer |
|---|---:|---:|---:|---:|---:|
| qlaf_go_second_r24 | +16.94% | +15.87% | +39.29% | +42.71% | -30.19% |
| qlaf_go_second_r48 | +11.01% | +19.24% | +43.19% | +41.89% | -29.73% |
| qlaf_go_second_r96 | -2.50% | +26.92% | +37.76% | +41.39% | -29.51% |
| transformer_matched | baseline | baseline | baseline | baseline | baseline |

## seq512

| Model | Val loss | Acc | Train tok/s | Infer tok/s | Latency ms | Params |
|---|---:|---:|---:|---:|---:|---:|
| qlaf_go_second_r24 | 9.3963 | 0.1178 | 11344 | 40572 | 12.64 | 1551088 |
| qlaf_go_second_r48 | 9.3448 | 0.1486 | 11020 | 38024 | 13.47 | 1578736 |
| qlaf_go_second_r96 | 11.5997 | 0.0661 | 9550 | 37912 | 13.51 | 1634032 |
| transformer_matched | 8.0815 | 0.0534 | 5588 | 9953 | 51.53 | 1614080 |

| Model | Loss vs transformer | Acc vs transformer | Train tok/s vs transformer | Infer tok/s vs transformer | Latency vs transformer |
|---|---:|---:|---:|---:|---:|
| qlaf_go_second_r24 | +16.27% | +120.31% | +102.99% | +307.64% | -75.46% |
| qlaf_go_second_r48 | +15.63% | +178.09% | +97.19% | +282.04% | -73.87% |
| qlaf_go_second_r96 | +43.53% | +23.68% | +70.89% | +280.91% | -73.79% |
| transformer_matched | baseline | baseline | baseline | baseline | baseline |

## seq1024

| Model | Val loss | Acc | Train tok/s | Infer tok/s | Latency ms | Params |
|---|---:|---:|---:|---:|---:|---:|
| qlaf_go_second_r24 | 46.7296 | 0.0393 | 7760 | 38200 | 26.81 | 1551088 |
| qlaf_go_second_r48 | 41.3836 | 0.0146 | 7536 | 44394 | 23.07 | 1578736 |
| qlaf_go_second_r96 | 48.0517 | 0.0146 | 7907 | 35031 | 29.23 | 1634032 |
| transformer_matched | 19.3870 | 0.0288 | 4068 | 3423 | 299.13 | 1614080 |

| Model | Loss vs transformer | Acc vs transformer | Train tok/s vs transformer | Infer tok/s vs transformer | Latency vs transformer |
|---|---:|---:|---:|---:|---:|
| qlaf_go_second_r24 | +141.04% | +36.52% | +90.73% | +1015.91% | -91.04% |
| qlaf_go_second_r48 | +113.46% | -49.26% | +85.24% | +1196.83% | -92.29% |
| qlaf_go_second_r96 | +147.86% | -49.26% | +94.35% | +923.32% | -90.23% |
| transformer_matched | baseline | baseline | baseline | baseline | baseline |
