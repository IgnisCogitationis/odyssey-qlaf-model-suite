## seq128
- qlaf_adaptive_margin_base: loss=3.4898, acc=0.2271, train_tok_s=5896, infer_tok_s=9906, latency_ms=13.54, rss_delta_mb=51.32
- qlaf_adaptive_margin_longhead: loss=3.2001, acc=0.2461, train_tok_s=6006, infer_tok_s=12153, latency_ms=10.53, rss_delta_mb=54.81
- qlaf_dense_longhead: loss=3.1760, acc=0.2243, train_tok_s=5655, infer_tok_s=13286, latency_ms=9.66, rss_delta_mb=56.08
- qlaf_entropy_longhead: loss=4.0808, acc=0.1752, train_tok_s=5092, infer_tok_s=10248, latency_ms=12.66, rss_delta_mb=104.70
- transformer_matched: loss=3.7735, acc=0.1196, train_tok_s=4483, infer_tok_s=10309, latency_ms=12.42, rss_delta_mb=106.50

## seq512
- qlaf_adaptive_margin_base: loss=8.9799, acc=0.1259, train_tok_s=7789, infer_tok_s=27450, latency_ms=18.67, rss_delta_mb=84.70
- qlaf_adaptive_margin_longhead: loss=7.7674, acc=0.1503, train_tok_s=5851, infer_tok_s=15714, latency_ms=32.58, rss_delta_mb=93.75
- qlaf_dense_longhead: loss=12.6963, acc=0.0426, train_tok_s=5465, infer_tok_s=26208, latency_ms=19.55, rss_delta_mb=176.44
- qlaf_entropy_longhead: loss=13.9123, acc=0.0527, train_tok_s=6303, infer_tok_s=20123, latency_ms=29.64, rss_delta_mb=110.75
- transformer_matched: loss=7.8727, acc=0.0715, train_tok_s=3729, infer_tok_s=5841, latency_ms=91.60, rss_delta_mb=179.33

## seq1024
- qlaf_adaptive_margin_base: loss=44.6614, acc=0.0297, train_tok_s=3748, infer_tok_s=17021, latency_ms=60.16, rss_delta_mb=163.47
- qlaf_adaptive_margin_longhead: loss=44.9123, acc=0.0146, train_tok_s=4955, infer_tok_s=25903, latency_ms=39.53, rss_delta_mb=49.46
- qlaf_dense_longhead: loss=38.8487, acc=0.0555, train_tok_s=3997, infer_tok_s=31973, latency_ms=32.03, rss_delta_mb=22.02
- qlaf_entropy_longhead: loss=42.4996, acc=0.0146, train_tok_s=3480, infer_tok_s=18030, latency_ms=56.79, rss_delta_mb=188.48
- transformer_matched: loss=21.1024, acc=0.0211, train_tok_s=2328, infer_tok_s=1852, latency_ms=552.81, rss_delta_mb=210.77
