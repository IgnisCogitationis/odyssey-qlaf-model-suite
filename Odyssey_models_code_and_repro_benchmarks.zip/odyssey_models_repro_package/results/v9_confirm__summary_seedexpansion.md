# v9 Seed Expansion Confirmation

## seq512

### qlaf_adaptive_margin_longhead

| metric | mean | sd | 95% CI half-width | n |
|---|---:|---:|---:|---:|
| val_loss | 3.3077 | 1.0575 | 2.6271 | 3 |
| accuracy | 0.2212 | 0.0672 | 0.1670 | 3 |
| train_tok_s | 10152.0655 | 560.3605 | 1392.1251 | 3 |
| infer_tok_s | 32601.6228 | 2032.1071 | 5048.4413 | 3 |
| latency_ms | 15.7448 | 0.9643 | 2.3957 | 3 |
| rss_delta_mb | 131.3711 | 99.0603 | 246.0992 | 3 |

### transformer_matched

| metric | mean | sd | 95% CI half-width | n |
|---|---:|---:|---:|---:|
| val_loss | 3.7824 | 0.1757 | 0.4366 | 3 |
| accuracy | 0.0976 | 0.0170 | 0.0422 | 3 |
| train_tok_s | 5704.5399 | 67.0181 | 166.4957 | 3 |
| infer_tok_s | 10160.1912 | 446.5056 | 1109.2709 | 3 |
| latency_ms | 50.4590 | 2.2628 | 5.6215 | 3 |
| rss_delta_mb | 210.7812 | 13.8810 | 34.4851 | 3 |

### Pairwise mean comparison vs transformer

| metric | qlaf mean | transformer mean | qlaf vs transformer |
|---|---:|---:|---:|
| val_loss | 3.3077 | 3.7824 | -12.55% |
| accuracy | 0.2212 | 0.0976 | +126.57% |
| train_tok_s | 10152.0655 | 5704.5399 | +77.96% |
| infer_tok_s | 32601.6228 | 10160.1912 | +220.88% |
| latency_ms | 15.7448 | 50.4590 | -68.80% |
| rss_delta_mb | 131.3711 | 210.7812 | -37.67% |

## seq1024

### qlaf_dense_longhead

| metric | mean | sd | 95% CI half-width | n |
|---|---:|---:|---:|---:|
| val_loss | 15.7860 | 2.3790 | 5.9103 | 3 |
| accuracy | 0.0462 | 0.0205 | 0.0509 | 3 |
| train_tok_s | 8580.1058 | 374.8433 | 931.2375 | 3 |
| infer_tok_s | 38395.9054 | 839.2626 | 2085.0122 | 3 |
| latency_ms | 26.6781 | 0.5889 | 1.4630 | 3 |
| rss_delta_mb | 184.3294 | 2.7119 | 6.7373 | 3 |

### transformer_matched

| metric | mean | sd | 95% CI half-width | n |
|---|---:|---:|---:|---:|
| val_loss | 9.0274 | 0.6737 | 1.6736 | 3 |
| accuracy | 0.0408 | 0.0139 | 0.0346 | 3 |
| train_tok_s | 4119.3872 | 76.3641 | 189.7142 | 3 |
| infer_tok_s | 5160.4670 | 1434.0140 | 3562.5759 | 3 |
| latency_ms | 211.1973 | 69.0403 | 171.5194 | 3 |
| rss_delta_mb | 112.1406 | 94.4107 | 234.5481 | 3 |

### Pairwise mean comparison vs transformer

| metric | qlaf mean | transformer mean | qlaf vs transformer |
|---|---:|---:|---:|
| val_loss | 15.7860 | 9.0274 | +74.87% |
| accuracy | 0.0462 | 0.0408 | +13.03% |
| train_tok_s | 8580.1058 | 4119.3872 | +108.29% |
| infer_tok_s | 38395.9054 | 5160.4670 | +644.04% |
| latency_ms | 26.6781 | 211.1973 | -87.37% |
| rss_delta_mb | 184.3294 | 112.1406 | +64.37% |
