# v3 quick pyramid + second-order follow-up

## seq128

| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | Params |
|---|---:|---:|---:|---:|---:|---:|
| qlaf_global_order | 42.9474 | 0.0440 | 7019 | 18994 | 6.74 | 1523440 |
| qlaf_global_order_pyramid | 41.8199 | 0.0404 | 5941 | 14741 | 8.68 | 1531288 |
| qlaf_global_order_second | 41.4275 | 0.0436 | 7113 | 20830 | 6.15 | 1551088 |
| qlaf_global_order_pyramid_second | 39.9443 | 0.0554 | 5864 | 15097 | 8.48 | 1558936 |
| transformer_matched | 19.8671 | 0.0266 | 6410 | 14671 | 8.75 | 1483136 |

| Model | Loss vs transformer | Acc vs transformer | Train tok/s vs transformer | Infer tok/s vs transformer | Latency vs transformer |
|---|---:|---:|---:|---:|---:|
| qlaf_global_order | +116.17% | +65.43% | +9.50% | +29.47% | -22.91% |
| qlaf_global_order_pyramid | +110.50% | +51.85% | -7.32% | +0.48% | -0.73% |
| qlaf_global_order_second | +108.52% | +64.20% | +10.97% | +41.98% | -29.75% |
| qlaf_global_order_pyramid_second | +101.06% | +108.64% | -8.52% | +2.91% | -3.05% |
| transformer_matched | baseline | baseline | baseline | baseline | baseline |

## seq512

| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | Params |
|---|---:|---:|---:|---:|---:|---:|
| qlaf_global_order | 77.7565 | 0.0152 | 7718 | 41995 | 12.26 | 1523440 |
| qlaf_global_order_pyramid | 75.7198 | 0.0152 | 5819 | 27272 | 18.78 | 1531288 |
| qlaf_global_order_second | 79.2905 | 0.0152 | 7825 | 42303 | 12.13 | 1551088 |
| qlaf_global_order_pyramid_second | 74.3837 | 0.0152 | 5713 | 26636 | 19.26 | 1558936 |
| transformer_matched | 35.3121 | 0.0236 | 4606 | 9445 | 54.24 | 1483136 |

| Model | Loss vs transformer | Acc vs transformer | Train tok/s vs transformer | Infer tok/s vs transformer | Latency vs transformer |
|---|---:|---:|---:|---:|---:|
| qlaf_global_order | +120.20% | -35.86% | +67.57% | +344.62% | -77.40% |
| qlaf_global_order_pyramid | +114.43% | -35.86% | +26.33% | +188.74% | -65.38% |
| qlaf_global_order_second | +124.54% | -35.86% | +69.89% | +347.88% | -77.65% |
| qlaf_global_order_pyramid_second | +110.65% | -35.86% | +24.03% | +182.01% | -64.49% |
| transformer_matched | baseline | baseline | baseline | baseline | baseline |

## seq1024

| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | Params |
|---|---:|---:|---:|---:|---:|---:|
| qlaf_global_order | 109.4541 | 0.0150 | 9934 | 47378 | 21.61 | 1523440 |
| qlaf_global_order_pyramid | 110.5273 | 0.0150 | 5943 | 29189 | 35.08 | 1531288 |
| qlaf_global_order_second | 107.3729 | 0.0150 | 9007 | 46447 | 22.05 | 1551088 |
| qlaf_global_order_pyramid_second | 113.1668 | 0.0150 | 6015 | 28210 | 36.30 | 1558936 |
| transformer_matched | 73.2229 | 0.0150 | 3012 | 5486 | 186.65 | 1483136 |

| Model | Loss vs transformer | Acc vs transformer | Train tok/s vs transformer | Infer tok/s vs transformer | Latency vs transformer |
|---|---:|---:|---:|---:|---:|
| qlaf_global_order | +49.48% | +0.00% | +229.80% | +763.59% | -88.42% |
| qlaf_global_order_pyramid | +50.95% | +0.00% | +97.31% | +432.04% | -81.20% |
| qlaf_global_order_second | +46.64% | +0.00% | +199.02% | +746.62% | -88.19% |
| qlaf_global_order_pyramid_second | +54.55% | +0.00% | +99.70% | +414.21% | -80.55% |
| transformer_matched | baseline | baseline | baseline | baseline | baseline |
