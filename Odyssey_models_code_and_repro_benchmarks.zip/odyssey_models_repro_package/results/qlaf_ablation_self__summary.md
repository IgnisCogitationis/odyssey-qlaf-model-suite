# Controlled ablation results

## seq128

| Model | Val loss | Acc | Train tok/s | Infer tok/s | Latency ms | Params |
|---|---:|---:|---:|---:|---:|---:|
| qlaf_v1 | 58.5185 | 0.0201 | 6736 | 16311 | 7.85 | 392016 |
| qlaf_no_orderbank | 59.1790 | 0.0201 | 7324 | 17014 | 7.53 | 369592 |
| qlaf_no_localbank | 57.3374 | 0.0201 | 11027 | 43954 | 2.91 | 371208 |
| qlaf_global_plus_order | 55.9705 | 0.0201 | 12454 | 51368 | 2.49 | 333376 |
| transformer_matched | 30.6240 | 0.0167 | 18861 | 29437 | 4.36 | 396640 |

| Model | Loss vs transformer | Acc vs transformer | Train tok/s vs transformer | Infer tok/s vs transformer | Latency vs transformer |
|---|---:|---:|---:|---:|---:|
| qlaf_v1 | +91.09% | +20.00% | -64.28% | -44.59% | +79.90% |
| qlaf_no_orderbank | +93.24% | +20.00% | -61.17% | -42.20% | +72.58% |
| qlaf_no_localbank | +87.23% | +20.00% | -41.54% | +49.31% | -33.26% |
| qlaf_global_plus_order | +82.77% | +20.00% | -33.97% | +74.50% | -42.89% |
| transformer_matched | baseline | baseline | baseline | baseline | baseline |

## seq512

| Model | Val loss | Acc | Train tok/s | Infer tok/s | Latency ms | Params |
|---|---:|---:|---:|---:|---:|---:|
| qlaf_v1 | 81.3950 | 0.0176 | 2365 | 8316 | 61.58 | 392016 |
| qlaf_no_orderbank | 77.6317 | 0.0176 | 2373 | 10785 | 47.47 | 369592 |
| qlaf_no_localbank | 72.2685 | 0.0176 | 9443 | 93830 | 5.46 | 371208 |
| qlaf_global_plus_order | 79.3875 | 0.0176 | 9998 | 107988 | 4.74 | 333376 |
| transformer_matched | 49.8571 | 0.0178 | 10486 | 16448 | 31.13 | 396640 |

| Model | Loss vs transformer | Acc vs transformer | Train tok/s vs transformer | Infer tok/s vs transformer | Latency vs transformer |
|---|---:|---:|---:|---:|---:|
| qlaf_v1 | +63.26% | -1.10% | -77.45% | -49.44% | +97.78% |
| qlaf_no_orderbank | +55.71% | -1.10% | -77.37% | -34.43% | +52.48% |
| qlaf_no_localbank | +44.95% | -1.10% | -9.95% | +470.47% | -82.47% |
| qlaf_global_plus_order | +59.23% | -1.10% | -4.65% | +556.54% | -84.77% |
| transformer_matched | baseline | baseline | baseline | baseline | baseline |
