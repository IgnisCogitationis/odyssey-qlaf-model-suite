# Odyssey / QLAF Models Code + Reproducible Benchmarks

This package collects the **actual runnable code and saved benchmark outputs** produced in this workspace.
It is organized so the saved results can be inspected directly, and the benchmark sweeps can be rerun from code.

## What is included

### Core model code
- `code/models_v3.py` — multibank / pyramid QLAF baseline plus matched transformer implementation used by later runners.
- `code/models_v6.py` — sparse-routing QLAF (`dense`, `top1`, `top2`, `top4`) on the fixed global+order+second-order base.
- `code/models_v7.py` — adaptive-routing QLAF (`dense`, `top1`, `top2`, `adaptive_margin`, `adaptive_entropy`).
- `code/models_v8.py` — long-head interaction QLAF used for the strongest medium/long-context frontier models.

### Benchmark runners
- `code/run_ablation_v3.py` — earlier multibank / local-pyramid ablations.
- `code/run_ablation_v5.py` + `code/run_ablation_v5_resume.py` — second-order rank sweep.
- `code/run_ablation_v6.py` — fixed sparse-routing sweep.
- `code/run_ablation_v7.py` — adaptive-routing sweep.
- `code/run_ablation_v8.py` — long-head sweep.
- `code/run_ablation_v9.py` — longer matched-budget confirmation pass on the narrowed frontier.

### Saved benchmark outputs
The `results/` directory contains the JSON/markdown outputs that were actually saved during the runs in this workspace.
These include early ablations, the completed v5/v7/v8/v9 frontier results, and seed-expansion confirmation summaries.

### PDFs
- `pdfs/54.pdf` — uploaded archival monograph base PDF.
- `pdfs/validation_volume_appendix.pdf` — added validation appendix.
- `pdfs/Odyssey_Archival_Monograph_Full_With_Validation.pdf` — merged archival monograph with validation.

## Benchmark setup used in the included runners

The included runners use a **single-threaded CPU** benchmark setup with:
- PyTorch CPU execution
- a repeated byte-level synthetic corpus built from project-specific benchmark text inside each runner
- matched optimizer / token budget / evaluation structure within each sweep
- a matched transformer baseline selected by parameter count logic implemented in the runner/model stack

This package is therefore **fully reproducible for the benchmark family actually run here**.
It does **not** claim that the saved numbers are from WikiText/OpenWeb or from GPU runs unless a specific runner is changed to do that.

## Reproducing the saved benchmark family

From the package root:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cd code
```

Then run the specific sweeps:

### v5 second-order rank sweep
```bash
python run_ablation_v5.py
# if interrupted
python run_ablation_v5_resume.py
```

### v6 fixed sparse-routing sweep
```bash
python run_ablation_v6.py
```

### v7 adaptive-routing sweep
```bash
python run_ablation_v7.py
```

### v8 long-head sweep
```bash
python run_ablation_v8.py
```

### v9 longer-budget frontier confirmation
```bash
python run_ablation_v9.py
```

## Strongest confirmed frontier from the saved outputs

From the saved results in this package:
- **Best confirmed medium-context model (512):** `qlaf_adaptive_margin_longhead`
- **Best confirmed long-context operational model (1024):** `qlaf_dense_longhead`
- **Transformer keeps the stronger 1024 loss point, while QLAF keeps a strong speed/latency edge and improved accuracy in the longer-budget confirmation.**

## Notes on completeness

This zip contains the **actual code files and result files that are present in the container now**.
It does not fabricate missing files. In particular, some early prototypes that only existed in the chat/canvas and were never written to `/mnt/data` are not included unless they were materialized as Python files in this workspace.
