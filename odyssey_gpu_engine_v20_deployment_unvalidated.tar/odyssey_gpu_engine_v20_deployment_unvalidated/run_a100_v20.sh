#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python sdpa_backend_probe.py
python smoke_test_v20.py --device cuda --dtype bf16 --size small
python smoke_test_v20.py --device cuda --dtype bf16 --size small --quantize-cache
python fixed_shape_decode_benchmark_v20.py --device cuda --dtype bf16 --size small --batch 4 --context 1024 --steps 128 --trials 20 --out results/v20_a100_fixed_decode.csv
python fixed_shape_decode_benchmark_v20.py --device cuda --dtype bf16 --size small --batch 4 --context 1024 --steps 128 --trials 20 --quantize-cache --out results/v20_a100_fixed_decode_quant.csv
