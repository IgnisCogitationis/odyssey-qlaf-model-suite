# Odyssey GPU Engine v20 — Deployment Candidate Unvalidated

Status: **written and packaged, not CUDA/Triton validated in this environment**.

v20 continues from v19 and focuses on deployment readiness rather than adding more architecture branches.

## Main improvements over v19

- production-facing `OdysseyDeploymentEngine`
- fixed-shape decode benchmark harness
- CUDA graph capture scaffold
- quantized cache A/B script
- FlashAttention / SDPA backend probe
- kernel replacement contract preserved
- quality/speed/drift dashboard
- clean serving entrypoint
- deterministic config presets
- stronger contractor validation plan

## Package status

This is still a PyTorch reference implementation. The next true breakthrough requires replacing the reference kernel boundary functions with Triton/CUDA kernels and validating on A100/H100.
