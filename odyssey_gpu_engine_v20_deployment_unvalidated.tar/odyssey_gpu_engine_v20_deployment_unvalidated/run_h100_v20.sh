#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python sdpa_backend_probe.py
python smoke_test_v20.py --device cuda --dtype bf16 --size base
python smoke_test_v20.py --device cuda --dtype bf16 --size base --quantize-cache
python fixed_shape_decode_benchmark_v20.py --device cuda --dtype bf16 --size base --batch 8 --context 4096 --steps 256 --trials 20 --out results/v20_h100_fixed_decode.csv
python fixed_shape_decode_benchmark_v20.py --device cuda --dtype bf16 --size base --batch 8 --context 4096 --steps 256 --trials 20 --quantize-cache --out results/v20_h100_fixed_decode_quant.csv
