import argparse, csv, time, torch
from pathlib import Path
from odyssey_gpu_v20 import OdysseyGPUV20LM, OdysseyDeploymentEngine, preset_v20, drift_metrics

def sync(device):
    if device.type=="cuda": torch.cuda.synchronize()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--device",default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--dtype",default="bf16",choices=["fp32","fp16","bf16"])
    ap.add_argument("--size",default="small")
    ap.add_argument("--batch",type=int,default=4)
    ap.add_argument("--context",type=int,default=1024)
    ap.add_argument("--steps",type=int,default=128)
    ap.add_argument("--trials",type=int,default=10)
    ap.add_argument("--quantize-cache",action="store_true")
    ap.add_argument("--out",default="results/v20_fixed_decode.csv")
    args=ap.parse_args()
    device=torch.device(args.device); dtype={"fp32":torch.float32,"fp16":torch.float16,"bf16":torch.bfloat16}[args.dtype]
    amp=device.type=="cuda" and dtype!=torch.float32
    cfg=preset_v20(args.size,vocab_size=8192,max_seq_len=args.context+args.steps+8,quantize_cache=args.quantize_cache)
    model=OdysseyGPUV20LM(cfg).to(device).eval()
    eng=OdysseyDeploymentEngine(model)
    rows=[]
    for trial in range(args.trials):
        x=torch.randint(0,cfg.vocab_size,(args.batch,args.context),device=device)
        token=torch.randint(0,cfg.vocab_size,(args.batch,1),device=device)
        cache=eng.make_cache(args.batch,device,dtype)
        with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
            eng.prefill(x,cache,mode="balanced")
        sync(device)
        t0=time.perf_counter()
        for _ in range(args.steps):
            with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
                logits=eng.decode_recurrent(token,cache,mode="speed")
                token=logits.argmax(dim=-1,keepdim=True)
        sync(device)
        avg=(time.perf_counter()-t0)/args.steps
        rows.append({"trial":trial,"batch":args.batch,"context":args.context,"avg_decode_s":avg,"tokens_per_s":args.batch/avg,"cache_nbytes":cache.nbytes(),"quantized":args.quantize_cache})
        print(rows[-1])
    Path(args.out).parent.mkdir(parents=True,exist_ok=True)
    with open(args.out,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print("WROTE",args.out)
if __name__=="__main__": main()
