# v20 Deployment Notes

## Best expected production configuration

For serving:
```text
model size: small/base first
dtype: bf16
mode: speed
cache quantization: test both off/on
decode: recurrent
TSC: off during decode
QLAF route: top1
prefill: balanced top2
```

For training:
```text
mode: balanced
route: soft
TSC: budgeted
distill recurrent path from reference path
```

## What should be overwritten next

1. `qlaf_decode_kernel_reference` with Triton/CUDA.
2. `qlaf_prefill_kernel_reference` with Triton/CUDA.
3. Budgeted TSC token compaction.
4. CUDA graph capture for fixed-shape recurrent decode.
5. FlashAttention-verified transformer baseline.

## What should not be added

- More heavy branches.
- Always-on TSC.
- Full AION compute branch.
- Token-level Python routing in hot path.
- Claims of GPU performance before A100/H100 CSVs.
