from __future__ import annotations
from typing import Tuple, Optional
import torch
import torch.nn.functional as F

def route_weights_reference(logits: torch.Tensor, mode: str) -> Tuple[torch.Tensor, torch.Tensor]:
    if mode == "top1":
        idx = logits.argmax(dim=-1, keepdim=True)
        return torch.zeros_like(logits).scatter_(-1, idx, 1.0), idx.squeeze(-1)
    if mode == "top2" and logits.size(-1) > 2:
        vals, idx = torch.topk(logits, k=2, dim=-1)
        sparse = torch.full_like(logits, float("-inf"))
        sparse.scatter_(-1, idx, vals)
        return torch.softmax(sparse, dim=-1), idx[..., 0]
    return torch.softmax(logits, dim=-1), logits.argmax(dim=-1)

def qlaf_prefill_kernel_reference(x, packed_weight, out_weight, state_scale, n_states, route_mode):
    B,T,D = x.shape
    z = F.linear(x, packed_weight)
    raw = z[..., :n_states*D].view(B,T,n_states,D)
    logits = z[..., n_states*D:n_states*D+n_states]
    weights, route_id = route_weights_reference(logits, route_mode)
    states = torch.tanh(raw) * state_scale.view(1,1,n_states,D)
    combined = torch.einsum("bts,btsd->btd", weights, states)
    out = F.linear(combined, out_weight)
    return out, combined[:, -1, :], route_id, weights.max(dim=-1).values, z[..., n_states*D+n_states:]

def qlaf_decode_kernel_reference(x_token, prev_summary, packed_weight, out_weight, summary_weight, state_scale, n_states, summary_mix):
    B,T,D = x_token.shape
    assert T == 1
    z = F.linear(x_token, packed_weight)
    raw = z[..., :n_states*D].view(B,T,n_states,D)
    logits = z[..., n_states*D:n_states*D+n_states]
    weights, route_id = route_weights_reference(logits, "top1")
    states = torch.tanh(raw) * state_scale.view(1,1,n_states,D)
    combined = torch.einsum("bts,btsd->btd", weights, states)
    if prev_summary is not None:
        combined = summary_mix * F.linear(prev_summary, summary_weight).unsqueeze(1) + (1-summary_mix) * combined
    out = F.linear(combined, out_weight)
    return out, combined[:, -1, :], route_id.squeeze(1), weights.max(dim=-1).values.squeeze(1), z[..., n_states*D+n_states:]

def budgeted_tsc_reference(x, confidence, left_weight, right_weight, out_weight, rank, budget):
    if budget <= 0:
        return torch.zeros_like(x)
    B,T,D = x.shape
    k = max(1, int(T * budget))
    _, idx = torch.topk(-confidence, k=k, dim=1)
    mask = torch.zeros(B,T,device=x.device,dtype=x.dtype)
    mask.scatter_(1, idx, 1.0)
    left = F.linear(x, left_weight).view(B,T,rank,D)
    right = torch.softmax(F.linear(x, right_weight), dim=-1).view(B,T,rank,1)
    y = F.linear(torch.tanh((left*right).sum(dim=2)), out_weight)
    return y * mask.unsqueeze(-1)

def fused_residual_reference(x, q, local, tsc, gate, qlaf_weight, local_weight, tsc_weight, controller_mix):
    fixed = qlaf_weight*q + local_weight*local + tsc_weight*tsc
    adaptive = gate[...,0:1]*q + gate[...,1:2]*local + gate[...,2:3]*tsc
    return x + (1-controller_mix)*fixed + controller_mix*adaptive
