from dataclasses import dataclass
import torch

@dataclass
class QuantizedSummary:
    q: torch.Tensor
    scale: torch.Tensor
    dtype: str = "int8"

def quantize_summary_int8(x: torch.Tensor) -> QuantizedSummary:
    max_abs = x.detach().abs().amax(dim=-1, keepdim=True).clamp_min(1e-6)
    scale = max_abs / 127.0
    q = torch.clamp(torch.round(x / scale), -127, 127).to(torch.int8)
    return QuantizedSummary(q=q, scale=scale)

def dequantize_summary(x):
    if isinstance(x, QuantizedSummary):
        return x.q.float() * x.scale.float()
    return x

def maybe_quantize(x, enabled: bool):
    return quantize_summary_int8(x) if enabled else x

def cache_nbytes(x):
    if x is None:
        return 0
    if isinstance(x, QuantizedSummary):
        return x.q.numel() * x.q.element_size() + x.scale.numel() * x.scale.element_size()
    return x.numel() * x.element_size()
