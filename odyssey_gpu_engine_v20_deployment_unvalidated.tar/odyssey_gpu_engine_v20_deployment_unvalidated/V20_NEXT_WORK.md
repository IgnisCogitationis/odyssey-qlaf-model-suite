# v20 Next Work

1. Implement real Triton/CUDA `qlaf_decode_kernel_reference` replacement.
2. Implement CUDA graph capture after kernel replacement.
3. Add FlashAttention-2 explicit dependency baseline.
4. Add real corpus quality evaluation.
5. Add recurrent distillation into the main training loop.
6. Build a wheel/package layout for GitHub.
