import torch
import json
import platform

def main():
    info = {
        "python": platform.python_version(),
        "torch": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "gpu": torch.cuda.get_device_name() if torch.cuda.is_available() else None,
        "cuda_version": torch.version.cuda,
        "cudnn_version": torch.backends.cudnn.version() if torch.backends.cudnn.is_available() else None,
    }
    # Best-effort SDPA backend flags. These APIs vary by torch version.
    attrs = [
        ("flash_sdp_enabled", "flash_sdp_enabled"),
        ("mem_efficient_sdp_enabled", "mem_efficient_sdp_enabled"),
        ("math_sdp_enabled", "math_sdp_enabled"),
    ]
    for key, name in attrs:
        try:
            info[key] = bool(getattr(torch.backends.cuda, name)())
        except Exception as e:
            info[key] = f"unavailable: {e!r}"
    print(json.dumps(info, indent=2))

if __name__ == "__main__":
    main()
