from dataclasses import dataclass
import torch

@dataclass
class QLAFCache:
    summaries: torch.Tensor
    weights: torch.Tensor
    positions: torch.Tensor

    @classmethod
    def init(cls, layers, batch, states, rank, device, dtype):
        return cls(
            torch.zeros(layers, batch, states, rank, device=device, dtype=dtype),
            torch.zeros(layers, batch, states, device=device, dtype=dtype),
            torch.zeros(batch, device=device, dtype=torch.long),
        )

    def reorder(self, beam_idx):
        self.summaries = self.summaries[:, beam_idx]
        self.weights = self.weights[:, beam_idx]
        self.positions = self.positions[beam_idx]
        return self

    def reset(self):
        self.summaries.zero_()
        self.weights.zero_()
        self.positions.zero_()
        return self
