#!/usr/bin/env bash
set -euo pipefail
export TORCHINDUCTOR_MAX_AUTOTUNE=1
PYTHONPATH=. python -m odyssey_route_b.tests.test_ffn_strategies
PYTHONPATH=. python -m odyssey_route_b.tests.test_reference_single_kernel
PYTHONPATH=. python -m odyssey_route_b.tests.test_triton_single_kernel_smoke
PYTHONPATH=. python -m odyssey_route_b.benchmarks.benchmark_final_route_b --device cuda --dtype bfloat16 --batch 16 --seq 512 --ffn decode_light
PYTHONPATH=. python -m odyssey_route_b.benchmarks.benchmark_final_route_b --device cuda --dtype bfloat16 --batch 16 --seq 512 --ffn full_ffn
PYTHONPATH=. python -m odyssey_route_b.benchmarks.benchmark_final_route_b --device cuda --dtype bfloat16 --batch 16 --seq 512 --ffn decode_light --compile
