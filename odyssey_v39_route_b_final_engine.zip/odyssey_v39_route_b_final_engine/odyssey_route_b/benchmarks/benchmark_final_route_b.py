import argparse, time, json, torch
from odyssey_route_b.configuration_odyssey_v39 import OdysseyV39Config
from odyssey_route_b.modeling_odyssey_v39 import OdysseyV39ForCausalLM, build_compiled_model

def sync(d):
    if d.startswith("cuda"):
        torch.cuda.synchronize()

def bench(fn, warm, iters, d):
    for _ in range(warm):
        fn()
    sync(d)
    ts = []
    for _ in range(iters):
        t = time.perf_counter()
        fn()
        sync(d)
        ts.append(time.perf_counter() - t)
    return min(ts), sum(ts)/len(ts)

def count(m):
    return sum(p.numel() for p in m.parameters())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--dtype", default="bfloat16", choices=["float32","float16","bfloat16"])
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--seq", type=int, default=512)
    ap.add_argument("--ffn", default="decode_light", choices=["decode_light","full_ffn","none"])
    ap.add_argument("--compile", action="store_true")
    ap.add_argument("--iters", type=int, default=20)
    args = ap.parse_args()
    dtype = {"float32":torch.float32,"float16":torch.float16,"bfloat16":torch.bfloat16}[args.dtype]
    cfg = OdysseyV39Config(ffn_strategy=args.ffn)
    model = OdysseyV39ForCausalLM(cfg).to(args.device, dtype=dtype).eval()
    if args.compile:
        model = build_compiled_model(model)
    ids = torch.randint(0, cfg.vocab_size, (args.batch,args.seq), device=args.device)
    with torch.no_grad():
        best, mean = bench(lambda: model(ids, return_dict=False), 5, args.iters, args.device)
    print(json.dumps({
        "ffn_strategy": args.ffn,
        "params": count(model),
        "best_ms": best*1000,
        "mean_ms": mean*1000,
        "tok_per_sec": args.batch*args.seq/best,
        "compile": args.compile
    }, indent=2))

if __name__ == "__main__":
    main()
