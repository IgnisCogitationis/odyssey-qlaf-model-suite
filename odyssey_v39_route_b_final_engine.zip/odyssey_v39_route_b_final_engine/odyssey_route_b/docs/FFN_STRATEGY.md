# Locked FFN Strategy

Default:
```text
ffn_strategy = decode_light
decode_ffn_size = hidden_size
```

Rationale:
Route B already contains routed recurrent memory, AION routing, readout, and TSC repair. The full Transformer FFN is the remaining large decode branch. `decode_light` preserves gated nonlinear capacity while reducing compute.

Decision rule:
Keep `decode_light` if validation perplexity remains within 2–5% of `full_ffn` and decode speed improves materially.
