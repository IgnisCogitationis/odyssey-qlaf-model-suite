import torch
try:
    import triton
    import triton.language as tl
except Exception:
    triton = None
    tl = None

def triton_available():
    return triton is not None and torch.cuda.is_available()

def require_triton():
    if not triton_available():
        raise RuntimeError("Route B final engine requires CUDA + Triton. No runtime PyTorch fallback is allowed.")

def torch_reference_single_kernel(x, route_norm_w, to_state_w, summary, weight, readout_w,
                                  tsc_norm_w, tsc_gate_w, tsc_proj_w,
                                  threshold=0.55, eps=1e-6, tsc_scale=0.05):
    xf = x.float()
    inv = torch.rsqrt(xf.pow(2).mean(-1, keepdim=True) + eps)
    xn = (xf * inv).to(x.dtype) * route_norm_w
    proj = xn @ to_state_w.t()
    S = weight.shape[-1]
    route = torch.softmax(proj[:, :S], dim=-1)
    rank = proj[:, S:]
    conf = route.max(-1).values
    top1v, top1i = torch.topk(route, 1, dim=-1)
    top2v, top2i = torch.topk(route, 2, dim=-1)
    mask1 = torch.zeros_like(route).scatter_(-1, top1i, top1v)
    mask2 = torch.zeros_like(route).scatter_(-1, top2i, top2v)
    mask = torch.where((conf < threshold)[:, None], mask2, mask1)
    mask = mask / mask.sum(-1, keepdim=True).clamp_min(1e-6)
    nw = weight + mask
    upd = (summary * weight[:, :, None] + mask[:, :, None] * rank[:, None, :]) / nw[:, :, None].clamp_min(1e-6)
    ns = torch.where(mask[:, :, None] > 0, upd, summary)
    weighted = ns * (nw / nw.sum(-1, keepdim=True).clamp_min(1e-6))[:, :, None]
    readout = weighted.reshape(weight.shape[0], -1) @ readout_w.t()

    tx = (xf * inv).to(x.dtype) * tsc_norm_w
    gate = torch.sigmoid(tx @ tsc_gate_w.t())
    tsc = gate * (tx @ tsc_proj_w.t()) * tsc_scale
    return readout + tsc, ns, nw, top2i, conf

if triton is not None:
    @triton.jit
    def _single_kernel(
        x, route_norm_w, to_state_w, summary, weight, readout_w,
        tsc_norm_w, tsc_gate_w, tsc_proj_w,
        out_core, out_summary, out_weight, idx0_ptr, idx1_ptr, conf_ptr,
        threshold: tl.constexpr, eps: tl.constexpr, tsc_scale: tl.constexpr,
        H: tl.constexpr, S: tl.constexpr, R: tl.constexpr, BLOCK_H: tl.constexpr
    ):
        b = tl.program_id(0)
        hb = tl.program_id(1)

        ss = tl.full((), 0.0, tl.float32)
        for h in range(0, H):
            xv = tl.load(x + b * H + h).to(tl.float32)
            ss += xv * xv
        inv = tl.rsqrt(ss / H + eps)

        best0 = tl.full((), -3.402823e38, tl.float32)
        best1 = tl.full((), -3.402823e38, tl.float32)
        i0 = tl.full((), 0, tl.int64)
        i1 = tl.full((), 0, tl.int64)
        maxl = tl.full((), -3.402823e38, tl.float32)

        for s in range(0, S):
            acc = tl.full((), 0.0, tl.float32)
            for h in range(0, H):
                xn = tl.load(x + b * H + h).to(tl.float32) * inv * tl.load(route_norm_w + h).to(tl.float32)
                acc += xn * tl.load(to_state_w + s * H + h).to(tl.float32)
            maxl = tl.maximum(maxl, acc)
            n0 = acc > best0
            n1 = (acc > best1) & (~n0)
            best1 = tl.where(n0, best0, tl.where(n1, acc, best1))
            i1 = tl.where(n0, i0, tl.where(n1, s, i1))
            best0 = tl.where(n0, acc, best0)
            i0 = tl.where(n0, s, i0)

        denom = tl.full((), 0.0, tl.float32)
        for s in range(0, S):
            acc = tl.full((), 0.0, tl.float32)
            for h in range(0, H):
                xn = tl.load(x + b * H + h).to(tl.float32) * inv * tl.load(route_norm_w + h).to(tl.float32)
                acc += xn * tl.load(to_state_w + s * H + h).to(tl.float32)
            denom += tl.exp(acc - maxl)

        p0 = tl.exp(best0 - maxl) / tl.maximum(denom, 1.0e-6)
        p1 = tl.exp(best1 - maxl) / tl.maximum(denom, 1.0e-6)
        use2 = p0 < threshold
        normp = tl.where(use2, p0 + p1, p0)
        m0 = p0 / tl.maximum(normp, 1.0e-6)
        m1 = tl.where(use2, p1 / tl.maximum(normp, 1.0e-6), 0.0)

        if hb == 0:
            tl.store(idx0_ptr + b, i0)
            tl.store(idx1_ptr + b, i1)
            tl.store(conf_ptr + b, p0)
            for s in range(0, S):
                oldw = tl.load(weight + b * S + s)
                mv = (s == i0).to(tl.float32) * m0 + (s == i1).to(tl.float32) * m1
                nw = oldw + mv
                tl.store(out_weight + b * S + s, nw)
                for r in range(0, R):
                    racc = tl.full((), 0.0, tl.float32)
                    row = S + r
                    for h in range(0, H):
                        xn = tl.load(x + b * H + h).to(tl.float32) * inv * tl.load(route_norm_w + h).to(tl.float32)
                        racc += xn * tl.load(to_state_w + row * H + h).to(tl.float32)
                    old = tl.load(summary + (b * S + s) * R + r)
                    val = tl.where(mv > 0.0, (old * oldw + mv * racc) / tl.maximum(nw, 1.0e-6), old)
                    tl.store(out_summary + (b * S + s) * R + r, val)

        oh = hb * BLOCK_H + tl.arange(0, BLOCK_H)
        mask_h = oh < H
        total = tl.full((), 0.0, tl.float32)
        for s in range(0, S):
            total += tl.load(out_weight + b * S + s)
        total = tl.maximum(total, 1.0e-6)

        acc_out = tl.zeros((BLOCK_H,), tl.float32)
        for s in range(0, S):
            coeff = tl.load(out_weight + b * S + s) / total
            for r in range(0, R):
                state_val = tl.load(out_summary + (b * S + s) * R + r) * coeff
                rw = tl.load(readout_w + oh * (S * R) + (s * R + r), mask=mask_h, other=0.0)
                acc_out += state_val * rw

        gate_acc = tl.full((), 0.0, tl.float32)
        for h in range(0, H):
            tx = tl.load(x + b * H + h).to(tl.float32) * inv * tl.load(tsc_norm_w + h).to(tl.float32)
            gate_acc += tx * tl.load(tsc_gate_w + h).to(tl.float32)
        gate = 1.0 / (1.0 + tl.exp(-gate_acc))

        tsc_acc = tl.zeros((BLOCK_H,), tl.float32)
        for h in range(0, H):
            tx = tl.load(x + b * H + h).to(tl.float32) * inv * tl.load(tsc_norm_w + h).to(tl.float32)
            pw = tl.load(tsc_proj_w + oh * H + h, mask=mask_h, other=0.0)
            tsc_acc += tx * pw

        tl.store(out_core + b * H + oh, acc_out + gate * tsc_scale * tsc_acc, mask=mask_h)

def single_kernel_route_b(x, route_norm_w, to_state_w, summary, weight, readout_w,
                          tsc_norm_w, tsc_gate_w, tsc_proj_w,
                          threshold=0.55, eps=1e-6, tsc_scale=0.05):
    require_triton()
    B, H = x.shape
    S = weight.shape[-1]
    R = summary.shape[-1]
    out = torch.empty((B, H), device=x.device, dtype=x.dtype)
    ns = torch.empty_like(summary)
    nw = torch.empty_like(weight)
    i0 = torch.empty((B,), device=x.device, dtype=torch.int64)
    i1 = torch.empty((B,), device=x.device, dtype=torch.int64)
    conf = torch.empty((B,), device=x.device, dtype=torch.float32)
    bh = 32
    _single_kernel[(B, triton.cdiv(H, bh))](
        x.contiguous(), route_norm_w.contiguous(), to_state_w.contiguous(),
        summary.contiguous(), weight.contiguous(), readout_w.contiguous(),
        tsc_norm_w.contiguous(), tsc_gate_w.contiguous(), tsc_proj_w.contiguous(),
        out, ns, nw, i0, i1, conf,
        threshold, eps, tsc_scale, H, S, R, BLOCK_H=bh
    )
    return out, ns, nw, i0, i1, conf
