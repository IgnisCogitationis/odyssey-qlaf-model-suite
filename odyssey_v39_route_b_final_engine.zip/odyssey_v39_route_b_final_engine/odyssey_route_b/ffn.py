import torch
import torch.nn as nn
import torch.nn.functional as F

class DecodeLightFFN(nn.Module):
    def __init__(self, hidden_size, decode_ffn_size):
        super().__init__()
        self.norm = nn.RMSNorm(hidden_size)
        self.gate = nn.Linear(hidden_size, decode_ffn_size, bias=False)
        self.up = nn.Linear(hidden_size, decode_ffn_size, bias=False)
        self.down = nn.Linear(decode_ffn_size, hidden_size, bias=False)

    def forward(self, x):
        h = self.norm(x)
        return self.down(F.silu(self.gate(h)) * self.up(h))

class FullFFN(nn.Module):
    def __init__(self, hidden_size, intermediate_size):
        super().__init__()
        self.norm = nn.RMSNorm(hidden_size)
        self.up = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.down = nn.Linear(intermediate_size, hidden_size, bias=False)

    def forward(self, x):
        return self.down(F.silu(self.up(self.norm(x))))

class NoFFN(nn.Module):
    def forward(self, x):
        return torch.zeros_like(x)

def build_ffn(config):
    if config.ffn_strategy == "decode_light":
        return DecodeLightFFN(config.hidden_size, config.decode_ffn_size)
    if config.ffn_strategy == "full_ffn":
        return FullFFN(config.hidden_size, config.intermediate_size)
    if config.ffn_strategy == "none":
        return NoFFN()
    raise ValueError(f"Unknown ffn_strategy: {config.ffn_strategy}")
