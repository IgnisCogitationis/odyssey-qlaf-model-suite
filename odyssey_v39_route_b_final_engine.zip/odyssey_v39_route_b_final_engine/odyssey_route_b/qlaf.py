import torch
import torch.nn as nn
from .kernels import single_kernel_route_b, require_triton
from .ffn import build_ffn

class FusedTSCParams(nn.Module):
    def __init__(self, hidden_size, scale):
        super().__init__()
        self.norm = nn.RMSNorm(hidden_size)
        self.gate = nn.Linear(hidden_size, 1, bias=False)
        self.proj = nn.Linear(hidden_size, hidden_size, bias=False)
        self.scale = float(scale)

class QLAFBlock(nn.Module):
    def __init__(self, config):
        super().__init__()
        H, S, R = config.hidden_size, config.num_states, config.state_rank
        self.threshold = float(config.aion_threshold)
        self.rms_eps = float(config.rms_eps)
        self.require_triton_kernel = bool(config.require_triton_kernel)
        self.norm = nn.RMSNorm(H, eps=self.rms_eps)
        self.to_state = nn.Linear(H, S + R, bias=False)
        self.readout = nn.Linear(S * R, H, bias=False)
        self.tsc = FusedTSCParams(H, config.tsc_scale)
        self.ffn = build_ffn(config)

    def forward_step(self, x, summary, weight):
        if self.require_triton_kernel:
            require_triton()
        core, ns, nw, i0, i1, conf = single_kernel_route_b(
            x, self.norm.weight, self.to_state.weight, summary, weight, self.readout.weight,
            self.tsc.norm.weight, self.tsc.gate.weight, self.tsc.proj.weight,
            threshold=self.threshold, eps=self.rms_eps, tsc_scale=self.tsc.scale
        )
        return x + core + self.ffn(x), ns, nw, i0, i1, conf

    def forward(self, x, cache=None, layer_idx=None):
        if cache is None:
            raise ValueError("Final Route B requires recurrent cache.")
        if x.ndim == 2:
            y, ns, nw, _, _, _ = self.forward_step(x, cache.summaries[layer_idx], cache.weights[layer_idx])
            cache.summaries[layer_idx] = ns
            cache.weights[layer_idx] = nw
            return y
        outs = []
        for t in range(x.shape[1]):
            y, ns, nw, _, _, _ = self.forward_step(x[:, t], cache.summaries[layer_idx], cache.weights[layer_idx])
            cache.summaries[layer_idx] = ns
            cache.weights[layer_idx] = nw
            outs.append(y)
        return torch.stack(outs, dim=1)
