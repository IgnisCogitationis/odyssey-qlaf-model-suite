import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import PreTrainedModel
try:
    from transformers.modeling_outputs import CausalLMOutput
except Exception:
    CausalLMOutput = None
from .configuration_odyssey_v39 import OdysseyV39Config
from .qlaf import QLAFBlock
from .cache import QLAFCache

class OdysseyV39ForCausalLM(PreTrainedModel):
    config_class = OdysseyV39Config
    main_input_name = "input_ids"

    def __init__(self, config):
        super().__init__(config)
        self.config = config
        self.embed = nn.Embedding(config.vocab_size, config.hidden_size)
        self.pos = nn.Embedding(config.max_positions, config.hidden_size)
        self.layers = nn.ModuleList([QLAFBlock(config) for _ in range(config.num_layers)])
        self.norm = nn.RMSNorm(config.hidden_size)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)
        if config.tie_word_embeddings:
            self.lm_head.weight = self.embed.weight
        self.post_init()

    def init_cache(self, batch, device=None, dtype=None):
        return QLAFCache.init(
            self.config.num_layers, batch, self.config.num_states, self.config.state_rank,
            device or self.embed.weight.device, dtype or self.embed.weight.dtype
        )

    def forward(self, input_ids, labels=None, attention_mask=None, use_cache=True,
                past_key_values=None, return_dict=True, **kwargs):
        B, T = input_ids.shape
        cache = past_key_values if past_key_values is not None else self.init_cache(B, input_ids.device, self.embed.weight.dtype)
        pos = (cache.positions[:, None] + torch.arange(T, device=input_ids.device)[None, :]).clamp_max(self.config.max_positions - 1)
        x = self.embed(input_ids) + self.pos(pos)
        for i, layer in enumerate(self.layers):
            x = layer(x, cache=cache, layer_idx=i)
        cache.positions = cache.positions + T
        logits = self.lm_head(self.norm(x))
        loss = None
        if labels is not None:
            loss = F.cross_entropy(
                logits[:, :-1, :].contiguous().reshape(-1, logits.size(-1)),
                labels[:, 1:].contiguous().reshape(-1)
            )
        if not return_dict or CausalLMOutput is None:
            out = {"logits": logits, "past_key_values": cache}
            if loss is not None:
                out["loss"] = loss
            return out
        return CausalLMOutput(loss=loss, logits=logits, past_key_values=cache)

    def prepare_inputs_for_generation(self, input_ids, past_key_values=None, **kwargs):
        if past_key_values is not None:
            input_ids = input_ids[:, -1:]
        return {"input_ids": input_ids, "past_key_values": past_key_values, "use_cache": True}

    def _reorder_cache(self, past_key_values, beam_idx):
        return past_key_values.reorder(beam_idx) if past_key_values is not None else None

def build_compiled_model(model, mode="max-autotune", fullgraph=True):
    return torch.compile(model, mode=mode, fullgraph=fullgraph, dynamic=False)
