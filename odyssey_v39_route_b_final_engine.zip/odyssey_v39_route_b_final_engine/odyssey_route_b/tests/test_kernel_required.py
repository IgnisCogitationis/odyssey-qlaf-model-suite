import torch
from odyssey_route_b.configuration_odyssey_v39 import OdysseyV39Config
from odyssey_route_b.modeling_odyssey_v39 import OdysseyV39ForCausalLM
cfg = OdysseyV39Config(hidden_size=64, num_layers=1, num_states=4, state_rank=8,
                       intermediate_size=128, decode_ffn_size=32, vocab_size=256)
m = OdysseyV39ForCausalLM(cfg).eval()
ids = torch.randint(0, cfg.vocab_size, (1, 2))
if torch.cuda.is_available():
    print("cuda_available_run_gpu_validation")
else:
    try:
        m(ids, return_dict=False)
        raise AssertionError("expected RuntimeError")
    except RuntimeError:
        print("kernel_required_ok")
