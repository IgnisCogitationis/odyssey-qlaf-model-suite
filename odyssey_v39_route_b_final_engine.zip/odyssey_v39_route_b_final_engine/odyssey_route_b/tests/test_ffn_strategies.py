import torch
from odyssey_route_b.configuration_odyssey_v39 import OdysseyV39Config
from odyssey_route_b.ffn import build_ffn

for strategy in ["decode_light", "full_ffn", "none"]:
    cfg = OdysseyV39Config(hidden_size=64, intermediate_size=256, decode_ffn_size=32, ffn_strategy=strategy)
    y = build_ffn(cfg)(torch.randn(2, 4, 64))
    assert y.shape == (2, 4, 64)
print("ffn_strategies_ok")
