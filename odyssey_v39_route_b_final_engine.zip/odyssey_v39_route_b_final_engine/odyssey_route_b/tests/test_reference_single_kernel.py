import torch
from odyssey_route_b.kernels import torch_reference_single_kernel
B,H,S,R = 2,32,4,8
core,ns,nw,idx,conf = torch_reference_single_kernel(
    torch.randn(B,H), torch.randn(H), torch.randn(S+R,H),
    torch.zeros(B,S,R), torch.zeros(B,S), torch.randn(H,S*R),
    torch.randn(H), torch.randn(1,H), torch.randn(H,H)
)
assert core.shape == (B,H)
assert ns.shape == (B,S,R)
assert nw.shape == (B,S)
print("reference_single_kernel_ok")
