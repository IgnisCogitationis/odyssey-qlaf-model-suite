import torch
from odyssey_route_b.kernels import triton_available, single_kernel_route_b
if not triton_available():
    print("triton_unavailable_skip")
else:
    B,H,S,R = 2,128,8,64
    core,ns,nw,i0,i1,conf = single_kernel_route_b(
        torch.randn(B,H,device="cuda"), torch.randn(H,device="cuda"),
        torch.randn(S+R,H,device="cuda"), torch.zeros(B,S,R,device="cuda"),
        torch.zeros(B,S,device="cuda"), torch.randn(H,S*R,device="cuda"),
        torch.randn(H,device="cuda"), torch.randn(1,H,device="cuda"),
        torch.randn(H,H,device="cuda")
    )
    assert core.shape == (B,H)
    assert ns.shape == (B,S,R)
    assert nw.shape == (B,S)
    print("triton_single_kernel_smoke_ok")
