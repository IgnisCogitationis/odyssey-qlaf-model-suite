# Odyssey V39 Route B Final Engine Candidate

This is the unified Route B engine artifact.

Included in one codebase:
- Hugging Face-compatible `OdysseyV39ForCausalLM`
- recurrent QLAF cache
- full single-kernel Route B core source:
  - RMSNorm
  - projection H→S+R
  - AION top-1/top-2 routing
  - recurrent state update
  - normalized readout
  - TSC norm/gate/projection
- locked production FFN strategy:
  - default: `decode_light`
  - comparison: `full_ffn`
  - ablation: `none`
- strict no-runtime-PyTorch-fallback core path
- reference-only math path for tests
- GPU validation script
- benchmark harness

Production path:
```text
single-kernel Route B core + decode-light FFN
```

Important:
This is the complete unified source artifact. It still requires A100/H100 GPU validation before performance or correctness claims are final.
