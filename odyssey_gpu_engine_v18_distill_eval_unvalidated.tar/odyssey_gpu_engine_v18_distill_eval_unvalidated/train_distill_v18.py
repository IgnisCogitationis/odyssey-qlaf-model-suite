import argparse, csv, torch
from pathlib import Path
from odyssey_gpu_v18 import OdysseyGPUV18LM, OdysseyV18Engine, preset_v18

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--device",default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--dtype",default="bf16",choices=["fp32","fp16","bf16"])
    ap.add_argument("--size",default="tiny")
    ap.add_argument("--steps",type=int,default=20)
    ap.add_argument("--batch",type=int,default=2)
    ap.add_argument("--seq",type=int,default=128)
    ap.add_argument("--out",default="results/v18_distill_train.csv")
    args=ap.parse_args()
    device=torch.device(args.device); dtype={"fp32":torch.float32,"fp16":torch.float16,"bf16":torch.bfloat16}[args.dtype]
    cfg=preset_v18(args.size,vocab_size=4096,max_seq_len=args.seq)
    model=OdysseyGPUV18LM(cfg).to(device); eng=OdysseyV18Engine(model); opt=torch.optim.AdamW(model.parameters(),lr=1e-4)
    rows=[]
    for step in range(args.steps):
        x=torch.randint(0,cfg.vocab_size,(args.batch,args.seq),device=device)
        y=torch.randint(0,cfg.vocab_size,(args.batch,args.seq),device=device)
        loss,ce,kl=eng.distill_recurrent_step(x,y,opt,mode="speed")
        row={"step":step,"loss":float(loss.detach().cpu()),"ce":float(ce.cpu()),"kl":float(kl.cpu())}
        rows.append(row); print(row)
    Path(args.out).parent.mkdir(parents=True,exist_ok=True)
    with open(args.out,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print("WROTE",args.out)
if __name__=="__main__": main()
