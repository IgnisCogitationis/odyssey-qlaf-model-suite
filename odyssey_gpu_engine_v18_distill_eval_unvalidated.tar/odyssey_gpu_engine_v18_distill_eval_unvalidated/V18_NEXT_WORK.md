# v18 Next Work

1. Implement fused recurrent QLAF decode kernel.
2. Add activation checkpointing for training.
3. Add real dataset loader and tokenizer.
4. Add multi-seed quality evaluation.
5. Add FlashAttention-2 transformer baseline.
6. Add ONNX/TensorRT export investigation.
7. Add quantized summary cache.
