import argparse, csv, torch
from pathlib import Path
from odyssey_gpu_v18 import OdysseyGPUV18LM, OdysseyV18Engine, preset_v18, drift_metrics

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--device",default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--dtype",default="bf16",choices=["fp32","fp16","bf16"])
    ap.add_argument("--size",default="small")
    ap.add_argument("--seqs",nargs="+",type=int,default=[64,128,256,512])
    ap.add_argument("--batch",type=int,default=2)
    ap.add_argument("--out",default="results/v18_drift.csv")
    args=ap.parse_args()
    device=torch.device(args.device); dtype={"fp32":torch.float32,"fp16":torch.float16,"bf16":torch.bfloat16}[args.dtype]
    amp=device.type=="cuda" and dtype!=torch.float32
    cfg=preset_v18(args.size,vocab_size=8192,max_seq_len=max(args.seqs)+1)
    model=OdysseyGPUV18LM(cfg).to(device).eval()
    eng=OdysseyV18Engine(model)
    rows=[]
    for seq in args.seqs:
        x=torch.randint(0,cfg.vocab_size,(args.batch,seq+1),device=device)
        cache=eng.make_cache(args.batch,device,dtype)
        with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
            eng.prefill(x[:,:seq],cache,mode="balanced")
            ref=eng.decode_reference(x[:,:seq+1],None,mode="speed")
            rec=eng.decode_recurrent(x[:,seq:seq+1],cache,mode="speed")
        m=drift_metrics(ref,rec); m["seq"]=seq; rows.append(m); print(m)
    Path(args.out).parent.mkdir(parents=True,exist_ok=True)
    with open(args.out,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print("WROTE",args.out)
if __name__=="__main__": main()
