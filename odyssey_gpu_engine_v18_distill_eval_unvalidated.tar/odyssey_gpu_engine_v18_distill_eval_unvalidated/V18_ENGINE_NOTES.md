# v18 Engine Notes

## Why v18 exists

v17 introduced recurrent decode, but recurrent decode can diverge from full-context reference decode.

On GPU, this creates a strategic tradeoff:

- `decode_reference`: slower but closer to full model behavior
- `decode_recurrent`: faster but approximate

v18 introduces evaluation and training tools so the recurrent path can be treated as a deployable student path.

## Added concepts

### 1. Drift metrics

The package computes:

- mean absolute logit error
- max absolute logit error
- KL(reference || recurrent)
- top-1 agreement
- top-5 overlap

### 2. Lean decode distillation

Train recurrent decode to match reference decode:

```text
loss = CE(targets) + alpha * KL(reference_logits || recurrent_logits)
```

### 3. Mode separation

- `quality`: full correction, reference-preferred
- `balanced`: prefill/eval default
- `speed`: recurrent decode default
- `survival`: QLAF-only recurrent path

## Expected behavior

- recurrent decode should be faster;
- reference decode should be more accurate;
- distillation should reduce drift;
- quality claims require held-out corpus tests.
