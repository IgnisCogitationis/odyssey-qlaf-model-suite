#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python smoke_test_v18.py --device cuda --dtype bf16 --size small
python evaluate_drift_v18.py --device cuda --dtype bf16 --size small --seqs 128 256 512 1024 2048 --batch 4 --out results/v18_a100_drift.csv
python train_distill_v18.py --device cuda --dtype bf16 --size small --steps 50 --batch 4 --seq 512 --out results/v18_a100_distill.csv
