from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Literal, List, Dict
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

Phase = Literal["train","prefill","decode_reference","decode_recurrent","decode_chunk"]
Mode = Literal["quality","balanced","speed","survival"]

@dataclass
class V18Config:
    vocab_size: int = 8192
    d_model: int = 512
    n_layers: int = 8
    n_heads: int = 8
    d_ff: int = 2048
    max_seq_len: int = 4096
    dropout: float = 0.0
    n_states: int = 4
    tsc_rank: int = 4

    qlaf_weight: float = 0.88
    local_weight: float = 0.09
    tsc_weight: float = 0.03
    controller_mix: float = 0.05

    summary_mix: float = 0.875
    train_tsc_budget: float = 0.125
    prefill_tsc_budget: float = 0.125
    chunk_tsc_budget: float = 0.03125
    train_tsc_grad_scale: float = 0.30
    short_seq_cutoff: int = 128

    distill_alpha: float = 0.25
    grouped_local: bool = True
    local_kernel: int = 5

def preset_v18(size: str="small", **overrides) -> V18Config:
    presets = {
        "tiny": dict(d_model=128,n_layers=2,n_heads=4,d_ff=512,max_seq_len=2048,n_states=4,tsc_rank=4),
        "small": dict(d_model=256,n_layers=4,n_heads=4,d_ff=1024,max_seq_len=4096,n_states=4,tsc_rank=4),
        "base": dict(d_model=512,n_layers=8,n_heads=8,d_ff=2048,max_seq_len=4096,n_states=4,tsc_rank=4),
        "large": dict(d_model=768,n_layers=12,n_heads=12,d_ff=3072,max_seq_len=8192,n_states=6,tsc_rank=6),
    }
    kw = presets.get(size, presets["small"]).copy()
    kw.update(overrides)
    return V18Config(**kw)

@dataclass
class LayerCache:
    summary: Optional[torch.Tensor] = None
    route_id: Optional[torch.Tensor] = None
    confidence: Optional[torch.Tensor] = None
    steps: int = 0

@dataclass
class OdysseyV18Cache:
    batch_size: int
    n_layers: int
    d_model: int
    max_seq_len: int
    device: torch.device
    dtype: torch.dtype
    layers: List[LayerCache] = field(default_factory=list)
    token_count: int = 0
    valid: bool = True

    def __post_init__(self):
        if not self.layers:
            self.layers = [LayerCache() for _ in range(self.n_layers)]

    def validate(self, batch_size, device):
        if batch_size != self.batch_size:
            raise ValueError("cache batch mismatch")
        if device != self.device:
            raise ValueError("cache device mismatch")
        return True

    def reset(self):
        self.token_count = 0
        for l in self.layers:
            l.summary = None
            l.route_id = None
            l.confidence = None
            l.steps = 0

    def update(self, i, summary, route_id, confidence):
        l = self.layers[i]
        l.summary = summary.detach()
        l.route_id = route_id.detach() if route_id is not None else None
        l.confidence = confidence.detach() if confidence is not None else None
        l.steps += 1

class RMSNorm(nn.Module):
    def __init__(self,d,eps=1e-6):
        super().__init__()
        self.weight=nn.Parameter(torch.ones(d)); self.eps=eps
    def forward(self,x):
        return x*torch.rsqrt(x.square().mean(dim=-1,keepdim=True)+self.eps)*self.weight

class SwiGLU(nn.Module):
    def __init__(self,d,ff):
        super().__init__()
        self.a=nn.Linear(d,ff,bias=False); self.b=nn.Linear(d,ff,bias=False); self.o=nn.Linear(ff,d,bias=False)
    def forward(self,x):
        return self.o(F.silu(self.a(x))*self.b(x))

def route_mode(phase):
    if phase=="train": return "soft"
    if phase=="prefill": return "top2"
    return "top1"

def route_weights(logits, mode):
    if mode == "top1":
        idx = logits.argmax(dim=-1, keepdim=True)
        return torch.zeros_like(logits).scatter_(-1, idx, 1.0), idx.squeeze(-1)
    if mode == "top2" and logits.size(-1) > 2:
        vals, idx = torch.topk(logits, k=2, dim=-1)
        sparse = torch.full_like(logits, float("-inf"))
        sparse.scatter_(-1, idx, vals)
        return torch.softmax(sparse, dim=-1), idx[..., 0]
    return torch.softmax(logits, dim=-1), logits.argmax(dim=-1)

class PackedQLAFV18(nn.Module):
    def __init__(self,cfg):
        super().__init__()
        self.cfg=cfg
        d,s=cfg.d_model,cfg.n_states
        self.packed=nn.Linear(d,s*d+s+d,bias=False)
        self.out=nn.Linear(d,d,bias=False)
        self.summary_proj=nn.Linear(d,d,bias=False)
        self.scale=nn.Parameter(torch.ones(s,d)/math.sqrt(d))
    def forward(self,x,phase,prev_summary=None):
        B,T,D=x.shape; S=self.cfg.n_states
        z=self.packed(x)
        raw=z[...,:S*D].view(B,T,S,D)
        logits=z[...,S*D:S*D+S]
        control=z[...,S*D+S:]
        w,rid=route_weights(logits,route_mode(phase))
        states=torch.tanh(raw)*self.scale.view(1,1,S,D)
        combined=torch.einsum("bts,btsd->btd",w,states)
        if phase=="decode_recurrent" and prev_summary is not None and T==1:
            combined = self.cfg.summary_mix*self.summary_proj(prev_summary).unsqueeze(1) + (1-self.cfg.summary_mix)*combined
        return self.out(combined), control, combined[:,-1,:], rid, w.max(dim=-1).values

class AIONV18(nn.Module):
    def __init__(self,d):
        super().__init__()
        self.branch=nn.Linear(d,3,bias=True); self.conf=nn.Linear(d,1,bias=True)
    def forward(self,c):
        h=torch.tanh(c)
        return torch.softmax(self.branch(h),dim=-1), torch.sigmoid(self.conf(h)).squeeze(-1)

class LocalV18(nn.Module):
    def __init__(self,cfg):
        super().__init__()
        d=cfg.d_model; self.cfg=cfg
        self.group=nn.Sequential(nn.Linear(d,d,bias=False),nn.GELU(),nn.Linear(d,d,bias=False))
        self.dw=nn.Conv1d(d,d,kernel_size=cfg.local_kernel,padding=cfg.local_kernel-1,groups=d,bias=False)
        self.pw=nn.Linear(d,d,bias=False); self.g=nn.Linear(d,d,bias=False)
    def forward(self,x):
        if self.cfg.grouped_local:
            y=self.group(x)
        else:
            y=self.dw(x.transpose(1,2))[:,:,:x.size(1)].transpose(1,2); y=self.pw(y)
        return y*torch.sigmoid(self.g(x))

class TSCV18(nn.Module):
    def __init__(self,cfg):
        super().__init__()
        d,r=cfg.d_model,cfg.tsc_rank
        self.r=r
        self.l=nn.Linear(d,r*d,bias=False); self.rg=nn.Linear(d,r,bias=False); self.o=nn.Linear(d,d,bias=False)
    def all(self,x):
        B,T,D=x.shape
        l=self.l(x).view(B,T,self.r,D)
        r=torch.softmax(self.rg(x),dim=-1).view(B,T,self.r,1)
        return self.o(torch.tanh((l*r).sum(dim=2)))
    def budget(self,x,conf,budget):
        if budget<=0: return torch.zeros_like(x)
        B,T,D=x.shape; k=max(1,int(T*budget))
        _,idx=torch.topk(-conf,k=k,dim=1)
        mask=torch.zeros(B,T,device=x.device,dtype=x.dtype); mask.scatter_(1,idx,1.0)
        return self.all(x)*mask.unsqueeze(-1)

def policy(cfg,phase,mode,seq_len):
    if phase!="train" and seq_len <= cfg.short_seq_cutoff:
        return dict(local=0,tsc=0,budget=0,ff=1)
    if mode=="survival":
        return dict(local=0,tsc=0,budget=0,ff=.70)
    if mode=="speed":
        if phase in ("decode_reference","decode_recurrent"):
            return dict(local=0,tsc=0,budget=0,ff=.85)
        if phase=="decode_chunk":
            return dict(local=.15,tsc=.05,budget=cfg.chunk_tsc_budget,ff=.90)
        return dict(local=.30,tsc=.10,budget=cfg.prefill_tsc_budget,ff=1)
    if mode=="balanced":
        if phase in ("decode_reference","decode_recurrent"):
            return dict(local=.10,tsc=0,budget=0,ff=.90)
        if phase=="decode_chunk":
            return dict(local=.30,tsc=.15,budget=cfg.chunk_tsc_budget,ff=1)
        return dict(local=.80,tsc=.35,budget=cfg.train_tsc_budget if phase=="train" else cfg.prefill_tsc_budget,ff=1)
    return dict(local=1,tsc=1,budget=1,ff=1)

class BlockV18(nn.Module):
    def __init__(self,cfg):
        super().__init__()
        self.cfg=cfg; d=cfg.d_model
        self.n1=RMSNorm(d); self.qlaf=PackedQLAFV18(cfg); self.aion=AIONV18(d)
        self.local=LocalV18(cfg); self.tsc=TSCV18(cfg); self.n2=RMSNorm(d); self.ff=SwiGLU(d,cfg.d_ff)
    def forward(self,x,phase,mode,prev=None):
        cfg=self.cfg; h=self.n1(x)
        prev_summary = prev.summary if prev is not None else None
        q,control,summary,rid,qconf=self.qlaf(h,phase,prev_summary)
        gate,aconf=self.aion(control); conf=.5*qconf+.5*aconf
        pol=policy(cfg,phase,mode,x.size(1))
        l=self.local(h)*pol["local"] if pol["local"]>0 else torch.zeros_like(q)
        if pol["tsc"]<=0: t=torch.zeros_like(q)
        elif pol["budget"]>=1: t=self.tsc.all(h)*pol["tsc"]
        else:
            t=self.tsc.budget(h,conf,pol["budget"])*pol["tsc"]
            if phase=="train":
                t=t*cfg.train_tsc_grad_scale + t.detach()*(1-cfg.train_tsc_grad_scale)
        fixed=cfg.qlaf_weight*q+cfg.local_weight*l+cfg.tsc_weight*t
        adapt=gate[...,0:1]*q+gate[...,1:2]*l+gate[...,2:3]*t
        x=x+(1-cfg.controller_mix)*fixed+cfg.controller_mix*adapt
        if pol["ff"]>0: x=x+self.ff(self.n2(x))*pol["ff"]
        return x,summary,rid,conf

class OdysseyGPUV18LM(nn.Module):
    def __init__(self,cfg):
        super().__init__()
        self.cfg=cfg
        self.tok=nn.Embedding(cfg.vocab_size,cfg.d_model); self.pos=nn.Embedding(cfg.max_seq_len,cfg.d_model)
        self.blocks=nn.ModuleList([BlockV18(cfg) for _ in range(cfg.n_layers)])
        self.norm=RMSNorm(cfg.d_model); self.head=nn.Linear(cfg.d_model,cfg.vocab_size,bias=False); self.head.weight=self.tok.weight
    def forward(self,idx,targets=None,phase="train",mode="balanced",cache=None):
        B,T=idx.shape
        if cache is not None: cache.validate(B,idx.device)
        pos_base = cache.token_count if (cache is not None and phase=="decode_recurrent") else 0
        pos=torch.clamp(pos_base+torch.arange(T,device=idx.device), max=self.cfg.max_seq_len-1).unsqueeze(0)
        x=self.tok(idx)+self.pos(pos)
        for i,b in enumerate(self.blocks):
            prev=cache.layers[i] if cache is not None else None
            x,s,r,c=b(x,phase,mode,prev)
            if cache is not None: cache.update(i,s,r,c)
        if cache is not None: cache.token_count += T if phase=="prefill" else 1
        x=self.norm(x); logits=self.head(x)
        loss=None
        if targets is not None: loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1))
        return logits,loss

class OdysseyV18Engine:
    def __init__(self,model):
        self.model=model; self.cfg=model.cfg
    def make_cache(self,batch_size,device,dtype):
        return OdysseyV18Cache(batch_size,self.cfg.n_layers,self.cfg.d_model,self.cfg.max_seq_len,device,dtype)
    @torch.no_grad()
    def prefill(self,idx,cache=None,mode="balanced"):
        self.model.eval(); return self.model(idx,phase="prefill",mode=mode,cache=cache)[0]
    @torch.no_grad()
    def decode_reference(self,idx,cache=None,mode="speed"):
        self.model.eval(); return self.model(idx,phase="decode_reference",mode=mode,cache=cache)[0][:,-1,:]
    @torch.no_grad()
    def decode_recurrent(self,token,cache,mode="speed"):
        self.model.eval(); return self.model(token,phase="decode_recurrent",mode=mode,cache=cache)[0][:,-1,:]
    def distill_recurrent_step(self,idx,targets,opt,mode="speed"):
        self.model.train(); opt.zero_grad(set_to_none=True)
        B,T=idx.shape
        cache=self.make_cache(B,idx.device,next(self.model.parameters()).dtype)
        with torch.no_grad():
            ref_logits,_=self.model(idx,phase="decode_reference",mode="balanced",cache=None)
            ref_last=ref_logits[:,-1,:].detach()
            self.prefill(idx[:,:max(1,T-1)],cache,mode="balanced")
        rec_logits,_=self.model(idx[:,-1:],phase="decode_recurrent",mode=mode,cache=cache)
        rec_last=rec_logits[:,-1,:]
        ce=F.cross_entropy(rec_last,targets[:,-1])
        kl=F.kl_div(F.log_softmax(rec_last,dim=-1),F.softmax(ref_last,dim=-1),reduction="batchmean")
        loss=ce+self.cfg.distill_alpha*kl
        loss.backward(); opt.step()
        return loss, ce.detach(), kl.detach()

def drift_metrics(reference_logits, recurrent_logits, k=5):
    ref=reference_logits.detach().float(); rec=recurrent_logits.detach().float()
    abs_err=(ref-rec).abs()
    kl=F.kl_div(F.log_softmax(rec,dim=-1),F.softmax(ref,dim=-1),reduction="batchmean")
    top1=(ref.argmax(dim=-1)==rec.argmax(dim=-1)).float().mean()
    ref_top=torch.topk(ref,k=k,dim=-1).indices
    rec_top=torch.topk(rec,k=k,dim=-1).indices
    overlap=[]
    for a,b in zip(ref_top,rec_top):
        overlap.append(len(set(a.tolist()).intersection(set(b.tolist())))/k)
    return {
        "mae": float(abs_err.mean().cpu()),
        "max_abs": float(abs_err.max().cpu()),
        "kl_ref_rec": float(kl.cpu()),
        "top1_agreement": float(top1.cpu()),
        "top5_overlap": float(torch.tensor(overlap).mean().cpu())
    }

class TransformerAttention(nn.Module):
    def __init__(self,cfg):
        super().__init__(); assert cfg.d_model%cfg.n_heads==0
        self.cfg=cfg; self.qkv=nn.Linear(cfg.d_model,3*cfg.d_model,bias=False); self.o=nn.Linear(cfg.d_model,cfg.d_model,bias=False)
    def forward(self,x):
        B,T,D=x.shape; H=self.cfg.n_heads; hd=D//H
        qkv=self.qkv(x).view(B,T,3,H,hd).transpose(1,3)
        q,k,v=qkv[:,:,0],qkv[:,:,1],qkv[:,:,2]
        y=F.scaled_dot_product_attention(q,k,v,is_causal=True)
        return self.o(y.transpose(1,2).contiguous().view(B,T,D))

class TransformerBlock(nn.Module):
    def __init__(self,cfg):
        super().__init__(); self.n1=RMSNorm(cfg.d_model); self.attn=TransformerAttention(cfg); self.n2=RMSNorm(cfg.d_model); self.ff=SwiGLU(cfg.d_model,cfg.d_ff)
    def forward(self,x): return x+self.attn(self.n1(x))+self.ff(self.n2(x))

class MatchedTransformerV18LM(nn.Module):
    def __init__(self,cfg):
        super().__init__(); self.cfg=cfg
        self.tok=nn.Embedding(cfg.vocab_size,cfg.d_model); self.pos=nn.Embedding(cfg.max_seq_len,cfg.d_model)
        self.blocks=nn.ModuleList([TransformerBlock(cfg) for _ in range(cfg.n_layers)])
        self.norm=RMSNorm(cfg.d_model); self.head=nn.Linear(cfg.d_model,cfg.vocab_size,bias=False); self.head.weight=self.tok.weight
    def forward(self,idx,targets=None,phase="train",mode="balanced",cache=None):
        B,T=idx.shape; pos=torch.arange(T,device=idx.device).unsqueeze(0)
        x=self.tok(idx)+self.pos(pos)
        for b in self.blocks: x=b(x)
        x=self.norm(x); logits=self.head(x)
        loss=None
        if targets is not None: loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1))
        return logits,loss

def count_params(m): return sum(p.numel() for p in m.parameters())
def maybe_compile(m,enabled):
    if not enabled: return m
    try: return torch.compile(m)
    except Exception as e:
        print("compile failed:",repr(e)); return m
