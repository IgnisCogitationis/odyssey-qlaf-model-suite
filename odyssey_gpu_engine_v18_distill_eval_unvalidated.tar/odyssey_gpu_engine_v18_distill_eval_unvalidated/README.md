# Odyssey GPU Engine v18 — Distillation + Drift Evaluation Pass

Status: **written and packaged, not CUDA/Triton validated in this environment**.

v18 continues from v17 and addresses the next production risk:

> Recurrent decode can be fast, but may drift from the full reference path. The engine needs built-in tools to measure and train away that drift.

v18 adds:

- `OdysseyGPUV18LM`
- `OdysseyV18Engine`
- recurrent decode cache
- reference-vs-recurrent drift metrics
- lean decode distillation loss
- teacher/student path comparison
- speed/quality serving modes
- benchmark script
- drift evaluation script
- minimal training script for recurrent distillation
- matched transformer baseline
- A100/H100 scripts

This is still a PyTorch reference package. The next layer after v18 is a Triton/CUDA kernel implementation.
