#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python smoke_test_v18.py --device cuda --dtype bf16 --size base
python evaluate_drift_v18.py --device cuda --dtype bf16 --size base --seqs 256 512 1024 2048 4096 --batch 8 --out results/v18_h100_drift.csv
python train_distill_v18.py --device cuda --dtype bf16 --size base --steps 100 --batch 8 --seq 1024 --out results/v18_h100_distill.csv
