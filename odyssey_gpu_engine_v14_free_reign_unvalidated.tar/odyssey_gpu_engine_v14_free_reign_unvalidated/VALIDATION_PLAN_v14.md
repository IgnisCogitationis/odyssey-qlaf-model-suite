# v14 Validation Plan

## Stage 1 — smoke

```bash
python smoke_test_v14.py --device cuda --dtype bf16 --size tiny
```

Pass criteria:
- forward loss finite
- backward finite
- decode produces logits
- no CUDA OOM

## Stage 2 — small GPU benchmark

```bash
python benchmark_v14_gpu.py --device cuda --dtype bf16 --size small --seqs 128 256 512 --batches 1 2
```

Pass criteria:
- CSVs written
- no OOM
- percent table generated

## Stage 3 — long context

```bash
python benchmark_v14_gpu.py --device cuda --dtype bf16 --size small --seqs 1024 2048 4096 --batches 1 2 4
```

Expected:
- Odyssey begins to beat transformer in prefill/decode.
- Train may be mixed.

## Stage 4 — pressure mode sweep

Compare:
- full
- balanced
- lean
- survival

Expected:
- survival fastest, lowest quality potential
- balanced best overall
- full slowest

## Stage 5 — compile

Add:
```bash
--compile
```

Expected:
- possible speed improvement
- possible failure if dynamic control path not static enough

## Stage 6 — quality validation

Train matched transformer and Odyssey:
- same tokenizer
- same corpus
- same tokens
- same optimizer
- same LR
- same seeds

Do not claim quality win without this.
