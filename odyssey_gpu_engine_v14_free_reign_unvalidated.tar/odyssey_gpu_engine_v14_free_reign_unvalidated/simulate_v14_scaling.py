import csv
from pathlib import Path

def est(seq,batch,d,layers,pressure):
    flash_factor = 0.22
    transformer = layers*batch*(seq*seq*d*flash_factor + seq*d*d*2.4)
    qlaf = layers*batch*(seq*d*d*1.85 + seq*d*4*0.2)
    local = layers*batch*seq*d*0.25
    tsc = layers*batch*seq*d*0.0
    if pressure == "full": tsc = layers*batch*seq*d*0.45
    elif pressure == "balanced": tsc = layers*batch*seq*d*0.12
    elif pressure == "lean": tsc = layers*batch*seq*d*0.02; local *= 0.2
    elif pressure == "survival": local=0; tsc=0
    od = qlaf+local+tsc
    return transformer/od

def main():
    rows=[]
    for d,layers in [(256,4),(512,8),(768,12),(1024,16)]:
        for seq in [64,128,256,512,1024,2048,4096,8192,16384]:
            for batch in [1,2,4,8,16]:
                for pressure in ["full","balanced","lean","survival"]:
                    ratio=est(seq,batch,d,layers,pressure)
                    rows.append({"d_model":d,"layers":layers,"seq":seq,"batch":batch,"pressure":pressure,"estimated_speed_ratio_transformer_over_odyssey":ratio,"estimated_percent_speedup":(ratio-1)*100})
    out=Path("results/v14_scaling_estimates.csv"); out.parent.mkdir(exist_ok=True)
    with open(out,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print("WROTE",out)

if __name__=="__main__":
    main()
