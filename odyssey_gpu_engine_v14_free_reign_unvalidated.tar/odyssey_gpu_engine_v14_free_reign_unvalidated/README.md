# Odyssey GPU Engine v14 — Free-Reign Engineering Pass

Status: **written and packaged, not CUDA/Triton validated in this environment**.

This package is a full design-and-code pass over the Odyssey / QLAF / AION / TSC GPU engine. It keeps the ideas most likely to scale on A100/H100-style GPUs and removes or demotes ideas likely to fail under real GPU pressure.

## Core decision

The engine should not be a CPU-style branchy architecture moved to GPU.

The engine should be:

```text
packed QLAF tensor-core path
+ controller-only AION policy
+ optional budgeted TSC correction
+ small local/MLP branch
+ explicit train/prefill/decode kernels
+ pressure modes
+ validation harness
```

## Files

- `odyssey_gpu_v14.py` — revised engine implementation
- `ENGINE_AUDIT_v14.md` — smallest-to-biggest subsystem audit
- `FAILURE_MODES_AND_FIXES_v14.md` — scaled GPU failure map
- `VALIDATION_PLAN_v14.md` — exact A100/H100 test order
- `benchmark_v14_gpu.py` — GPU benchmark runner
- `simulate_v14_scaling.py` — analytical scale simulator
- `smoke_test_v14.py` — smoke test
- `run_a100_v14.sh` — A100 script
- `run_h100_v14.sh` — H100 script
- `requirements.txt`
- `SHA256SUMS.txt`

## Quick start

```bash
pip install -r requirements.txt
python smoke_test_v14.py --device cuda --dtype bf16
bash run_a100_v14.sh
```

## CPU fallback

```bash
python smoke_test_v14.py --device cpu --dtype fp32
python benchmark_v14_gpu.py --device cpu --dtype fp32 --size tiny --seqs 64 128 --batches 1 --trials 2 --warmup 1
```

## Important

The package includes optional kernel boundaries and execution policy hooks. It does **not** claim validated GPU performance until run on real GPU hardware.
