import argparse, csv, json, platform, time
from pathlib import Path
import torch
from odyssey_gpu_v14 import OdysseyGPUV14LM, MatchedTransformerV14LM, preset_v14, count_params, maybe_compile

def sync(device):
    if device.type == "cuda": torch.cuda.synchronize()

def timeit(fn, device, warmup, trials):
    for _ in range(warmup): fn()
    sync(device)
    vals=[]
    for _ in range(trials):
        t0=time.perf_counter(); fn(); sync(device); vals.append(time.perf_counter()-t0)
    return sum(vals)/len(vals), min(vals), max(vals)

def case(model, name, cfg, mode, pressure, batch, seq, device, dtype, warmup, trials):
    amp = device.type=="cuda" and dtype != torch.float32
    x=torch.randint(0,cfg.vocab_size,(batch,seq),device=device)
    y=torch.randint(0,cfg.vocab_size,(batch,seq),device=device)
    if mode == "train":
        opt=torch.optim.AdamW(model.parameters(),lr=1e-4)
        model.train()
        def fn():
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
                _,loss=model(x,y,phase="train",pressure=pressure)
            loss.backward(); opt.step()
    else:
        phase = "prefill" if mode == "prefill" else "decode"
        model.eval()
        def fn():
            with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
                model(x,None,phase=phase,pressure=pressure)
    if device.type=="cuda": torch.cuda.reset_peak_memory_stats()
    avg,mn,mx=timeit(fn,device,warmup,trials)
    mem=torch.cuda.max_memory_allocated()/1024/1024 if device.type=="cuda" else 0.0
    return {"model":name,"mode":mode,"pressure":pressure,"batch":batch,"seq":seq,"avg_s":avg,"min_s":mn,"max_s":mx,"tokens_per_s":batch*seq/avg,"peak_mem_mb":mem,"params":count_params(model)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--device",default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--dtype",default="bf16",choices=["fp32","fp16","bf16"])
    ap.add_argument("--size",default="small",choices=["tiny","small","base","large"])
    ap.add_argument("--seqs",nargs="+",type=int,default=[128,256,512,1024])
    ap.add_argument("--batches",nargs="+",type=int,default=[1,2])
    ap.add_argument("--modes",nargs="+",default=["prefill","decode","train"])
    ap.add_argument("--pressures",nargs="+",default=["balanced","lean","survival"])
    ap.add_argument("--warmup",type=int,default=5)
    ap.add_argument("--trials",type=int,default=10)
    ap.add_argument("--compile",action="store_true")
    ap.add_argument("--out",default="results/v14_gpu_raw.csv")
    args=ap.parse_args()
    device=torch.device(args.device)
    dtype={"fp32":torch.float32,"fp16":torch.float16,"bf16":torch.bfloat16}[args.dtype]
    cfg=preset_v14(args.size,vocab_size=8192,max_seq_len=max(args.seqs))
    Path(args.out).parent.mkdir(parents=True,exist_ok=True)
    env={"python":platform.python_version(),"torch":torch.__version__,"cuda":torch.cuda.is_available(),"gpu":torch.cuda.get_device_name() if torch.cuda.is_available() and device.type=="cuda" else None,"cfg":cfg.__dict__}
    Path(args.out).with_name("v14_environment.json").write_text(json.dumps(env,indent=2))
    rows=[]
    for batch in args.batches:
        for seq in args.seqs:
            for mode in args.modes:
                for pressure in args.pressures:
                    for name,cls in [("transformer",MatchedTransformerV14LM),("odyssey_v14",OdysseyGPUV14LM)]:
                        m=maybe_compile(cls(cfg).to(device),args.compile)
                        try:
                            r=case(m,name,cfg,mode,pressure,batch,seq,device,dtype,args.warmup,args.trials)
                            rows.append(r); print(r)
                        except RuntimeError as e:
                            print("SKIP",name,mode,pressure,batch,seq,repr(e))
                        del m
                        if device.type=="cuda": torch.cuda.empty_cache()
    with open(args.out,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    by={}
    for r in rows:
        by.setdefault((r["mode"],r["pressure"],r["batch"],r["seq"]),{})[r["model"]]=r
    pct=[]
    for k,d in by.items():
        if "transformer" not in d: continue
        base=d["transformer"]["avg_s"]
        for model,r in d.items():
            pct.append({"mode":k[0],"pressure":k[1],"batch":k[2],"seq":k[3],"model":model,"avg_s":r["avg_s"],"transformer_avg_s":base,"speed_ratio_vs_transformer":base/r["avg_s"],"percent_speedup_vs_transformer":(base/r["avg_s"]-1)*100,"tokens_per_s":r["tokens_per_s"],"peak_mem_mb":r["peak_mem_mb"]})
    pct_path=Path(args.out).with_name("v14_percent_vs_transformer.csv")
    with open(pct_path,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(pct[0].keys())); w.writeheader(); w.writerows(pct)
    print("WROTE",args.out); print("WROTE",pct_path)

if __name__=="__main__":
    main()
