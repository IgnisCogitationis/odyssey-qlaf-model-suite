#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python smoke_test_v14.py --device cuda --dtype bf16 --size small
python benchmark_v14_gpu.py \
  --device cuda \
  --dtype bf16 \
  --size small \
  --seqs 128 256 512 1024 2048 4096 \
  --batches 1 2 4 \
  --modes prefill decode train \
  --pressures balanced lean survival \
  --warmup 10 \
  --trials 20 \
  --out results/v14_a100_raw.csv
python simulate_v14_scaling.py
