from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional, Tuple, Dict
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

Phase = Literal["train", "prefill", "decode", "decode_chunk"]
Pressure = Literal["full", "balanced", "lean", "survival"]


@dataclass
class V14Config:
    vocab_size: int = 8192
    d_model: int = 512
    n_layers: int = 8
    n_heads: int = 8
    d_ff: int = 2048
    max_seq_len: int = 4096
    dropout: float = 0.0

    n_states: int = 4
    tsc_rank: int = 4

    qlaf_weight: float = 0.82
    local_weight: float = 0.13
    tsc_weight: float = 0.05
    controller_mix: float = 0.08

    train_route: str = "soft"
    prefill_route: str = "top2"
    decode_route: str = "top1"

    tsc_budget_train: float = 0.125
    tsc_budget_prefill: float = 0.125
    tsc_budget_decode: float = 0.03125
    train_tsc_grad_scale: float = 0.35

    local_kernel: int = 5
    use_grouped_local: bool = True
    qlaf_only_short_seq_cutoff: int = 128


def preset_v14(size: str = "small", **overrides) -> V14Config:
    presets = {
        "tiny": dict(d_model=128, n_layers=2, n_heads=4, d_ff=512, max_seq_len=2048, n_states=4, tsc_rank=4),
        "small": dict(d_model=256, n_layers=4, n_heads=4, d_ff=1024, max_seq_len=4096, n_states=4, tsc_rank=4),
        "base": dict(d_model=512, n_layers=8, n_heads=8, d_ff=2048, max_seq_len=4096, n_states=4, tsc_rank=4),
        "large": dict(d_model=768, n_layers=12, n_heads=12, d_ff=3072, max_seq_len=8192, n_states=6, tsc_rank=6),
    }
    kw = presets.get(size, presets["small"]).copy()
    kw.update(overrides)
    return V14Config(**kw)


class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(d))
        self.eps = eps

    def forward(self, x):
        return x * torch.rsqrt(x.square().mean(dim=-1, keepdim=True) + self.eps) * self.weight


class SwiGLU(nn.Module):
    def __init__(self, d, ff):
        super().__init__()
        self.w1 = nn.Linear(d, ff, bias=False)
        self.w2 = nn.Linear(d, ff, bias=False)
        self.w3 = nn.Linear(ff, d, bias=False)

    def forward(self, x):
        return self.w3(F.silu(self.w1(x)) * self.w2(x))


def route_weights(logits: torch.Tensor, mode: str) -> torch.Tensor:
    if mode == "top1":
        idx = logits.argmax(dim=-1, keepdim=True)
        return torch.zeros_like(logits).scatter_(-1, idx, 1.0)
    if mode == "top2" and logits.size(-1) > 2:
        vals, idx = torch.topk(logits, k=2, dim=-1)
        sparse = torch.full_like(logits, float("-inf"))
        sparse.scatter_(-1, idx, vals)
        return torch.softmax(sparse, dim=-1)
    return torch.softmax(logits, dim=-1)


class PackedQLAFV14(nn.Module):
    """
    Packed QLAF path.

    Produces state candidates, route logits, and controller features from one projection.
    This is the core engine path.
    """
    def __init__(self, cfg: V14Config):
        super().__init__()
        self.cfg = cfg
        d, s = cfg.d_model, cfg.n_states
        packed_dim = s * d + s + d
        self.packed = nn.Linear(d, packed_dim, bias=False)
        self.out = nn.Linear(d, d, bias=False)
        self.scale = nn.Parameter(torch.ones(s, d) / math.sqrt(d))

    def forward(self, x, phase: Phase) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        cfg = self.cfg
        B, T, D = x.shape
        S = cfg.n_states

        z = self.packed(x)
        state_raw = z[..., :S*D].view(B, T, S, D)
        logits = z[..., S*D:S*D+S]
        control = z[..., S*D+S:]

        if phase == "train":
            mode = cfg.train_route
        elif phase == "prefill":
            mode = cfg.prefill_route
        else:
            mode = cfg.decode_route

        w = route_weights(logits, mode)
        states = torch.tanh(state_raw) * self.scale.view(1, 1, S, D)
        combined = torch.einsum("bts,btsd->btd", w, states)
        return self.out(combined), logits, control


class AIONPolicyV14(nn.Module):
    """
    AION as control plane only.
    """
    def __init__(self, d):
        super().__init__()
        self.branch = nn.Linear(d, 3, bias=True)
        self.conf = nn.Linear(d, 1, bias=True)
        self.pressure = nn.Linear(d, 4, bias=True)

    def forward(self, control):
        branch = torch.softmax(self.branch(torch.tanh(control)), dim=-1)
        confidence = torch.sigmoid(self.conf(control)).squeeze(-1)
        pressure_logits = self.pressure(control).mean(dim=1)
        return branch, confidence, pressure_logits


class LocalMixerV14(nn.Module):
    def __init__(self, cfg: V14Config):
        super().__init__()
        d = cfg.d_model
        self.cfg = cfg
        self.dw = nn.Conv1d(d, d, kernel_size=cfg.local_kernel, groups=d, padding=cfg.local_kernel-1, bias=False)
        self.pw = nn.Linear(d, d, bias=False)
        self.grouped = nn.Sequential(
            nn.Linear(d, d, bias=False),
            nn.GELU(),
            nn.Linear(d, d, bias=False),
        )
        self.gate = nn.Linear(d, d, bias=False)

    def forward(self, x):
        if self.cfg.use_grouped_local:
            y = self.grouped(x)
        else:
            y = self.dw(x.transpose(1, 2))[:, :, :x.size(1)].transpose(1, 2)
            y = self.pw(y)
        return y * torch.sigmoid(self.gate(x))


class BudgetTSCV14(nn.Module):
    def __init__(self, cfg: V14Config):
        super().__init__()
        d, r = cfg.d_model, cfg.tsc_rank
        self.d, self.r = d, r
        self.l = nn.Linear(d, r*d, bias=False)
        self.rg = nn.Linear(d, r, bias=False)
        self.o = nn.Linear(d, d, bias=False)

    def forward_all(self, x):
        B, T, D = x.shape
        l = self.l(x).view(B, T, self.r, D)
        r = torch.softmax(self.rg(x), dim=-1).view(B, T, self.r, 1)
        return self.o(torch.tanh((l*r).sum(dim=2)))

    def forward_budget(self, x, confidence, budget: float):
        if budget <= 0:
            return torch.zeros_like(x)
        B, T, D = x.shape
        k = max(1, int(T * budget))
        # low confidence gets correction
        _, idx = torch.topk(-confidence, k=k, dim=1)
        mask = torch.zeros(B, T, device=x.device, dtype=x.dtype)
        mask.scatter_(1, idx, 1.0)
        return self.forward_all(x) * mask.unsqueeze(-1)


class V14Policy:
    @staticmethod
    def branch_scales(cfg: V14Config, phase: Phase, pressure: Pressure, seq_len: int) -> Dict[str, float]:
        # Short seq: avoid overhead unless training.
        if phase != "train" and seq_len <= cfg.qlaf_only_short_seq_cutoff:
            return {"local": 0.0, "tsc": 0.0, "budget": 0.0, "ff": 1.0}

        if pressure == "survival":
            return {"local": 0.0, "tsc": 0.0, "budget": 0.0, "ff": 0.75}
        if pressure == "lean":
            if phase in ("decode", "decode_chunk"):
                return {"local": 0.15, "tsc": 0.0, "budget": 0.0, "ff": 0.90}
            return {"local": 0.35, "tsc": 0.15, "budget": cfg.tsc_budget_train if phase == "train" else cfg.tsc_budget_prefill, "ff": 1.0}
        if pressure == "balanced":
            if phase in ("decode", "decode_chunk"):
                return {"local": 0.50, "tsc": 0.25, "budget": cfg.tsc_budget_decode, "ff": 1.0}
            return {"local": 1.0, "tsc": 0.50, "budget": cfg.tsc_budget_train if phase == "train" else cfg.tsc_budget_prefill, "ff": 1.0}
        return {"local": 1.0, "tsc": 1.0, "budget": 1.0, "ff": 1.0}


class OdysseyBlockV14(nn.Module):
    def __init__(self, cfg: V14Config):
        super().__init__()
        self.cfg = cfg
        d = cfg.d_model
        self.n1 = RMSNorm(d)
        self.qlaf = PackedQLAFV14(cfg)
        self.aion = AIONPolicyV14(d)
        self.local = LocalMixerV14(cfg)
        self.tsc = BudgetTSCV14(cfg)
        self.n2 = RMSNorm(d)
        self.ff = SwiGLU(d, cfg.d_ff)
        self.drop = nn.Dropout(cfg.dropout)

    def forward(self, x, phase: Phase, pressure: Pressure):
        cfg = self.cfg
        h = self.n1(x)
        q, route_logits, control = self.qlaf(h, phase)
        branch_gate, confidence, pressure_logits = self.aion(control)
        scales = V14Policy.branch_scales(cfg, phase, pressure, x.size(1))

        if scales["local"] > 0:
            l = self.local(h) * scales["local"]
        else:
            l = torch.zeros_like(q)

        if scales["tsc"] <= 0:
            t = torch.zeros_like(q)
        elif scales["budget"] >= 1.0:
            t = self.tsc.forward_all(h) * scales["tsc"]
        else:
            t = self.tsc.forward_budget(h, confidence, scales["budget"]) * scales["tsc"]
            if phase == "train":
                t = t * cfg.train_tsc_grad_scale + t.detach() * (1.0 - cfg.train_tsc_grad_scale)

        fixed = cfg.qlaf_weight*q + cfg.local_weight*l + cfg.tsc_weight*t
        adaptive = branch_gate[...,0:1]*q + branch_gate[...,1:2]*l + branch_gate[...,2:3]*t
        y = (1-cfg.controller_mix)*fixed + cfg.controller_mix*adaptive

        x = x + self.drop(y)
        if scales["ff"] > 0:
            x = x + self.drop(self.ff(self.n2(x)) * scales["ff"])
        return x


class OdysseyGPUV14LM(nn.Module):
    def __init__(self, cfg: V14Config):
        super().__init__()
        self.cfg = cfg
        self.tok = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.pos = nn.Embedding(cfg.max_seq_len, cfg.d_model)
        self.blocks = nn.ModuleList([OdysseyBlockV14(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.head.weight = self.tok.weight

    def forward(self, idx, targets=None, phase: Phase="train", pressure: Pressure="balanced"):
        B, T = idx.shape
        if T > self.cfg.max_seq_len:
            raise ValueError("sequence too long")
        pos = torch.arange(T, device=idx.device).unsqueeze(0)
        x = self.tok(idx) + self.pos(pos)
        for block in self.blocks:
            x = block(x, phase, pressure)
        x = self.norm(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss

    @torch.no_grad()
    def generate(self, idx, steps: int, pressure: Pressure="lean", temperature: float=1.0):
        self.eval()
        for _ in range(steps):
            ctx = idx[:, -self.cfg.max_seq_len:]
            logits, _ = self.forward(ctx, phase="decode", pressure=pressure)
            probs = torch.softmax(logits[:, -1, :] / max(temperature, 1e-6), dim=-1)
            nxt = torch.multinomial(probs, 1)
            idx = torch.cat([idx, nxt], dim=1)
        return idx


class TransformerAttentionV14(nn.Module):
    def __init__(self, cfg: V14Config):
        super().__init__()
        assert cfg.d_model % cfg.n_heads == 0
        self.cfg = cfg
        self.qkv = nn.Linear(cfg.d_model, 3*cfg.d_model, bias=False)
        self.o = nn.Linear(cfg.d_model, cfg.d_model, bias=False)

    def forward(self, x):
        B,T,D = x.shape
        H = self.cfg.n_heads
        hd = D // H
        qkv = self.qkv(x).view(B,T,3,H,hd).transpose(1,3)
        q,k,v = qkv[:,:,0], qkv[:,:,1], qkv[:,:,2]
        y = F.scaled_dot_product_attention(q,k,v,is_causal=True)
        return self.o(y.transpose(1,2).contiguous().view(B,T,D))


class TransformerBlockV14(nn.Module):
    def __init__(self, cfg: V14Config):
        super().__init__()
        self.n1 = RMSNorm(cfg.d_model)
        self.attn = TransformerAttentionV14(cfg)
        self.n2 = RMSNorm(cfg.d_model)
        self.ff = SwiGLU(cfg.d_model, cfg.d_ff)

    def forward(self, x):
        x = x + self.attn(self.n1(x))
        x = x + self.ff(self.n2(x))
        return x


class MatchedTransformerV14LM(nn.Module):
    def __init__(self, cfg: V14Config):
        super().__init__()
        self.cfg = cfg
        self.tok = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.pos = nn.Embedding(cfg.max_seq_len, cfg.d_model)
        self.blocks = nn.ModuleList([TransformerBlockV14(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.head.weight = self.tok.weight

    def forward(self, idx, targets=None, phase: Phase="train", pressure: Pressure="balanced"):
        B,T = idx.shape
        pos = torch.arange(T, device=idx.device).unsqueeze(0)
        x = self.tok(idx) + self.pos(pos)
        for block in self.blocks:
            x = block(x)
        x = self.norm(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss


def count_params(model):
    return sum(p.numel() for p in model.parameters())


def maybe_compile(model, enabled):
    if not enabled:
        return model
    try:
        return torch.compile(model)
    except Exception as e:
        print("compile failed, using eager:", repr(e))
        return model
