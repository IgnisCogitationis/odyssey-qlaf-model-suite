# GPU Failure Modes and Fixes

## Failure 1: Transformer wins at short sequence

Cause:
- FlashAttention is highly optimized.
- Odyssey has branch overhead.

Fix:
- Use QLAF-only survival for short sequence.
- Disable TSC.
- Disable local branch if batch/seq small.
- Compile decode path.
- Use larger batch or longer seq for fair scaling comparisons.

## Failure 2: QLAF underutilizes tensor cores

Cause:
- state projections too small or split.

Fix:
- one packed projection.
- dimensions divisible by 64/128.
- BF16.
- avoid Python-side branch loops.

## Failure 3: TSC destroys training speed

Cause:
- low-rank correction backward path active everywhere.

Fix:
- budgeted tokens.
- partial gradient scale.
- detach option.
- delayed TSC warmup.
- TSC only after CE stabilizes.

## Failure 4: Dynamic routing breaks compile

Cause:
- Python branching and variable top-k.

Fix:
- fixed routing modes per phase.
- static pressure mode during benchmark.
- separate compiled functions for decode/prefill/train.

## Failure 5: Memory explosion at long context

Cause:
- materializing `[B,T,S,D]`.
- storing branch intermediates.

Fix:
- compact state combine.
- activation checkpoint.
- survival mode.
- fused state combine output.

## Failure 6: Quality loss from QLAF-only serving

Cause:
- correction branch disabled too often.

Fix:
- refresh cadence.
- low-confidence TSC.
- chunk-level TSC.
- distill balanced path into lean path.

## Failure 7: AION becomes overhead

Cause:
- controller too large.

Fix:
- reuse QLAF packed features.
- one gate only.
- chunk-level policy.

## Failure 8: Local mixer weak on GPU

Cause:
- depthwise conv not tensor-core dominant.

Fix:
- optional grouped-linear local mixer.
- disable under lean/survival.
- use local branch mainly for quality, not speed.

## Failure 9: Decode cache not real

Cause:
- full sequence recomputed for each token.

Fix:
- production decode must cache:
  - recent hidden state
  - route id
  - controller confidence
  - compact QLAF state
  - refresh metadata

## Failure 10: Benchmark overclaims

Cause:
- CPU/eager results used as GPU proof.

Fix:
- label estimates as estimates.
- require A100/H100 CSVs.
- compare against FlashAttention transformer.
