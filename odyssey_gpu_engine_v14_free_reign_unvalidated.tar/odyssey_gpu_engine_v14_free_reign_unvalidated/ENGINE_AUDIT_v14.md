# Odyssey GPU Engine v14 — Full Engineering Audit

## Executive verdict

The best scaled GPU engine should keep:

1. QLAF as the dominant fast path.
2. AION as a controller, not a full branch.
3. TSC as adaptive correction, not always-on compute.
4. Packed projections and tensor-core-friendly matrix shapes.
5. Separate phase policies for train, prefill, decode, and survival.
6. Fallback transformer only as a baseline and optional rescue path.

The engine should remove or demote:

1. Many small projections.
2. Token-level dynamic branches that break fusion.
3. Always-on TSC.
4. Heavy AION compute.
5. CPU-style Python control inside hot decode loops.
6. Generic forward path for all phases.

---

# 1. Smallest-level details

## Tensor shapes

Bad:
```text
[B,T,S,D] materialized repeatedly
many reshape/einsum/projection operations
```

Better:
```text
one packed [B*T,D] -> [B*T, packed_dim] GEMM
state combine immediately
output projection immediately
```

Best future:
```text
single fused QLAF state-combine-output kernel
```

## Data type

Default GPU dtype should be BF16 on A100/H100. FP16 may be faster but less stable. FP32 should be debug only.

## Alignment

Use dimensions divisible by 64 or 128 where possible:
- 256
- 512
- 768
- 1024

Avoid awkward state/rank sizes that create poor matmul tiles.

## Kernel launch count

Every small branch costs. The target is:
- one packed QLAF projection
- one local branch only when useful
- one TSC branch only when policy activates
- one FFN
- one output projection

## Routing

Token-level routing is expressive but expensive. Use:
- top-1 routing for decode
- top-2 routing for prefill
- soft routing for training only
- chunk-level routing where possible

---

# 2. Module-level audit

## QLAF

Keep. This is the core GPU advantage if fused.

Changes:
- Make it packed.
- Make routing mode phase-specific.
- Avoid materializing states outside debug path.
- Add chunk-routing option.
- Add QLAF-only survival path.

## AION

Keep but shrink. It should not be a compute branch.

Changes:
- Use AION only to control:
  - TSC budget
  - pressure mode
  - routing softness
  - local branch scale
  - decode refresh cadence
- Reuse QLAF control features.
- Do not create separate deep AION tower.

## RKHS / operator concepts

Keep as theory/control framing, not heavy literal compute.

Changes:
- Express as learned operator features and norms.
- Avoid expensive kernels unless justified by quality.

## TSC

Keep as 0–10% correction.

Changes:
- Budgeted activation.
- Low-rank only.
- Off by default in survival.
- Lean gradient in training.
- Adaptive in decode.

## Local mixer

Keep small.

Changes:
- Use either depthwise conv fallback or grouped linear local mixer.
- Benchmark both.
- Disable in survival.

## MLP

Keep. It uses tensor cores well.

Changes:
- SwiGLU preferred.
- Consider FFN expansion lower than transformer if QLAF carries more sequence work.

---

# 3. Engine-level audit

## Prefill

Goal:
- build compact state summaries.
- use top-2 routing.
- allow TSC budget if confidence low.

## Decode

Goal:
- top-1 QLAF.
- TSC mostly off.
- cached AION decisions.
- no full sequence recompute in production path.

## Training

Goal:
- soft QLAF routing for gradients.
- budgeted TSC.
- partial TSC gradient.
- checkpoint QLAF if memory pressure.

## Memory pressure

Modes:
- full: maximum quality
- balanced: default
- lean: serving default
- survival: QLAF-only

---

# 4. Biggest-level architecture

Best production architecture:

```text
Odyssey GPU v14
  QLAF packed state engine
  AION control plane
  TSC adaptive correction
  Local/MLP residual branch
  Phase scheduler
  Pressure controller
  Benchmark/telemetry harness
```

Best split:

```text
Training path: balanced/full, soft routing, TSC budget
Serving path: lean/survival, top-1 routing, TSC off/adaptive
Evaluation path: balanced, deterministic routing
```

---

# 5. What will beat transformer furthest

Most likely:
- long-context decode
- long-context prefill
- memory-constrained serving
- batch decode at 1024+
- survival mode under pressure

Least likely:
- sequence length 64–128
- tiny batch
- uncompiled eager PyTorch
- naive TSC always-on training

---

# 6. Final v14 design choices

v14 overwrites v13 behavior by:

1. Making branch policy more explicit.
2. Adding chunk routing.
3. Adding QLAF-only fast exit.
4. Adding a stricter pressure controller.
5. Adding fused-kernel boundary functions.
6. Adding runtime telemetry hooks.
7. Adding model-size recommendations.
