import argparse,csv,time,torch
from pathlib import Path
from odyssey_engine import OdysseyGPUV23LM, OdysseyEngineV23, preset_v23

def sync(device):
    if device.type=="cuda": torch.cuda.synchronize()

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--device",default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--dtype",default="bf16",choices=["fp32","fp16","bf16"])
    p.add_argument("--size",default="small")
    p.add_argument("--batch",type=int,default=4)
    p.add_argument("--context",type=int,default=1024)
    p.add_argument("--steps",type=int,default=128)
    p.add_argument("--trials",type=int,default=10)
    p.add_argument("--out",default="results/v23_decode.csv")
    a=p.parse_args()
    device=torch.device(a.device); dtype={"fp32":torch.float32,"fp16":torch.float16,"bf16":torch.bfloat16}[a.dtype]
    amp=device.type=="cuda" and dtype!=torch.float32
    cfg=preset_v23(a.size,vocab_size=8192,max_seq_len=a.context+a.steps+8)
    model=OdysseyGPUV23LM(cfg).to(device).eval(); eng=OdysseyEngineV23(model); rows=[]
    for trial in range(a.trials):
        x=torch.randint(0,cfg.vocab_size,(a.batch,a.context),device=device)
        token=torch.randint(0,cfg.vocab_size,(a.batch,1),device=device)
        cache=eng.make_cache(a.batch,device,dtype)
        with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp): eng.prefill(x,cache)
        sync(device); t0=time.perf_counter()
        for _ in range(a.steps):
            with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
                logits=eng.decode_recurrent(token,cache); token=logits.argmax(dim=-1,keepdim=True)
        sync(device); avg=(time.perf_counter()-t0)/a.steps
        row={"trial":trial,"batch":a.batch,"context":a.context,"avg_decode_s":avg,"tokens_per_s":a.batch/avg}
        rows.append(row); print(row)
    Path(a.out).parent.mkdir(parents=True,exist_ok=True)
    with open(a.out,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print("WROTE",a.out)
if __name__=="__main__": main()
