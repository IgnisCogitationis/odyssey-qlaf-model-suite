# Odyssey GPU Engine v23 Model Card

## Status
Reference implementation. Not yet CUDA/Triton/TensorRT validated.

## Intended use
Research, benchmarking, contractor kernel implementation, recurrent decode experiments.

## Primary architecture
Packed QLAF + AION controller + budgeted TSC + recurrent summary decode.

## Not intended as
A verified production model or proven transformer replacement until GPU validation is complete.
