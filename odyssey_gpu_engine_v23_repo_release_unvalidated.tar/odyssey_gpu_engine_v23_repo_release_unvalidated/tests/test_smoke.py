import torch
from odyssey_engine import OdysseyGPUV23LM, OdysseyEngineV23, preset_v23

def test_tiny_forward_decode_cpu():
    cfg=preset_v23("tiny",vocab_size=128,max_seq_len=64)
    m=OdysseyGPUV23LM(cfg)
    x=torch.randint(0,cfg.vocab_size,(1,16))
    logits,loss=m(x,x,phase="train",mode="balanced")
    assert logits.shape==(1,16,cfg.vocab_size)
    assert loss is not None
    eng=OdysseyEngineV23(m)
    cache=eng.make_cache(1,torch.device("cpu"),torch.float32)
    eng.prefill(x[:,:8],cache)
    y=eng.decode_recurrent(x[:,8:9],cache)
    assert y.shape==(1,cfg.vocab_size)
