# Contractor Handoff v23

Priority order:

1. Run `python -m odyssey_engine.validate --device cuda --dtype bf16`.
2. Run `python scripts/benchmark_decode.py --device cuda --dtype bf16`.
3. Replace `odyssey_engine/kernels.py::qlaf_decode_only` with Triton/CUDA.
4. Verify numerical equivalence to PyTorch reference.
5. Add CUDA graph replay.
6. Flatten cache summaries for TensorRT.
7. Add FlashAttention-2 transformer baseline.
8. Return CSVs, environment report, and profiler traces.
