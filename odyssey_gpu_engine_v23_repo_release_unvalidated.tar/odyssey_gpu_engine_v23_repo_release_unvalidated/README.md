# Odyssey GPU Engine v23 — Repo Release Candidate

Status: written and packaged, not CUDA/Triton/TensorRT validated here.

v23 turns the v22 engine into a cleaner GitHub/contractor-ready repository layout.

## Adds

- installable Python package layout
- `odyssey_engine` module
- pytest smoke tests
- benchmark configs
- model card
- kernel API boundary
- export scaffold
- A100/H100 scripts
- release checklist
- contractor handoff
- SHA256 manifest

## Core target

```text
balanced prefill
+ speed recurrent decode
+ top1 QLAF route
+ fused decode kernel API
+ TensorRT plugin path
+ FlashAttention baseline check
```

## Run

```bash
pip install -e .
python -m odyssey_engine.validate --device cuda --dtype bf16
python scripts/benchmark_decode.py --device cuda --dtype bf16
```
