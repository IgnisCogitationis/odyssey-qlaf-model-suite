# Release Checklist v23

- [ ] Run CPU smoke test
- [ ] Run CUDA BF16 smoke test
- [ ] Run A100 decode benchmark
- [ ] Run H100 decode benchmark
- [ ] Add FlashAttention baseline
- [ ] Implement Triton decode kernel
- [ ] Validate kernel equivalence
- [ ] Add license
- [ ] Add model card
- [ ] Add raw CSV benchmark outputs
