import argparse, torch
from .model import OdysseyGPUV23LM, OdysseyEngineV23, preset_v23, drift_metrics, count_params

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--device",default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--dtype",default="bf16",choices=["fp32","fp16","bf16"])
    p.add_argument("--size",default="tiny")
    a=p.parse_args()
    device=torch.device(a.device)
    dtype={"fp32":torch.float32,"fp16":torch.float16,"bf16":torch.bfloat16}[a.dtype]
    amp=device.type=="cuda" and dtype!=torch.float32
    cfg=preset_v23(a.size,vocab_size=2048,max_seq_len=256)
    m=OdysseyGPUV23LM(cfg).to(device)
    x=torch.randint(0,cfg.vocab_size,(2,64),device=device); y=torch.randint(0,cfg.vocab_size,(2,64),device=device)
    opt=torch.optim.AdamW(m.parameters(),lr=1e-4)
    with torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
        _,loss=m(x,y,phase="train",mode="balanced")
    assert torch.isfinite(loss); loss.backward(); opt.step()
    eng=OdysseyEngineV23(m); cache=eng.make_cache(2,device,dtype)
    with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
        eng.prefill(x[:,:32],cache)
        ref=eng.decode_reference(x[:,:33])
        rec=eng.decode_recurrent(x[:,32:33],cache)
    print({"status":"PASS","params":count_params(m),"loss":float(loss.detach().cpu()),"drift":drift_metrics(ref,rec)})
if __name__=="__main__": main()
