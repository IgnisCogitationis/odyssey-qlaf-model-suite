#!/usr/bin/env bash
set -euo pipefail
pip install -e .
mkdir -p results
python -m odyssey_engine.validate --device cuda --dtype bf16 --size small
python scripts/benchmark_decode.py --device cuda --dtype bf16 --size small --batch 4 --context 1024 --steps 128 --trials 20 --out results/v23_a100_decode.csv
