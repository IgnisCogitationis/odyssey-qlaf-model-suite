#!/usr/bin/env bash
set -euo pipefail
pip install -e .
mkdir -p results
python -m odyssey_engine.validate --device cuda --dtype bf16 --size base
python scripts/benchmark_decode.py --device cuda --dtype bf16 --size base --batch 8 --context 4096 --steps 256 --trials 20 --out results/v23_h100_decode.csv
