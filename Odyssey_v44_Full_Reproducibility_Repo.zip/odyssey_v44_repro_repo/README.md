# Odyssey v44 Full Reproducibility Repo

This repository converts the preserved Odyssey / QLAF code and benchmark artifacts into a reproducibility-oriented repo layout.

## What this repo contains

- `src/qlaf_ablation/`
  Model definitions and earlier ablation runners extracted from the preserved workspace.
- `src/odyssey_repro/bridgeqlaf_v1.py`
  The BridgeQLAF model family used by the bridge benchmark.
- `src/odyssey_repro/scripts/`
  Patched benchmark runners that write to repo-local `outputs/` instead of `/mnt/data`.
- `configs/`
  Standardized suite definitions for the preserved frontier benchmark families.
- `expected_outputs/`
  Preserved JSON result families used for verification.
- `run_repro.py`
  Unified CLI for listing suites, running suites, and verifying outputs.

## Environment setup

### Option A: pip
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### Option B: conda
```bash
conda env create -f environment.yml
conda activate odyssey-repro
```

## Reproduction order

1. List suites:
```bash
python run_repro.py list
```

2. Run the direct curriculum comparison:
```bash
python run_repro.py run curriculum_frontier_compare
```

3. Run the extension / frontier suite:
```bash
python run_repro.py run objective_attack_extend
```

4. Run the long-context scaling suite:
```bash
python run_repro.py run scaling_longctx
```

5. Run the bridge negative-result suite:
```bash
python run_repro.py run bridgeqlaf_bench_safe
```

6. Verify outputs:
```bash
python run_repro.py verify curriculum_frontier_compare
python run_repro.py verify objective_attack_extend
python run_repro.py verify scaling_longctx
python run_repro.py verify bridgeqlaf_bench_safe
```

Or run everything in sequence:
```bash
python run_repro.py run all
python run_repro.py verify all
```

## Expected behavior

These suites reproduce the preserved CPU benchmark family used in the archive:
- synthetic byte-level corpus defined inside each runner
- PyTorch CPU execution
- matched transformer comparisons
- preserved JSON result structure for verification

## Important honesty

This repo is designed to make the preserved benchmark family portable outside the original container.
It does **not** claim to recreate historical artifacts that never existed in the workspace.
The strongest portable benchmark families present here are:
- `curriculum_frontier_compare`
- `objective_attack_extend`
- `scaling_longctx`
- `bridgeqlaf_bench_safe`

The included `expected_outputs/` directory provides the verification target for those suites.