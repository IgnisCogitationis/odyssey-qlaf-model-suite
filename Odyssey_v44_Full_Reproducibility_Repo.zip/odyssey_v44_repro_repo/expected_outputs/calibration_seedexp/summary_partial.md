# Calibration seed expansion (current partial)

This is the current partial state of the calibration-winner seed expansion.

## seq512 current 2-seed aggregate

| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | RSS Δ MB ↓ |
|---|---:|---:|---:|---:|---:|---:|
| transformer_trained | 3.2601 | 0.1318 | - | 14609.5 | 35.10 | - |
| baseline | 3.7361 | 0.2121 | 14644.5 | 49995.9 | 10.24 | 34.79 |
| temp08_selkl_margin | 3.7005 | 0.2208 | 5715.2 | 52978.0 | 9.67 | 227.15 |

## Current read

- The earlier single-seed loss flip at 512 is **not stable** under the current 2-seed aggregate.
- `temp08_selkl_margin` still improves accuracy and serving behavior, but the trained transformer keeps the loss edge.
- The next exact continuation is to finish the remaining seed-expansion pieces and then extend the same check to 1024.
