# BridgeQLAF-v1 @1024 with trained matched-transformer teacher, tighter gate-cost sweep, smaller bridge budgets

Meta: {'seq_len': 1024, 'batch': 1, 'teacher_steps': 22, 'student_steps': 22, 'seeds': [0, 1], 'transformer_match': {'n_layers': 6, 'd_ff': 640, 'params': 1680512, 'diff': 12815}}

## Mean results
- transformer_matched_teacher: loss=9.2813, acc=0.0477, train=3791.1, infer=2912.1, lat=352.63, rssΔ=101.14
- frontier_base: loss=16.3574, acc=0.0530, train=8863.3, infer=43604.4, lat=23.49, rssΔ=0.50
- bridge_gc0005_t48_s2: loss=30.2125, acc=0.0403, train=2270.8, infer=22956.7, lat=44.66, rssΔ=84.00, gate=0.0938
- bridge_gc002_t32_s2: loss=28.8014, acc=0.0213, train=2206.6, infer=22171.3, lat=46.44, rssΔ=82.93, gate=0.0938
- bridge_gc01_t24_s1: loss=28.6187, acc=0.0233, train=2194.3, infer=23788.6, lat=43.05, rssΔ=121.78, gate=0.0938

## % vs trained transformer teacher comparator
### frontier_base
- loss: +76.24%
- accuracy: +11.07%
- train tok/s: +133.79%
- infer tok/s: +1397.36%
- latency: -93.34%
- rss delta: -99.51%

### bridge_gc0005_t48_s2
- loss: +225.52%
- accuracy: -15.57%
- train tok/s: -40.10%
- infer tok/s: +688.32%
- latency: -87.33%
- rss delta: -16.95%
- bridge active rate: 0.0938

### bridge_gc002_t32_s2
- loss: +210.32%
- accuracy: -55.33%
- train tok/s: -41.80%
- infer tok/s: +661.35%
- latency: -86.83%
- rss delta: -18.00%
- bridge active rate: 0.0938

### bridge_gc01_t24_s1
- loss: +208.35%
- accuracy: -51.23%
- train tok/s: -42.12%
- infer tok/s: +716.89%
- latency: -87.79%
- rss delta: +20.40%
- bridge active rate: 0.0938
