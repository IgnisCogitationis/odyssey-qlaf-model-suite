# v10 5-seed matched confirmation

## seq512
- qlaf_adaptive_margin_longhead: loss 4.3662, acc 0.1750, train 13735.6, infer 49820.2, latency 10.32, rssΔ 118.04
- transformer_matched: loss 3.9705, acc 0.1185, train 7707.9, infer 14859.1, latency 34.47, rssΔ 209.36

## seq1024
- qlaf_dense_longhead: loss 15.5079, acc 0.0550, train 11414.3, infer 60078.5, latency 17.09, rssΔ 187.35
- transformer_matched: loss 8.9757, acc 0.0420, train 5661.7, infer 7064.7, latency 165.53, rssΔ 221.27
