import argparse, json, random, time, math
from pathlib import Path
import psutil, torch
from models_v8 import QLAFLongHeadConfig, QLAFLongHeadLM, MatchedTransformerLM, count_parameters

torch.set_num_threads(1)
BASE_TEXT=("In the beginning the archive was only a sketch of a theorem and a benchmark claim. "
"Then the project split into pooled states, routed states, local states, cache semantics, and benchmark discipline. "
"A narrow symmetric summary forgets order. A richer multibank summary can preserve content, locality, and directional structure. "
"The benchmark must match sequence length, optimizer, budget, and evaluation cadence. "
"Longer contexts increase the burden on pairwise interaction models and challenge constrained state families differently. ")

def build_dataset(total_tokens=160_000):
 text=(BASE_TEXT*((total_tokens//len(BASE_TEXT))+2))[:total_tokens]
 data=torch.tensor(list(text.encode('utf-8')),dtype=torch.long)
 split=int(0.9*len(data))
 return data[:split], data[split:], 256

def get_batch(data,batch_size,seq_len):
 max_start=len(data)-seq_len-1
 ix=torch.randint(0,max_start,(batch_size,))
 x=torch.stack([data[i:i+seq_len] for i in ix],dim=0)
 return x, x.clone()

def eval_model(model,val_data,batch_size,seq_len,eval_steps=12):
 model.eval(); losses=[]; accs=[]; rstats=[]
 with torch.no_grad():
  for _ in range(eval_steps):
   x,y=get_batch(val_data,batch_size,seq_len)
   out=model(x,targets=y)
   logits=out['logits'][:, :-1]; tgt=y[:,1:]
   pred=logits.argmax(dim=-1)
   accs.append((pred==tgt).float().mean().item())
   losses.append(float(out['loss']))
   if 'router_stats' in out: rstats.append(out['router_stats'])
 merged={}
 if rstats:
  keys=set().union(*[r.keys() for r in rstats])
  for k in keys: merged[k]=sum(r[k] for r in rstats if k in r)/len([1 for r in rstats if k in r])
 return {'val_loss': sum(losses)/len(losses), 'accuracy': sum(accs)/len(accs), **merged}

def measure_inference(model,seq_len,reps=12):
 model.eval(); x=torch.randint(0,256,(1,seq_len)); t0=time.perf_counter()
 with torch.no_grad():
  for _ in range(reps): _=model(x)
 dt=time.perf_counter()-t0
 return (reps*seq_len)/dt, dt*1000/reps

def rss_mb(): return psutil.Process().memory_info().rss/(1024*1024)

def train_one(model, train_data, val_data, seq_len, seed, steps, batch_size, lr=3e-4):
 random.seed(seed); torch.manual_seed(seed)
 opt=torch.optim.AdamW(model.parameters(),lr=lr)
 start_rss=rss_mb(); total_tokens=0; t0=time.perf_counter(); model.train()
 for _ in range(steps):
  x,y=get_batch(train_data,batch_size,seq_len)
  out=model(x,targets=y); loss=out['loss']
  opt.zero_grad(set_to_none=True); loss.backward(); opt.step(); total_tokens += batch_size*seq_len
 train_time=time.perf_counter()-t0
 train_tok_s=total_tokens/train_time
 eval_metrics=eval_model(model,val_data,batch_size,seq_len)
 infer_tok_s,latency_ms=measure_inference(model,seq_len)
 end_rss=rss_mb()
 return {**eval_metrics,'train_tok_s':train_tok_s,'infer_tok_s':infer_tok_s,'latency_ms':latency_ms,'rss_start_mb':start_rss,'rss_end_mb':end_rss,'rss_delta_mb':end_rss-start_rss}

def make_qlaf(name, seq_len):
 base=dict(vocab_size=256,max_seq_len=max(2048,seq_len),d_model=128,n_layers=3,d_ff=384,k_global=4,k_order=4,second_order_rank=48,long_rank=24,long_head_threshold=384)
 if name=='qlaf_adaptive_margin_longhead':
  return QLAFLongHeadLM(QLAFLongHeadConfig(**base,routing_mode='adaptive_margin',use_long_head=True,long_head_scale=1.0))
 if name=='qlaf_dense_longhead':
  return QLAFLongHeadLM(QLAFLongHeadConfig(**base,routing_mode='dense',use_long_head=True,long_head_scale=1.0))
 raise ValueError(name)

def make_transformer(target_params, seq_len):
 best=None; matched=None
 for n_layers in range(2,7):
  for d_ff in [256,320,384,448,512,640,768]:
   tr=MatchedTransformerLM(vocab_size=256,d_model=128,n_layers=n_layers,n_heads=4,d_ff=d_ff,max_seq_len=max(2048,seq_len))
   diff=abs(count_parameters(tr)-target_params)
   if best is None or diff<best[0]: best=(diff,n_layers,d_ff,count_parameters(tr)); matched=tr
 return matched

if __name__=='__main__':
 p=argparse.ArgumentParser()
 p.add_argument('--seq', type=int, required=True)
 p.add_argument('--model', choices=['qlaf','transformer'], required=True)
 p.add_argument('--qlaf-name', required=True)
 p.add_argument('--seed', type=int, required=True)
 p.add_argument('--steps', type=int, required=True)
 p.add_argument('--batch', type=int, required=True)
 p.add_argument('--outdir', required=True)
 args=p.parse_args()
 train_data,val_data,_=build_dataset()
 qlaf = make_qlaf(args.qlaf_name, args.seq)
 qlaf_params = count_parameters(qlaf)
 if args.model=='qlaf':
  model=qlaf; name=args.qlaf_name
 else:
  model=make_transformer(qlaf_params, args.seq); name='transformer_matched'
 row=train_one(model,train_data,val_data,args.seq,args.seed,args.steps,args.batch)
 row['params']=count_parameters(model)
 Path(args.outdir).mkdir(parents=True, exist_ok=True)
 fp=Path(args.outdir)/f'{name}_{args.seq}_{args.seed}.json'
 fp.write_text(json.dumps(row, indent=2))
 print(fp)
