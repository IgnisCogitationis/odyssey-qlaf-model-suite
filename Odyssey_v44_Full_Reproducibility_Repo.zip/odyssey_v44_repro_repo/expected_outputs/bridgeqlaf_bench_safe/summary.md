# BridgeQLAF-v1 vs Frontier Base vs Matched Transformer

## seq512
| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | RSS Δ MB ↓ |
|---|---:|---:|---:|---:|---:|---:|
| frontier_base | 10.4936 | 0.1396 | 7878.2 | 38274.3 | 13.38 | 30.68 |
| bridgeqlaf_v1 | 10.4951 | 0.0890 | 6305.8 | 27856.7 | 18.39 | 18.08 |
| transformer_matched | 5.6672 | 0.1264 | 4968.9 | 5624.1 | 91.05 | 2.49 |

### % vs transformer
- frontier_base: loss +85.16%, acc +10.45%, train +58.55%, infer +580.54%, latency -85.30%, rss_delta +1131.03%
- bridgeqlaf_v1: loss +85.19%, acc -29.55%, train +26.91%, infer +395.31%, latency -79.81%, rss_delta +625.63%
- bridge_active_rate: 0.1250

## seq1024
| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | RSS Δ MB ↓ |
|---|---:|---:|---:|---:|---:|---:|
| frontier_base | 36.3449 | 0.0335 | 8868.1 | 45919.0 | 22.33 | 21.85 |
| bridgeqlaf_v1 | 28.7162 | 0.0389 | 5347.1 | 19554.7 | 52.90 | 64.41 |
| transformer_matched | 23.0719 | 0.0336 | 3675.4 | 3061.2 | 334.55 | 81.12 |

### % vs transformer
- frontier_base: loss +57.53%, acc -0.48%, train +141.28%, infer +1400.04%, latency -93.33%, rss_delta -73.06%
- bridgeqlaf_v1: loss +24.46%, acc +15.74%, train +45.48%, infer +538.80%, latency -84.19%, rss_delta -20.60%
- bridge_active_rate: 0.0938
