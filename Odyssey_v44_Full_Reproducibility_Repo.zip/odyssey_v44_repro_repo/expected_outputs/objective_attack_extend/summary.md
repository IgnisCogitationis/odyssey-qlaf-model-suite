# Objective/Curriculum Extension Results

## seq512

| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | RSS Δ MB ↓ |
|---|---:|---:|---:|---:|---:|---:|
| frontier_base | 6.2709 | 0.1450 | 13643.4 | 52278.4 | 9.81 | 105.95 |
| frontier_curriculum_256_512 | 3.4654 | 0.2592 | 14398.3 | 51532.4 | 9.96 | 105.64 |
| frontier_curriculum_256_512_ls | 4.2585 | 0.2539 | 16285.1 | 52827.9 | 9.69 | 9.00 |
| frontier_label_smoothing | 6.2709 | 0.1450 | 13472.8 | 52472.0 | 9.77 | 18.77 |
| transformer_matched | 4.8848 | 0.0849 | 7687.6 | 14108.3 | 36.37 | 157.05 |

## seq1024 (4-seed confirmation)

| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | RSS Δ MB ↓ |
|---|---:|---:|---:|---:|---:|---:|
| frontier_base | 17.3182 | 0.0582 | 11817.2 | 63267.0 | 16.19 | 50.81 |
| frontier_curriculum_512_1024 | 5.1849 | 0.1593 | 14143.8 | 60398.0 | 17.04 | 59.86 |
| transformer_matched | 10.4664 | 0.0269 | 5636.4 | 5450.0 | 208.51 | 128.83 |