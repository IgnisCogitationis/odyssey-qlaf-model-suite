# Curriculum frontier direct compare

## seq512

| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | RSS Δ MB ↓ |
|---|---:|---:|---:|---:|---:|---:|
| curriculum_128_256_512 | 4.3399 | 0.1890 | 13924.7 | 51783.7 | 9.89 | 154.60 |
| transformer_matched | 3.9882 | 0.1044 | 9123.2 | 15005.5 | 34.12 | 128.45 |

## seq1024

| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | RSS Δ MB ↓ |
|---|---:|---:|---:|---:|---:|---:|
| curriculum_256_512_1024 | 4.6798 | 0.1734 | 15806.1 | 62809.3 | 16.31 | 57.51 |
| transformer_matched | 4.1468 | 0.0975 | 7682.7 | 6452.7 | 182.10 | 223.04 |
