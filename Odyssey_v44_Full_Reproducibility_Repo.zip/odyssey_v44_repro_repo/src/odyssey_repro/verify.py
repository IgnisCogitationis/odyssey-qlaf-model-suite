from __future__ import annotations
import json, math
from pathlib import Path

def _load(path: Path):
    return json.loads(path.read_text())

def _is_num(x):
    return isinstance(x, (int, float))

def compare_json(expected, actual, tol=1e-4, path="root", diffs=None):
    if diffs is None:
        diffs = []
    if type(expected) != type(actual):
        diffs.append(f"{path}: type mismatch {type(expected).__name__} != {type(actual).__name__}")
        return diffs
    if isinstance(expected, dict):
        for k in sorted(set(expected.keys()) | set(actual.keys())):
            if k not in expected:
                diffs.append(f"{path}.{k}: unexpected key in actual")
            elif k not in actual:
                diffs.append(f"{path}.{k}: missing key in actual")
            else:
                compare_json(expected[k], actual[k], tol=tol, path=f"{path}.{k}", diffs=diffs)
        return diffs
    if isinstance(expected, list):
        if len(expected) != len(actual):
            diffs.append(f"{path}: length mismatch {len(expected)} != {len(actual)}")
            return diffs
        for i, (e, a) in enumerate(zip(expected, actual)):
            compare_json(e, a, tol=tol, path=f"{path}[{i}]", diffs=diffs)
        return diffs
    if _is_num(expected) and _is_num(actual):
        if math.isnan(expected) != math.isnan(actual) or (not math.isnan(expected) and abs(expected - actual) > tol):
            diffs.append(f"{path}: numeric mismatch {expected} != {actual}")
        return diffs
    if expected != actual:
        diffs.append(f"{path}: value mismatch {expected!r} != {actual!r}")
    return diffs

def verify_file(expected_path: Path, actual_path: Path, tol=1e-4):
    if not expected_path.exists():
        return [f"missing expected file: {expected_path}"]
    if not actual_path.exists():
        return [f"missing actual file: {actual_path}"]
    return compare_json(_load(expected_path), _load(actual_path), tol=tol)
