import json, os, random, sys, time, gc
from pathlib import Path
import psutil
import torch

from pathlib import Path
REPO_ROOT = Path(__file__).resolve().parents[3]
import sys
sys.path.insert(0, str(REPO_ROOT / 'src' / 'qlaf_ablation'))
from models_v8 import QLAFLongHeadConfig, QLAFLongHeadLM, MatchedTransformerLM, count_parameters

torch.set_num_threads(1)
BASE_TEXT=("In the beginning the archive was only a sketch of a theorem and a benchmark claim. "
"Then the project split into pooled states, routed states, local states, cache semantics, and benchmark discipline. "
"A narrow symmetric summary forgets order. A richer multibank summary can preserve content, locality, and directional structure. "
"The benchmark must match sequence length, optimizer, budget, and evaluation cadence. "
"Longer contexts increase the burden on pairwise interaction models and challenge constrained state families differently. ")

def build_dataset(total_tokens=280_000):
    text=(BASE_TEXT*((total_tokens//len(BASE_TEXT))+2))[:total_tokens]
    data=torch.tensor(list(text.encode('utf-8')),dtype=torch.long)
    split=int(0.9*len(data))
    return data[:split], data[split:], 256

def get_batch(data,batch_size,seq_len):
    max_start=len(data)-seq_len-1
    ix=torch.randint(0,max_start,(batch_size,))
    x=torch.stack([data[i:i+seq_len] for i in ix],dim=0)
    return x, x.clone()

def rss_mb():
    return psutil.Process(os.getpid()).memory_info().rss/(1024*1024)

def next_token_loss(logits, targets, label_smoothing=0.0):
    return torch.nn.functional.cross_entropy(
        logits[:, :-1].reshape(-1, logits.size(-1)),
        targets[:, 1:].reshape(-1),
        label_smoothing=label_smoothing,
    )

def eval_model(model,val_data,batch_size,seq_len,eval_steps=10,label_smoothing=0.0):
    model.eval(); losses=[]; accs=[]
    with torch.no_grad():
        for _ in range(eval_steps):
            x,y=get_batch(val_data,batch_size,seq_len)
            out=model(x)
            logits=out['logits']
            losses.append(float(next_token_loss(logits,y,label_smoothing=label_smoothing)))
            pred=logits[:, :-1].argmax(dim=-1)
            tgt=y[:,1:]
            accs.append(float((pred==tgt).float().mean()))
    return {'val_loss': sum(losses)/len(losses), 'accuracy': sum(accs)/len(accs)}

def measure_inference(model,seq_len,reps=8):
    model.eval(); x=torch.randint(0,256,(1,seq_len)); t0=time.perf_counter()
    with torch.no_grad():
        for _ in range(reps):
            _=model(x)
    dt=time.perf_counter()-t0
    return (reps*seq_len)/dt, dt*1000/reps

def make_frontier(seq_len):
    if seq_len == 512:
        cfg=QLAFLongHeadConfig(vocab_size=256,max_seq_len=max(2048,seq_len),d_model=128,n_layers=3,d_ff=384,k_global=4,k_order=4,
            second_order_rank=48,long_rank=32,routing_mode='adaptive_margin',use_long_head=True,long_head_scale=1.0,long_head_threshold=512)
    else:
        cfg=QLAFLongHeadConfig(vocab_size=256,max_seq_len=max(2048,seq_len),d_model=128,n_layers=3,d_ff=384,k_global=4,k_order=4,
            second_order_rank=48,long_rank=32,routing_mode='dense',use_long_head=True,long_head_scale=1.0,long_head_threshold=256)
    return QLAFLongHeadLM(cfg)

def make_transformer(target_params,seq_len):
    best=None; model=None
    for n_layers in range(2,7):
        for d_ff in [256,320,384,448,512,640,768]:
            tr=MatchedTransformerLM(vocab_size=256,d_model=128,n_layers=n_layers,n_heads=4,d_ff=d_ff,max_seq_len=max(2048,seq_len))
            diff=abs(count_parameters(tr)-target_params)
            if best is None or diff<best[0]:
                best=(diff,n_layers,d_ff,count_parameters(tr)); model=tr
    return model, {'diff':best[0],'n_layers':best[1],'d_ff':best[2],'params':best[3]}

def train_variant(name, seed, train_data, val_data, out_dir, seq_len, batch_size):
    fp=Path(out_dir)/f'{name}_seed{seed}.json'
    if fp.exists():
        return json.loads(fp.read_text())
    random.seed(seed); torch.manual_seed(seed)
    if name=='transformer_matched':
        tmp_frontier=make_frontier(seq_len)
        model, meta = make_transformer(count_parameters(tmp_frontier), seq_len)
        label_smoothing=0.0
        stages=[('direct', seq_len, 44 if seq_len==512 else 22)]
    else:
        model=make_frontier(seq_len)
        meta=None
        label_smoothing = 0.05 if 'ls' in name else 0.0
        if name=='frontier_curriculum_256_512' or name=='frontier_curriculum_256_512_ls':
            stages=[('warm256',256,56),('main512',512,22)]
        elif name=='frontier_curriculum_512_1024' or name=='frontier_curriculum_512_1024_ls':
            stages=[('warm512',512,28),('main1024',1024,22)]
        else:
            stages=[('direct', seq_len, 44 if seq_len==512 else 22)]
    opt=torch.optim.AdamW(model.parameters(),lr=3e-4)
    start_rss=rss_mb(); total_tokens=0; t0=time.perf_counter(); model.train()
    stage_losses=[]
    for stage_name, stage_seq, steps in stages:
        for _ in range(steps):
            x,y=get_batch(train_data,batch_size,stage_seq)
            out=model(x)
            loss=next_token_loss(out['logits'], y, label_smoothing=label_smoothing)
            opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
            total_tokens += batch_size*stage_seq
            stage_losses.append(float(loss.detach()))
    train_time=time.perf_counter()-t0
    train_tok_s=total_tokens/train_time
    metrics=eval_model(model,val_data,batch_size,seq_len,eval_steps=12,label_smoothing=label_smoothing)
    infer_tok_s,latency_ms=measure_inference(model,seq_len)
    end_rss=rss_mb()
    row={
        'model':name,'seed':seed,'seq_len':seq_len,'params':count_parameters(model),
        'train_tok_s':train_tok_s,'infer_tok_s':infer_tok_s,'latency_ms':latency_ms,
        'rss_delta_mb':end_rss-start_rss,'train_loss_last':stage_losses[-1],
        **metrics
    }
    if meta is not None:
        row['match_meta']=meta
    fp.write_text(json.dumps(row, indent=2))
    return row

def mean(rows):
    keys=['val_loss','accuracy','train_tok_s','infer_tok_s','latency_ms','rss_delta_mb','train_loss_last','params']
    return {k: sum(r[k] for r in rows)/len(rows) for k in keys}

def run_block(out_dir, seq_len, variants, seeds, batch_size):
    out_dir=Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    train_data,val_data,_=build_dataset()
    results={f'seq{seq_len}':{'models':{}}}
    for name in variants:
        rows=[]
        for seed in seeds:
            row=train_variant(name, seed, train_data, val_data, out_dir, seq_len, batch_size)
            rows.append(row)
            gc.collect()
        results[f'seq{seq_len}']['models'][name]={'per_seed':rows,'mean':mean(rows)}
        (out_dir/'results_partial.json').write_text(json.dumps(results, indent=2))
    (out_dir/'results.json').write_text(json.dumps(results, indent=2))
    return results

def main():
    base=str(Path(os.environ.get('ODYSSEY_REPRO_OUTPUT_ROOT', REPO_ROOT / 'outputs')) / 'objective_attack_extend')
    final={}
    final.update(run_block(base+'/seq512',512,
        ['frontier_base','frontier_label_smoothing','frontier_curriculum_256_512','frontier_curriculum_256_512_ls','transformer_matched'],
        [0,1],4))
    final.update(run_block(base+'/seq1024_seedexp',1024,
        ['frontier_base','frontier_curriculum_512_1024','transformer_matched'],
        [0,1,2,3],2))
    Path(base+'/results_all.json').write_text(json.dumps(final, indent=2))

    md=['# Objective/Curriculum Extension','','## seq512','','| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | RSS Δ MB ↓ |','|---|---:|---:|---:|---:|---:|---:|']
    for name,data in final['seq512']['models'].items():
        m=data['mean']
        md.append(f"| {name} | {m['val_loss']:.4f} | {m['accuracy']:.4f} | {m['train_tok_s']:.1f} | {m['infer_tok_s']:.1f} | {m['latency_ms']:.2f} | {m['rss_delta_mb']:.2f} |")
    md += ['','## seq1024 (4-seed key confirmation)','','| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | RSS Δ MB ↓ |','|---|---:|---:|---:|---:|---:|---:|']
    for name,data in final['seq1024']['models'].items():
        m=data['mean']
        md.append(f"| {name} | {m['val_loss']:.4f} | {m['accuracy']:.4f} | {m['train_tok_s']:.1f} | {m['infer_tok_s']:.1f} | {m['latency_ms']:.2f} | {m['rss_delta_mb']:.2f} |")
    Path(base+'/summary.md').write_text('\n'.join(md))
    print(json.dumps(final, indent=2))

if __name__=='__main__':
    main()
