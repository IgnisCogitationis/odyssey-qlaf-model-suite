import gc, json, os, random, time
from pathlib import Path
import psutil, torch
from odyssey_repro.bridgeqlaf_v1 import BridgeQLAFConfig, BridgeQLAFv1, count_parameters
from models_v8 import QLAFLongHeadConfig, QLAFLongHeadLM, MatchedTransformerLM

torch.set_num_threads(1)
BASE_TEXT=("In the beginning the archive was only a sketch of a theorem and a benchmark claim. "
"Then the project split into pooled states, routed states, local states, cache semantics, and benchmark discipline. "
"A narrow symmetric summary forgets order. A richer multibank summary can preserve content, locality, and directional structure. "
"The benchmark must match sequence length, optimizer, budget, and evaluation cadence. "
"Longer contexts increase the burden on pairwise interaction models and challenge constrained state families differently. ")

def build_dataset(total_tokens=180_000):
 text=(BASE_TEXT*((total_tokens//len(BASE_TEXT))+2))[:total_tokens]
 data=torch.tensor(list(text.encode('utf-8')),dtype=torch.long)
 split=int(0.9*len(data))
 return data[:split], data[split:], 256

def get_batch(data,batch_size,seq_len):
 max_start=len(data)-seq_len-1
 ix=torch.randint(0,max_start,(batch_size,))
 x=torch.stack([data[i:i+seq_len] for i in ix],dim=0)
 return x, x.clone()

def rss_mb(): return psutil.Process(os.getpid()).memory_info().rss/(1024*1024)

def eval_model(model,val_data,batch_size,seq_len,eval_steps=6):
 model.eval(); losses=[]; accs=[]; bridge=[]
 with torch.no_grad():
  for _ in range(eval_steps):
   x,y=get_batch(val_data,batch_size,seq_len)
   out=model(x,targets=y,return_aux=True) if 'return_aux' in model.forward.__code__.co_varnames else model(x,targets=y)
   logits=out['logits'][:, :-1]; tgt=y[:,1:]
   pred=logits.argmax(dim=-1)
   losses.append(float(out['loss'])); accs.append((pred==tgt).float().mean().item())
   if isinstance(out, dict) and 'bridge_aux' in out and 'bridge_active_rate' in out['bridge_aux']:
    bridge.append(float(out['bridge_aux']['bridge_active_rate']))
 res={'val_loss':sum(losses)/len(losses), 'accuracy':sum(accs)/len(accs)}
 if bridge: res['bridge_active_rate']=sum(bridge)/len(bridge)
 return res

def measure_inference(model,seq_len,reps=4):
 model.eval(); x=torch.randint(0,256,(1,seq_len)); t0=time.perf_counter()
 with torch.no_grad():
  for _ in range(reps):
   _=model(x)
 dt=time.perf_counter()-t0
 return (reps*seq_len)/dt, dt*1000/reps

def train_one(model, train_data, val_data, seq_len, seed, steps, batch_size, lr=3e-4):
 random.seed(seed); torch.manual_seed(seed)
 opt=torch.optim.AdamW(model.parameters(),lr=lr)
 start_rss=rss_mb(); total_tokens=0; t0=time.perf_counter(); model.train()
 for _ in range(steps):
  x,y=get_batch(train_data,batch_size,seq_len)
  out=model(x,targets=y,return_aux=True) if 'return_aux' in model.forward.__code__.co_varnames else model(x,targets=y)
  loss=out['loss']
  opt.zero_grad(set_to_none=True); loss.backward(); opt.step(); total_tokens += batch_size*seq_len
 train_time=time.perf_counter()-t0
 res=eval_model(model,val_data,batch_size,seq_len)
 infer_tok_s, latency_ms = measure_inference(model,seq_len)
 end_rss=rss_mb()
 res.update({'train_tok_s':total_tokens/train_time,'infer_tok_s':infer_tok_s,'latency_ms':latency_ms,'rss_start_mb':start_rss,'rss_end_mb':end_rss,'rss_delta_mb':end_rss-start_rss})
 return res

def aggregate(rows): return {k: sum(r[k] for r in rows)/len(rows) for k in rows[0]}

def make_frontier(seq_len):
 if seq_len==512:
  cfg=QLAFLongHeadConfig(vocab_size=256,max_seq_len=2048,d_model=128,n_layers=3,d_ff=384,k_global=4,k_order=4,second_order_rank=48,long_rank=32,routing_mode='adaptive_margin',use_long_head=True,long_head_scale=1.0,long_head_threshold=512)
 else:
  cfg=QLAFLongHeadConfig(vocab_size=256,max_seq_len=2048,d_model=128,n_layers=3,d_ff=384,k_global=4,k_order=4,second_order_rank=48,long_rank=32,routing_mode='dense',use_long_head=True,long_head_scale=1.0,long_head_threshold=256)
 return QLAFLongHeadLM(cfg)

def make_bridge(seq_len):
 routing='adaptive_margin' if seq_len==512 else 'dense'
 cfg=BridgeQLAFConfig(vocab_size=256,d_model=128,n_layers=3,d_ff=384,max_seq_len=2048,k_global=4,k_order=4,routing_mode=routing,second_order_rank=32,long_head_dim=32,long_head_scale=1.0,long_head_threshold=(512 if seq_len==512 else 256),bridge_heads=2,bridge_head_dim=16,bridge_topk_tokens=(48 if seq_len==512 else 64),bridge_support_topk_states=4,bridge_mode='hard_topk',teacher_kl_weight=0.0,margin_weight=0.0,gate_cost_weight=0.0,preset=('amlh_rank32' if seq_len==512 else 'dlh_rank32')).apply_preset()
 return BridgeQLAFv1(cfg)

def make_transformer(target_params, seq_len):
 best=None; matched=None
 for n_layers in range(2,7):
  for d_ff in [256,320,384,448,512,640,768]:
   tr=MatchedTransformerLM(vocab_size=256,d_model=128,n_layers=n_layers,n_heads=4,d_ff=d_ff,max_seq_len=2048)
   diff=abs(count_parameters(tr)-target_params)
   if best is None or diff<best[0]: best=(diff,n_layers,d_ff,count_parameters(tr)); matched=tr
 return matched, {'diff':best[0],'n_layers':best[1],'d_ff':best[2],'params':best[3]}

def run_seq(base, seq_len, steps, batch, seeds):
 train,val,_=build_dataset()
 out=Path(base)/f'seq{seq_len}'; out.mkdir(parents=True, exist_ok=True)
 bridge_params=count_parameters(make_bridge(seq_len))
 tr_meta=make_transformer(bridge_params, seq_len)[1]
 results={f'seq{seq_len}':{'meta':{'seq_len':seq_len,'steps':steps,'batch':batch,'seeds':seeds,'bridge_params':bridge_params,'transformer_match':tr_meta},'models':{}}}
 for name in ['frontier_base','bridgeqlaf_v1','transformer_matched']:
  if name=='frontier_base': model=make_frontier(seq_len)
  elif name=='bridgeqlaf_v1': model=make_bridge(seq_len)
  else: model=make_transformer(bridge_params, seq_len)[0]
  rows=[]
  for seed in seeds:
   fp=out/f'{name}_{seed}.json'
   if fp.exists(): row=json.loads(fp.read_text())
   else:
    row=train_one(model, train, val, seq_len, seed, steps, batch)
    row['params']=count_parameters(model)
    fp.write_text(json.dumps(row, indent=2))
   rows.append(row); gc.collect()
  results[f'seq{seq_len}']['models'][name]={'per_seed':rows,'mean':aggregate(rows)}
  (out/'results_partial.json').write_text(json.dumps(results, indent=2))
 (out/'results.json').write_text(json.dumps(results, indent=2))
 print('done', seq_len)

if __name__=='__main__':
 base=str(Path(os.environ.get('ODYSSEY_REPRO_OUTPUT_ROOT', REPO_ROOT / 'outputs')) / 'bridgeqlaf_bench_safe')
 run_seq(base, 512, steps=24, batch=1, seeds=[0,1])
 run_seq(base, 1024, steps=10, batch=1, seeds=[0,1])
