import json, os, random, sys, time, gc
from pathlib import Path
import psutil
import torch
import torch.nn.functional as F

from pathlib import Path
REPO_ROOT = Path(__file__).resolve().parents[3]
import sys
sys.path.insert(0, str(REPO_ROOT / 'src' / 'qlaf_ablation'))
from models_v8 import QLAFLongHeadConfig, QLAFLongHeadLM, MatchedTransformerLM, count_parameters

torch.set_num_threads(1)
BASE_TEXT=("In the beginning the archive was only a sketch of a theorem and a benchmark claim. "
"Then the project split into pooled states, routed states, local states, cache semantics, and benchmark discipline. "
"A narrow symmetric summary forgets order. A richer multibank summary can preserve content, locality, and directional structure. "
"The benchmark must match sequence length, optimizer, budget, and evaluation cadence. "
"Longer contexts increase the burden on pairwise interaction models and challenge constrained state families differently. ")

def build_dataset(total_tokens=420_000):
    text=(BASE_TEXT*((total_tokens//len(BASE_TEXT))+2))[:total_tokens]
    data=torch.tensor(list(text.encode('utf-8')),dtype=torch.long)
    split=int(0.9*len(data))
    return data[:split], data[split:], 256

def get_batch(data,batch_size,seq_len):
    max_start=len(data)-seq_len-1
    ix=torch.randint(0,max_start,(batch_size,))
    x=torch.stack([data[i:i+seq_len] for i in ix],dim=0)
    return x, x.clone()

def rss_mb():
    return psutil.Process(os.getpid()).memory_info().rss/(1024*1024)

def next_token_loss(logits, targets, tau=1.0):
    return F.cross_entropy((logits[:, :-1]/tau).reshape(-1, logits.size(-1)), targets[:, 1:].reshape(-1))

def eval_model(model,val_data,batch_size,seq_len,eval_steps=8,tau=1.0):
    model.eval(); losses=[]; accs=[]
    with torch.no_grad():
        for _ in range(eval_steps):
            x,y=get_batch(val_data,batch_size,seq_len)
            out=model(x)
            logits=out['logits']
            losses.append(float(next_token_loss(logits,y,tau=tau)))
            pred=logits[:, :-1].argmax(dim=-1)
            tgt=y[:,1:]
            accs.append(float((pred==tgt).float().mean()))
    return {'val_loss':sum(losses)/len(losses),'accuracy':sum(accs)/len(accs)}

def measure_inference(model,seq_len,reps=4):
    model.eval(); x=torch.randint(0,256,(1,seq_len)); t0=time.perf_counter()
    with torch.no_grad():
        for _ in range(reps):
            _=model(x)
    dt=time.perf_counter()-t0
    return (reps*seq_len)/dt, dt*1000/reps

def make_frontier(seq_len):
    cfg=QLAFLongHeadConfig(vocab_size=256,max_seq_len=max(4096,seq_len),d_model=128,n_layers=3,d_ff=384,k_global=4,k_order=4,
        second_order_rank=48,long_rank=32,routing_mode='dense',use_long_head=True,long_head_scale=1.0,long_head_threshold=256)
    return QLAFLongHeadLM(cfg)

def make_transformer(target_params,seq_len):
    best=None; model=None
    for n_layers in range(2,7):
        for d_ff in [256,320,384,448,512,640,768]:
            tr=MatchedTransformerLM(vocab_size=256,d_model=128,n_layers=n_layers,n_heads=4,d_ff=d_ff,max_seq_len=max(4096,seq_len))
            diff=abs(count_parameters(tr)-target_params)
            if best is None or diff<best[0]:
                best=(diff,n_layers,d_ff,count_parameters(tr)); model=tr
    return model, {'diff':best[0],'n_layers':best[1],'d_ff':best[2],'params':best[3]}

def train_variant(name, seed, seq_len, train_data, val_data, out_dir):
    fp=Path(out_dir)/f'{name}_seed{seed}.json'
    if fp.exists():
        return json.loads(fp.read_text())
    random.seed(seed); torch.manual_seed(seed)
    batch_size=1 if seq_len>=1536 else 2
    if name=='transformer_matched':
        tmp=make_frontier(seq_len)
        model, meta=make_transformer(count_parameters(tmp), seq_len)
        stages=[('direct', seq_len, 18 if seq_len==1536 else 14)]
        tau=1.0
    else:
        model=make_frontier(seq_len)
        meta=None
        tau=0.8 if name=='curriculum_temp08' else 1.0
        if seq_len==1536:
            stages=[('warm256',256,12),('warm512',512,10),('warm1024',1024,8),('main1536',1536,8)]
        elif seq_len==2048:
            stages=[('warm256',256,12),('warm512',512,10),('warm1024',1024,8),('warm1536',1536,6),('main2048',2048,6)]
        else:
            raise ValueError(seq_len)
    opt=torch.optim.AdamW(model.parameters(), lr=3e-4)
    start_rss=rss_mb(); total_tokens=0; t0=time.perf_counter(); model.train(); losses=[]
    for stage_name, stage_seq, steps in stages:
        for _ in range(steps):
            x,y=get_batch(train_data,batch_size,stage_seq)
            out=model(x)
            loss=next_token_loss(out['logits'], y, tau=tau)
            opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
            total_tokens += batch_size*stage_seq
            losses.append(float(loss.detach()))
    train_tok_s=total_tokens/(time.perf_counter()-t0)
    metrics=eval_model(model,val_data,batch_size,seq_len,eval_steps=8,tau=tau)
    infer_tok_s, latency_ms=measure_inference(model,seq_len,reps=4)
    row={
        'model':name,'seq_len':seq_len,'seed':seed,'params':count_parameters(model),
        'train_tok_s':train_tok_s,'infer_tok_s':infer_tok_s,'latency_ms':latency_ms,
        'rss_delta_mb':rss_mb()-start_rss,'train_loss_last':losses[-1],
        **metrics
    }
    if meta is not None:
        row['match_meta']=meta
    fp.write_text(json.dumps(row, indent=2))
    return row

def mean(rows):
    keys=['val_loss','accuracy','train_tok_s','infer_tok_s','latency_ms','rss_delta_mb','train_loss_last','params']
    return {k: sum(r[k] for r in rows)/len(rows) for k in keys}

def run_seq(seq_len, out_dir):
    out=Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    train_data,val_data,_=build_dataset()
    results={f'seq{seq_len}':{'models':{}}}
    for name in ['curriculum_base','curriculum_temp08','transformer_matched']:
        rows=[]
        for seed in [0,1]:
            row=train_variant(name, seed, seq_len, train_data, val_data, out)
            rows.append(row)
            gc.collect()
        results[f'seq{seq_len}']['models'][name]={'per_seed':rows,'mean':mean(rows)}
        (out/'results_partial.json').write_text(json.dumps(results, indent=2))
    (out/'results.json').write_text(json.dumps(results, indent=2))
    return results

def main():
    base=str(Path(os.environ.get('ODYSSEY_REPRO_OUTPUT_ROOT', REPO_ROOT / 'outputs')) / 'scaling_longctx')
    allres={}
    allres.update(run_seq(1536, base+'/seq1536'))
    allres.update(run_seq(2048, base+'/seq2048'))
    Path(base+'/results_all.json').write_text(json.dumps(allres, indent=2))
    md=['# Long-context scaling confirmation','']
    for key in ['seq1536','seq2048']:
        md += [f'## {key}','', '| Model | Val loss ↓ | Acc ↑ | Train tok/s ↑ | Infer tok/s ↑ | Latency ms ↓ | RSS Δ MB ↓ |','|---|---:|---:|---:|---:|---:|---:|']
        for name,data in allres[key]['models'].items():
            m=data['mean']
            md.append(f"| {name} | {m['val_loss']:.4f} | {m['accuracy']:.4f} | {m['train_tok_s']:.1f} | {m['infer_tok_s']:.1f} | {m['latency_ms']:.2f} | {m['rss_delta_mb']:.2f} |")
        md.append('')
    Path(base+'/summary.md').write_text('\n'.join(md))
    print(json.dumps(allres, indent=2))

if __name__=='__main__':
    main()
