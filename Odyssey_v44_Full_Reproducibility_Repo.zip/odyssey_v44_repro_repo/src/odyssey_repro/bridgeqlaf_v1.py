"""
bridgeqlaf_v1.py

BridgeQLAF-v1: a loss-gap attack model that keeps the current QLAF frontier base
and adds a selective micro-attention residual bridge plus an optional teacher-KL
training mode.

Design goals:
- Preserve the strong QLAF operational profile.
- Add exact-interaction repair only where it helps loss.
- Keep the bridge sparse through a learned gate and optional top-k token selection.
- Support standard CE training, teacher-KL distillation, margin shaping, and gate-cost regularization.

This file is self-contained and intended as a practical starting point for matched
benchmark experiments against a transformer baseline.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Literal, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


RoutingMode = Literal["dense", "top1", "top2", "adaptive_margin"]


@dataclass
class BridgeQLAFConfig:
    vocab_size: int
    d_model: int = 256
    n_layers: int = 4
    d_ff: int = 1024
    dropout: float = 0.0
    max_seq_len: int = 2048

    routing_mode: RoutingMode = "adaptive_margin"
    second_order_rank: int = 32
    long_head_dim: int = 32
    long_head_scale: float = 1.0
    long_head_threshold: int = 512

    k_global: int = 4
    k_order: int = 4
    adaptive_margin_threshold: float = 0.14

    use_bridge: bool = True
    bridge_heads: int = 2
    bridge_head_dim: int = 32
    bridge_dropout: float = 0.0
    bridge_topk_tokens: int = 64
    bridge_support_topk_states: int = 4
    bridge_use_state_summary: bool = True
    bridge_gate_hidden_mult: float = 1.0
    bridge_gate_init_bias: float = -1.0
    bridge_mode: Literal["soft", "hard_topk"] = "hard_topk"

    tie_embeddings: bool = True

    label_smoothing: float = 0.0
    teacher_temperature: float = 1.0
    teacher_kl_weight: float = 0.0
    margin_weight: float = 0.0
    gate_cost_weight: float = 0.0

    preset: Optional[Literal["amlh_rank32", "dlh_rank32"]] = None

    def apply_preset(self) -> "BridgeQLAFConfig":
        if self.preset == "amlh_rank32":
            self.routing_mode = "adaptive_margin"
            self.second_order_rank = 32
            self.long_head_dim = 32
            self.long_head_scale = 1.0
            self.long_head_threshold = 512
            self.bridge_topk_tokens = 64
        elif self.preset == "dlh_rank32":
            self.routing_mode = "dense"
            self.second_order_rank = 32
            self.long_head_dim = 32
            self.long_head_scale = 1.0
            self.long_head_threshold = 256
            self.bridge_topk_tokens = 96
        return self


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        scale = torch.rsqrt(x.pow(2).mean(dim=-1, keepdim=True) + self.eps)
        return x * scale * self.weight


class FeedForward(nn.Module):
    def __init__(self, d_model: int, d_ff: int, dropout: float) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class PositionalFeatureEncoder(nn.Module):
    def __init__(self, d_model: int, max_seq_len: int) -> None:
        super().__init__()
        self.abs_pos = nn.Embedding(max_seq_len, d_model)

    def forward(self, h: torch.Tensor) -> torch.Tensor:
        bsz, seq_len, dim = h.shape
        device = h.device
        pos = torch.arange(seq_len, device=device)
        pos_f = pos.float()
        rev_f = (seq_len - 1 - pos).float()
        denom = max(seq_len - 1, 1)

        abs_embed = self.abs_pos(pos).unsqueeze(0).expand(bsz, -1, -1)
        pos_norm = (pos_f / denom).view(1, seq_len, 1).expand(bsz, -1, -1)
        rev_norm = (rev_f / denom).view(1, seq_len, 1).expand(bsz, -1, -1)
        center = ((pos_f - 0.5 * denom).abs() / max(0.5 * denom, 1.0)).view(1, seq_len, 1)
        center = center.expand(bsz, -1, -1)
        return torch.cat([h, abs_embed, pos_norm, rev_norm, center], dim=-1)


class FeatureProjector(nn.Module):
    def __init__(self, d_model: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2 * d_model + 3, d_model),
            nn.GELU(),
            nn.Linear(d_model, d_model),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class GlobalBank(nn.Module):
    def __init__(self, d_model: int, n_states: int) -> None:
        super().__init__()
        self.templates = nn.Parameter(torch.randn(n_states, d_model) / math.sqrt(d_model))
        self.value_proj = nn.Linear(d_model, d_model, bias=False)

    def forward(self, z: torch.Tensor, h: torch.Tensor) -> Dict[str, torch.Tensor]:
        scores = torch.einsum("btd,kd->btk", z, self.templates)
        weights = F.softmax(scores, dim=1)
        values = self.value_proj(h)
        states = torch.einsum("btk,btd->bkd", weights, values)
        return {"states": states, "token_weights": weights, "token_scores": scores}


class OrderBank(nn.Module):
    def __init__(self, d_model: int, n_states: int) -> None:
        super().__init__()
        self.fwd_templates = nn.Parameter(torch.randn(n_states, d_model) / math.sqrt(d_model))
        self.rev_templates = nn.Parameter(torch.randn(n_states, d_model) / math.sqrt(d_model))
        self.prefix_gate = nn.Linear(d_model, n_states)
        self.suffix_gate = nn.Linear(d_model, n_states)
        self.mix = nn.Linear(4 * n_states, n_states, bias=False)
        self.value_proj = nn.Linear(d_model, d_model, bias=False)

    def _weighted_sum(self, weights: torch.Tensor, values: torch.Tensor) -> torch.Tensor:
        return torch.einsum("btk,btd->bkd", weights, values)

    def forward(self, z: torch.Tensor, h: torch.Tensor) -> Dict[str, torch.Tensor]:
        values = self.value_proj(h)
        fwd_scores = torch.einsum("btd,kd->btk", z, self.fwd_templates)
        rev_scores = torch.einsum("btd,kd->btk", z.flip(1), self.rev_templates).flip(1)
        prefix_scores = torch.cumsum(self.prefix_gate(z), dim=1)
        suffix_scores = torch.cumsum(self.suffix_gate(z.flip(1)), dim=1).flip(1)

        fwd_states = self._weighted_sum(F.softmax(fwd_scores, dim=1), values)
        rev_states = self._weighted_sum(F.softmax(rev_scores, dim=1), values)
        prefix_states = self._weighted_sum(F.softmax(prefix_scores, dim=1), values)
        suffix_states = self._weighted_sum(F.softmax(suffix_scores, dim=1), values)

        stacked = torch.cat([fwd_states, rev_states, prefix_states, suffix_states], dim=1)
        mix_w = F.softmax(self.mix.weight, dim=-1)
        states = torch.einsum("ks,bsd->bkd", mix_w, stacked)
        return {"states": states}


class DenseStateRouter(nn.Module):
    def __init__(self, d_model: int, n_total_states: int) -> None:
        super().__init__()
        self.router = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Linear(d_model, n_total_states),
        )

    def forward(self, q: torch.Tensor) -> Dict[str, torch.Tensor]:
        logits = self.router(q)
        weights = F.softmax(logits, dim=-1)
        return {"logits": logits, "weights": weights}


def apply_routing_policy(weights: torch.Tensor, mode: RoutingMode, adaptive_margin_threshold: float = 0.14) -> Dict[str, torch.Tensor]:
    bsz, seq_len, n_states = weights.shape
    device = weights.device
    if mode == "dense":
        return {"weights": weights, "topk": torch.full((bsz, seq_len), n_states, device=device, dtype=torch.long)}

    top_vals, top_idx = torch.topk(weights, k=min(2, n_states), dim=-1)
    top1_val = top_vals[..., 0]
    top2_val = top_vals[..., 1] if n_states > 1 else torch.zeros_like(top1_val)
    margin = top1_val - top2_val

    if mode == "top1":
        mask = torch.zeros_like(weights)
        mask.scatter_(-1, top_idx[..., :1], 1.0)
    elif mode == "top2":
        mask = torch.zeros_like(weights)
        mask.scatter_(-1, top_idx[..., :2], 1.0)
    elif mode == "adaptive_margin":
        use_top1 = margin >= adaptive_margin_threshold
        mask_top1 = torch.zeros_like(weights)
        mask_top1.scatter_(-1, top_idx[..., :1], 1.0)
        mask_top2 = torch.zeros_like(weights)
        mask_top2.scatter_(-1, top_idx[..., :2], 1.0)
        mask_dense = torch.ones_like(weights)

        use_top1_f = use_top1.float().unsqueeze(-1)
        use_top2 = (margin < adaptive_margin_threshold) & (margin >= 0.5 * adaptive_margin_threshold)
        use_top2_f = use_top2.float().unsqueeze(-1)
        use_dense = (~use_top1) & (~use_top2)
        use_dense_f = use_dense.float().unsqueeze(-1)
        mask = use_top1_f * mask_top1 + use_top2_f * mask_top2 + use_dense_f * mask_dense
    else:
        raise ValueError(mode)

    sparse = weights * mask
    sparse = sparse / sparse.sum(dim=-1, keepdim=True).clamp_min(1e-12)
    return {"weights": sparse, "topk": mask.sum(dim=-1).long(), "margin": margin}


class SecondOrderCorrection(nn.Module):
    def __init__(self, d_model: int, rank: int) -> None:
        super().__init__()
        self.q_proj = nn.Linear(d_model, rank, bias=False)
        self.s_proj = nn.Linear(d_model, rank, bias=False)
        self.out = nn.Linear(rank, d_model, bias=False)

    def forward(self, q: torch.Tensor, mixed_states: torch.Tensor) -> torch.Tensor:
        return self.out(self.q_proj(q) * self.s_proj(mixed_states))


class LongContextInteraction(nn.Module):
    def __init__(self, d_model: int, head_dim: int, scale: float = 1.0) -> None:
        super().__init__()
        self.q_proj = nn.Linear(d_model, head_dim, bias=False)
        self.k_proj = nn.Linear(d_model, head_dim, bias=False)
        self.v_proj = nn.Linear(d_model, d_model, bias=False)
        self.out = nn.Linear(d_model, d_model, bias=False)
        self.scale = scale / math.sqrt(max(head_dim, 1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        q = self.q_proj(x)
        k = self.k_proj(x)
        v = self.v_proj(x)
        scores = torch.einsum("btd,bsd->bts", q, k) * self.scale
        attn = F.softmax(scores, dim=-1)
        mixed = torch.einsum("bts,bsd->btd", attn, v)
        return self.out(mixed)


class BridgeGate(nn.Module):
    def __init__(self, d_model: int, hidden_mult: float = 1.0, init_bias: float = -1.0) -> None:
        super().__init__()
        hidden = max(int(d_model * hidden_mult), 32)
        self.net = nn.Sequential(
            nn.Linear(d_model + 4, hidden),
            nn.GELU(),
            nn.Linear(hidden, 1),
        )
        nn.init.constant_(self.net[-1].bias, init_bias)

    def forward(self, x: torch.Tensor, logits: torch.Tensor, route_weights: torch.Tensor) -> Dict[str, torch.Tensor]:
        probs = F.softmax(logits, dim=-1)
        top2_vals, _ = torch.topk(probs, k=2, dim=-1)
        pred_margin = top2_vals[..., 0] - top2_vals[..., 1]
        entropy = -(probs * torch.log(probs.clamp_min(1e-12))).sum(dim=-1)
        entropy = entropy / math.log(probs.shape[-1])
        route_top2, _ = torch.topk(route_weights, k=min(2, route_weights.shape[-1]), dim=-1)
        route_margin = route_top2[..., 0] - route_top2[..., 1] if route_top2.shape[-1] > 1 else route_top2[..., 0]
        hidden_norm = x.norm(dim=-1)
        features = torch.stack([pred_margin, entropy, route_margin, hidden_norm], dim=-1)
        gate_input = torch.cat([x, features], dim=-1)
        gate_logits = self.net(gate_input).squeeze(-1)
        gate_prob = torch.sigmoid(gate_logits)
        return {"gate_logits": gate_logits, "gate_prob": gate_prob, "pred_margin": pred_margin, "entropy": entropy, "route_margin": route_margin}


class MicroAttentionBridge(nn.Module):
    def __init__(self, d_model: int, n_heads: int, head_dim: int, dropout: float = 0.0) -> None:
        super().__init__()
        self.n_heads = n_heads
        self.head_dim = head_dim
        self.inner_dim = n_heads * head_dim
        self.q_proj = nn.Linear(d_model, self.inner_dim, bias=False)
        self.k_proj = nn.Linear(d_model, self.inner_dim, bias=False)
        self.v_proj = nn.Linear(d_model, self.inner_dim, bias=False)
        self.out = nn.Linear(self.inner_dim, d_model, bias=False)
        self.dropout = nn.Dropout(dropout)

    def _reshape(self, x: torch.Tensor) -> torch.Tensor:
        bsz, seq_len, _ = x.shape
        return x.view(bsz, seq_len, self.n_heads, self.head_dim).transpose(1, 2)

    def forward(self, x: torch.Tensor, query_token_mask: torch.Tensor, kv_context: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        context = x if kv_context is None else torch.cat([x, kv_context], dim=1)
        q = self._reshape(self.q_proj(x))
        k = self._reshape(self.k_proj(context))
        v = self._reshape(self.v_proj(context))
        scores = torch.einsum("bhtd,bhsd->bhts", q, k) / math.sqrt(self.head_dim)
        attn = F.softmax(scores, dim=-1)
        attn = self.dropout(attn)
        out = torch.einsum("bhts,bhsd->bhtd", attn, v)
        out = out.transpose(1, 2).contiguous().view(x.shape[0], x.shape[1], self.inner_dim)
        out = self.out(out)
        out = out * query_token_mask.unsqueeze(-1)
        return {"bridge_delta": out, "bridge_attn": attn}


class FrontierQLAFBlock(nn.Module):
    def __init__(self, cfg: BridgeQLAFConfig) -> None:
        super().__init__()
        self.cfg = cfg
        self.norm_x = RMSNorm(cfg.d_model)
        self.norm_q = RMSNorm(cfg.d_model)
        self.pos_enc = PositionalFeatureEncoder(cfg.d_model, cfg.max_seq_len)
        self.feat_proj = FeatureProjector(cfg.d_model)
        self.global_bank = GlobalBank(cfg.d_model, cfg.k_global)
        self.order_bank = OrderBank(cfg.d_model, cfg.k_order)
        self.total_states = cfg.k_global + cfg.k_order
        self.router = DenseStateRouter(cfg.d_model, self.total_states)
        self.second = SecondOrderCorrection(cfg.d_model, cfg.second_order_rank)
        self.long_head = LongContextInteraction(cfg.d_model, cfg.long_head_dim, cfg.long_head_scale)
        self.out_proj = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
        self.dropout = nn.Dropout(cfg.dropout)
        self.ff_norm = RMSNorm(cfg.d_model)
        self.ff = FeedForward(cfg.d_model, cfg.d_ff, cfg.dropout)

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        h = self.norm_x(x)
        z = self.feat_proj(self.pos_enc(h))
        q = self.norm_q(h)
        gb = self.global_bank(z, h)
        ob = self.order_bank(z, h)
        all_states = torch.cat([gb["states"], ob["states"]], dim=1)
        route_raw = self.router(q)
        route = apply_routing_policy(route_raw["weights"], self.cfg.routing_mode, self.cfg.adaptive_margin_threshold)
        mixed = torch.einsum("btk,bkd->btd", route["weights"], all_states)
        update = self.out_proj(mixed) + self.second(q, mixed)
        if x.shape[1] >= self.cfg.long_head_threshold:
            update = update + self.long_head(h)
        x_resid = x + self.dropout(update)
        x_out = x_resid + self.dropout(self.ff(self.ff_norm(x_resid)))
        return {"x": x_out, "states": all_states, "route_weights": route["weights"], "route_raw_weights": route_raw["weights"], "route_logits": route_raw["logits"], "route_topk": route["topk"]}


class BridgeQLAFv1(nn.Module):
    def __init__(self, cfg: BridgeQLAFConfig) -> None:
        super().__init__()
        self.cfg = cfg.apply_preset()
        self.tok_emb = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.blocks = nn.ModuleList([FrontierQLAFBlock(cfg) for _ in range(cfg.n_layers)])
        self.final_norm = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        if cfg.tie_embeddings:
            self.lm_head.weight = self.tok_emb.weight
        self.use_bridge = cfg.use_bridge
        if cfg.use_bridge:
            self.bridge_gate = BridgeGate(cfg.d_model, cfg.bridge_gate_hidden_mult, cfg.bridge_gate_init_bias)
            self.bridge = MicroAttentionBridge(cfg.d_model, cfg.bridge_heads, cfg.bridge_head_dim, cfg.bridge_dropout)
            self.bridge_norm = RMSNorm(cfg.d_model)

    def _state_support_summary(self, states: torch.Tensor, route_weights: torch.Tensor, topk_states: int) -> torch.Tensor:
        usage = route_weights.mean(dim=1)
        k = min(topk_states, states.shape[1])
        _, idx = torch.topk(usage, k=k, dim=-1)
        gather_idx = idx.unsqueeze(-1).expand(-1, -1, states.shape[-1])
        return torch.gather(states, dim=1, index=gather_idx)

    def _make_bridge_mask(self, gate_prob: torch.Tensor, topk_tokens: int, mode: Literal["soft", "hard_topk"]) -> Dict[str, torch.Tensor]:
        if mode == "soft":
            return {"mask": gate_prob, "active_rate": gate_prob.mean()}
        k = min(topk_tokens, gate_prob.shape[1])
        _, top_idx = torch.topk(gate_prob, k=k, dim=-1)
        hard_mask = torch.zeros_like(gate_prob)
        hard_mask.scatter_(-1, top_idx, 1.0)
        return {"mask": hard_mask, "active_rate": hard_mask.mean()}

    def forward(self, idx: torch.Tensor, targets: Optional[torch.Tensor] = None, teacher_logits: Optional[torch.Tensor] = None, return_aux: bool = False) -> Dict[str, torch.Tensor]:
        x = self.tok_emb(idx)
        block_aux: List[Dict[str, torch.Tensor]] = []
        for block in self.blocks:
            out = block(x)
            x = out["x"]
            block_aux.append(out)
        x = self.final_norm(x)
        bridge_aux: Dict[str, torch.Tensor] = {}
        if self.use_bridge:
            last = block_aux[-1]
            gate = self.bridge_gate(x, torch.matmul(x, self.lm_head.weight.t()), last["route_raw_weights"])
            mask_info = self._make_bridge_mask(gate["gate_prob"], self.cfg.bridge_topk_tokens, self.cfg.bridge_mode)
            kv_support = None
            if self.cfg.bridge_use_state_summary:
                kv_support = self._state_support_summary(last["states"], last["route_weights"], self.cfg.bridge_support_topk_states)
            bridge = self.bridge(self.bridge_norm(x), mask_info["mask"], kv_support)
            x = x + bridge["bridge_delta"]
            bridge_aux = {"gate_prob": gate["gate_prob"], "gate_logits": gate["gate_logits"], "bridge_active_rate": mask_info["active_rate"], "bridge_mask": mask_info["mask"]}
        logits = self.lm_head(x)
        out: Dict[str, torch.Tensor] = {"logits": logits}
        if targets is not None:
            out.update(compute_bridgeqlaf_losses(logits, targets, teacher_logits, bridge_aux.get("gate_prob"), self.cfg.label_smoothing, self.cfg.teacher_temperature, self.cfg.teacher_kl_weight, self.cfg.margin_weight, self.cfg.gate_cost_weight))
        if return_aux:
            out["block_aux"] = block_aux
            out["bridge_aux"] = bridge_aux
        return out


def next_token_cross_entropy(logits: torch.Tensor, targets: torch.Tensor, label_smoothing: float = 0.0) -> torch.Tensor:
    return F.cross_entropy(logits[:, :-1].reshape(-1, logits.size(-1)), targets[:, 1:].reshape(-1), label_smoothing=label_smoothing)


def teacher_kl_loss(student_logits: torch.Tensor, teacher_logits: torch.Tensor, temperature: float = 1.0) -> torch.Tensor:
    s = student_logits[:, :-1] / temperature
    t = teacher_logits[:, :-1] / temperature
    return F.kl_div(F.log_softmax(s, dim=-1), F.softmax(t, dim=-1), reduction="batchmean") * (temperature ** 2)


def logit_margin_loss(logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
    pred = logits[:, :-1]
    tgt = targets[:, 1:]
    correct = pred.gather(-1, tgt.unsqueeze(-1)).squeeze(-1)
    masked = pred.clone()
    masked.scatter_(-1, tgt.unsqueeze(-1), float("-inf"))
    competitor = masked.max(dim=-1).values
    return F.softplus(-(correct - competitor)).mean()


def compute_bridgeqlaf_losses(logits: torch.Tensor, targets: torch.Tensor, teacher_logits: Optional[torch.Tensor] = None, gate_prob: Optional[torch.Tensor] = None, ce_label_smoothing: float = 0.0, teacher_temperature: float = 1.0, teacher_kl_weight: float = 0.0, margin_weight: float = 0.0, gate_cost_weight: float = 0.0) -> Dict[str, torch.Tensor]:
    ce = next_token_cross_entropy(logits, targets, ce_label_smoothing)
    total = ce
    out = {"loss_ce": ce}
    if teacher_logits is not None and teacher_kl_weight > 0.0:
        kl = teacher_kl_loss(logits, teacher_logits, teacher_temperature)
        total = total + teacher_kl_weight * kl
        out["loss_teacher_kl"] = kl
    else:
        out["loss_teacher_kl"] = torch.tensor(0.0, device=logits.device)
    if margin_weight > 0.0:
        margin = logit_margin_loss(logits, targets)
        total = total + margin_weight * margin
        out["loss_margin"] = margin
    else:
        out["loss_margin"] = torch.tensor(0.0, device=logits.device)
    if gate_cost_weight > 0.0:
        gate_cost = gate_prob.mean() if gate_prob is not None else torch.tensor(0.0, device=logits.device)
        total = total + gate_cost_weight * gate_cost
        out["loss_gate_cost"] = gate_cost
    else:
        out["loss_gate_cost"] = torch.tensor(0.0, device=logits.device)
    out["loss"] = total
    return out


def count_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


def estimate_bridgeqlaf_memory_bytes(cfg: BridgeQLAFConfig, batch_size: int, seq_len: int, bytes_per_elem: int = 4) -> Dict[str, int]:
    total_states = cfg.k_global + cfg.k_order
    token_hidden = batch_size * seq_len * cfg.d_model * bytes_per_elem
    route_logits = batch_size * seq_len * total_states * bytes_per_elem
    state_tensor = batch_size * total_states * cfg.d_model * bytes_per_elem
    bridge_inner = 0
    bridge_scores = 0
    if cfg.use_bridge:
        bridge_inner = batch_size * seq_len * (cfg.bridge_heads * cfg.bridge_head_dim) * bytes_per_elem
        bridge_scores = batch_size * cfg.bridge_heads * seq_len * (seq_len + cfg.bridge_support_topk_states) * bytes_per_elem
    total = token_hidden + route_logits + state_tensor + bridge_inner + bridge_scores
    return {"token_hidden_bytes": token_hidden, "route_logits_bytes": route_logits, "state_tensor_bytes": state_tensor, "bridge_inner_bytes": bridge_inner, "bridge_scores_bytes": bridge_scores, "approx_total_bytes": total}


if __name__ == "__main__":
    torch.manual_seed(0)
    cfg = BridgeQLAFConfig(vocab_size=256, preset="amlh_rank32", use_bridge=True, teacher_kl_weight=0.25, margin_weight=0.05, gate_cost_weight=0.01).apply_preset()
    model = BridgeQLAFv1(cfg)
    x = torch.randint(0, cfg.vocab_size, (2, 256))
    teacher_logits = torch.randn(2, 256, cfg.vocab_size)
    out = model(x, targets=x, teacher_logits=teacher_logits, return_aux=True)
    print("params:", count_parameters(model))
    print("loss:", float(out["loss"]))
    print("bridge_active_rate:", float(out["bridge_aux"]["bridge_active_rate"]))
    print("memory:", estimate_bridgeqlaf_memory_bytes(cfg, batch_size=2, seq_len=256))
