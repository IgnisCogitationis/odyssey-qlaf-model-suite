import math
from dataclasses import dataclass
from typing import Dict, Optional
import torch
import torch.nn as nn
import torch.nn.functional as F
from models_v3 import RMSNorm, PositionalFeatureEncoder, FeatureProjector, GlobalBank, OrderBank, SecondOrderCorrection, MatchedTransformerLM, count_parameters

@dataclass
class QLAFLongHeadConfig:
    vocab_size: int
    d_model: int = 128
    n_layers: int = 3
    d_ff: int = 384
    dropout: float = 0.0
    max_seq_len: int = 2048
    k_global: int = 4
    k_order: int = 4
    second_order_rank: int = 48
    long_rank: int = 24
    routing_mode: str = 'adaptive_margin'  # dense, top1, top2, adaptive_margin, adaptive_entropy
    margin_top1: float = 0.18
    margin_top2: float = 0.07
    entropy_threshold: float = 0.72
    use_long_head: bool = True
    long_head_scale: float = 1.0
    long_head_threshold: int = 384
    tie_embeddings: bool = True

class AdaptiveRouter(nn.Module):
    def __init__(self, d_model: int, widths: Dict[str, int], mode: str = 'dense', margin_top1: float = 0.18, margin_top2: float = 0.07, entropy_threshold: float = 0.72):
        super().__init__()
        self.names = list(widths.keys())
        self.widths = widths
        self.total = sum(widths.values())
        self.mode = mode
        self.margin_top1 = margin_top1
        self.margin_top2 = margin_top2
        self.entropy_threshold = entropy_threshold
        self.net = nn.Sequential(nn.Linear(d_model, d_model), nn.GELU(), nn.Linear(d_model, self.total))

    def _apply_topk(self, weights: torch.Tensor, k: int) -> torch.Tensor:
        vals, idx = torch.topk(weights, k, dim=-1)
        sparse = torch.zeros_like(weights)
        sparse.scatter_(-1, idx, vals)
        return sparse / sparse.sum(dim=-1, keepdim=True).clamp_min(1e-9)

    def forward(self, q: torch.Tensor):
        logits = self.net(q)
        weights = F.softmax(logits, dim=-1)
        stats = {}
        if self.mode == 'dense':
            routed = weights
        elif self.mode == 'top1':
            routed = self._apply_topk(weights, 1)
        elif self.mode == 'top2':
            routed = self._apply_topk(weights, 2)
        elif self.mode == 'adaptive_margin':
            top2_vals, _ = torch.topk(weights, 2, dim=-1)
            margin = top2_vals[..., 0] - top2_vals[..., 1]
            w1 = self._apply_topk(weights, 1)
            w2 = self._apply_topk(weights, 2)
            use1 = (margin >= self.margin_top1).unsqueeze(-1)
            use2 = ((margin >= self.margin_top2) & (margin < self.margin_top1)).unsqueeze(-1)
            routed = torch.where(use1, w1, torch.where(use2, w2, weights))
            stats['margin_mean'] = float(margin.mean().detach())
            stats['top1_frac'] = float(use1.float().mean().detach())
            stats['top2_frac'] = float(use2.float().mean().detach())
        elif self.mode == 'adaptive_entropy':
            entropy = -(weights * (weights.clamp_min(1e-9).log())).sum(dim=-1) / math.log(float(self.total))
            w2 = self._apply_topk(weights, 2)
            use2 = (entropy <= self.entropy_threshold).unsqueeze(-1)
            routed = torch.where(use2, w2, weights)
            stats['entropy_mean'] = float(entropy.mean().detach())
            stats['top2_frac'] = float(use2.float().mean().detach())
        else:
            raise ValueError(f'unknown routing mode {self.mode}')
        split = {}
        start = 0
        for name in self.names:
            width = self.widths[name]
            split[name] = routed[..., start:start+width]
            start += width
        return split, stats

class LongContextCorrection(nn.Module):
    """
    Adds a modest long-context-only interaction branch.
    It interacts token queries with a cheap global summary and turns on more strongly
    only once sequence length exceeds a threshold.
    """
    def __init__(self, d_model: int, rank: int, threshold: int = 384, scale: float = 1.0):
        super().__init__()
        self.q_proj = nn.Linear(d_model, rank, bias=False)
        self.g_proj = nn.Linear(d_model, rank, bias=False)
        self.mix = nn.Linear(rank, d_model, bias=False)
        self.threshold = threshold
        self.scale = scale
        self.gate_bias = nn.Parameter(torch.tensor(0.0))

    def forward(self, q: torch.Tensor, global_states: torch.Tensor) -> torch.Tensor:
        # global_states: [B, Kg, D]
        seq_len = q.size(1)
        global_summary = global_states.mean(dim=1, keepdim=True).expand(-1, seq_len, -1)
        qf = self.q_proj(q)
        gf = self.g_proj(global_summary)
        raw = self.mix(qf * gf)
        # deterministic length-aware gate, learnably shifted
        length_signal = (seq_len - self.threshold) / max(self.threshold, 1)
        gate = torch.sigmoid(torch.tensor(float(length_signal), device=q.device) + self.gate_bias)
        return raw * gate * self.scale

class QLAFLongHeadBlock(nn.Module):
    def __init__(self, cfg: QLAFLongHeadConfig):
        super().__init__()
        self.cfg = cfg
        self.norm_x = RMSNorm(cfg.d_model)
        self.norm_q = RMSNorm(cfg.d_model)
        self.pos = PositionalFeatureEncoder(cfg.d_model, cfg.max_seq_len)
        self.feat = FeatureProjector(cfg.d_model)
        self.global_bank = GlobalBank(cfg.d_model, cfg.k_global)
        self.order_bank = OrderBank(cfg.d_model, cfg.k_order)
        self.router = AdaptiveRouter(cfg.d_model, {'global': cfg.k_global, 'order': cfg.k_order}, mode=cfg.routing_mode, margin_top1=cfg.margin_top1, margin_top2=cfg.margin_top2, entropy_threshold=cfg.entropy_threshold)
        self.out_proj = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
        self.ff_norm = RMSNorm(cfg.d_model)
        self.ff = nn.Sequential(nn.Linear(cfg.d_model, cfg.d_ff), nn.GELU(), nn.Linear(cfg.d_ff, cfg.d_model))
        self.dropout = nn.Dropout(cfg.dropout)
        self.second_order = SecondOrderCorrection(cfg.d_model, cfg.second_order_rank)
        self.long_head = LongContextCorrection(cfg.d_model, cfg.long_rank, threshold=cfg.long_head_threshold, scale=cfg.long_head_scale) if cfg.use_long_head else None

    def forward(self, x: torch.Tensor):
        h = self.norm_x(x)
        z = self.feat(self.pos(h))
        q = self.norm_q(h)
        gs = self.global_bank(z, h)
        os = self.order_bank(z, h)
        states = torch.cat([gs, os], dim=1)
        split, stats = self.router(q)
        route = torch.cat([split['global'], split['order']], dim=-1)
        mixed = torch.einsum('btk,bkd->btd', route, states)
        update = self.out_proj(mixed) + self.second_order(q, mixed)
        if self.long_head is not None:
            update = update + self.long_head(q, gs)
        x = x + self.dropout(update)
        x = x + self.dropout(self.ff(self.ff_norm(x)))
        return x, stats

class QLAFLongHeadLM(nn.Module):
    def __init__(self, cfg: QLAFLongHeadConfig):
        super().__init__()
        self.cfg = cfg
        self.tok_emb = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.blocks = nn.ModuleList([QLAFLongHeadBlock(cfg) for _ in range(cfg.n_layers)])
        self.final_norm = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        if cfg.tie_embeddings:
            self.lm_head.weight = self.tok_emb.weight

    def forward(self, idx, targets: Optional[torch.Tensor] = None):
        x = self.tok_emb(idx)
        stats_acc = []
        for block in self.blocks:
            x, stats = block(x)
            if stats:
                stats_acc.append(stats)
        x = self.final_norm(x)
        logits = self.lm_head(x)
        out = {'logits': logits}
        if targets is not None:
            out['loss'] = F.cross_entropy(logits[:, :-1].reshape(-1, logits.size(-1)), targets[:, 1:].reshape(-1))
        if stats_acc:
            merged = {}
            keys = set().union(*[s.keys() for s in stats_acc])
            for k in keys:
                vals = [s[k] for s in stats_acc if k in s]
                merged[k] = sum(vals) / len(vals)
            out['router_stats'] = merged
        return out
