import gc, json, os, random, time
from pathlib import Path
import psutil, torch
from models_v6 import QLAFSparseConfig, QLAFSparseLM, MatchedTransformerLM, count_parameters

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
BASE_TEXT=("In the beginning the archive was only a sketch of a theorem and a benchmark claim. "
"Then the project split into pooled states, routed states, local states, cache semantics, and benchmark discipline. "
"A narrow symmetric summary forgets order. A richer multibank summary can preserve content, locality, and directional structure. "
"The benchmark must match sequence length, optimizer, budget, and evaluation cadence. "
"Longer contexts increase the burden on pairwise interaction models and challenge constrained state families differently. ")

def build_dataset(total_tokens=120_000):
 text=(BASE_TEXT*((total_tokens//len(BASE_TEXT))+2))[:total_tokens]
 data=torch.tensor(list(text.encode('utf-8')),dtype=torch.long)
 split=int(0.9*len(data))
 return data[:split], data[split:], 256

def get_batch(data,batch_size,seq_len):
 max_start=len(data)-seq_len-1
 ix=torch.randint(0,max_start,(batch_size,))
 x=torch.stack([data[i:i+seq_len] for i in ix],dim=0)
 return x, x.clone()

def eval_model(model,val_data,batch_size,seq_len,eval_steps=8):
 model.eval(); losses=[]; accs=[]
 with torch.no_grad():
  for _ in range(eval_steps):
   x,y=get_batch(val_data,batch_size,seq_len)
   out=model(x,targets=y)
   logits=out['logits'][:, :-1]; tgt=y[:,1:]
   pred=logits.argmax(dim=-1)
   accs.append((pred==tgt).float().mean().item())
   losses.append(float(out['loss']))
 return {'val_loss': sum(losses)/len(losses), 'accuracy': sum(accs)/len(accs)}

def measure_inference(model,seq_len,reps=8):
 model.eval(); x=torch.randint(0,256,(1,seq_len)); t0=time.perf_counter()
 with torch.no_grad():
  for _ in range(reps): _=model(x)
 dt=time.perf_counter()-t0
 return (reps*seq_len)/dt, dt*1000/reps

def rss_mb(): return psutil.Process(os.getpid()).memory_info().rss/(1024*1024)

def train_one(model, train_data, val_data, seq_len, seed, steps, batch_size, lr=3e-4):
 random.seed(seed); torch.manual_seed(seed)
 opt=torch.optim.AdamW(model.parameters(),lr=lr)
 start_rss=rss_mb(); total_tokens=0; t0=time.perf_counter(); model.train()
 for _ in range(steps):
  x,y=get_batch(train_data,batch_size,seq_len)
  out=model(x,targets=y); loss=out['loss']
  opt.zero_grad(set_to_none=True); loss.backward(); opt.step(); total_tokens += batch_size*seq_len
 train_time=time.perf_counter()-t0
 train_tok_s=total_tokens/train_time
 eval_metrics=eval_model(model,val_data,batch_size,seq_len)
 infer_tok_s,latency_ms=measure_inference(model,seq_len)
 end_rss=rss_mb()
 return {**eval_metrics,'train_tok_s':train_tok_s,'infer_tok_s':infer_tok_s,'latency_ms':latency_ms,'rss_start_mb':start_rss,'rss_end_mb':end_rss,'rss_delta_mb':end_rss-start_rss}

def aggregate(rows): return {k: sum(r[k] for r in rows)/len(rows) for k in rows[0]}

def make_models(seq_len):
 base=dict(vocab_size=256,max_seq_len=max(2048,seq_len),d_model=128,n_layers=3,d_ff=384,k_global=4,k_order=4,second_order_rank=48)
 models={
  'qlaf_go_second_r48_dense': QLAFSparseLM(QLAFSparseConfig(**base,router_topk=0)),
  'qlaf_go_second_r48_top1': QLAFSparseLM(QLAFSparseConfig(**base,router_topk=1)),
  'qlaf_go_second_r48_top2': QLAFSparseLM(QLAFSparseConfig(**base,router_topk=2)),
  'qlaf_go_second_r48_top4': QLAFSparseLM(QLAFSparseConfig(**base,router_topk=4)),
 }
 target_params=count_parameters(models['qlaf_go_second_r48_dense'])
 best=None; matched=None
 for n_layers in range(2,7):
  for d_ff in [256,320,384,448,512,640,768]:
   tr=MatchedTransformerLM(vocab_size=256,d_model=128,n_layers=n_layers,n_heads=4,d_ff=d_ff,max_seq_len=max(2048,seq_len))
   diff=abs(count_parameters(tr)-target_params)
   if best is None or diff<best[0]: best=(diff,n_layers,d_ff,count_parameters(tr)); matched=tr
 models['transformer_matched']=matched
 return models, {'target_params': target_params, 'transformer_match': {'diff': best[0], 'n_layers': best[1], 'd_ff': best[2], 'params': best[3]}}

def run_suite(out_dir):
 out_dir=Path(out_dir); out_dir.mkdir(exist_ok=True,parents=True)
 train_data,val_data,_=build_dataset(); all_results={}
 for seq_len in [128,512,1024]:
  models,meta=make_models(seq_len)
  if seq_len==128: steps,batch,seeds=60,8,[0,1]
  elif seq_len==512: steps,batch,seeds=28,4,[0,1]
  else: steps,batch,seeds=12,2,[0]
  seq_res={'meta':meta,'models':{}}
  for name,model in models.items():
   rows=[]
   for seed in seeds:
    fp=out_dir/f'{name}_{seq_len}_{seed}.json'
    if fp.exists(): row=json.loads(fp.read_text())
    else:
     row=train_one(model,train_data,val_data,seq_len,seed,steps,batch)
     row['params']=count_parameters(model)
     if name.startswith('qlaf'):
      cfg=model.cfg; total_states=cfg.k_global+cfg.k_order
      approx_bytes=(batch*total_states*cfg.d_model*4)+(batch*seq_len*cfg.d_model*4)+(batch*seq_len*total_states*4)
      row['approx_state_mem_mb']=approx_bytes/(1024*1024)
     else: row['approx_state_mem_mb']=float('nan')
     fp.write_text(json.dumps(row,indent=2))
    rows.append(row); gc.collect()
   seq_res['models'][name]={'per_seed':rows,'mean':aggregate(rows)}
   all_results[f'seq{seq_len}']=seq_res
   (out_dir/'results_partial.json').write_text(json.dumps(all_results,indent=2))
  all_results[f'seq{seq_len}']=seq_res
 (out_dir/'results.json').write_text(json.dumps(all_results,indent=2))
 print('done')

if __name__=='__main__': run_suite('/mnt/data/qlaf_ablation/v6_sparse')
