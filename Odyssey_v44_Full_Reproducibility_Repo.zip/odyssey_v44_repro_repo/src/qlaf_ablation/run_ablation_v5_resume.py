import gc, json, os, random, time
from pathlib import Path

import psutil
import torch

from models_v3 import MatchedTransformerLM, QLAFPyramidConfig, QLAFPyramidLM, count_parameters, estimate_state_memory_bytes

torch.set_num_threads(1)
torch.set_num_interop_threads(1)

BASE_TEXT = (
    "In the beginning the archive was only a sketch of a theorem and a benchmark claim. "
    "Then the project split into pooled states, routed states, local states, cache semantics, and benchmark discipline. "
    "A narrow symmetric summary forgets order. A richer multibank summary can preserve content, locality, and directional structure. "
    "The benchmark must match sequence length, optimizer, budget, and evaluation cadence. "
    "Longer contexts increase the burden on pairwise interaction models and challenge constrained state families differently. "
)

def build_dataset(total_tokens: int = 120_000):
    text = (BASE_TEXT * ((total_tokens // len(BASE_TEXT)) + 2))[:total_tokens]
    data = torch.tensor(list(text.encode('utf-8')), dtype=torch.long)
    split = int(0.9 * len(data))
    return data[:split], data[split:], 256

def get_batch(data, batch_size, seq_len):
    max_start = len(data) - seq_len - 1
    ix = torch.randint(0, max_start, (batch_size,))
    x = torch.stack([data[i:i+seq_len] for i in ix], dim=0)
    y = x.clone()
    return x, y

def eval_model(model, val_data, batch_size, seq_len, eval_steps=8):
    model.eval()
    losses, accs = [], []
    with torch.no_grad():
        for _ in range(eval_steps):
            x, y = get_batch(val_data, batch_size, seq_len)
            out = model(x, targets=y)
            logits = out['logits'][:, :-1]
            tgt = y[:, 1:]
            pred = logits.argmax(dim=-1)
            accs.append((pred == tgt).float().mean().item())
            losses.append(float(out['loss']))
    return {'val_loss': sum(losses)/len(losses), 'accuracy': sum(accs)/len(accs)}

def measure_inference(model, seq_len, reps=8):
    model.eval()
    x = torch.randint(0, 256, (1, seq_len))
    t0 = time.perf_counter()
    with torch.no_grad():
        for _ in range(reps):
            _ = model(x)
    dt = time.perf_counter() - t0
    return (reps * seq_len) / dt, dt * 1000 / reps

def rss_mb():
    return psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024)

def train_one(model, train_data, val_data, seq_len, seed, steps, batch_size, lr=3e-4):
    random.seed(seed)
    torch.manual_seed(seed)
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    start_rss = rss_mb()
    total_tokens = 0
    t0 = time.perf_counter()
    model.train()
    for _ in range(steps):
        x, y = get_batch(train_data, batch_size, seq_len)
        out = model(x, targets=y)
        loss = out['loss']
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        total_tokens += batch_size * seq_len
    train_time = time.perf_counter() - t0
    train_tok_s = total_tokens / train_time
    eval_metrics = eval_model(model, val_data, batch_size, seq_len)
    infer_tok_s, latency_ms = measure_inference(model, seq_len)
    end_rss = rss_mb()
    return {**eval_metrics,'train_tok_s': train_tok_s,'infer_tok_s': infer_tok_s,'latency_ms': latency_ms,'rss_start_mb': start_rss,'rss_end_mb': end_rss,'rss_delta_mb': end_rss - start_rss}

def aggregate(rows):
    return {k: sum(r[k] for r in rows)/len(rows) for k in rows[0]}

def make_models(seq_len):
    base = dict(vocab_size=256, max_seq_len=max(2048, seq_len), d_model=128, n_layers=3, d_ff=384, k_global=4, k_order=4, k_local=0, local_scales=tuple(), use_second_order_correction=True)
    models = {
        'qlaf_go_second_r24': QLAFPyramidLM(QLAFPyramidConfig(**base, second_order_rank=24)),
        'qlaf_go_second_r48': QLAFPyramidLM(QLAFPyramidConfig(**base, second_order_rank=48)),
        'qlaf_go_second_r96': QLAFPyramidLM(QLAFPyramidConfig(**base, second_order_rank=96)),
    }
    target_name = 'qlaf_go_second_r48'
    target_params = count_parameters(models[target_name])
    best = None; matched = None
    for n_layers in range(2, 7):
        for d_ff in [256, 320, 384, 448, 512, 640, 768]:
            tr = MatchedTransformerLM(vocab_size=256, d_model=128, n_layers=n_layers, n_heads=4, d_ff=d_ff, max_seq_len=max(2048, seq_len))
            diff = abs(count_parameters(tr) - target_params)
            if best is None or diff < best[0]:
                best = (diff, n_layers, d_ff, count_parameters(tr)); matched = tr
    models['transformer_matched'] = matched
    return models, {'target_params': target_params, 'transformer_match': {'diff': best[0], 'n_layers': best[1], 'd_ff': best[2], 'params': best[3]}}

def main(out_dir):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    partial_path = out_dir/'results_partial.json'
    all_results = json.loads(partial_path.read_text()) if partial_path.exists() else {}
    train_data, val_data, _ = build_dataset()
    for seq_len in [128, 512, 1024]:
        seq_key = f'seq{seq_len}'
        models, meta = make_models(seq_len)
        if seq_len == 128:
            steps, batch, seeds = 60, 8, [0,1]
        elif seq_len == 512:
            steps, batch, seeds = 28, 4, [0,1]
        else:
            steps, batch, seeds = 12, 2, [0]
        seq_res = all_results.get(seq_key, {'meta': meta, 'models': {}})
        seq_res['meta'] = meta
        for name, model in models.items():
            existing = seq_res['models'].get(name, {}).get('per_seed', [])
            done = {i for i in range(len(existing))}
            rows = list(existing)
            for idx, seed in enumerate(seeds):
                f = out_dir/f'{name}_{seq_len}_{seed}.json'
                if f.exists() and idx not in done:
                    row = json.loads(f.read_text()); rows.append(row); done.add(idx)
                if idx in done:
                    continue
                row = train_one(model, train_data, val_data, seq_len, seed, steps, batch)
                row['params'] = count_parameters(model)
                row['approx_state_mem_mb'] = estimate_state_memory_bytes(model.cfg, batch, seq_len)['approx_total_bytes'] / (1024*1024) if name.startswith('qlaf') else float('nan')
                rows.append(row)
                f.write_text(json.dumps(row, indent=2))
                gc.collect()
                seq_res['models'][name] = {'per_seed': rows, 'mean': aggregate(rows)}
                all_results[seq_key] = seq_res
                partial_path.write_text(json.dumps(all_results, indent=2))
            seq_res['models'][name] = {'per_seed': rows, 'mean': aggregate(rows)}
            all_results[seq_key] = seq_res
            partial_path.write_text(json.dumps(all_results, indent=2))
    (out_dir/'results.json').write_text(json.dumps(all_results, indent=2))
    lines = ['# v5 second-order rank sweep', '']
    for seq_key, seq_res in all_results.items():
        base = seq_res['models']['transformer_matched']['mean']
        lines += [f'## {seq_key}', '', '| Model | Val loss | Acc | Train tok/s | Infer tok/s | Latency ms | Params |', '|---|---:|---:|---:|---:|---:|---:|']
        for name, data in seq_res['models'].items():
            m = data['mean']
            lines.append(f"| {name} | {m['val_loss']:.4f} | {m['accuracy']:.4f} | {m['train_tok_s']:.0f} | {m['infer_tok_s']:.0f} | {m['latency_ms']:.2f} | {m['params']:.0f} |")
        lines += ['', '| Model | Loss vs transformer | Acc vs transformer | Train tok/s vs transformer | Infer tok/s vs transformer | Latency vs transformer |', '|---|---:|---:|---:|---:|---:|']
        for name, data in seq_res['models'].items():
            if name == 'transformer_matched':
                lines.append('| transformer_matched | baseline | baseline | baseline | baseline | baseline |')
            else:
                m = data['mean']
                lines.append(f"| {name} | {(m['val_loss']-base['val_loss'])/base['val_loss']*100:+.2f}% | {(m['accuracy']-base['accuracy'])/max(base['accuracy'],1e-9)*100:+.2f}% | {(m['train_tok_s']-base['train_tok_s'])/base['train_tok_s']*100:+.2f}% | {(m['infer_tok_s']-base['infer_tok_s'])/base['infer_tok_s']*100:+.2f}% | {(m['latency_ms']-base['latency_ms'])/base['latency_ms']*100:+.2f}% |")
        lines.append('')
    (out_dir/'summary.md').write_text('\n'.join(lines))

if __name__ == '__main__':
    main('/mnt/data/qlaf_ablation/v5_secondrank')
