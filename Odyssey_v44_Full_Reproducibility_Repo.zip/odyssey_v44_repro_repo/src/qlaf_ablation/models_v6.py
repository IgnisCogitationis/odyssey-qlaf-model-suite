import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Dict, Optional
from models_v3 import RMSNorm, PositionalFeatureEncoder, FeatureProjector, GlobalBank, OrderBank, SecondOrderCorrection, MatchedTransformerLM, count_parameters

@dataclass
class QLAFSparseConfig:
    vocab_size: int
    d_model: int = 128
    n_layers: int = 3
    d_ff: int = 384
    dropout: float = 0.0
    max_seq_len: int = 2048
    k_global: int = 4
    k_order: int = 4
    use_second_order_correction: bool = True
    second_order_rank: int = 48
    router_topk: int = 0
    tie_embeddings: bool = True

class SparseRouter(nn.Module):
    def __init__(self, d_model: int, widths: Dict[str, int], topk: int = 0):
        super().__init__()
        self.names = list(widths.keys())
        self.widths = widths
        self.total = sum(widths.values())
        self.topk = topk
        self.net = nn.Sequential(nn.Linear(d_model, d_model), nn.GELU(), nn.Linear(d_model, self.total))
    def forward(self, q):
        logits = self.net(q)
        weights = F.softmax(logits, dim=-1)
        if self.topk and self.topk < self.total:
            vals, idx = torch.topk(weights, self.topk, dim=-1)
            sparse = torch.zeros_like(weights)
            sparse.scatter_(-1, idx, vals)
            weights = sparse / sparse.sum(dim=-1, keepdim=True).clamp_min(1e-9)
        split = {}
        start = 0
        for name in self.names:
            width = self.widths[name]
            split[name] = weights[..., start:start+width]
            start += width
        return split

class QLAFSparseBlock(nn.Module):
    def __init__(self, cfg: QLAFSparseConfig):
        super().__init__()
        self.norm_x = RMSNorm(cfg.d_model)
        self.norm_q = RMSNorm(cfg.d_model)
        self.pos = PositionalFeatureEncoder(cfg.d_model, cfg.max_seq_len)
        self.feat = FeatureProjector(cfg.d_model)
        self.global_bank = GlobalBank(cfg.d_model, cfg.k_global)
        self.order_bank = OrderBank(cfg.d_model, cfg.k_order)
        self.router = SparseRouter(cfg.d_model, {'global': cfg.k_global, 'order': cfg.k_order}, topk=cfg.router_topk)
        self.out_proj = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
        self.ff_norm = RMSNorm(cfg.d_model)
        self.ff = nn.Sequential(nn.Linear(cfg.d_model, cfg.d_ff), nn.GELU(), nn.Linear(cfg.d_ff, cfg.d_model))
        self.dropout = nn.Dropout(cfg.dropout)
        self.second_order = SecondOrderCorrection(cfg.d_model, cfg.second_order_rank) if cfg.use_second_order_correction else None
    def forward(self, x):
        h = self.norm_x(x)
        z = self.feat(self.pos(h))
        q = self.norm_q(h)
        gs = self.global_bank(z, h)
        os = self.order_bank(z, h)
        states = torch.cat([gs, os], dim=1)
        split = self.router(q)
        route = torch.cat([split['global'], split['order']], dim=-1)
        mixed = torch.einsum('btk,bkd->btd', route, states)
        update = self.out_proj(mixed)
        if self.second_order is not None:
            update = update + self.second_order(q, mixed)
        x = x + self.dropout(update)
        x = x + self.dropout(self.ff(self.ff_norm(x)))
        return x

class QLAFSparseLM(nn.Module):
    def __init__(self, cfg: QLAFSparseConfig):
        super().__init__()
        self.cfg = cfg
        self.tok_emb = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.blocks = nn.ModuleList([QLAFSparseBlock(cfg) for _ in range(cfg.n_layers)])
        self.final_norm = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        if cfg.tie_embeddings:
            self.lm_head.weight = self.tok_emb.weight
    def forward(self, idx, targets: Optional[torch.Tensor] = None):
        x = self.tok_emb(idx)
        for block in self.blocks:
            x = block(x)
        x = self.final_norm(x)
        logits = self.lm_head(x)
        out={'logits': logits}
        if targets is not None:
            out['loss']=F.cross_entropy(logits[:, :-1].reshape(-1, logits.size(-1)), targets[:, 1:].reshape(-1))
        return out
