import math
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class QLAFPyramidConfig:
    vocab_size: int
    d_model: int = 128
    n_layers: int = 3
    d_ff: int = 384
    dropout: float = 0.0
    max_seq_len: int = 2048
    k_global: int = 4
    k_order: int = 4
    k_local: int = 4
    local_scales: Tuple[int, ...] = (16, 64, 256)
    use_second_order_correction: bool = False
    second_order_rank: int = 24
    tie_embeddings: bool = True


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(dim=-1, keepdim=True) + self.eps) * self.weight


class PositionalFeatureEncoder(nn.Module):
    def __init__(self, d_model: int, max_seq_len: int):
        super().__init__()
        self.abs_pos = nn.Embedding(max_seq_len, d_model)

    def forward(self, h):
        bsz, seq_len, _ = h.shape
        device = h.device
        pos = torch.arange(seq_len, device=device)
        denom = max(seq_len - 1, 1)
        pos_norm = (pos.float() / denom).view(1, seq_len, 1).expand(bsz, -1, -1)
        rev_norm = ((seq_len - 1 - pos).float() / denom).view(1, seq_len, 1).expand(bsz, -1, -1)
        center_dist = ((pos.float() - 0.5 * denom).abs() / max(0.5 * denom, 1.0)).view(1, seq_len, 1).expand(bsz, -1, -1)
        return torch.cat([h, self.abs_pos(pos).unsqueeze(0).expand(bsz, -1, -1), pos_norm, rev_norm, center_dist], dim=-1)


class FeatureProjector(nn.Module):
    def __init__(self, d_model: int):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(2 * d_model + 3, d_model), nn.GELU(), nn.Linear(d_model, d_model))

    def forward(self, x):
        return self.net(x)


class GlobalBank(nn.Module):
    def __init__(self, d_model: int, k: int):
        super().__init__()
        self.k = k
        self.templates = nn.Parameter(torch.randn(k, d_model) / math.sqrt(d_model)) if k > 0 else None
        self.value_proj = nn.Linear(d_model, d_model, bias=False)

    def forward(self, z, h):
        values = self.value_proj(h)
        if self.k == 0:
            return values.new_zeros(values.size(0), 0, values.size(-1))
        scores = torch.einsum('btd,kd->btk', z, self.templates)
        weights = F.softmax(scores, dim=1)
        return torch.einsum('btk,btd->bkd', weights, values)


class OrderBank(nn.Module):
    def __init__(self, d_model: int, k: int):
        super().__init__()
        self.k = k
        self.value_proj = nn.Linear(d_model, d_model, bias=False)
        if k > 0:
            self.fwd_templates = nn.Parameter(torch.randn(k, d_model) / math.sqrt(d_model))
            self.rev_templates = nn.Parameter(torch.randn(k, d_model) / math.sqrt(d_model))
            self.prefix_gate = nn.Linear(d_model, k)
            self.suffix_gate = nn.Linear(d_model, k)
            self.mix = nn.Linear(4 * k, k, bias=False)

    def _pool(self, scores, values):
        return torch.einsum('btk,btd->bkd', F.softmax(scores, dim=1), values)

    def forward(self, z, h):
        values = self.value_proj(h)
        if self.k == 0:
            return values.new_zeros(values.size(0), 0, values.size(-1))
        fwd = self._pool(torch.einsum('btd,kd->btk', z, self.fwd_templates), values)
        rev = self._pool(torch.einsum('btd,kd->btk', z.flip(1), self.rev_templates).flip(1), values)
        pref = self._pool(torch.cumsum(self.prefix_gate(z), dim=1), values)
        suff = self._pool(torch.cumsum(self.suffix_gate(z.flip(1)), dim=1).flip(1), values)
        stacked = torch.cat([fwd, rev, pref, suff], dim=1)
        mix_w = F.softmax(self.mix.weight, dim=-1)
        return torch.einsum('ks,bsd->bkd', mix_w, stacked)


class PyramidLocalBank(nn.Module):
    """Hierarchical chunk pyramid: cheap local summaries across multiple chunk scales."""
    def __init__(self, d_model: int, k: int, scales: Tuple[int, ...]):
        super().__init__()
        self.k = k
        self.scales = tuple(scales)
        self.value_proj = nn.Linear(d_model, d_model, bias=False)
        if k > 0 and len(scales) > 0:
            self.templates = nn.Parameter(torch.randn(len(scales), k, d_model) / math.sqrt(d_model))
            self.scale_mix = nn.Linear(len(scales) * k, k, bias=False)
            self.residual_gate = nn.Linear(d_model, k)

    def forward(self, z, h):
        values = self.value_proj(h)
        bsz, seq_len, dim = z.shape
        if self.k == 0 or len(self.scales) == 0:
            return values.new_zeros(values.size(0), 0, values.size(-1))
        per_scale = []
        for si, scale in enumerate(self.scales):
            n_chunks = max(1, math.ceil(seq_len / scale))
            chunk_zs = []
            chunk_vs = []
            for c in range(n_chunks):
                lo, hi = c * scale, min(seq_len, (c + 1) * scale)
                zc = z[:, lo:hi, :]
                vc = values[:, lo:hi, :]
                # keep both mean and a weak boundary-sensitive residual statistic
                chunk_zs.append(zc.mean(dim=1) + 0.1 * (zc[:, -1, :] - zc[:, 0, :]))
                chunk_vs.append(vc.mean(dim=1))
            chunk_z = torch.stack(chunk_zs, dim=1)
            chunk_v = torch.stack(chunk_vs, dim=1)
            scores = torch.einsum('bcd,kd->bck', chunk_z, self.templates[si])
            weights = F.softmax(scores, dim=1)
            pooled = torch.einsum('bck,bcd->bkd', weights, chunk_v)
            per_scale.append(pooled)
        stacked = torch.cat(per_scale, dim=1)
        mix_w = F.softmax(self.scale_mix.weight, dim=-1)
        mixed = torch.einsum('ks,bsd->bkd', mix_w, stacked)
        # add a weak global residual anchor derived from token-level pooled gates
        gate = F.softmax(self.residual_gate(z), dim=1)
        anchor = torch.einsum('btk,btd->bkd', gate, values)
        return mixed + 0.2 * anchor


class DenseRouter(nn.Module):
    def __init__(self, d_model: int, widths: Dict[str, int]):
        super().__init__()
        self.names = list(widths.keys())
        self.widths = widths
        total = sum(widths.values())
        self.net = nn.Sequential(nn.Linear(d_model, d_model), nn.GELU(), nn.Linear(d_model, total))

    def forward(self, q):
        logits = self.net(q)
        weights = F.softmax(logits, dim=-1)
        split = {}
        start = 0
        for name in self.names:
            w = self.widths[name]
            split[name] = weights[..., start:start+w]
            start += w
        return split


class SecondOrderCorrection(nn.Module):
    def __init__(self, d_model: int, rank: int):
        super().__init__()
        self.q_proj = nn.Linear(d_model, rank, bias=False)
        self.s_proj = nn.Linear(d_model, rank, bias=False)
        self.out = nn.Linear(rank, d_model, bias=False)

    def forward(self, q, mixed):
        return self.out(self.q_proj(q) * self.s_proj(mixed))


class QLAFPyramidBlock(nn.Module):
    def __init__(self, cfg: QLAFPyramidConfig):
        super().__init__()
        self.norm_x = RMSNorm(cfg.d_model)
        self.norm_q = RMSNorm(cfg.d_model)
        self.pos = PositionalFeatureEncoder(cfg.d_model, cfg.max_seq_len)
        self.feat = FeatureProjector(cfg.d_model)
        self.global_bank = GlobalBank(cfg.d_model, cfg.k_global)
        self.order_bank = OrderBank(cfg.d_model, cfg.k_order)
        self.local_bank = PyramidLocalBank(cfg.d_model, cfg.k_local, cfg.local_scales)
        self.router = DenseRouter(cfg.d_model, {'global': cfg.k_global, 'order': cfg.k_order, 'local': cfg.k_local})
        self.out_proj = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
        self.ff_norm = RMSNorm(cfg.d_model)
        self.ff = nn.Sequential(nn.Linear(cfg.d_model, cfg.d_ff), nn.GELU(), nn.Linear(cfg.d_ff, cfg.d_model))
        self.dropout = nn.Dropout(cfg.dropout)
        self.second_order = SecondOrderCorrection(cfg.d_model, cfg.second_order_rank) if cfg.use_second_order_correction else None

    def forward(self, x):
        h = self.norm_x(x)
        z = self.feat(self.pos(h))
        q = self.norm_q(h)
        gs = self.global_bank(z, h)
        os = self.order_bank(z, h)
        ls = self.local_bank(z, h)
        states = torch.cat([gs, os, ls], dim=1)
        split = self.router(q)
        route = torch.cat([split['global'], split['order'], split['local']], dim=-1)
        mixed = torch.einsum('btk,bkd->btd', route, states)
        update = self.out_proj(mixed)
        if self.second_order is not None:
            update = update + self.second_order(q, mixed)
        x = x + self.dropout(update)
        x = x + self.dropout(self.ff(self.ff_norm(x)))
        return x


class QLAFPyramidLM(nn.Module):
    def __init__(self, cfg: QLAFPyramidConfig):
        super().__init__()
        self.cfg = cfg
        self.tok_emb = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.blocks = nn.ModuleList([QLAFPyramidBlock(cfg) for _ in range(cfg.n_layers)])
        self.final_norm = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        if cfg.tie_embeddings:
            self.lm_head.weight = self.tok_emb.weight

    def forward(self, idx, targets: Optional[torch.Tensor] = None):
        x = self.tok_emb(idx)
        for b in self.blocks:
            x = b(x)
        x = self.final_norm(x)
        logits = self.lm_head(x)
        out = {'logits': logits}
        if targets is not None:
            out['loss'] = F.cross_entropy(logits[:, :-1].reshape(-1, logits.size(-1)), targets[:, 1:].reshape(-1))
        return out


class TransformerBlock(nn.Module):
    def __init__(self, d_model: int, n_heads: int, d_ff: int, dropout: float):
        super().__init__()
        self.norm1 = RMSNorm(d_model)
        self.attn = nn.MultiheadAttention(d_model, n_heads, dropout=dropout, batch_first=True)
        self.norm2 = RMSNorm(d_model)
        self.ff = nn.Sequential(nn.Linear(d_model, d_ff), nn.GELU(), nn.Linear(d_ff, d_model))
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        h = self.norm1(x)
        T = h.size(1)
        mask = torch.triu(torch.ones(T, T, device=h.device, dtype=torch.bool), diagonal=1)
        y, _ = self.attn(h, h, h, attn_mask=mask, need_weights=False)
        x = x + self.dropout(y)
        x = x + self.dropout(self.ff(self.norm2(x)))
        return x


class MatchedTransformerLM(nn.Module):
    def __init__(self, vocab_size: int, d_model: int = 128, n_layers: int = 3, n_heads: int = 4, d_ff: int = 384, max_seq_len: int = 2048, dropout: float = 0.0, tie_embeddings: bool = True):
        super().__init__()
        self.tok_emb = nn.Embedding(vocab_size, d_model)
        self.pos_emb = nn.Embedding(max_seq_len, d_model)
        self.blocks = nn.ModuleList([TransformerBlock(d_model, n_heads, d_ff, dropout) for _ in range(n_layers)])
        self.final_norm = RMSNorm(d_model)
        self.lm_head = nn.Linear(d_model, vocab_size, bias=False)
        if tie_embeddings:
            self.lm_head.weight = self.tok_emb.weight

    def forward(self, idx, targets: Optional[torch.Tensor] = None):
        B, T = idx.shape
        pos = torch.arange(T, device=idx.device)
        x = self.tok_emb(idx) + self.pos_emb(pos)[None, :, :]
        for b in self.blocks:
            x = b(x)
        x = self.final_norm(x)
        logits = self.lm_head(x)
        out = {'logits': logits}
        if targets is not None:
            out['loss'] = F.cross_entropy(logits[:, :-1].reshape(-1, logits.size(-1)), targets[:, 1:].reshape(-1))
        return out


def count_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


def estimate_state_memory_bytes(cfg: QLAFPyramidConfig, batch_size: int, seq_len: int, bytes_per_elem: int = 4):
    total_states = cfg.k_global + cfg.k_order + cfg.k_local
    return {
        'state_tensor_bytes': batch_size * total_states * cfg.d_model * bytes_per_elem,
        'token_hidden_bytes': batch_size * seq_len * cfg.d_model * bytes_per_elem,
        'route_logits_bytes': batch_size * seq_len * total_states * bytes_per_elem,
        'approx_total_bytes': batch_size * (total_states * cfg.d_model + seq_len * cfg.d_model + seq_len * total_states) * bytes_per_elem,
    }
