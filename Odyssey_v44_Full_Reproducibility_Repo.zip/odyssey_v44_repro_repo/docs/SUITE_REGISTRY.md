# Suite Registry

- curriculum_frontier_compare: direct curriculum frontier comparisons at 512 and 1024
- objective_attack_extend: objective/curriculum extension family
- scaling_longctx: 1536 / 2048 long-context scaling confirmation
- bridgeqlaf_bench_safe: stable bridge benchmark family
- v10_confirmation: preserved 5-seed confirmation package (preserved for inspection; not wired into automated run)