import argparse, torch
from odyssey_gpu_v21 import OdysseyGPUV21LM, OdysseyDeploymentEngineV21, preset_v21, drift_metrics

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--device",default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--dtype",default="bf16",choices=["fp32","fp16","bf16"])
    ap.add_argument("--quantize-cache",action="store_true")
    args=ap.parse_args()
    device=torch.device(args.device); dtype={"fp32":torch.float32,"fp16":torch.float16,"bf16":torch.bfloat16}[args.dtype]
    amp=device.type=="cuda" and dtype!=torch.float32
    cfg=preset_v21("tiny",vocab_size=2048,max_seq_len=256,quantize_cache=args.quantize_cache)
    model=OdysseyGPUV21LM(cfg).to(device)
    x=torch.randint(0,cfg.vocab_size,(2,64),device=device)
    y=torch.randint(0,cfg.vocab_size,(2,64),device=device)
    opt=torch.optim.AdamW(model.parameters(),lr=1e-4)
    with torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
        _,loss=model(x,y,phase="train",mode="balanced")
    assert torch.isfinite(loss)
    loss.backward(); opt.step()
    eng=OdysseyDeploymentEngineV21(model)
    cache=eng.make_cache(2,device,dtype)
    with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
        eng.prefill(x[:,:32],cache,mode="balanced")
        ref=eng.decode_reference(x[:,:33],None,mode="speed")
        rec=eng.decode_recurrent(x[:,32:33],cache,mode="speed")
    print("PASS loss",float(loss.detach().cpu()),"drift",drift_metrics(ref,rec),"cache_nbytes",cache.nbytes())
if __name__=="__main__": main()
