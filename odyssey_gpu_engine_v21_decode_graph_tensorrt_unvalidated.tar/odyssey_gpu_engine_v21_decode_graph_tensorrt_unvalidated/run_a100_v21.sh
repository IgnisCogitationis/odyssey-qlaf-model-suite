#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python validate_v21.py --device cuda --dtype bf16
python validate_v21.py --device cuda --dtype bf16 --quantize-cache
python benchmark_v21_decode.py --device cuda --dtype bf16 --size small --batch 4 --context 1024 --steps 128 --trials 20 --out results/v21_a100_decode.csv
python benchmark_v21_decode.py --device cuda --dtype bf16 --size small --batch 4 --context 1024 --steps 128 --trials 20 --quantize-cache --out results/v21_a100_decode_quant.csv
python benchmark_v21_decode.py --device cuda --dtype bf16 --size small --batch 4 --context 1024 --steps 128 --trials 20 --cuda-graph --out results/v21_a100_decode_graph.csv
