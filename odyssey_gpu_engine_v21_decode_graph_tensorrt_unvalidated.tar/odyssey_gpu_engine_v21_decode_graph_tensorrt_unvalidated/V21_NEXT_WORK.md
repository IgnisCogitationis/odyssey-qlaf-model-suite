# v21 Next Work

1. Replace `fused_qlaf_decode_only_reference` with real Triton/CUDA.
2. Flatten cache tensors for TensorRT export.
3. Add ONNX export scripts for decode-only mode.
4. Validate CUDA graph replay after fixed-shape kernel replacement.
5. Add FlashAttention-2 baseline package.
6. Distill recurrent decode on real corpus.
