#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python validate_v21.py --device cuda --dtype bf16
python validate_v21.py --device cuda --dtype bf16 --quantize-cache
python benchmark_v21_decode.py --device cuda --dtype bf16 --size base --batch 8 --context 4096 --steps 256 --trials 20 --out results/v21_h100_decode.csv
python benchmark_v21_decode.py --device cuda --dtype bf16 --size base --batch 8 --context 4096 --steps 256 --trials 20 --quantize-cache --out results/v21_h100_decode_quant.csv
python benchmark_v21_decode.py --device cuda --dtype bf16 --size base --batch 8 --context 4096 --steps 256 --trials 20 --cuda-graph --out results/v21_h100_decode_graph.csv
