"""
v21 kernel boundaries.

Reference functions are correct PyTorch implementations. A GPU engineer should replace
the decode/prefill functions with Triton/CUDA kernels while preserving signatures.
"""

from __future__ import annotations
from typing import Optional, Tuple
import torch
import torch.nn.functional as F


def fused_route_controller_reference(
    control: torch.Tensor,
    branch_weight: torch.Tensor,
    branch_bias: torch.Tensor,
    conf_weight: torch.Tensor,
    conf_bias: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Reference route-controller fusion.

    Future kernel should compute branch gate + confidence in one pass.
    """
    h = torch.tanh(control)
    gate = torch.softmax(F.linear(h, branch_weight, branch_bias), dim=-1)
    confidence = torch.sigmoid(F.linear(h, conf_weight, conf_bias)).squeeze(-1)
    return gate, confidence


def route_weights_reference(logits: torch.Tensor, mode: str):
    if mode == "top1":
        idx = logits.argmax(dim=-1, keepdim=True)
        return torch.zeros_like(logits).scatter_(-1, idx, 1.0), idx.squeeze(-1)
    if mode == "top2" and logits.size(-1) > 2:
        vals, idx = torch.topk(logits, k=2, dim=-1)
        sparse = torch.full_like(logits, float("-inf"))
        sparse.scatter_(-1, idx, vals)
        return torch.softmax(sparse, dim=-1), idx[..., 0]
    return torch.softmax(logits, dim=-1), logits.argmax(dim=-1)


def fused_qlaf_decode_only_reference(
    x_token: torch.Tensor,
    prev_summary: Optional[torch.Tensor],
    packed_weight: torch.Tensor,
    out_weight: torch.Tensor,
    summary_weight: torch.Tensor,
    state_scale: torch.Tensor,
    n_states: int,
    summary_mix: float,
):
    """
    True target: one fused decode-only CUDA/Triton kernel.

    Input:
      x_token [B,1,D]
      prev_summary [B,D] or None

    Output:
      qlaf_out [B,1,D]
      next_summary [B,D]
      route_id [B]
      confidence [B]
      control [B,1,D]
    """
    B, T, D = x_token.shape
    assert T == 1
    z = F.linear(x_token, packed_weight)
    raw = z[..., : n_states * D].view(B, 1, n_states, D)
    logits = z[..., n_states * D : n_states * D + n_states]
    control = z[..., n_states * D + n_states :]
    weights, route_id = route_weights_reference(logits, "top1")
    states = torch.tanh(raw) * state_scale.view(1, 1, n_states, D)
    combined = torch.einsum("bts,btsd->btd", weights, states)
    if prev_summary is not None:
        recurrent = F.linear(prev_summary, summary_weight).unsqueeze(1)
        combined = summary_mix * recurrent + (1.0 - summary_mix) * combined
    out = F.linear(combined, out_weight)
    confidence = weights.max(dim=-1).values.squeeze(1)
    return out, combined[:, -1, :], route_id.squeeze(1), confidence, control


def fused_qlaf_prefill_reference(
    x: torch.Tensor,
    packed_weight: torch.Tensor,
    out_weight: torch.Tensor,
    state_scale: torch.Tensor,
    n_states: int,
    route_mode: str,
):
    B, T, D = x.shape
    z = F.linear(x, packed_weight)
    raw = z[..., : n_states * D].view(B, T, n_states, D)
    logits = z[..., n_states * D : n_states * D + n_states]
    control = z[..., n_states * D + n_states :]
    weights, route_id = route_weights_reference(logits, route_mode)
    states = torch.tanh(raw) * state_scale.view(1, 1, n_states, D)
    combined = torch.einsum("bts,btsd->btd", weights, states)
    out = F.linear(combined, out_weight)
    return out, combined[:, -1, :], route_id, weights.max(dim=-1).values, control


def budgeted_tsc_reference(x, confidence, left_weight, right_weight, out_weight, rank, budget):
    if budget <= 0:
        return torch.zeros_like(x)
    B, T, D = x.shape
    k = max(1, int(T * budget))
    _, idx = torch.topk(-confidence, k=k, dim=1)
    mask = torch.zeros(B, T, device=x.device, dtype=x.dtype)
    mask.scatter_(1, idx, 1.0)
    left = F.linear(x, left_weight).view(B, T, rank, D)
    right = torch.softmax(F.linear(x, right_weight), dim=-1).view(B, T, rank, 1)
    y = F.linear(torch.tanh((left * right).sum(dim=2)), out_weight)
    return y * mask.unsqueeze(-1)


def fused_residual_reference(x, q, local, tsc, gate, qlaf_weight, local_weight, tsc_weight, controller_mix):
    fixed = qlaf_weight * q + local_weight * local + tsc_weight * tsc
    adaptive = gate[..., 0:1] * q + gate[..., 1:2] * local + gate[..., 2:3] * tsc
    return x + (1.0 - controller_mix) * fixed + controller_mix * adaptive
