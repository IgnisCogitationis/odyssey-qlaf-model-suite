# Odyssey GPU Engine v21 — Decode Kernel + Graph Replay + TensorRT Specialization Pass

Status: **written and packaged, not CUDA/Triton/TensorRT validated in this environment**.

v21 targets the five highest-upside production optimizations:

1. true decode-only fused kernel boundary
2. CUDA graph replay scaffold
3. quantized summaries
4. route-controller fusion
5. TensorRT specialization/export plan

This package is still a PyTorch reference implementation with guarded production hooks. It is designed to be handed to a GPU/Triton/TensorRT engineer.

## Main files

- `odyssey_gpu_v21.py` — v21 model + deployment engine
- `kernel_boundaries_v21.py` — fused decode/prefill/reference kernel contracts
- `cuda_graph_replay_v21.py` — CUDA graph replay wrapper scaffold
- `cache_quant_v21.py` — int8 cache summary quantization
- `tensorrt_specialization_v21.md` — TensorRT/export plan
- `benchmark_v21_decode.py` — fixed-shape recurrent decode benchmark
- `validate_v21.py` — smoke + cache + drift validation
- `run_a100_v21.sh`
- `run_h100_v21.sh`

## Best intended deployment mode

```text
prefill: balanced, top2 routing
decode: speed, recurrent, top1 routing, TSC off
cache: quantized summaries optional
graph replay: fixed batch/shape decode
kernel: fused QLAF decode-only kernel
```

## Still required before performance claims

- implement Triton/CUDA fused decode kernel
- validate numerical equivalence
- run A100/H100 benchmarks
- compare against FlashAttention transformer
- train/distill recurrent decode path on a real corpus
