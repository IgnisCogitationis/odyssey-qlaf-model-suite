from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Literal, List, Any
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from kernel_boundaries_v21 import (
    fused_qlaf_decode_only_reference,
    fused_qlaf_prefill_reference,
    fused_route_controller_reference,
    budgeted_tsc_reference,
    fused_residual_reference,
)
from cache_quant_v21 import maybe_quantize, dequantize, nbytes

Phase = Literal["train","prefill","decode_reference","decode_recurrent","decode_chunk"]
Mode = Literal["quality","balanced","speed","survival"]

@dataclass
class V21Config:
    vocab_size: int = 8192
    d_model: int = 512
    n_layers: int = 8
    n_heads: int = 8
    d_ff: int = 2048
    max_seq_len: int = 4096
    dropout: float = 0.0
    n_states: int = 4
    tsc_rank: int = 4
    qlaf_weight: float = 0.91
    local_weight: float = 0.06
    tsc_weight: float = 0.03
    controller_mix: float = 0.035
    summary_mix: float = 0.875
    train_tsc_budget: float = 0.125
    prefill_tsc_budget: float = 0.125
    chunk_tsc_budget: float = 0.03125
    train_tsc_grad_scale: float = 0.30
    short_seq_cutoff: int = 128
    quantize_cache: bool = False
    grouped_local: bool = True
    local_kernel: int = 5

def preset_v21(size: str="small", **overrides) -> V21Config:
    presets = {
        "tiny": dict(d_model=128,n_layers=2,n_heads=4,d_ff=512,max_seq_len=2048,n_states=4,tsc_rank=4),
        "small": dict(d_model=256,n_layers=4,n_heads=4,d_ff=1024,max_seq_len=4096,n_states=4,tsc_rank=4),
        "base": dict(d_model=512,n_layers=8,n_heads=8,d_ff=2048,max_seq_len=4096,n_states=4,tsc_rank=4),
        "large": dict(d_model=768,n_layers=12,n_heads=12,d_ff=3072,max_seq_len=8192,n_states=6,tsc_rank=6),
    }
    kw = presets.get(size, presets["small"]).copy()
    kw.update(overrides)
    return V21Config(**kw)

@dataclass
class LayerCache:
    summary: Optional[Any] = None
    route_id: Optional[torch.Tensor] = None
    confidence: Optional[torch.Tensor] = None
    steps: int = 0

@dataclass
class OdysseyV21Cache:
    batch_size: int
    n_layers: int
    d_model: int
    max_seq_len: int
    device: torch.device
    dtype: torch.dtype
    quantized: bool = False
    layers: List[LayerCache] = field(default_factory=list)
    token_count: int = 0
    def __post_init__(self):
        if not self.layers:
            self.layers = [LayerCache() for _ in range(self.n_layers)]
    def validate(self,batch,device):
        if batch != self.batch_size: raise ValueError("cache batch mismatch")
        if device != self.device: raise ValueError("cache device mismatch")
    def get_summary(self,i):
        return dequantize(self.layers[i].summary)
    def update(self,i,summary,route_id,confidence):
        layer=self.layers[i]
        layer.summary=maybe_quantize(summary.detach(), self.quantized)
        layer.route_id=route_id.detach() if route_id is not None else None
        layer.confidence=confidence.detach() if confidence is not None else None
        layer.steps += 1
    def nbytes(self):
        total=0
        for l in self.layers:
            total += nbytes(l.summary)+nbytes(l.route_id)+nbytes(l.confidence)
        return total
    def reset(self):
        self.token_count=0
        for l in self.layers:
            l.summary=None; l.route_id=None; l.confidence=None; l.steps=0

class RMSNorm(nn.Module):
    def __init__(self,d,eps=1e-6):
        super().__init__(); self.weight=nn.Parameter(torch.ones(d)); self.eps=eps
    def forward(self,x):
        return x*torch.rsqrt(x.square().mean(dim=-1,keepdim=True)+self.eps)*self.weight

class SwiGLU(nn.Module):
    def __init__(self,d,ff):
        super().__init__(); self.a=nn.Linear(d,ff,bias=False); self.b=nn.Linear(d,ff,bias=False); self.o=nn.Linear(ff,d,bias=False)
    def forward(self,x): return self.o(F.silu(self.a(x))*self.b(x))

class QLAFV21(nn.Module):
    def __init__(self,cfg):
        super().__init__(); self.cfg=cfg
        d,s=cfg.d_model,cfg.n_states
        self.packed=nn.Linear(d,s*d+s+d,bias=False)
        self.out=nn.Linear(d,d,bias=False)
        self.summary_proj=nn.Linear(d,d,bias=False)
        self.scale=nn.Parameter(torch.ones(s,d)/math.sqrt(d))
    def forward(self,x,phase,prev=None):
        if phase=="decode_recurrent" and x.size(1)==1:
            return fused_qlaf_decode_only_reference(
                x, prev, self.packed.weight, self.out.weight, self.summary_proj.weight,
                self.scale, self.cfg.n_states, self.cfg.summary_mix
            )
        route = "soft" if phase=="train" else ("top2" if phase=="prefill" else "top1")
        return fused_qlaf_prefill_reference(x,self.packed.weight,self.out.weight,self.scale,self.cfg.n_states,route)

class AIONV21(nn.Module):
    def __init__(self,d):
        super().__init__(); self.branch=nn.Linear(d,3,bias=True); self.conf=nn.Linear(d,1,bias=True)
    def forward(self,control):
        return fused_route_controller_reference(control,self.branch.weight,self.branch.bias,self.conf.weight,self.conf.bias)

class LocalV21(nn.Module):
    def __init__(self,cfg):
        super().__init__(); d=cfg.d_model; self.cfg=cfg
        self.group=nn.Sequential(nn.Linear(d,d,bias=False),nn.GELU(),nn.Linear(d,d,bias=False))
        self.dw=nn.Conv1d(d,d,kernel_size=cfg.local_kernel,padding=cfg.local_kernel-1,groups=d,bias=False)
        self.pw=nn.Linear(d,d,bias=False); self.g=nn.Linear(d,d,bias=False)
    def forward(self,x):
        if self.cfg.grouped_local: y=self.group(x)
        else:
            y=self.dw(x.transpose(1,2))[:,:,:x.size(1)].transpose(1,2); y=self.pw(y)
        return y*torch.sigmoid(self.g(x))

class TSCV21(nn.Module):
    def __init__(self,cfg):
        super().__init__(); d,r=cfg.d_model,cfg.tsc_rank; self.cfg=cfg
        self.l=nn.Linear(d,r*d,bias=False); self.r=nn.Linear(d,r,bias=False); self.o=nn.Linear(d,d,bias=False)
    def forward(self,x,conf,budget):
        return budgeted_tsc_reference(x,conf,self.l.weight,self.r.weight,self.o.weight,self.cfg.tsc_rank,budget)

def policy(cfg,phase,mode,seq):
    if phase!="train" and seq<=cfg.short_seq_cutoff: return dict(local=0,tsc=0,budget=0,ff=1)
    if mode=="survival": return dict(local=0,tsc=0,budget=0,ff=.70)
    if mode=="speed":
        if phase in ("decode_reference","decode_recurrent"): return dict(local=0,tsc=0,budget=0,ff=.85)
        if phase=="decode_chunk": return dict(local=.10,tsc=.05,budget=cfg.chunk_tsc_budget,ff=.90)
        return dict(local=.25,tsc=.10,budget=cfg.prefill_tsc_budget,ff=1)
    if mode=="balanced":
        if phase in ("decode_reference","decode_recurrent"): return dict(local=.05,tsc=0,budget=0,ff=.90)
        if phase=="decode_chunk": return dict(local=.25,tsc=.10,budget=cfg.chunk_tsc_budget,ff=1)
        return dict(local=.75,tsc=.30,budget=cfg.train_tsc_budget if phase=="train" else cfg.prefill_tsc_budget,ff=1)
    return dict(local=1,tsc=1,budget=1,ff=1)

class BlockV21(nn.Module):
    def __init__(self,cfg):
        super().__init__(); self.cfg=cfg; d=cfg.d_model
        self.n1=RMSNorm(d); self.qlaf=QLAFV21(cfg); self.aion=AIONV21(d); self.local=LocalV21(cfg); self.tsc=TSCV21(cfg)
        self.n2=RMSNorm(d); self.ff=SwiGLU(d,cfg.d_ff)
    def forward(self,x,phase,mode,prev=None):
        cfg=self.cfg; h=self.n1(x)
        q,summary,rid,qconf,control = self.qlaf(h,phase,prev)
        gate,aconf = self.aion(control)
        conf=.5*qconf+.5*aconf
        pol=policy(cfg,phase,mode,x.size(1))
        local=self.local(h)*pol["local"] if pol["local"]>0 else torch.zeros_like(q)
        tsc=self.tsc(h,conf,pol["budget"])*pol["tsc"] if pol["tsc"]>0 else torch.zeros_like(q)
        if phase=="train" and pol["tsc"]>0:
            tsc=tsc*cfg.train_tsc_grad_scale + tsc.detach()*(1-cfg.train_tsc_grad_scale)
        x=fused_residual_reference(x,q,local,tsc,gate,cfg.qlaf_weight,cfg.local_weight,cfg.tsc_weight,cfg.controller_mix)
        if pol["ff"]>0: x=x+self.ff(self.n2(x))*pol["ff"]
        return x,summary,rid,conf

class OdysseyGPUV21LM(nn.Module):
    def __init__(self,cfg):
        super().__init__(); self.cfg=cfg
        self.tok=nn.Embedding(cfg.vocab_size,cfg.d_model); self.pos=nn.Embedding(cfg.max_seq_len,cfg.d_model)
        self.blocks=nn.ModuleList([BlockV21(cfg) for _ in range(cfg.n_layers)])
        self.norm=RMSNorm(cfg.d_model); self.head=nn.Linear(cfg.d_model,cfg.vocab_size,bias=False); self.head.weight=self.tok.weight
    def forward(self,idx,targets=None,phase="train",mode="balanced",cache=None):
        B,T=idx.shape
        if cache is not None: cache.validate(B,idx.device)
        base=cache.token_count if (cache is not None and phase=="decode_recurrent") else 0
        pos=torch.clamp(base+torch.arange(T,device=idx.device),max=self.cfg.max_seq_len-1).unsqueeze(0)
        x=self.tok(idx)+self.pos(pos)
        for i,b in enumerate(self.blocks):
            prev=cache.get_summary(i) if cache is not None else None
            x,s,r,c=b(x,phase,mode,prev)
            if cache is not None: cache.update(i,s,r,c)
        if cache is not None: cache.token_count += T if phase=="prefill" else 1
        x=self.norm(x); logits=self.head(x)
        loss=None
        if targets is not None: loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1))
        return logits,loss

class OdysseyDeploymentEngineV21:
    def __init__(self,model):
        self.model=model; self.cfg=model.cfg
    def make_cache(self,batch,device,dtype):
        return OdysseyV21Cache(batch,self.cfg.n_layers,self.cfg.d_model,self.cfg.max_seq_len,device,dtype,quantized=self.cfg.quantize_cache)
    @torch.no_grad()
    def prefill(self,idx,cache=None,mode="balanced"):
        self.model.eval(); return self.model(idx,phase="prefill",mode=mode,cache=cache)[0]
    @torch.no_grad()
    def decode_recurrent(self,token,cache,mode="speed"):
        self.model.eval(); return self.model(token,phase="decode_recurrent",mode=mode,cache=cache)[0][:,-1,:]
    @torch.no_grad()
    def decode_reference(self,idx,cache=None,mode="speed"):
        self.model.eval(); return self.model(idx,phase="decode_reference",mode=mode,cache=cache)[0][:,-1,:]

def drift_metrics(ref,rec):
    ref=ref.detach().float(); rec=rec.detach().float(); err=(ref-rec).abs()
    kl=F.kl_div(F.log_softmax(rec,dim=-1),F.softmax(ref,dim=-1),reduction="batchmean")
    return {"mae":float(err.mean().cpu()),"max_abs":float(err.max().cpu()),"kl":float(kl.cpu()),"top1":float((ref.argmax(-1)==rec.argmax(-1)).float().mean().cpu())}

def count_params(m): return sum(p.numel() for p in m.parameters())
