# TensorRT Specialization Plan

## Goal

Specialize Odyssey v21 for fixed-shape recurrent decode deployment.

## Candidate export units

### Unit 1: decode-only QLAF block

Inputs:
- token embedding hidden `[B,1,D]`
- per-layer summary `[B,D]`
- fixed weights

Outputs:
- logits `[B,V]`
- updated summaries `[layers,B,D]`

### Unit 2: prefill engine

Inputs:
- prompt tokens `[B,T]`

Outputs:
- logits `[B,T,V]`
- summaries `[layers,B,D]`

## TensorRT constraints

Dynamic Python control must be removed. Export should use:
- fixed batch
- fixed max context
- fixed dtype BF16/FP16
- fixed serving mode `speed`
- TSC disabled for decode
- route fixed to top1
- cache summaries as tensors

## ONNX/TensorRT risks

- Python cache dataclasses must be flattened to tensors.
- Quantized summary object must be replaced by tensor + scale.
- Top-k routing may need custom plugin.
- Einsum may need lowering to matmul/elementwise.
- Weight tying may need explicit head weight export.

## Recommendation

Do not export the whole training model first.

Export:
1. decode-only speed mode
2. prefill balanced mode
3. transformer baseline for comparison
