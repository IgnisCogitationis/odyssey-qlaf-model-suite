"""
CUDA graph replay scaffold.

This is intentionally guarded. It only activates on CUDA and fixed shapes.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Optional
import torch


@dataclass
class CUDAGraphDecodeReplay:
    fn: Callable
    static_token: torch.Tensor
    cache: object
    mode: str = "speed"
    graph: Optional[torch.cuda.CUDAGraph] = None
    static_output: Optional[torch.Tensor] = None
    enabled: bool = False

    def capture(self):
        if not torch.cuda.is_available() or self.static_token.device.type != "cuda":
            self.enabled = False
            return False
        try:
            # Warmup
            for _ in range(3):
                self.static_output = self.fn(self.static_token, self.cache, self.mode)
            torch.cuda.synchronize()
            self.graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(self.graph):
                self.static_output = self.fn(self.static_token, self.cache, self.mode)
            self.enabled = True
            return True
        except Exception as e:
            print("CUDA graph capture failed:", repr(e))
            self.enabled = False
            return False

    def replay(self, token: torch.Tensor):
        if not self.enabled or self.graph is None:
            return self.fn(token, self.cache, self.mode)
        self.static_token.copy_(token)
        self.graph.replay()
        return self.static_output
