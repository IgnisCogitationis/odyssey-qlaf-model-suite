# Odyssey Optimized GPU Engine — Unvalidated

Full CUDA-oriented reference engine for Odyssey / QLAF / AION / TSC. It includes PyTorch fallbacks, optional Triton dispatch points, decode cache, matched transformer baseline, smoke tests, and A100 benchmark scripts.

Status: written but not CUDA-validated in this environment.

Run:
```bash
pip install -r requirements.txt
python tests/smoke_test.py --device cuda --dtype bf16
bash scripts/run_a100.sh
```
