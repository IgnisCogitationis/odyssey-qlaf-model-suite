import argparse, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import torch
from odyssey_gpu_engine.config import preset
from odyssey_gpu_engine.model import OdysseyOptimizedGPUModel, count_parameters
from odyssey_gpu_engine.baseline import MatchedTransformerLM
from odyssey_gpu_engine.engine import OdysseyGPUInferenceEngine

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu'); ap.add_argument('--dtype',default='bf16',choices=['fp32','fp16','bf16']); ap.add_argument('--size',default='tiny'); args=ap.parse_args()
    dtype={'fp32':torch.float32,'fp16':torch.float16,'bf16':torch.bfloat16}[args.dtype]; dev=torch.device(args.device); cfg=preset(args.size,vocab_size=4096,max_seq_len=512)
    for name,cls in [('odyssey',OdysseyOptimizedGPUModel),('transformer',MatchedTransformerLM)]:
        m=cls(cfg).to(dev); x=torch.randint(0,cfg.vocab_size,(2,64),device=dev); y=torch.randint(0,cfg.vocab_size,(2,64),device=dev); opt=torch.optim.AdamW(m.parameters(),lr=1e-4)
        opt.zero_grad(set_to_none=True)
        with torch.autocast(device_type=dev.type,dtype=dtype,enabled=dev.type=='cuda'):
            logits,loss=m(x,y,decode=False)
        assert logits.shape==(2,64,cfg.vocab_size); assert torch.isfinite(loss); loss.backward(); opt.step()
        print(name,'PASS','params',count_parameters(m),'loss',float(loss.detach().cpu()))
    eng=OdysseyGPUInferenceEngine(OdysseyOptimizedGPUModel(cfg),device=dev,dtype=dtype); seed=torch.randint(0,cfg.vocab_size,(1,8),device=dev); eng.prefill(seed); nxt,_=eng.decode_step(seed[:,-1:]); print('engine PASS',nxt.shape)
if __name__=='__main__': main()
