# Engine Design Notes

This is an unvalidated optimized GPU engine reference. It implements QLAF as the dominant fast path, AION operator gating, adaptive TSC correction, local mixer residual compute, decode cache wrappers, and a future Triton dispatch point. The current math path uses the correct PyTorch fallback until a validated Triton/CUDA fused kernel is inserted.
