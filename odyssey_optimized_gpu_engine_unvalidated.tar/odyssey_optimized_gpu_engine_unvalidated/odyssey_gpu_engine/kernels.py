import torch
try:
    import triton, triton.language as tl
    HAS_TRITON=True
except Exception:
    triton=None; tl=None; HAS_TRITON=False

def qlaf_project_fallback(x,in_weight,gate_weight,state_scale,out_weight,n_states:int,decode_top1:bool):
    B,T,D=x.shape
    states=torch.nn.functional.linear(x,in_weight).view(B,T,n_states,D)
    states=torch.tanh(states)*state_scale.view(1,1,n_states,D)
    logits=torch.nn.functional.linear(x,gate_weight)
    if decode_top1:
        idx=logits.argmax(-1,keepdim=True); weights=torch.zeros_like(logits).scatter_(-1,idx,1.0)
    else:
        weights=torch.softmax(logits,dim=-1)
    combined=torch.einsum('bts,btsd->btd',weights,states)
    return torch.nn.functional.linear(combined,out_weight)

def qlaf_project_maybe_triton(x,in_weight,gate_weight,state_scale,out_weight,n_states:int,decode_top1:bool,use_triton:bool):
    # Correct fallback. Triton hook is intentionally reserved until GPU validation.
    return qlaf_project_fallback(x,in_weight,gate_weight,state_scale,out_weight,n_states,decode_top1)
