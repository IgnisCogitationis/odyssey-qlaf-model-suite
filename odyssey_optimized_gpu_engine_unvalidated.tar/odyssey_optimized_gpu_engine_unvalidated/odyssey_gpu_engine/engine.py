import torch
from .cache import DecodeCache, RuntimeStats
class OdysseyGPUInferenceEngine:
    def __init__(self,model,device=None,dtype=torch.bfloat16,compile_model=False):
        self.device=torch.device(device or ('cuda' if torch.cuda.is_available() else 'cpu')); self.dtype=dtype; self.model=model.to(self.device); self.cache=DecodeCache(max_seq_len=model.cfg.max_seq_len); self.stats=RuntimeStats()
        if compile_model:
            try: self.model=torch.compile(self.model)
            except Exception: pass
    def reset(self): self.cache.reset()
    @torch.no_grad()
    def prefill(self,tokens):
        self.stats.prefill_calls+=1; ctx=self.cache.append(tokens.to(self.device))
        with torch.autocast(device_type=self.device.type,dtype=self.dtype,enabled=self.device.type=='cuda'): return self.model(ctx,decode=False)[0]
    @torch.no_grad()
    def decode_step(self,new_token,temperature=1.0):
        self.stats.decode_calls+=1; self.stats.generated_tokens+=1; ctx=self.cache.append(new_token.to(self.device))
        with torch.autocast(device_type=self.device.type,dtype=self.dtype,enabled=self.device.type=='cuda'): logits,_=self.model(ctx,decode=True)
        probs=torch.softmax(logits[:,-1,:]/max(temperature,1e-6),-1); return torch.multinomial(probs,1),logits
    def train_step(self,opt,idx,targets):
        self.stats.train_calls+=1; self.model.train(); idx=idx.to(self.device); targets=targets.to(self.device); opt.zero_grad(set_to_none=True)
        with torch.autocast(device_type=self.device.type,dtype=self.dtype,enabled=self.device.type=='cuda'): _,loss=self.model(idx,targets,decode=False)
        loss.backward(); opt.step(); return loss.detach()
