from typing import Optional
import torch, torch.nn as nn, torch.nn.functional as F
from .model import RMSNorm,SwiGLU
class CausalSelfAttention(nn.Module):
    def __init__(self,cfg): super().__init__(); assert cfg.d_model%cfg.n_heads==0; self.cfg=cfg; self.qkv=nn.Linear(cfg.d_model,3*cfg.d_model,bias=False); self.proj=nn.Linear(cfg.d_model,cfg.d_model,bias=False)
    def forward(self,x): B,T,D=x.shape; H=self.cfg.n_heads; hd=D//H; qkv=self.qkv(x).view(B,T,3,H,hd).transpose(1,3); q,k,v=qkv[:,:,0],qkv[:,:,1],qkv[:,:,2]; y=F.scaled_dot_product_attention(q,k,v,is_causal=True,dropout_p=self.cfg.dropout if self.training else 0.0); return self.proj(y.transpose(1,2).contiguous().view(B,T,D))
class TransformerBlock(nn.Module):
    def __init__(self,cfg): super().__init__(); self.n1=RMSNorm(cfg.d_model,cfg.eps); self.attn=CausalSelfAttention(cfg); self.n2=RMSNorm(cfg.d_model,cfg.eps); self.ff=SwiGLU(cfg.d_model,cfg.d_ff); self.drop=nn.Dropout(cfg.dropout)
    def forward(self,x): x=x+self.drop(self.attn(self.n1(x))); return x+self.drop(self.ff(self.n2(x)))
class MatchedTransformerLM(nn.Module):
    def __init__(self,cfg): super().__init__(); self.cfg=cfg; self.tok=nn.Embedding(cfg.vocab_size,cfg.d_model); self.pos=nn.Embedding(cfg.max_seq_len,cfg.d_model); self.blocks=nn.ModuleList([TransformerBlock(cfg) for _ in range(cfg.n_layers)]); self.norm=RMSNorm(cfg.d_model,cfg.eps); self.lm_head=nn.Linear(cfg.d_model,cfg.vocab_size,bias=False); self.lm_head.weight=self.tok.weight
    def forward(self,idx,targets:Optional[torch.Tensor]=None,decode=False):
        B,T=idx.shape
        if T>self.cfg.max_seq_len: idx=idx[:,-self.cfg.max_seq_len:]; T=idx.size(1)
        x=self.tok(idx)+self.pos(torch.arange(T,device=idx.device).unsqueeze(0))
        for b in self.blocks: x=b(x)
        logits=self.lm_head(self.norm(x)); loss=None
        if targets is not None: targets=targets[:,-T:]; loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1))
        return logits,loss
