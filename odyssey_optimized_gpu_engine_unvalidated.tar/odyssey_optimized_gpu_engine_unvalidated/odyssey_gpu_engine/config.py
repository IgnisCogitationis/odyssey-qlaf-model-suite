from dataclasses import dataclass
@dataclass
class OdysseyGPUConfig:
    vocab_size:int=32000; d_model:int=512; n_layers:int=8; n_heads:int=8; d_ff:int=2048; max_seq_len:int=4096; dropout:float=0.0
    qlaf_ratio:float=0.70; local_ratio:float=0.20; tsc_ratio:float=0.10; fixed_ratio:float=0.85; aion_adaptive_ratio:float=0.15
    n_states:int=4; tsc_rank:int=4; decode_bias:bool=True; tsc_decode_mode:str='adaptive'; tsc_train_mode:str='lean'; tsc_threshold:float=0.62
    use_triton_if_available:bool=True; fused_qlaf_projection:bool=True; compile_model:bool=False; eps:float=1e-6

def preset(name:str='small', **overrides):
    p={'tiny':dict(d_model=128,n_layers=2,n_heads=4,d_ff=512,max_seq_len=2048),'small':dict(d_model=256,n_layers=4,n_heads=4,d_ff=1024,max_seq_len=4096),'base':dict(d_model=512,n_layers=8,n_heads=8,d_ff=2048,max_seq_len=4096),'large':dict(d_model=768,n_layers=12,n_heads=12,d_ff=3072,max_seq_len=8192),'a100_1bish':dict(d_model=1536,n_layers=20,n_heads=16,d_ff=6144,max_seq_len=8192)}
    kw=p.get(name,p['small']).copy(); kw.update(overrides); return OdysseyGPUConfig(**kw)
