from __future__ import annotations
from typing import Optional
import math, torch
import torch.nn as nn
import torch.nn.functional as F
from .config import OdysseyGPUConfig
from .kernels import qlaf_project_maybe_triton
class RMSNorm(nn.Module):
    def __init__(self,d,eps=1e-6): super().__init__(); self.weight=nn.Parameter(torch.ones(d)); self.eps=eps
    def forward(self,x): return x*torch.rsqrt(x.pow(2).mean(-1,keepdim=True)+self.eps)*self.weight
class SwiGLU(nn.Module):
    def __init__(self,d,ff): super().__init__(); self.w1=nn.Linear(d,ff,bias=False); self.w2=nn.Linear(d,ff,bias=False); self.w3=nn.Linear(ff,d,bias=False)
    def forward(self,x): return self.w3(F.silu(self.w1(x))*self.w2(x))
class LocalMixer(nn.Module):
    def __init__(self,d,k=5): super().__init__(); self.dw=nn.Conv1d(d,d,k,groups=d,padding=k-1,bias=False); self.pw=nn.Linear(d,d,bias=False); self.g=nn.Linear(d,d,bias=False)
    def forward(self,x): y=self.dw(x.transpose(1,2))[:,:,:x.size(1)].transpose(1,2); return self.pw(y)*torch.sigmoid(self.g(x))
class FusedQLAFPath(nn.Module):
    def __init__(self,cfg): super().__init__(); self.cfg=cfg; d=cfg.d_model; s=cfg.n_states; self.in_proj=nn.Linear(d,d*s,bias=False); self.gate=nn.Linear(d,s,bias=False); self.state_scale=nn.Parameter(torch.ones(s,d)/math.sqrt(d)); self.out_proj=nn.Linear(d,d,bias=False)
    def forward(self,x,decode=False): return qlaf_project_maybe_triton(x,self.in_proj.weight,self.gate.weight,self.state_scale,self.out_proj.weight,self.cfg.n_states,bool(decode and self.cfg.decode_bias),self.cfg.use_triton_if_available)
class AIONOperatorGate(nn.Module):
    def __init__(self,d): super().__init__(); self.op=nn.Linear(d,d,bias=False); self.gate=nn.Linear(d,3,bias=True)
    def forward(self,x): return torch.softmax(self.gate(torch.tanh(self.op(x))),dim=-1)
class TSCCorrection(nn.Module):
    def __init__(self,d,rank): super().__init__(); self.rank=rank; self.left=nn.Linear(d,rank*d,bias=False); self.right=nn.Linear(d,rank,bias=False); self.out=nn.Linear(d,d,bias=False)
    def forward(self,x): B,T,D=x.shape; l=self.left(x).view(B,T,self.rank,D); r=torch.softmax(self.right(x),-1).view(B,T,self.rank,1); return self.out(torch.tanh((l*r).sum(2)))
class OdysseyGPUBlock(nn.Module):
    def __init__(self,cfg): super().__init__(); self.cfg=cfg; d=cfg.d_model; self.n1=RMSNorm(d,cfg.eps); self.n2=RMSNorm(d,cfg.eps); self.qlaf=FusedQLAFPath(cfg); self.local=LocalMixer(d); self.tsc=TSCCorrection(d,max(cfg.tsc_rank,cfg.n_states)); self.aion=AIONOperatorGate(d); self.ff=SwiGLU(d,cfg.d_ff); self.drop=nn.Dropout(cfg.dropout)
    def _run_tsc(self,h,decode):
        c=self.cfg
        if decode:
            if c.tsc_decode_mode=='off': return False
            if c.tsc_decode_mode=='full': return True
            with torch.no_grad(): return bool(self.aion(h).max(-1).values.mean().item()<c.tsc_threshold)
        return c.tsc_train_mode!='off'
    def forward(self,x,decode=False):
        h=self.n1(x); q=self.qlaf(h,decode); l=self.local(h)
        if self._run_tsc(h,decode):
            t=self.tsc(h)
            if self.training and not decode:
                if self.cfg.tsc_train_mode=='detached': t=t.detach()
                elif self.cfg.tsc_train_mode=='lean': t=0.5*t
        else: t=torch.zeros_like(q)
        fixed=self.cfg.qlaf_ratio*q+self.cfg.local_ratio*l+self.cfg.tsc_ratio*t
        g=self.aion(h); adaptive=g[...,0:1]*q+g[...,1:2]*l+g[...,2:3]*t
        y=self.cfg.fixed_ratio*fixed+self.cfg.aion_adaptive_ratio*adaptive
        x=x+self.drop(y); x=x+self.drop(self.ff(self.n2(x))); return x
class OdysseyOptimizedGPUModel(nn.Module):
    def __init__(self,cfg:OdysseyGPUConfig): super().__init__(); self.cfg=cfg; self.tok=nn.Embedding(cfg.vocab_size,cfg.d_model); self.pos=nn.Embedding(cfg.max_seq_len,cfg.d_model); self.blocks=nn.ModuleList([OdysseyGPUBlock(cfg) for _ in range(cfg.n_layers)]); self.norm=RMSNorm(cfg.d_model,cfg.eps); self.lm_head=nn.Linear(cfg.d_model,cfg.vocab_size,bias=False); self.lm_head.weight=self.tok.weight
    def forward(self,idx,targets:Optional[torch.Tensor]=None,decode=False):
        B,T=idx.shape
        if T>self.cfg.max_seq_len: idx=idx[:,-self.cfg.max_seq_len:]; T=idx.size(1)
        x=self.tok(idx)+self.pos(torch.arange(T,device=idx.device).unsqueeze(0))
        for b in self.blocks: x=b(x,decode)
        logits=self.lm_head(self.norm(x)); loss=None
        if targets is not None: targets=targets[:,-T:]; loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1))
        return logits,loss
    @torch.no_grad()
    def generate(self,idx,max_new_tokens,temperature=1.0):
        self.eval()
        for _ in range(max_new_tokens):
            logits,_=self(idx[:,-self.cfg.max_seq_len:],decode=True); probs=torch.softmax(logits[:,-1,:]/max(temperature,1e-6),-1); idx=torch.cat([idx,torch.multinomial(probs,1)],1)
        return idx
def count_parameters(model): return sum(p.numel() for p in model.parameters())
