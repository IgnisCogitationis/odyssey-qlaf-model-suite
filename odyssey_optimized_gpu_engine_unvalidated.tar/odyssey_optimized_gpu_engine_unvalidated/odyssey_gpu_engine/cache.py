from dataclasses import dataclass
import torch
@dataclass
class DecodeCache:
    tokens: torch.Tensor|None=None; max_seq_len:int=4096
    def append(self,new_tokens):
        self.tokens=new_tokens if self.tokens is None else torch.cat([self.tokens,new_tokens],1)
        if self.tokens.size(1)>self.max_seq_len: self.tokens=self.tokens[:,-self.max_seq_len:]
        return self.tokens
    def reset(self): self.tokens=None
@dataclass
class RuntimeStats:
    prefill_calls:int=0; decode_calls:int=0; train_calls:int=0; generated_tokens:int=0
