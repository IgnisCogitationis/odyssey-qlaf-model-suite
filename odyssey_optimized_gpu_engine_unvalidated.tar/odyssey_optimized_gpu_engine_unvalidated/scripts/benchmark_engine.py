import argparse,csv,json,pathlib,platform,sys,time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import torch
from odyssey_gpu_engine.config import preset
from odyssey_gpu_engine.model import OdysseyOptimizedGPUModel, count_parameters
from odyssey_gpu_engine.baseline import MatchedTransformerLM

def sync(d):
    if d.type=='cuda': torch.cuda.synchronize()
def timeit(fn,d,warm,trials):
    for _ in range(warm): fn()
    sync(d); vals=[]
    for _ in range(trials):
        t=time.perf_counter(); fn(); sync(d); vals.append(time.perf_counter()-t)
    return sum(vals)/len(vals),min(vals),max(vals)
def bench(name,m,cfg,dev,dtype,b,s,mode,warm,trials):
    x=torch.randint(0,cfg.vocab_size,(b,s),device=dev); y=torch.randint(0,cfg.vocab_size,(b,s),device=dev); amp=dev.type=='cuda' and dtype!=torch.float32
    if mode=='train':
        m.train(); opt=torch.optim.AdamW(m.parameters(),lr=1e-4)
        def fn():
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=dev.type,dtype=dtype,enabled=amp): _,loss=m(x,y,decode=False)
            loss.backward(); opt.step()
    else:
        m.eval(); dec=(mode=='decode')
        def fn():
            with torch.no_grad(), torch.autocast(device_type=dev.type,dtype=dtype,enabled=amp): m(x,None,decode=dec)
    if dev.type=='cuda': torch.cuda.reset_peak_memory_stats()
    avg,mn,mx=timeit(fn,dev,warm,trials); peak=torch.cuda.max_memory_allocated()/1048576 if dev.type=='cuda' else 0
    return dict(model=name,mode=mode,batch=b,seq=s,avg_s=avg,min_s=mn,max_s=mx,tokens_per_s=b*s/avg,peak_mem_mb=peak,params=count_parameters(m))
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu'); ap.add_argument('--dtype',default='bf16',choices=['fp32','fp16','bf16']); ap.add_argument('--size',default='small'); ap.add_argument('--seqs',nargs='+',type=int,default=[128,256,512,1024]); ap.add_argument('--batch-sizes',nargs='+',type=int,default=[1,2]); ap.add_argument('--modes',nargs='+',default=['forward','decode','train']); ap.add_argument('--warmup',type=int,default=5); ap.add_argument('--trials',type=int,default=10); ap.add_argument('--compile',action='store_true'); ap.add_argument('--out',default='results/engine_benchmark_raw.csv'); args=ap.parse_args()
    dev=torch.device(args.device); dtype={'fp32':torch.float32,'fp16':torch.float16,'bf16':torch.bfloat16}[args.dtype]; cfg=preset(args.size,vocab_size=8192,max_seq_len=max(args.seqs)); out=pathlib.Path(args.out); out.parent.mkdir(parents=True,exist_ok=True); rows=[]
    for b in args.batch_sizes:
      for s in args.seqs:
       for mode in args.modes:
        for name,cls in [('transformer',MatchedTransformerLM),('odyssey_gpu_engine',OdysseyOptimizedGPUModel)]:
          m=cls(cfg).to(dev)
          if args.compile:
            try: m=torch.compile(m)
            except Exception as e: print('compile skipped',e)
          try:
            row=bench(name,m,cfg,dev,dtype,b,s,mode,args.warmup,args.trials); rows.append(row); print(row)
          except RuntimeError as e: print('SKIP',name,mode,b,s,e)
          del m
          if dev.type=='cuda': torch.cuda.empty_cache()
    if rows:
      with out.open('w',newline='') as f: w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
      by={}
      for r in rows: by.setdefault((r['mode'],r['batch'],r['seq']),{})[r['model']]=r
      pct=[]
      for k,d in by.items():
        if 'transformer' not in d: continue
        base=d['transformer']['avg_s']
        for model,r in d.items():
          ratio=base/r['avg_s']; pct.append(dict(mode=k[0],batch=k[1],seq=k[2],model=model,avg_s=r['avg_s'],transformer_avg_s=base,speed_ratio_vs_transformer=ratio,percent_speedup_vs_transformer=(ratio-1)*100,tokens_per_s=r['tokens_per_s'],peak_mem_mb=r['peak_mem_mb'],params=r['params']))
      pp=out.with_name('engine_percent_vs_transformer.csv')
      with pp.open('w',newline='') as f: w=csv.DictWriter(f,fieldnames=list(pct[0].keys())); w.writeheader(); w.writerows(pct)
      out.with_name('environment_report.json').write_text(json.dumps(dict(torch=torch.__version__,cuda=torch.cuda.is_available(),gpu=torch.cuda.get_device_name() if torch.cuda.is_available() and dev.type=='cuda' else None,platform=platform.platform(),config=cfg.__dict__),indent=2))
      print('WROTE',out,pp)
if __name__=='__main__': main()
