#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
python tests/smoke_test.py --device cuda --dtype bf16 --size small
python scripts/benchmark_engine.py --device cuda --dtype bf16 --size small --seqs 128 256 512 1024 2048 4096 --batch-sizes 1 2 4 --trials 20 --warmup 10 --out results/a100_engine_benchmark_raw.csv
