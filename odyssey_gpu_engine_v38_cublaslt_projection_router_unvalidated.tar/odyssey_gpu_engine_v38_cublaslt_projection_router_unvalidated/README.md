# Odyssey GPU Engine v38 — cuBLASLt Projection Router Pass

Status: **written and packaged; not compiled or GPU validated here.**

v38 continues from v37 and targets the exact remaining blockers:

1. real projection buffer path for packed projection;
2. route selection on projection output;
3. cuBLASLt plan for packed/summary/output projections;
4. B=1/2/4/8 benchmark matrix;
5. Nsight Compute tensor-core verification.

v38 still keeps the scalar fused CUDA kernel as the correctness fallback. The cuBLASLt helper is a build-target implementation scaffold that must be compiled and tested on an NVIDIA system.

## Build

```bash
cd plugins/tensorrt
./build_plugin.sh
```

## Run matrix

```bash
bash scripts/run_batch_matrix_v38.sh
bash scripts/profile_ncu_v38.sh
python scripts/analyze_ncu_v38.py --profiles profiles
```
