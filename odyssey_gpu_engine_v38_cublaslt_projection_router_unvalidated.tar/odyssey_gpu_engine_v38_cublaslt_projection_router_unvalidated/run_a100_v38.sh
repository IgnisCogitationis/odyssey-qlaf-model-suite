#!/usr/bin/env bash
set -euo pipefail
pip install -e .
mkdir -p results profiles
python -m odyssey_engine.validate --device cuda --dtype fp16 --size small
bash scripts/run_batch_matrix_v38.sh
bash scripts/profile_ncu_v38.sh || true
