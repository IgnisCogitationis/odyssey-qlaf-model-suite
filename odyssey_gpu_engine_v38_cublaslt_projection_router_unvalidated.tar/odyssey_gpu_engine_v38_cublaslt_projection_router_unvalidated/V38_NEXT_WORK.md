# V38 Next Work

1. Compile plugin and fix TensorRT API incompatibilities if any.
2. Unit test cuBLASLt projection output vs PyTorch linear.
3. Unit test route-on-projection output vs PyTorch route.
4. Run B=1/2/4/8 matrix.
5. Inspect Nsight Compute for HMMA/tensor-core use and memory bandwidth.
