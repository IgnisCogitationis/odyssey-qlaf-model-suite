from dataclasses import dataclass
import math, torch
import torch.nn as nn
import torch.nn.functional as F
@dataclass
class V38Config:
    vocab_size:int=2048; d_model:int=128; n_layers:int=2; d_ff:int=512; max_seq_len:int=256; n_states:int=4; summary_mix:float=.875
def preset_v38(size="tiny", **over):
    presets={"tiny":dict(d_model=128,n_layers=2,d_ff=512,max_seq_len=256),"small":dict(d_model=256,n_layers=4,d_ff=1024,max_seq_len=2048),"base":dict(d_model=512,n_layers=8,d_ff=2048,max_seq_len=4096)}
    kw=presets.get(size,presets["tiny"]).copy(); kw.update(over); return V38Config(**kw)
class RMSNorm(nn.Module):
    def __init__(self,d): super().__init__(); self.w=nn.Parameter(torch.ones(d))
    def forward(self,x): return x*torch.rsqrt(x.square().mean(-1,keepdim=True)+1e-6)*self.w
class Block(nn.Module):
    def __init__(self,cfg):
        super().__init__(); self.cfg=cfg; d=cfg.d_model; s=cfg.n_states
        self.n=RMSNorm(d); self.packed=nn.Linear(d,s*d+s+d,bias=False); self.out=nn.Linear(d,d,bias=False); self.summary=nn.Linear(d,d,bias=False); self.scale=nn.Parameter(torch.ones(s,d)/math.sqrt(d)); self.ff=nn.Sequential(RMSNorm(d),nn.Linear(d,cfg.d_ff),nn.GELU(),nn.Linear(cfg.d_ff,d))
    def forward(self,x,phase,prev=None):
        h=self.n(x); B,T,D=h.shape; S=self.cfg.n_states
        z=self.packed(h); raw=z[...,:S*D].view(B,T,S,D); logits=z[...,S*D:S*D+S]; route=logits.argmax(-1)
        sel=raw[torch.arange(B,device=x.device).view(B,1),torch.arange(T,device=x.device).view(1,T),route]
        sel=torch.tanh(sel)*self.scale[route]
        if phase=="decode_recurrent" and prev is not None: sel=self.cfg.summary_mix*self.summary(prev).unsqueeze(1)+(1-self.cfg.summary_mix)*sel
        return x+self.out(sel)+self.ff(x), sel[:,-1], route[:,-1], torch.softmax(logits[:,-1],-1).max(-1).values
class OdysseyGPUV38LM(nn.Module):
    def __init__(self,cfg):
        super().__init__(); self.cfg=cfg; self.tok=nn.Embedding(cfg.vocab_size,cfg.d_model); self.pos=nn.Embedding(cfg.max_seq_len,cfg.d_model); self.blocks=nn.ModuleList([Block(cfg) for _ in range(cfg.n_layers)]); self.n=RMSNorm(cfg.d_model); self.head=nn.Linear(cfg.d_model,cfg.vocab_size,bias=False); self.head.weight=self.tok.weight
    def forward(self,idx,targets=None,phase='train',cache=None):
        B,T=idx.shape; base=cache.token_count if cache is not None and phase=="decode_recurrent" else 0
        x=self.tok(idx)+self.pos(torch.clamp(base+torch.arange(T,device=idx.device),max=self.cfg.max_seq_len-1).unsqueeze(0))
        for i,b in enumerate(self.blocks):
            prev=cache.summaries[i] if cache is not None else None
            x,s,r,c=b(x,phase,prev)
            if cache is not None: cache.summaries[i].copy_(s.detach()); cache.route_ids[i].copy_(r.detach()); cache.confidence[i].copy_(c.detach())
        if cache is not None: cache.token_count += T if phase!="decode_recurrent" else 1
        logits=self.head(self.n(x)); loss=None
        if targets is not None: loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1))
        return logits,loss
class Cache:
    def __init__(self,L,B,D,device,dtype):
        self.summaries=torch.zeros(L,B,D,device=device,dtype=dtype); self.route_ids=torch.zeros(L,B,device=device,dtype=torch.long); self.confidence=torch.zeros(L,B,device=device,dtype=dtype); self.token_count=0
    def nbytes(self): return self.summaries.numel()*self.summaries.element_size()+self.route_ids.numel()*self.route_ids.element_size()+self.confidence.numel()*self.confidence.element_size()
class OdysseyEngineV38:
    def __init__(self,m): self.model=m; self.cfg=m.cfg
    def make_cache(self,B,device,dtype): return Cache(self.cfg.n_layers,B,self.cfg.d_model,device,dtype)
    @torch.no_grad()
    def prefill(self,idx,cache): self.model.eval(); return self.model(idx,phase='prefill',cache=cache)[0]
    @torch.no_grad()
    def decode_recurrent(self,tok,cache): self.model.eval(); return self.model(tok,phase='decode_recurrent',cache=cache)[0][:,-1]
def count_params(m): return sum(p.numel() for p in m.parameters())
