import argparse, torch
from .model import OdysseyGPUV38LM, OdysseyEngineV38, preset_v38, count_params
def main():
    p=argparse.ArgumentParser(); p.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu'); p.add_argument('--dtype',default='bf16',choices=['fp32','fp16','bf16']); p.add_argument('--size',default='tiny'); a=p.parse_args()
    device=torch.device(a.device); dtype={'fp32':torch.float32,'fp16':torch.float16,'bf16':torch.bfloat16}[a.dtype]; amp=device.type=='cuda' and dtype!=torch.float32
    cfg=preset_v38(a.size); m=OdysseyGPUV38LM(cfg).to(device)
    x=torch.randint(0,cfg.vocab_size,(2,32),device=device)
    with torch.autocast(device_type=device.type,dtype=dtype,enabled=amp): logits,loss=m(x,x)
    assert torch.isfinite(loss)
    eng=OdysseyEngineV38(m); cache=eng.make_cache(2,device,dtype)
    with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp): eng.prefill(x[:,:16],cache); out=eng.decode_recurrent(x[:,16:17],cache)
    print({'status':'PASS','params':count_params(m),'loss':float(loss.detach().cpu()),'out_shape':tuple(out.shape),'cache_nbytes':cache.nbytes()})
if __name__=='__main__': main()
