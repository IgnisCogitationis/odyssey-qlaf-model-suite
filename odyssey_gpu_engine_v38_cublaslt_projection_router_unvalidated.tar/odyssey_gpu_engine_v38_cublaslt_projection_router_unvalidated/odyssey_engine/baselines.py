import torch, torch.nn as nn, torch.nn.functional as F
class RMSNorm(nn.Module):
    def __init__(self,d): super().__init__(); self.w=nn.Parameter(torch.ones(d))
    def forward(self,x): return x*torch.rsqrt(x.square().mean(-1,keepdim=True)+1e-6)*self.w
class Attn(nn.Module):
    def __init__(self,d,h): super().__init__(); self.h=h; self.hd=d//h; self.qkv=nn.Linear(d,3*d,bias=False); self.o=nn.Linear(d,d,bias=False)
    def forward(self,x):
        B,T,D=x.shape; qkv=self.qkv(x).view(B,T,3,self.h,self.hd).transpose(1,3); q,k,v=qkv[:,:,0],qkv[:,:,1],qkv[:,:,2]
        y=F.scaled_dot_product_attention(q,k,v,is_causal=True)
        return self.o(y.transpose(1,2).contiguous().view(B,T,D))
class Block(nn.Module):
    def __init__(self,d,ff,h): super().__init__(); self.n1=RMSNorm(d); self.a=Attn(d,h); self.n2=RMSNorm(d); self.ff=nn.Sequential(nn.Linear(d,ff),nn.GELU(),nn.Linear(ff,d))
    def forward(self,x): return x+self.a(self.n1(x))+self.ff(self.n2(x))
class MatchedFlashTransformerLM(nn.Module):
    def __init__(self,vocab_size=2048,d_model=128,n_layers=2,n_heads=4,d_ff=512,max_seq_len=256):
        super().__init__(); self.tok=nn.Embedding(vocab_size,d_model); self.pos=nn.Embedding(max_seq_len,d_model); self.blocks=nn.ModuleList([Block(d_model,d_ff,n_heads) for _ in range(n_layers)]); self.n=RMSNorm(d_model); self.head=nn.Linear(d_model,vocab_size,bias=False); self.head.weight=self.tok.weight
    def forward(self,idx,targets=None):
        x=self.tok(idx)+self.pos(torch.arange(idx.shape[1],device=idx.device).unsqueeze(0))
        for b in self.blocks: x=b(x)
        logits=self.head(self.n(x)); loss=None
        if targets is not None: loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1))
        return logits,loss
