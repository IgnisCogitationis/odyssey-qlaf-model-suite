import argparse, pathlib, re
def main():
    p=argparse.ArgumentParser(); p.add_argument('--profiles',default='profiles'); a=p.parse_args()
    files=list(pathlib.Path(a.profiles).glob('*details*.txt'))
    out={'detail_files':[str(f) for f in files],'tensor_core_mentions':0,'cublaslt_mentions':0,'memory_mentions':0,'occupancy_mentions':0}
    for f in files:
        txt=f.read_text(errors='ignore')
        out['tensor_core_mentions'] += len(re.findall('tensor|mma|hmma', txt, re.I))
        out['cublaslt_mentions'] += len(re.findall('cublasLt|cublas', txt, re.I))
        out['memory_mentions'] += len(re.findall('memory|bandwidth', txt, re.I))
        out['occupancy_mentions'] += len(re.findall('occupancy', txt, re.I))
    print(out)
if __name__=='__main__': main()
