#!/usr/bin/env bash
set -euo pipefail
mkdir -p results
for B in 1 2 4 8; do
  python scripts/final_side_by_side_v38.py --device cuda --dtype bf16 --size small --batch "$B" --context 1024 --steps 128 --trials 10 --out "results/v38_batch_${B}.csv"
done
