import argparse,time,csv,torch
from pathlib import Path
from odyssey_engine.model import OdysseyGPUV38LM, OdysseyEngineV38, preset_v38
from odyssey_engine.baselines import MatchedFlashTransformerLM
def sync(device):
    if device.type=='cuda': torch.cuda.synchronize()
def main():
    p=argparse.ArgumentParser(); p.add_argument('--device',default='cuda' if torch.cuda.is_available() else 'cpu'); p.add_argument('--dtype',default='bf16',choices=['fp32','fp16','bf16']); p.add_argument('--size',default='small'); p.add_argument('--batch',type=int,default=4); p.add_argument('--context',type=int,default=512); p.add_argument('--steps',type=int,default=64); p.add_argument('--trials',type=int,default=5); p.add_argument('--out',default='results/v38_side_by_side.csv'); a=p.parse_args()
    device=torch.device(a.device); dtype={'fp32':torch.float32,'fp16':torch.float16,'bf16':torch.bfloat16}[a.dtype]; amp=device.type=='cuda' and dtype!=torch.float32
    cfg=preset_v38(a.size,vocab_size=2048,max_seq_len=a.context+a.steps+8)
    od=OdysseyGPUV38LM(cfg).to(device).eval(); eng=OdysseyEngineV38(od)
    tf=MatchedFlashTransformerLM(2048,cfg.d_model,cfg.n_layers,4,cfg.d_ff,cfg.max_seq_len).to(device).eval()
    rows=[]
    for tr in range(a.trials):
        x=torch.randint(0,cfg.vocab_size,(a.batch,a.context),device=device); token=torch.randint(0,cfg.vocab_size,(a.batch,1),device=device)
        cache=eng.make_cache(a.batch,device,dtype)
        with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp): eng.prefill(x,cache)
        sync(device); t0=time.perf_counter()
        for _ in range(a.steps):
            with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp): logits=eng.decode_recurrent(token,cache); token=logits.argmax(-1,keepdim=True)
        sync(device); od_s=time.perf_counter()-t0
        sync(device); t0=time.perf_counter()
        with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp): tf(x)
        sync(device); tf_s=time.perf_counter()-t0
        row={'trial':tr,'batch':a.batch,'odyssey_decode_s':od_s,'odyssey_tok_s':a.batch*a.steps/od_s,'flash_full_s':tf_s,'flash_tok_s':a.batch*a.context/tf_s}
        rows.append(row); print(row)
    Path(a.out).parent.mkdir(exist_ok=True,parents=True)
    with open(a.out,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print('WROTE',a.out)
if __name__=='__main__': main()
