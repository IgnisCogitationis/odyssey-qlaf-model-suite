#!/usr/bin/env bash
set -euo pipefail
mkdir -p profiles results
if ! command -v ncu >/dev/null 2>&1; then
  echo "ncu not found. Install NVIDIA Nsight Compute."
  exit 1
fi
ncu --set full --target-processes all --export profiles/v38_ncu_report \
  python -m odyssey_engine.validate --device cuda --dtype fp16 --size small
ncu --import profiles/v38_ncu_report.ncu-rep --page details > profiles/v38_ncu_details.txt || true
