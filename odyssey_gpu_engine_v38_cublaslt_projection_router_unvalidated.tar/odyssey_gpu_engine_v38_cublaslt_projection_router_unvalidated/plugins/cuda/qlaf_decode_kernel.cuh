#pragma once
#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdint.h>
#include "qlaf_cublaslt_helpers.cuh"

enum QLAFKernelMode {
    QLAF_KERNEL_SCALAR_FP16 = 0,
    QLAF_KERNEL_CUBLASLT_PROJECTIONS = 2
};

extern "C" cudaError_t launch_qlaf_decode_route_fp16(
    QLAFLtWorkspace* lt_ws,
    const half* x,
    const half* packed_w,
    const half* prev_summary,
    const half* summary_w,
    const half* out_w,
    const half* state_scale,
    half* projection_buffer,
    half* summary_buffer,
    half* out,
    half* next_summary,
    int64_t* route_id,
    half* confidence,
    int B, int D, int S,
    float summary_mix,
    int kernel_mode,
    cudaStream_t stream
);
