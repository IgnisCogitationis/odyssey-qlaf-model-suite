#include "qlaf_decode_kernel.cuh"
#include "qlaf_cublaslt_helpers.cuh"
#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdint.h>
#include <math.h>

__device__ __forceinline__ float h2f(half x) { return __half2float(x); }
__device__ __forceinline__ half f2h(float x) { return __float2half_rn(x); }

// Scalar correctness fallback.
__global__
void qlaf_scalar_decode_kernel(
    const half* __restrict__ x,
    const half* __restrict__ packed_w,
    const half* __restrict__ prev_summary,
    const half* __restrict__ summary_w,
    const half* __restrict__ out_w,
    const half* __restrict__ state_scale,
    half* __restrict__ out,
    half* __restrict__ next_summary,
    int64_t* __restrict__ route_id,
    half* __restrict__ confidence,
    int B, int D, int S,
    float summary_mix,
    int has_prev
) {
    extern __shared__ float sh[];
    float* selected = sh;
    float* route_logits = sh + D;
    int b = blockIdx.x;
    int tid = threadIdx.x;
    if (b >= B) return;

    for (int s = tid; s < S; s += blockDim.x) {
        int row = S * D + s;
        float acc = 0.0f;
        for (int k=0;k<D;++k) acc += h2f(x[b*D+k]) * h2f(packed_w[row*D+k]);
        route_logits[s] = acc;
    }
    __syncthreads();

    __shared__ int best_s;
    if (tid == 0) {
        int bi=0; float bv=route_logits[0];
        for (int s=1;s<S;++s) if (route_logits[s] > bv) { bv=route_logits[s]; bi=s; }
        float denom=0.0f;
        for (int s=0;s<S;++s) denom += expf(route_logits[s]-bv);
        best_s=bi; route_id[b]=(int64_t)bi; confidence[b]=f2h(1.0f/fmaxf(denom,1e-6f));
    }
    __syncthreads();

    for (int d=tid; d<D; d+=blockDim.x) {
        int row = best_s * D + d;
        float acc=0.0f;
        for (int k=0;k<D;++k) acc += h2f(x[b*D+k]) * h2f(packed_w[row*D+k]);
        selected[d] = tanhf(acc) * h2f(state_scale[best_s*D+d]);
    }
    __syncthreads();

    for (int d=tid; d<D; d+=blockDim.x) {
        float rec=0.0f;
        if (has_prev) for (int k=0;k<D;++k) rec += h2f(prev_summary[b*D+k]) * h2f(summary_w[d*D+k]);
        float ns = has_prev ? summary_mix*rec + (1.0f-summary_mix)*selected[d] : selected[d];
        next_summary[b*D+d] = f2h(ns);
    }
    __syncthreads();

    for (int d=tid; d<D; d+=blockDim.x) {
        float acc=0.0f;
        for (int k=0;k<D;++k) acc += h2f(next_summary[b*D+k]) * h2f(out_w[d*D+k]);
        out[b*D+d] = f2h(acc);
    }
}

// Route on packed projection output from cuBLASLt.
// projection_buffer: [B, S*D+S+D]
__global__
void qlaf_route_from_projection_kernel(
    const half* __restrict__ projection_buffer,
    const half* __restrict__ state_scale,
    half* __restrict__ selected_state,
    int64_t* __restrict__ route_id,
    half* __restrict__ confidence,
    int B, int D, int S
) {
    int b = blockIdx.x;
    int tid = threadIdx.x;
    if (b >= B) return;
    extern __shared__ float sh[];
    float* logits = sh;

    const half* z = projection_buffer + b * (S*D + S + D);
    for (int s=tid; s<S; s+=blockDim.x) logits[s] = h2f(z[S*D + s]);
    __syncthreads();

    __shared__ int best_s;
    if (tid == 0) {
        int bi=0; float bv=logits[0];
        for (int s=1;s<S;++s) if (logits[s] > bv) { bv=logits[s]; bi=s; }
        float denom=0.0f;
        for (int s=0;s<S;++s) denom += expf(logits[s]-bv);
        best_s=bi; route_id[b]=(int64_t)bi; confidence[b]=f2h(1.0f/fmaxf(denom,1e-6f));
    }
    __syncthreads();

    for (int d=tid; d<D; d+=blockDim.x) {
        float raw = h2f(z[best_s*D + d]);
        selected_state[b*D+d] = f2h(tanhf(raw) * h2f(state_scale[best_s*D+d]));
    }
}

// Blend projected summary_buffer [B,D] and selected_state [B,D].
__global__
void qlaf_summary_blend_kernel(
    const half* __restrict__ selected_state,
    const half* __restrict__ summary_buffer,
    half* __restrict__ next_summary,
    int B, int D,
    float summary_mix,
    int has_prev
) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    int total = B * D;
    if (idx >= total) return;
    float sel = h2f(selected_state[idx]);
    float val = has_prev ? summary_mix * h2f(summary_buffer[idx]) + (1.0f-summary_mix) * sel : sel;
    next_summary[idx] = f2h(val);
}

extern "C" cudaError_t launch_qlaf_decode_route_fp16(
    QLAFLtWorkspace* lt_ws,
    const half* x,
    const half* packed_w,
    const half* prev_summary,
    const half* summary_w,
    const half* out_w,
    const half* state_scale,
    half* projection_buffer,
    half* summary_buffer,
    half* out,
    half* next_summary,
    int64_t* route_id,
    half* confidence,
    int B, int D, int S,
    float summary_mix,
    int kernel_mode,
    cudaStream_t stream
) {
    if (D > 1024) return cudaErrorInvalidValue;
    int has_prev = prev_summary != nullptr ? 1 : 0;

    if (kernel_mode == QLAF_KERNEL_CUBLASLT_PROJECTIONS && lt_ws && projection_buffer && summary_buffer) {
        int packedN = S*D + S + D;

        cudaError_t e = qlaf_lt_matmul_fp16(lt_ws, x, packed_w, projection_buffer, B, D, packedN, stream);
        if (e != cudaSuccess) return e;

        half* selected_state = next_summary; // temporary until after blend
        qlaf_route_from_projection_kernel<<<B, 256, sizeof(float)*S, stream>>>(
            projection_buffer, state_scale, selected_state, route_id, confidence, B, D, S
        );
        e = cudaGetLastError(); if (e != cudaSuccess) return e;

        if (has_prev) {
            e = qlaf_lt_matmul_fp16(lt_ws, prev_summary, summary_w, summary_buffer, B, D, D, stream);
            if (e != cudaSuccess) return e;
        }

        int total = B * D;
        qlaf_summary_blend_kernel<<<(total+255)/256, 256, 0, stream>>>(
            selected_state, summary_buffer, next_summary, B, D, summary_mix, has_prev
        );
        e = cudaGetLastError(); if (e != cudaSuccess) return e;

        e = qlaf_lt_matmul_fp16(lt_ws, next_summary, out_w, out, B, D, D, stream);
        return e;
    }

    int threads=256;
    size_t shmem=sizeof(float)*(D+S);
    qlaf_scalar_decode_kernel<<<B, threads, shmem, stream>>>(
        x, packed_w, prev_summary, summary_w, out_w, state_scale,
        out, next_summary, route_id, confidence, B, D, S, summary_mix, has_prev
    );
    return cudaGetLastError();
}
