#include "qlaf_cublaslt_helpers.cuh"
#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <cublasLt.h>
#include <cublas_v2.h>

// cuBLASLt row-major A[B,K] * Bmat[N,K]^T -> C[B,N].
// This is a real helper skeleton intended to compile on CUDA/cuBLASLt systems.
// It uses FP32 accumulation with FP16 input/output where supported.

cudaError_t qlaf_lt_matmul_fp16(
    QLAFLtWorkspace* ws,
    const half* A,
    const half* Bmat,
    half* C,
    int batch,
    int K,
    int N,
    cudaStream_t stream
) {
    if (!ws || !ws->lt) return cudaErrorInvalidValue;

    cublasLtMatmulDesc_t opDesc = nullptr;
    cublasLtMatrixLayout_t aDesc = nullptr, bDesc = nullptr, cDesc = nullptr;
    cublasLtMatmulPreference_t pref = nullptr;

    cublasOperation_t transA = CUBLAS_OP_N;
    cublasOperation_t transB = CUBLAS_OP_T;
    cublasComputeType_t computeType = CUBLAS_COMPUTE_32F;
    cudaDataType_t scaleType = CUDA_R_32F;

    if (cublasLtMatmulDescCreate(&opDesc, computeType, scaleType) != CUBLAS_STATUS_SUCCESS) return cudaErrorUnknown;
    cublasLtMatmulDescSetAttribute(opDesc, CUBLASLT_MATMUL_DESC_TRANSA, &transA, sizeof(transA));
    cublasLtMatmulDescSetAttribute(opDesc, CUBLASLT_MATMUL_DESC_TRANSB, &transB, sizeof(transB));

    // Row-major layouts: leading dimension is columns.
    cublasLtMatrixLayoutCreate(&aDesc, CUDA_R_16F, batch, K, K);
    cublasLtMatrixLayoutCreate(&bDesc, CUDA_R_16F, N, K, K);
    cublasLtMatrixLayoutCreate(&cDesc, CUDA_R_16F, batch, N, N);

    cublasLtOrder_t order = CUBLASLT_ORDER_ROW;
    cublasLtMatrixLayoutSetAttribute(aDesc, CUBLASLT_MATRIX_LAYOUT_ORDER, &order, sizeof(order));
    cublasLtMatrixLayoutSetAttribute(bDesc, CUBLASLT_MATRIX_LAYOUT_ORDER, &order, sizeof(order));
    cublasLtMatrixLayoutSetAttribute(cDesc, CUBLASLT_MATRIX_LAYOUT_ORDER, &order, sizeof(order));

    cublasLtMatmulPreferenceCreate(&pref);
    cublasLtMatmulPreferenceSetAttribute(pref, CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES, &ws->workspace_bytes, sizeof(ws->workspace_bytes));

    cublasLtMatmulHeuristicResult_t heuristic;
    int returned = 0;
    cublasStatus_t hs = cublasLtMatmulAlgoGetHeuristic(ws->lt, opDesc, aDesc, bDesc, cDesc, cDesc, pref, 1, &heuristic, &returned);
    if (hs != CUBLAS_STATUS_SUCCESS || returned == 0) {
        cublasLtMatmulPreferenceDestroy(pref);
        cublasLtMatrixLayoutDestroy(cDesc); cublasLtMatrixLayoutDestroy(bDesc); cublasLtMatrixLayoutDestroy(aDesc);
        cublasLtMatmulDescDestroy(opDesc);
        return cudaErrorUnknown;
    }

    const float alpha = 1.0f;
    const float beta = 0.0f;
    cublasStatus_t st = cublasLtMatmul(
        ws->lt, opDesc, &alpha,
        A, aDesc,
        Bmat, bDesc,
        &beta,
        C, cDesc,
        C, cDesc,
        &heuristic.algo,
        ws->workspace, ws->workspace_bytes,
        stream
    );

    cublasLtMatmulPreferenceDestroy(pref);
    cublasLtMatrixLayoutDestroy(cDesc); cublasLtMatrixLayoutDestroy(bDesc); cublasLtMatrixLayoutDestroy(aDesc);
    cublasLtMatmulDescDestroy(opDesc);
    return st == CUBLAS_STATUS_SUCCESS ? cudaSuccess : cudaErrorUnknown;
}
