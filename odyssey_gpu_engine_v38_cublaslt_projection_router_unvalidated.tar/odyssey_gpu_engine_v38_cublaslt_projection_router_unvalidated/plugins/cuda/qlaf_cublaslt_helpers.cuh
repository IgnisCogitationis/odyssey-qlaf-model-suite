#pragma once
#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <cublasLt.h>

struct QLAFLtWorkspace {
    void* workspace;
    size_t workspace_bytes;
    cublasLtHandle_t lt;
};

cudaError_t qlaf_lt_matmul_fp16(
    QLAFLtWorkspace* ws,
    const half* A,      // [B,K] row-major
    const half* Bmat,   // [N,K] row-major, used as B^T logically
    half* C,            // [B,N] row-major
    int batch,
    int K,
    int N,
    cudaStream_t stream
);
