#!/usr/bin/env bash
set -euo pipefail
: "${TENSORRT_INCLUDE_DIR:?Set TENSORRT_INCLUDE_DIR}"
: "${TENSORRT_LIB_DIR:?Set TENSORRT_LIB_DIR}"
mkdir -p build
cd build
cmake .. -DTENSORRT_INCLUDE_DIR="$TENSORRT_INCLUDE_DIR" -DTENSORRT_LIB_DIR="$TENSORRT_LIB_DIR"
cmake --build . -j
