#include <NvInfer.h>
#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <cublasLt.h>
#include <string>
#include <cstring>
#include <stdint.h>
#include "../cuda/qlaf_decode_kernel.cuh"

using namespace nvinfer1;

class QLAFDecodePlugin final : public IPluginV2DynamicExt {
public:
    QLAFDecodePlugin(int dModel, int nStates, float summaryMix, int kernelMode)
        : dModel_(dModel), nStates_(nStates), summaryMix_(summaryMix), kernelMode_(kernelMode) {}

    const char* getPluginType() const noexcept override { return "QLAFDecodePlugin"; }
    const char* getPluginVersion() const noexcept override { return "0.38"; }
    int getNbOutputs() const noexcept override { return 4; }

    DimsExprs getOutputDimensions(int outputIndex, const DimsExprs* inputs, int nbInputs, IExprBuilder& exprBuilder) noexcept override {
        DimsExprs out;
        if (outputIndex == 0 || outputIndex == 1) out = inputs[0];
        else { out.nbDims = 1; out.d[0] = inputs[0].d[0]; }
        return out;
    }

    bool supportsFormatCombination(int pos, const PluginTensorDesc* inOut, int nbInputs, int nbOutputs) noexcept override {
        if (pos == nbInputs + 2) return inOut[pos].type == DataType::kINT64 && inOut[pos].format == TensorFormat::kLINEAR;
        return inOut[pos].format == TensorFormat::kLINEAR &&
               (inOut[pos].type == DataType::kHALF || inOut[pos].type == DataType::kFLOAT || inOut[pos].type == DataType::kBF16);
    }

    int enqueue(const PluginTensorDesc* inputDesc, const PluginTensorDesc* outputDesc,
                const void* const* inputs, void* const* outputs,
                void* workspace, cudaStream_t stream) noexcept override {
        // v38 plugin signature expects extra workspace buffers:
        // inputs:
        // 0 x [B,D]
        // 1 packed_w [S*D+S+D,D]
        // 2 prev_summary [B,D]
        // 3 summary_w [D,D]
        // 4 out_w [D,D]
        // 5 state_scale [S,D]
        // 6 projection_buffer [B,S*D+S+D]
        // 7 summary_buffer [B,D]
        int B = inputDesc[0].dims.d[0];
        int D = inputDesc[0].dims.d[1];
        if (D != dModel_) return 1;
        if (inputDesc[0].type != DataType::kHALF) return 2;

        QLAFLtWorkspace ltws;
        ltws.workspace = workspace;
        ltws.workspace_bytes = getWorkspaceSize(inputDesc, 8, outputDesc, 4);
        cublasLtCreate(&ltws.lt);

        auto err = launch_qlaf_decode_route_fp16(
            &ltws,
            static_cast<const half*>(inputs[0]),
            static_cast<const half*>(inputs[1]),
            static_cast<const half*>(inputs[2]),
            static_cast<const half*>(inputs[3]),
            static_cast<const half*>(inputs[4]),
            static_cast<const half*>(inputs[5]),
            static_cast<half*>(const_cast<void*>(inputs[6])),
            static_cast<half*>(const_cast<void*>(inputs[7])),
            static_cast<half*>(outputs[0]),
            static_cast<half*>(outputs[1]),
            static_cast<int64_t*>(outputs[2]),
            static_cast<half*>(outputs[3]),
            B, D, nStates_, summaryMix_, kernelMode_, stream
        );
        cublasLtDestroy(ltws.lt);
        return err == cudaSuccess ? 0 : 3;
    }

    size_t getWorkspaceSize(const PluginTensorDesc*, int, const PluginTensorDesc*, int) const noexcept override {
        return 4 * 1024 * 1024;
    }
    IPluginV2DynamicExt* clone() const noexcept override { return new QLAFDecodePlugin(dModel_, nStates_, summaryMix_, kernelMode_); }
    void destroy() noexcept override { delete this; }
    int initialize() noexcept override { return 0; }
    void terminate() noexcept override {}
    size_t getSerializationSize() const noexcept override { return 0; }
    void serialize(void*) const noexcept override {}
    void setPluginNamespace(const char* pluginNamespace) noexcept override { namespace_ = pluginNamespace ? pluginNamespace : ""; }
    const char* getPluginNamespace() const noexcept override { return namespace_.c_str(); }
    DataType getOutputDataType(int outputIndex, const DataType* inputTypes, int nbInputs) const noexcept override {
        if (outputIndex == 2) return DataType::kINT64;
        return inputTypes[0];
    }
    void configurePlugin(const DynamicPluginTensorDesc*, int, const DynamicPluginTensorDesc*, int) noexcept override {}

private:
    int dModel_, nStates_, kernelMode_;
    float summaryMix_;
    std::string namespace_;
};
