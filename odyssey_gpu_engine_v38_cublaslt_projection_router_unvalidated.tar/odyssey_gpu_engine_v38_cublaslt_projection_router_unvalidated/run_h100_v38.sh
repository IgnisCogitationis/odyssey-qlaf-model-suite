#!/usr/bin/env bash
set -euo pipefail
pip install -e .
mkdir -p results profiles
python -m odyssey_engine.validate --device cuda --dtype fp16 --size base
for B in 1 2 4 8; do
  python scripts/final_side_by_side_v38.py --device cuda --dtype bf16 --size base --batch "$B" --context 4096 --steps 256 --trials 10 --out "results/v38_h100_batch_${B}.csv"
done
bash scripts/profile_ncu_v38.sh || true
