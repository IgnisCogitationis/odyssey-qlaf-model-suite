import torch
from odyssey_engine import OdysseyGPUV38LM, OdysseyEngineV38, preset_v38
def test_cpu():
    cfg=preset_v38('tiny',vocab_size=128)
    m=OdysseyGPUV38LM(cfg)
    x=torch.randint(0,cfg.vocab_size,(1,16))
    logits,loss=m(x,x)
    assert logits.shape==(1,16,cfg.vocab_size)
    eng=OdysseyEngineV38(m); cache=eng.make_cache(1,torch.device('cpu'),torch.float32)
    eng.prefill(x[:,:8],cache); out=eng.decode_recurrent(x[:,8:9],cache)
    assert out.shape==(1,cfg.vocab_size)
