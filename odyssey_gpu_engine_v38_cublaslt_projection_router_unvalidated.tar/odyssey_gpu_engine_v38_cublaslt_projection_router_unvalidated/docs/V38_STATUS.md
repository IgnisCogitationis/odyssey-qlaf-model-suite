# V38 Status

v38 adds:
- cuBLASLt helper implementation scaffold for row-major FP16 projections;
- route-on-projection-output CUDA kernel;
- summary blend CUDA kernel;
- cuBLASLt projection mode in launcher;
- TensorRT plugin wiring for projection and summary buffers;
- B=1/2/4/8 benchmark script;
- Nsight Compute tensor-core/cublasLt analysis.

Still not final:
- plugin input contract now needs external projection/summary buffers;
- cuBLASLt helper must compile and be validated;
- final A100/H100 benchmark CSVs and Nsight reports are still required.
