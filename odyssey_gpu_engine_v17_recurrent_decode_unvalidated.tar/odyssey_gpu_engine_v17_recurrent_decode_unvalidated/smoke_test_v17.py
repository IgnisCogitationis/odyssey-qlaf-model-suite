import argparse, torch
from odyssey_gpu_v17 import OdysseyGPUV17LM, MatchedTransformerV17LM, OdysseyV17Engine, preset_v17, count_params

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--device",default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--dtype",default="bf16",choices=["fp32","fp16","bf16"])
    ap.add_argument("--size",default="tiny")
    args=ap.parse_args()
    device=torch.device(args.device); dtype={"fp32":torch.float32,"fp16":torch.float16,"bf16":torch.bfloat16}[args.dtype]
    amp=device.type=="cuda" and dtype!=torch.float32
    cfg=preset_v17(args.size,vocab_size=2048,max_seq_len=256)
    for name,cls in [("odyssey_v17",OdysseyGPUV17LM),("transformer",MatchedTransformerV17LM)]:
        m=cls(cfg).to(device)
        x=torch.randint(0,cfg.vocab_size,(2,64),device=device); y=torch.randint(0,cfg.vocab_size,(2,64),device=device)
        opt=torch.optim.AdamW(m.parameters(),lr=1e-4)
        with torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
            _,loss=m(x,y,phase="train",mode="balanced")
        assert torch.isfinite(loss); loss.backward(); opt.step()
        if name=="odyssey_v17":
            eng=OdysseyV17Engine(m); cache=eng.make_cache(2,device,dtype)
            with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
                eng.prefill(x[:,:32],cache,mode="balanced")
                ref=eng.decode_one_reference(x[:,:32],cache,mode="speed")
                rec=eng.decode_one_recurrent(x[:,32:33],cache,mode="speed")
                chk=eng.decode_chunk(x[:,32:48],cache,mode="speed")
            assert ref.shape==rec.shape==(2,cfg.vocab_size)
            print("cache token_count:",cache.token_count)
        print(f"{name}: PASS params={count_params(m):,} loss={float(loss.detach().cpu()):.4f}")
    if device.type=="cuda":
        print("GPU:",torch.cuda.get_device_name(),"peak_mem_mb:",torch.cuda.max_memory_allocated()/1024/1024)
if __name__=="__main__": main()
