# v17 Next Work

1. Replace recurrent summary update with Triton fused kernel.
2. Add learned recurrent summary distillation loss.
3. Add cache quantization for summaries.
4. Add route-id and confidence histogram telemetry.
5. Add accuracy/quality eval harness.
6. Add real FlashAttention-2 baseline check.
7. Add CUDA graphs for fixed-shape decode.
