# v17 Validation Notes

## What must be tested on GPU

1. Does `decode_one_recurrent` avoid sequence-length scaling?
   - It should process `[B,1,D]` plus cache summaries.
   - Runtime should grow much slower than full-context reference decode.

2. Does recurrent decode drift?
   - Compare logits from reference decode and recurrent decode.
   - Expect differences because recurrent summary is approximate.
   - Distill recurrent decode from reference/balanced path if quality drop is large.

3. Does cache stay valid?
   - Check batch size.
   - Check dtype/device.
   - Check layer count.
   - Reset cache between independent sequences.

4. Does transformer baseline use FlashAttention?
   - PyTorch `scaled_dot_product_attention` may dispatch optimized kernels when available.
   - For publication claims, explicitly verify backend.

## Expected outcome

- `decode_one_recurrent` should be fastest.
- `decode_one_reference` should be slower and scale with context length.
- Prefill should still need packed QLAF/Triton fusion for maximum gain.
- Train remains limited by backward pass and TSC budget.
