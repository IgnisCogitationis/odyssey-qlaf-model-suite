# Odyssey GPU Engine v17 — Recurrent Decode Interface Pass

Status: **written and packaged, not CUDA/Triton validated in this environment**.

v17 continues from v16 and focuses on the next production-critical gap:

> Decode must stop behaving like full-context recompute. The model needs a compact recurrent QLAF summary update path with cache validation and measurable separation between reference decode and recurrent decode.

This package adds:

- `OdysseyGPUV17LM`
- `OdysseyV17Engine`
- `OdysseyV17StateCache`
- per-layer compact recurrent QLAF summaries
- `decode_one_recurrent()` API
- `decode_one_reference()` API
- cache validation and reset tools
- serving modes: `quality`, `balanced`, `speed`, `survival`
- benchmark rows for:
  - prefill
  - decode_one_reference
  - decode_one_recurrent
  - decode_chunk
  - train
- matched transformer baseline
- A100/H100 scripts
- GPU validation checklist
- SHA256 manifest

Important: v17 implements a **reference recurrent summary path** in PyTorch. It is still not a final fused CUDA/Triton decode kernel.
