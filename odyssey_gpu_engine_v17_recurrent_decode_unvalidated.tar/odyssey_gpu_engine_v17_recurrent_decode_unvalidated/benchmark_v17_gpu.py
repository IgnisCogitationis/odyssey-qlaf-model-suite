import argparse,csv,json,platform,time
from pathlib import Path
import torch
from odyssey_gpu_v17 import OdysseyGPUV17LM, MatchedTransformerV17LM, OdysseyV17Engine, preset_v17, count_params, maybe_compile

def sync(d):
    if d.type=="cuda": torch.cuda.synchronize()
def timeit(fn,d,warm,trials):
    for _ in range(warm): fn()
    sync(d); vals=[]
    for _ in range(trials):
        t=time.perf_counter(); fn(); sync(d); vals.append(time.perf_counter()-t)
    return sum(vals)/len(vals),min(vals),max(vals)

def run(name,m,cfg,mode,serv,batch,seq,device,dtype,warm,trials):
    amp=device.type=="cuda" and dtype!=torch.float32
    x=torch.randint(0,cfg.vocab_size,(batch,seq),device=device); y=torch.randint(0,cfg.vocab_size,(batch,seq),device=device)
    eng=OdysseyV17Engine(m) if name=="odyssey_v17" else None
    cache=eng.make_cache(batch,device,dtype) if eng else None
    if eng and mode in ("decode_one_recurrent","decode_one_reference"):
        with torch.no_grad():
            eng.prefill(x[:,:max(1,seq-1)],cache,mode="balanced")
    if mode=="train":
        opt=torch.optim.AdamW(m.parameters(),lr=1e-4)
        def fn():
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
                _,loss=m(x,y,phase="train",mode=serv)
            loss.backward(); opt.step()
    elif mode=="prefill":
        def fn():
            with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
                eng.prefill(x,cache,mode=serv) if eng else m(x,None,phase="prefill",mode=serv)
    elif mode=="decode_one_reference":
        def fn():
            with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
                eng.decode_one_reference(x,cache,mode=serv) if eng else m(x,None,phase="decode_reference",mode=serv)
    elif mode=="decode_one_recurrent":
        tok=x[:,-1:]
        def fn():
            with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
                eng.decode_one_recurrent(tok,cache,mode=serv) if eng else m(tok,None,phase="decode_recurrent",mode=serv)
    else:
        chunk=x[:,-min(seq,32):]
        def fn():
            with torch.no_grad(), torch.autocast(device_type=device.type,dtype=dtype,enabled=amp):
                eng.decode_chunk(chunk,cache,mode=serv) if eng else m(chunk,None,phase="decode_chunk",mode=serv)
    if device.type=="cuda": torch.cuda.reset_peak_memory_stats()
    avg,mn,mx=timeit(fn,device,warm,trials)
    mem=torch.cuda.max_memory_allocated()/1024/1024 if device.type=="cuda" else 0.0
    toks=batch*(1 if "decode_one" in mode else (min(seq,32) if mode=="decode_chunk" else seq))
    return {"model":name,"mode":mode,"serving_mode":serv,"batch":batch,"seq":seq,"avg_s":avg,"min_s":mn,"max_s":mx,"tokens_per_s":toks/avg,"peak_mem_mb":mem,"params":count_params(m)}
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--device",default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--dtype",default="bf16",choices=["fp32","fp16","bf16"])
    ap.add_argument("--size",default="small",choices=["tiny","small","base","large"])
    ap.add_argument("--seqs",nargs="+",type=int,default=[128,256,512,1024])
    ap.add_argument("--batches",nargs="+",type=int,default=[1,2])
    ap.add_argument("--modes",nargs="+",default=["prefill","decode_one_reference","decode_one_recurrent","decode_chunk","train"])
    ap.add_argument("--serving-modes",nargs="+",default=["balanced","speed","survival"])
    ap.add_argument("--warmup",type=int,default=5); ap.add_argument("--trials",type=int,default=10)
    ap.add_argument("--compile",action="store_true"); ap.add_argument("--out",default="results/v17_gpu_raw.csv")
    args=ap.parse_args()
    device=torch.device(args.device); dtype={"fp32":torch.float32,"fp16":torch.float16,"bf16":torch.bfloat16}[args.dtype]
    cfg=preset_v17(args.size,vocab_size=8192,max_seq_len=max(args.seqs))
    Path(args.out).parent.mkdir(parents=True,exist_ok=True)
    env={"python":platform.python_version(),"torch":torch.__version__,"cuda":torch.cuda.is_available(),"gpu":torch.cuda.get_device_name() if torch.cuda.is_available() and device.type=="cuda" else None,"cfg":cfg.__dict__}
    Path(args.out).with_name("v17_environment.json").write_text(json.dumps(env,indent=2))
    rows=[]
    for b in args.batches:
      for s in args.seqs:
       for mode in args.modes:
        for serv in args.serving_modes:
         for name,cls in [("transformer",MatchedTransformerV17LM),("odyssey_v17",OdysseyGPUV17LM)]:
          m=maybe_compile(cls(cfg).to(device),args.compile)
          try:
            r=run(name,m,cfg,mode,serv,b,s,device,dtype,args.warmup,args.trials); rows.append(r); print(r)
          except RuntimeError as e: print("SKIP",name,mode,serv,b,s,repr(e))
          del m
          if device.type=="cuda": torch.cuda.empty_cache()
    with open(args.out,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    by={}
    for r in rows: by.setdefault((r["mode"],r["serving_mode"],r["batch"],r["seq"]),{})[r["model"]]=r
    pct=[]
    for k,d in by.items():
        if "transformer" not in d: continue
        base=d["transformer"]["avg_s"]
        for model,r in d.items():
            pct.append({"mode":k[0],"serving_mode":k[1],"batch":k[2],"seq":k[3],"model":model,"avg_s":r["avg_s"],"transformer_avg_s":base,"speed_ratio_vs_transformer":base/r["avg_s"],"percent_speedup_vs_transformer":(base/r["avg_s"]-1)*100,"tokens_per_s":r["tokens_per_s"],"peak_mem_mb":r["peak_mem_mb"]})
    p=Path(args.out).with_name("v17_percent_vs_transformer.csv")
    with open(p,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(pct[0].keys())); w.writeheader(); w.writerows(pct)
    print("WROTE",args.out); print("WROTE",p)
if __name__=="__main__": main()
